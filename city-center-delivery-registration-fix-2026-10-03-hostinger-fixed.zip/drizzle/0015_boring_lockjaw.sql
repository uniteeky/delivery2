CREATE TABLE `companyAddresses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`companyId` int NOT NULL,
	`label` varchar(180) NOT NULL,
	`address` text NOT NULL,
	`phone` varchar(40),
	`isDefault` boolean NOT NULL DEFAULT false,
	`active` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `companyAddresses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `company_addresses_company_default_idx` ON `companyAddresses` (`companyId`,`isDefault`,`active`);
--> statement-breakpoint
INSERT INTO `companyAddresses` (`companyId`,`label`,`address`,`phone`,`isDefault`)
SELECT c.`id`, 'العنوان الرئيسي', c.`address`, c.`phone`, true
FROM `companies` c
LEFT JOIN `companyAddresses` ca ON ca.`companyId` = c.`id`
WHERE c.`address` IS NOT NULL AND TRIM(c.`address`) <> '' AND ca.`id` IS NULL;
