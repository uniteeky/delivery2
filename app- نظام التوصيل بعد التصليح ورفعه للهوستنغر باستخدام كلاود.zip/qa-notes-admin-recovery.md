# AdminRecovery visual QA

The `/admin-recovery` page was rendered at 1280×720 and 390×844. The visible language switcher appears above the card, the Arabic RTL layout is aligned correctly, labels and placeholders are readable, and the mobile card remains within the viewport with vertical scrolling available for the lower controls. No overlap or horizontal clipping was observed in either capture.

## Local login visual QA

The `/local-login` page was rendered at 390×844 and 1280×720. The Civil ID and password fields, approval notice, secure-login action, and return link remain readable and vertically stacked in Arabic RTL. The phone view fits the card within the viewport while preserving comfortable spacing; the desktop view remains centered without clipping.
