# Security QA

## Dependency audit — 2026-08-19

The production dependency audit was run with `pnpm audit --prod --audit-level high`. Direct dependencies with available patches were upgraded: `axios` to 1.19.0, `nanoid` to 5.1.16, `@trpc/client`, `@trpc/react-query`, and `@trpc/server` to 11.18.0, `drizzle-orm` to 0.45.2, and the AWS S3 packages to 3.1114.0. TypeScript, all 64 Vitest tests, and the production build pass after the upgrades.

The remaining audit output reports transitive issues through Express 4's legacy `path-to-regexp`, Mermaid's `lodash-es`, and Recharts 2's `lodash`. These were not force-upgraded because the available fixes involve a framework or charting major-version change and require a separate compatibility review. No audit result was treated as a claim that the application is vulnerability-free.

The application-level authorization suite continues to cover manager boundaries, driver isolation, company media permissions, local Civil ID authentication, and order media access. Authenticated browser security evidence remains pending until a safe non-sensitive test account is available.
