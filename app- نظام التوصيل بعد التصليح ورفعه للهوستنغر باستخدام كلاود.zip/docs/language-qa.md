# Language and Direction QA

The application supports Arabic, English, Bengali, and Hindi through a persisted language context. The document records implementation status rather than claiming a completed authenticated language-switch session.

| Screen | Translation coverage verified in code | Direction behavior |
|---|---|---|
| Dashboard/Home | Navigation, KPI labels, latest-orders, quick actions, setup/search headings, operations-room labels | Arabic RTL; non-Arabic languages use the document direction from the language context |
| DriverHome | Trips, shift state/actions, order statistics, My Orders, and empty assigned-orders state | Dedicated mobile layout remains RTL in the current page shell; language context sets document direction |
| Companies | Administration, add company, company list, search, empty state, and company form headings | RTL shell preserved; global direction follows selected language |
| Finance | Finance heading, summary, delivered-orders, total-fees, and empty-state labels | RTL shell preserved; global direction follows selected language |
| Users | Administration, staff account, and registered accounts headings | RTL shell preserved; global direction follows selected language |
| NewOrder | Order source, delivery details, company/external order options, and core field labels | RTL shell preserved; global direction follows selected language |

The four dictionaries are checked for matching keys and non-empty values by `client/src/i18n.test.ts`. Static Arabic responsive captures were completed at mobile and desktop sizes for all six core routes. A live authenticated switch through all four languages, including LTR visual inspection of every protected route, still requires a safe non-sensitive test account and remains a release-validation item.

## 2026-08-19 — Companies and CompanyPortal follow-up

Companies now routes its form labels, loading and error feedback, save states, company statuses, portal status, and helper copy through the four-language dictionary. CompanyPortal routes its core feedback, empty states, address display, and media fallback labels through the same dictionary. A 390px Arabic capture confirms the Companies layout remains readable without horizontal overflow. Full authenticated language switching across all four languages remains a pending validation item.
