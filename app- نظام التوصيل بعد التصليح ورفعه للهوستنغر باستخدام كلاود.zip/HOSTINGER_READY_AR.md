# جاهزية النشر على Hostinger

هذه النسخة جاهزة كتطبيق **Node.js** باستخدام `server.js` كملف دخول و`npm start` كأمر تشغيل.

## الإعداد المعتمد

| الإعداد | القيمة |
|---|---|
| Node.js | 20 أو أحدث، ويفضّل 22 |
| Build command | `npm ci && npm run build` |
| Start command | `npm start` |
| Entry file | `server.js` |
| Output directory | `dist` عند طلبها |

## الخطوة الإلزامية لقاعدة البيانات

بعد ضبط `DATABASE_URL` في بيئة Hostinger، شغّل:

```bash
npm run db:migrate
npm run db:check-accounts
```

لا تستورد ملف `hostinger-ccdapp-empty-schema.sql` لأنه أرشيف تاريخي متوقف. للتفاصيل الكاملة وخطوات الاعتماد بعد النشر، راجع [دليل النشر](/HOSTINGER_DEPLOYMENT_AR.md).
