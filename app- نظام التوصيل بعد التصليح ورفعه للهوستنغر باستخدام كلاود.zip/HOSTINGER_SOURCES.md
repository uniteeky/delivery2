# مصادر Hostinger المستخدمة لإعداد النشر

- [Hostinger API Reference](https://docs.hostinger.com/api-reference/overview): التوثيق الرسمي لمصادقة API عبر Bearer token، ونقطة النهاية `https://developers.hostinger.com`، وخادم MCP الرسمي `https://mcp.hostinger.com`.
- [Deploy a Node.js website in Hostinger](https://www.hostinger.com/support/how-to-deploy-a-nodejs-website-in-hostinger/): التوثيق الرسمي لرفع ملف ZIP أو الربط بـGitHub، وتعيين دليل المخرجات وملف الدخول لتطبيقات Node.js.
