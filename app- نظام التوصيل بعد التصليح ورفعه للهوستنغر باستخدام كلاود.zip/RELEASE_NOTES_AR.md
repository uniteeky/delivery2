# ملاحظات إصدار إصلاح الحسابات وHostinger

**تاريخ التجهيز:** 2026-10-03

## الإصلاحات

- دعم كامل لإنشاء حسابات الشركة، التاجر، المشرف، السائق، والمحاسب.
- تطبيع الرقم المدني المكتوب بالأرقام العربية أو الإنجليزية في التسجيل والدخول.
- قبول البريد الإلكتروني أو اسم المستخدم الإنجليزي لتسجيل الشركة والتاجر، وتسجيل الدخول بهما بعد الاعتماد.
- إضافة اسم فعلي إلى نموذج تسجيل السائق والموظف بدلاً من الاسم الافتراضي.
- إكمال إدارة دور التاجر من واجهة المستخدمين والأدوار الإضافية.
- تحديث ترحيلات MySQL وفحص يضمن وجود `trader` في أعمدة الأدوار.
- منع التحويل الصامت من تاجر إلى شركة عند وجود قاعدة MySQL قديمة.
- ضبط خادم الإنتاج ليستمع إلى منفذ Hostinger المعين.
- مزامنة `package-lock.json` ليعمل `npm ci` في Hostinger.
- إزالة اعتماد XLSX غير المستخدم؛ فحص اعتمادات الإنتاج لا يحتوي ثغرات عالية أو حرجة.

## التحقق المنفذ

```bash
npm ci
npm run check
npm run test -- server/local-login.route.test.ts server/account-role-registration.contract.test.ts server/hostinger-runtime.contract.test.ts server/business-registration.test.ts server/registration.validation.test.ts server/production-build-safety.test.ts
npm run build
```

تم التحقق أيضاً من `/api/build-version` و`/register-business` من حزمة الإنتاج محلياً.

## قبل النشر

اتبع `HOSTINGER_DEPLOYMENT_AR.md` وأضف متغيرات البيئة من `.env.example` إلى Hostinger. ثم شغّل `npm run db:migrate` و`npm run db:check-accounts` قبل فتح التسجيل للمستخدمين.
