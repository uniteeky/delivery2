import {
  and,
  asc,
  desc,
  eq,
  gte,
  inArray,
  isNotNull,
  isNull,
  lte,
  ne,
  or,
  sql,
  like,
} from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  createCipheriv,
  createDecipheriv,
  createHash,
  randomBytes,
  scrypt as scryptCallback,
  timingSafeEqual,
} from "node:crypto";
import { promisify } from "node:util";
import {
  InsertUser,
  auditLogs,
  companies,
  companyAddresses,
  companyDriverAssignments,
  companyUsers,
  drivers,
  driverLocations,
  financialEntries,
  messageAttachments,
  messageThreads,
  threadMembers,
  messages,
  orderEvents,
  orderMedia,
  orderTransfers,
  orders,
  shifts,
  notifications,
  backupSchedules,
  backupSnapshots,
  platformSettings,
  governorates,
  deliveryAreas,
  companyAreaRates,
  companyGovernorateRates,
  driverCommissionRates,
  users,
  userPermissions,
  userRoles,
  trips,
} from "../drizzle/schema";
import { ENV } from "./_core/env";
import {
  buildShiftEndValues,
  buildShiftStartValues,
  canAddOrderToTrip,
  canGroupOrdersInAutomaticTrip,
  canStartDriverShift,
  canTransitionTrip,
  filterCompanyMediaForPortal,
} from "../shared/operations";
import {
  DEFAULT_PLATFORM_SETTINGS,
  getSubscriptionMode,
  getSubscriptionReminderDays,
} from "../shared/platform";
import {
  formatOrderNumber,
  type OrderNumberFormat,
} from "../shared/order-number";
import { KUWAIT_GOVERNORATES } from "../shared/kuwait-locations";
import {
  initialOrderShares,
  resolveDriverCommission,
  type DriverPayType,
} from "../shared/driver-compensation";
import { resolveCompanyDeliveryRate } from "../shared/company-delivery-rate";
import { buildLocationLabelMaps, locationLabelKey } from "./location-labels";
import {
  shouldCountCompanyShare,
  shouldCountDeliveryFee,
  shouldCountDriverCommission,
} from "../shared/order-accounting";
import { summarizeCashCollections } from "../shared/cash-collection";
import { adminRecoveryAuditAction } from "./admin-recovery";
import { ensurePlatformSettingsSchema } from "./platform-settings-schema";
import { ensureOperationalSchema } from "./operational-schema";

let _db: ReturnType<typeof drizzle> | null = null;
let orderContactColumnsReady = false;
let messageAttachmentsReady = false;
let companyAddressesReady = false;
let operationalSchemaReady = false;
const scrypt = promisify(scryptCallback);

function backupKey() {
  return createHash("sha256")
    .update(ENV.cookieSecret || "city-center-backup-key")
    .digest();
}
export function encryptBackupData(value: string) {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", backupKey(), iv);
  const encrypted = Buffer.concat([
    cipher.update(value, "utf8"),
    cipher.final(),
  ]);
  return `${iv.toString("base64url")}.${cipher.getAuthTag().toString("base64url")}.${encrypted.toString("base64url")}`;
}
export function decryptBackupData(value: string) {
  const [ivText, tagText, dataText] = value.split(".");
  if (!ivText || !tagText || !dataText)
    throw new Error("Invalid encrypted backup payload");
  const decipher = createDecipheriv(
    "aes-256-gcm",
    backupKey(),
    Buffer.from(ivText, "base64url")
  );
  decipher.setAuthTag(Buffer.from(tagText, "base64url"));
  return Buffer.concat([
    decipher.update(Buffer.from(dataText, "base64url")),
    decipher.final(),
  ]).toString("utf8");
}

export function normalizeCivilId(value: string) {
  return value
    .trim()
    .replace(/[٠-٩]/g, digit => String(digit.charCodeAt(0) - 0x660))
    .replace(/[۰-۹]/g, digit => String(digit.charCodeAt(0) - 0x6f0))
    .replace(/\s+/g, "");
}

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const derivedKey = (await scrypt(password, salt, 64)) as Buffer;
  return `${salt}:${derivedKey.toString("hex")}`;
}

export async function verifyPassword(password: string, encodedHash: string) {
  const [salt, expectedHex] = encodedHash.split(":");
  if (!salt || !expectedHex) return false;
  const expected = Buffer.from(expectedHex, "hex");
  const actual = (await scrypt(password, salt, expected.length)) as Buffer;
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  if (_db && !orderContactColumnsReady) {
    try {
      await _db.execute(
        "ALTER TABLE `orders` ADD COLUMN `pickupPhone` varchar(40)"
      );
      console.info("[Database] Added orders.pickupPhone column");
    } catch (error) {
      const rootCause =
        error && typeof error === "object" && "cause" in error
          ? (error as { cause?: unknown }).cause
          : undefined;
      const message = `${error instanceof Error ? error.message : String(error)} ${rootCause instanceof Error ? rootCause.message : String(rootCause ?? "")}`;
      if (!/duplicate column|already exists|ER_DUP_FIELDNAME/i.test(message))
        console.error("[Database] Could not add orders.pickupPhone:", message);
    }
    try {
      await _db.execute(
        "ALTER TABLE `orders` ADD COLUMN `pickupContactName` varchar(180)"
      );
      console.info("[Database] Added orders.pickupContactName column");
    } catch (error) {
      const rootCause =
        error && typeof error === "object" && "cause" in error
          ? (error as { cause?: unknown }).cause
          : undefined;
      const message = `${error instanceof Error ? error.message : String(error)} ${rootCause instanceof Error ? rootCause.message : String(rootCause ?? "")}`;
      if (!/duplicate column|already exists|ER_DUP_FIELDNAME/i.test(message))
        console.error(
          "[Database] Could not add orders.pickupContactName:",
          message
        );
    } finally {
      orderContactColumnsReady = true;
    }
  }
  if (_db && !messageAttachmentsReady) {
    try {
      await _db.execute(
        "CREATE TABLE IF NOT EXISTS `messageAttachments` (`id` bigint AUTO_INCREMENT NOT NULL, `messageId` bigint NOT NULL, `messageAttachmentType` enum('image','audio') NOT NULL, `fileKey` varchar(512) NOT NULL, `fileUrl` text NOT NULL, `fileName` varchar(180) NOT NULL, `mimeType` varchar(120) NOT NULL, `sizeBytes` int NOT NULL DEFAULT 0, `createdAt` timestamp NOT NULL DEFAULT (now()), CONSTRAINT `messageAttachments_id` PRIMARY KEY(`id`), INDEX `message_attachments_message_idx` (`messageId`,`createdAt`))"
      );
    } catch (error) {
      console.error(
        "[Database] Could not ensure message attachments table:",
        error instanceof Error ? error.message : String(error)
      );
    } finally {
      messageAttachmentsReady = true;
    }
  }
  if (_db && !companyAddressesReady) {
    try {
      await _db.execute(
        "CREATE TABLE IF NOT EXISTS `companyAddresses` (`id` int AUTO_INCREMENT NOT NULL, `companyId` int NOT NULL, `label` varchar(180) NOT NULL, `address` text NOT NULL, `phone` varchar(40), `isDefault` boolean NOT NULL DEFAULT false, `active` boolean NOT NULL DEFAULT true, `createdAt` timestamp NOT NULL DEFAULT (now()), `updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP, CONSTRAINT `companyAddresses_id` PRIMARY KEY(`id`), INDEX `company_addresses_company_default_idx` (`companyId`,`isDefault`,`active`))"
      );
      await _db.execute(
        "INSERT INTO `companyAddresses` (`companyId`,`label`,`address`,`phone`,`isDefault`) SELECT c.`id`, 'العنوان الرئيسي', c.`address`, c.`phone`, true FROM `companies` c LEFT JOIN `companyAddresses` ca ON ca.`companyId` = c.`id` WHERE c.`address` IS NOT NULL AND TRIM(c.`address`) <> '' AND ca.`id` IS NULL"
      );
    } catch (error) {
      console.error(
        "[Database] Could not ensure company addresses table:",
        error instanceof Error ? error.message : String(error)
      );
    } finally {
      companyAddressesReady = true;
    }
  }
  if (_db && !operationalSchemaReady) {
    await ensureOperationalSchema(_db);
    operationalSchemaReady = true;
  }
  return _db;
}

export async function getPlatformSettingsWithDb(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>
) {
  await ensurePlatformSettingsSchema(db);
  const existing = await db
    .select()
    .from(platformSettings)
    .where(eq(platformSettings.id, 1))
    .limit(1);
  if (existing[0]) return existing[0];
  await db
    .insert(platformSettings)
    .values({ id: 1, ...DEFAULT_PLATFORM_SETTINGS });
  const created = await db
    .select()
    .from(platformSettings)
    .where(eq(platformSettings.id, 1))
    .limit(1);
  if (!created[0]) throw new Error("تعذر تهيئة إعدادات المنصة");
  return created[0];
}

export async function getPlatformSettings() {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  try {
    return await getPlatformSettingsWithDb(db);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (
      !/platformSettings|doesn't exist|unknown table|ER_NO_SUCH_TABLE/i.test(
        message
      )
    )
      throw error;
    const now = new Date();
    return {
      id: 1,
      ...DEFAULT_PLATFORM_SETTINGS,
      logoUrl: DEFAULT_PLATFORM_SETTINGS.logoUrl,
      subscriptionStartsAt: null,
      subscriptionEndsAt: null,
      createdAt: now,
      updatedAt: now,
    };
  }
}

export type PlatformSettingsUpdate = Partial<{
  brandName: string;
  logoUrl: string | null;
  primaryColor: string;
  accentColor: string;
  subscriptionStartsAt: Date | null;
  subscriptionEndsAt: Date | null;
  allowDriverTransfer: boolean;
  allowSupervisorTransfer: boolean;
  allowManagerTransfer: boolean;
  orderNumberFormat: OrderNumberFormat;
  nextOrderNumber: number;
}>;

export async function updatePlatformSettings(
  input: PlatformSettingsUpdate,
  actorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const before = await getPlatformSettingsWithDb(db);
  await db
    .update(platformSettings)
    .set(input)
    .where(eq(platformSettings.id, 1));
  const after = await getPlatformSettingsWithDb(db);
  await db.insert(auditLogs).values({
    actorUserId,
    action: "platform.settings_updated",
    entityType: "platform_settings",
    entityId: "1",
    beforeJson: JSON.stringify(before),
    afterJson: JSON.stringify(after),
  });
  return after;
}

export async function getPlatformAccessState() {
  const settings = await getPlatformSettings();
  return {
    ...settings,
    mode: getSubscriptionMode({
      startsAt: settings.subscriptionStartsAt,
      endsAt: settings.subscriptionEndsAt,
    }),
    reminderDays: getSubscriptionReminderDays(settings.subscriptionEndsAt),
  };
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = [
    "name",
    "email",
    "phone",
    "loginMethod",
    "preferredLanguage",
  ] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? undefined;
      updateSet[field] = user[field] ?? undefined;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (user.status !== undefined) {
    values.status = user.status;
    updateSet.status = user.status;
  }
  if (user.mustChangePassword !== undefined) {
    values.mustChangePassword = user.mustChangePassword;
    updateSet.mustChangePassword = user.mustChangePassword;
  }
  values.lastSignedIn ??= new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db
    .insert(users)
    .values(values)
    .onDuplicateKeyUpdate({ set: updateSet });
}

export function publicDriverAccountDefaults() {
  return {
    role: "driver" as const,
    approvalStatus: "pending" as const,
    status: "inactive" as const,
    loginMethod: "local-civil-id" as const,
    mustChangePassword: false as const,
  };
}

type MysqlLikeError = { code?: unknown; errno?: unknown; sqlMessage?: unknown; message?: unknown; cause?: unknown };

/** Drizzle wraps the real MySQL error in `.cause`; the outer message only holds the SQL text. */
export function unwrapDatabaseError(error: unknown): { code: string; errno: number; message: string } {
  let current: unknown = error;
  let code = "";
  let errno = 0;
  let message = "";
  for (let depth = 0; depth < 5 && current && typeof current === "object"; depth += 1) {
    const item = current as MysqlLikeError;
    if (typeof item.code === "string" && item.code && !code) code = item.code;
    if (typeof item.errno === "number" && item.errno && !errno) errno = item.errno;
    const text = typeof item.sqlMessage === "string" ? item.sqlMessage : typeof item.message === "string" ? item.message : "";
    if (text && (!message || /^Failed query/i.test(message))) message = text;
    current = item.cause;
  }
  return { code, errno, message };
}

export function registrationDatabaseMessage(error: unknown): string | null {
  const { code, errno, message } = unwrapDatabaseError(error);
  const text = `${code} ${message}`;
  if (errno === 1265 || errno === 1366 || /WARN_DATA_TRUNCATED|TRUNCATED_WRONG_VALUE|Data truncated|Incorrect .* value/i.test(text))
    return "بنية المستخدمين في MySQL قديمة. طبّق ترحيلات قاعدة البيانات ثم أعد المحاولة.";
  if (errno === 1054 || /ER_BAD_FIELD_ERROR|Unknown column/i.test(text))
    return "قاعدة البيانات في الاستضافة تحتاج تحديثاً (عمود ناقص). شغّل npm run db:migrate ثم أعد المحاولة.";
  if (errno === 1146 || /ER_NO_SUCH_TABLE|doesn't exist/i.test(text))
    return "قاعدة البيانات في الاستضافة تحتاج تحديثاً (جدول ناقص). شغّل npm run db:migrate ثم أعد المحاولة.";
  if (errno === 1062 || /ER_DUP_ENTRY|Duplicate entry/i.test(text))
    return "البريد الإلكتروني أو اسم المستخدم أو رمز الشركة مسجل مسبقاً. جرّب قيمة مختلفة.";
  if (errno === 1048 || /ER_BAD_NULL_ERROR|cannot be null/i.test(text))
    return "بنية قاعدة البيانات في الاستضافة قديمة (عمود لا يقبل القيمة الفارغة). شغّل npm run db:migrate ثم أعد المحاولة.";
  if (errno === 1406 || /ER_DATA_TOO_LONG|Data too long/i.test(text))
    return "أحد الحقول أطول من المسموح. اختصر النص ثم حاول مرة أخرى.";
  return null;
}

export async function registerDriver(input: {
  civilId?: string;
  loginName?: string;
  password: string;
  name: string;
  phone: string;
  email?: string;
  preferredLanguage?: string;
  requestedRole?: "driver" | "supervisor" | "accountant" | "company" | "trader";
  businessName?: string;
  businessCode?: string;
  businessPhone?: string;
  businessAddress?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const requestedRole = input.requestedRole ?? "driver";
  const businessAccount =
    requestedRole === "company" || requestedRole === "trader";
  const businessName = input.businessName?.trim();
  if (businessAccount && !businessName)
    throw new Error("اسم الشركة أو التاجر مطلوب");
  const civilId = businessAccount
    ? null
    : input.civilId?.trim()
      ? normalizeCivilId(input.civilId)
      : null;
  const loginName =
    input.loginName?.trim().toLowerCase() ||
    input.email?.trim().toLowerCase() ||
    null;
  if (!civilId && !loginName)
    throw new Error("أدخل الرقم المدني أو البريد الإلكتروني/اسم المستخدم");
  const existing = civilId
    ? await db
        .select({ id: users.id })
        .from(users)
        .where(eq(users.civilId, civilId))
        .limit(1)
    : await db
        .select({ id: users.id })
        .from(users)
        .where(eq(users.email, loginName!))
        .limit(1);
  if (existing[0])
    throw new Error(
      civilId
        ? "هذا الرقم المدني مسجل مسبقاً"
        : "البريد الإلكتروني أو اسم المستخدم مسجل مسبقاً"
    );
  const passwordHash = await hashPassword(input.password);
  const userValues = {
    openId: null,
    civilId,
    passwordHash,
    name: input.name.trim(),
    phone: input.phone.trim(),
    email: loginName,
    preferredLanguage: input.preferredLanguage || "ar",
    role: requestedRole,
    requestedRole,
    approvalStatus: "pending",
    status: "inactive",
    loginMethod: civilId ? "local-civil-id" : "local-identifier",
    mustChangePassword: false,
  } as const;
  try {
    // One transaction: a failure halfway must not leave an orphan user that blocks the retry.
    const userId = await db.transaction(async tx => {
      const result = await tx.insert(users).values(userValues);
      const newUserId = Number(result[0].insertId);
      if (requestedRole === "company" || requestedRole === "trader") {
        const companyName = businessName!;
        const baseBusinessCode = (
          input.businessCode?.trim() ||
          `REG${(civilId || loginName || String(newUserId)).replace(/[^A-Za-z0-9]/g, "").slice(-8)}`
        ).toUpperCase();
        let businessCode = baseBusinessCode;
        for (let attempt = 2; attempt <= 20; attempt += 1) {
          const existingCode = await tx
            .select({ id: companies.id })
            .from(companies)
            .where(eq(companies.code, businessCode))
            .limit(1);
          if (!existingCode[0]) break;
          businessCode = `${baseBusinessCode.slice(0, 36)}-${attempt}`;
        }
        const companyResult = await tx.insert(companies).values({
          name: companyName,
          code: businessCode,
          phone: input.businessPhone?.trim() || null,
          address: input.businessAddress?.trim() || null,
          status: "inactive",
          portalEnabled: false,
        });
        await tx
          .insert(companyUsers)
          .values({ userId: newUserId, companyId: Number(companyResult[0].insertId) });
      }
      if (requestedRole === "driver")
        await tx.insert(drivers).values({ userId: newUserId, active: true });
      await tx.insert(auditLogs).values({
        actorUserId: newUserId,
        action: "account.registration_submitted",
        entityType: "user",
        entityId: String(newUserId),
        afterJson: JSON.stringify({
          civilId,
          loginName,
          role: requestedRole,
          requestedRole,
          approvalStatus: "pending",
        }),
      });
      return newUserId;
    });
    return { userId, requestedRole, approvalStatus: "pending" as const };
  } catch (error) {
    const friendly = registrationDatabaseMessage(error);
    // Log the real MySQL reason server-side only; never send SQL text or params (password hash) to the browser.
    console.error("[registerDriver] failed:", unwrapDatabaseError(error));
    throw new Error(friendly ?? "تعذر إرسال طلب التسجيل. حاول مرة أخرى أو تواصل مع الإدارة.");
  }
}

let managerBootstrapInFlight = false;

export function validateFirstManagerInput(input: {
  civilId: string;
  password: string;
  email: string;
}) {
  const civilId = normalizeCivilId(input.civilId);
  const email = input.email.trim().toLowerCase();
  if (!/^\d{12}$/.test(civilId))
    throw new Error("الرقم المدني يجب أن يتكون من 12 رقماً");
  if (input.password.length < 8)
    throw new Error("كلمة المرور يجب أن تكون 8 أحرف على الأقل");
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
    throw new Error("البريد الإلكتروني غير صالح");
  return { civilId, email };
}

export async function isFirstManagerBootstrapAvailable() {
  const db = await getDb();
  if (!db) return false;
  const existing = await db
    .select({ id: users.id })
    .from(users)
    .where(eq(users.role, "admin"))
    .limit(1);
  return !existing[0];
}

export async function bootstrapFirstManager(input: {
  civilId: string;
  password: string;
  email: string;
}) {
  if (managerBootstrapInFlight)
    throw new Error("تعذر إكمال الطلب الآن. أعد المحاولة بعد لحظة");
  const { civilId, email } = validateFirstManagerInput(input);

  managerBootstrapInFlight = true;
  try {
    const db = await getDb();
    if (!db) throw new Error("Database unavailable");
    const manager = await db
      .select({ id: users.id })
      .from(users)
      .where(eq(users.role, "admin"))
      .limit(1);
    if (manager[0])
      throw new Error(
        "تمت تهيئة حساب المدير بالفعل. سجّل الدخول بحساب المدير الحالي."
      );
    const civilConflict = await db
      .select({ id: users.id })
      .from(users)
      .where(eq(users.civilId, civilId))
      .limit(1);
    const emailConflict = await db
      .select({ id: users.id })
      .from(users)
      .where(eq(users.email, email))
      .limit(1);
    if (civilConflict[0] || emailConflict[0])
      throw new Error("الرقم المدني أو البريد الإلكتروني مستخدم في حساب آخر");
    const passwordHash = await hashPassword(input.password);
    const name = email.split("@")[0]?.slice(0, 160) || "مدير سيتي سنتر";
    const result = await db.insert(users).values({
      openId: null,
      civilId,
      passwordHash,
      name,
      email,
      role: "admin",
      approvalStatus: "approved",
      status: "active",
      loginMethod: "local-civil-id",
      mustChangePassword: false,
      preferredLanguage: "ar",
    });
    const userId = Number(result[0].insertId);
    await db.insert(auditLogs).values({
      actorUserId: userId,
      action: "account.first_manager_bootstrapped",
      entityType: "user",
      entityId: String(userId),
      afterJson: JSON.stringify({
        civilId,
        email,
        role: "admin",
        approvalStatus: "approved",
        status: "active",
      }),
    });
    return {
      id: userId,
      name,
      role: "admin" as const,
      approvalStatus: "approved" as const,
    };
  } finally {
    managerBootstrapInFlight = false;
  }
}

export async function bootstrapFirstAdminByUsername(input: {
  username: string;
  password: string;
}) {
  const username = input.username.trim().toLowerCase();
  if (!/^[a-z0-9][a-z0-9_.-]{2,79}$/.test(username))
    throw new Error(
      "اسم المستخدم يجب أن يكون 3 أحرف على الأقل ويحتوي على أحرف إنجليزية أو أرقام فقط"
    );
  if (input.password.length < 8)
    throw new Error("كلمة المرور يجب أن تكون 8 أحرف على الأقل");
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const existingAdmin = await db
    .select({ id: users.id })
    .from(users)
    .where(eq(users.role, "admin"))
    .limit(1);
  if (existingAdmin[0]) throw new Error("تم إنشاء حساب المدير بالفعل");
  const existingUsername = await db
    .select({ id: users.id })
    .from(users)
    .where(eq(users.email, username))
    .limit(1);
  if (existingUsername[0]) throw new Error("اسم المستخدم مستخدم في حساب آخر");
  const passwordHash = await hashPassword(input.password);
  const civilId = `99${Date.now().toString().slice(-10)}`;
  const result = await db.insert(users).values({
    openId: null,
    civilId,
    passwordHash,
    name: username,
    email: username,
    role: "admin",
    approvalStatus: "approved",
    status: "active",
    loginMethod: "local-username",
    mustChangePassword: false,
    preferredLanguage: "ar",
  });
  const userId = Number(result[0].insertId);
  await db.insert(auditLogs).values({
    actorUserId: userId,
    action: "account.first_admin_bootstrapped_by_username",
    entityType: "user",
    entityId: String(userId),
    afterJson: JSON.stringify({
      username,
      role: "admin",
      approvalStatus: "approved",
      status: "active",
    }),
  });
  return {
    id: userId,
    name: username,
    role: "admin" as const,
    approvalStatus: "approved" as const,
  };
}

export async function createManagerAccount(
  input: { civilId: string; password: string; email: string },
  actorUserId: number
) {
  const { civilId, email } = validateFirstManagerInput(input);
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const civilConflict = await db
    .select({ id: users.id })
    .from(users)
    .where(eq(users.civilId, civilId))
    .limit(1);
  const emailConflict = await db
    .select({ id: users.id })
    .from(users)
    .where(eq(users.email, email))
    .limit(1);
  if (civilConflict[0] || emailConflict[0])
    throw new Error("الرقم المدني أو البريد الإلكتروني مستخدم في حساب آخر");
  const passwordHash = await hashPassword(input.password);
  const name = email.split("@")[0]?.slice(0, 160) || "مدير سيتي سنتر";
  const result = await db.insert(users).values({
    openId: null,
    civilId,
    passwordHash,
    name,
    email,
    role: "admin",
    approvalStatus: "approved",
    status: "active",
    loginMethod: "local-civil-id",
    mustChangePassword: false,
    preferredLanguage: "ar",
  });
  const userId = Number(result[0].insertId);
  await db.insert(auditLogs).values({
    actorUserId,
    action: "account.manager_created",
    entityType: "user",
    entityId: String(userId),
    afterJson: JSON.stringify({
      civilId,
      email,
      role: "admin",
      approvalStatus: "approved",
      status: "active",
    }),
  });
  return {
    userId,
    role: "admin" as const,
    approvalStatus: "approved" as const,
    status: "active" as const,
  };
}

export async function registerStaffAccount(
  input: {
    civilId: string;
    password: string;
    name: string;
    phone: string;
    email?: string;
    role: "supervisor" | "accountant" | "driver" | "company" | "trader";
    companyId?: number;
  },
  actorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const civilId = normalizeCivilId(input.civilId);
  const existing = await db
    .select({ id: users.id })
    .from(users)
    .where(eq(users.civilId, civilId))
    .limit(1);
  if (existing[0]) throw new Error("هذا الرقم المدني مسجل مسبقاً");
  if (input.role === "company") {
    if (!input.companyId) throw new Error("اختر الشركة المرتبطة بحساب الشركة");
    const company = await db
      .select({ id: companies.id })
      .from(companies)
      .where(eq(companies.id, input.companyId))
      .limit(1);
    if (!company[0]) throw new Error("الشركة غير موجودة");
  }
  const passwordHash = await hashPassword(input.password);
  const result = await db.insert(users).values({
    openId: null,
    civilId,
    passwordHash,
    approvalStatus: "pending",
    name: input.name.trim(),
    phone: input.phone.trim(),
    email: input.email?.trim() || null,
    role: input.role,
    status: "inactive",
    loginMethod: "local-civil-id",
  });
  const userId = Number(result[0].insertId);
  if (input.role === "driver")
    await db.insert(drivers).values({ userId, active: true });
  if (input.role === "company" && input.companyId)
    await db
      .insert(companyUsers)
      .values({ userId, companyId: input.companyId });
  await db.insert(auditLogs).values({
    actorUserId,
    action: "account.staff_created_pending",
    entityType: "user",
    entityId: String(userId),
    afterJson: JSON.stringify({
      civilId,
      role: input.role,
      companyId: input.companyId,
      approvalStatus: "pending",
    }),
  });
  return { userId, role: input.role, approvalStatus: "pending" as const };
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result[0];
}

export async function verifyLocalCredentialsWithDb(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>,
  civilId: string,
  password: string
) {
  const normalizedLogin = normalizeCivilId(civilId);
  const result = /^\d{12}$/.test(normalizedLogin)
    ? await db
        .select()
        .from(users)
        .where(eq(users.civilId, normalizedLogin))
        .limit(1)
    : await db
        .select()
        .from(users)
        .where(eq(users.email, normalizedLogin.toLowerCase()))
        .limit(1);
  const user = result[0];
  if (
    !user?.passwordHash ||
    user.approvalStatus !== "approved" ||
    user.status !== "active"
  )
    return undefined;
  return (await verifyPassword(password, user.passwordHash)) ? user : undefined;
}

export async function changeLocalPassword(
  userId: number,
  currentPassword: string,
  newPassword: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const result = await db
    .select({
      id: users.id,
      passwordHash: users.passwordHash,
      civilId: users.civilId,
      role: users.role,
    })
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);
  const user = result[0];
  if (
    !user?.passwordHash ||
    !(await verifyPassword(currentPassword, user.passwordHash))
  )
    throw new Error("كلمة المرور الحالية غير صحيحة");
  if (newPassword.length < 8)
    throw new Error("كلمة المرور الجديدة يجب أن تكون 8 أحرف على الأقل");
  const passwordHash = await hashPassword(newPassword);
  await db
    .update(users)
    .set({ passwordHash, mustChangePassword: false })
    .where(eq(users.id, userId));
  await db.insert(auditLogs).values({
    actorUserId: userId,
    action: "account.password_changed",
    entityType: "user",
    entityId: String(userId),
    afterJson: JSON.stringify({ civilId: user.civilId, role: user.role }),
  });
  return { success: true as const };
}

export async function resetLocalPassword(
  userId: number,
  temporaryPassword: string,
  actorUserId: number
) {
  if (temporaryPassword.length < 8)
    throw new Error("كلمة المرور المؤقتة يجب أن تكون 8 أحرف على الأقل");
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const target = await db
    .select({
      id: users.id,
      civilId: users.civilId,
      role: users.role,
      status: users.status,
    })
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);
  if (!target[0]) throw new Error("الحساب غير موجود");
  const passwordHash = await hashPassword(temporaryPassword);
  await db
    .update(users)
    .set({ passwordHash, mustChangePassword: true })
    .where(eq(users.id, userId));
  await db.insert(auditLogs).values({
    actorUserId,
    action: "account.password_reset",
    entityType: "user",
    entityId: String(userId),
    afterJson: JSON.stringify({
      civilId: target[0].civilId,
      role: target[0].role,
      mustChangePassword: true,
    }),
  });
  return { success: true as const, userId, mustChangePassword: true as const };
}

export async function completeAdminPasswordRecovery(input: {
  login: string;
  newPassword: string;
  recoverySecret: string;
}) {
  const login = normalizeCivilId(input.login).toLowerCase();
  if (
    login &&
    !/^\d{12}$/.test(login) &&
    !/^[a-z0-9][a-z0-9_.-]{2,79}$/.test(login) &&
    !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(login)
  ) {
    throw new Error(
      "تعذر إتمام الاستعادة. تحقق من بيانات الحساب وحاول مجددًا."
    );
  }
  if (input.newPassword.length < 12 || input.newPassword.length > 128)
    throw new Error("كلمة المرور الجديدة يجب أن تكون بين 12 و128 حرفًا.");
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const selectedLogin =
    login ||
    normalizeCivilId(ENV.adminCivilId).toLowerCase() ||
    ENV.adminEmail.trim().toLowerCase();
  if (!selectedLogin)
    throw new Error("أدخل الرقم المدني أو البريد الإلكتروني لحساب المدير.");
  const targetRows = /^\d{12}$/.test(selectedLogin)
    ? await db
        .select({
          id: users.id,
          civilId: users.civilId,
          role: users.role,
          status: users.status,
          approvalStatus: users.approvalStatus,
        })
        .from(users)
        .where(and(eq(users.civilId, selectedLogin), eq(users.role, "admin")))
        .limit(1)
    : await db
        .select({
          id: users.id,
          civilId: users.civilId,
          role: users.role,
          status: users.status,
          approvalStatus: users.approvalStatus,
        })
        .from(users)
        .where(and(eq(users.email, selectedLogin), eq(users.role, "admin")))
        .limit(1);
  const target = targetRows[0];
  if (
    !target ||
    target.status !== "active" ||
    target.approvalStatus !== "approved"
  )
    throw new Error(
      "تعذر إتمام الاستعادة. تحقق من بيانات الحساب وحاول مجددًا."
    );
  const recoveryAction = adminRecoveryAuditAction(input.recoverySecret);
  const alreadyUsed = await db
    .select({ id: auditLogs.id })
    .from(auditLogs)
    .where(eq(auditLogs.action, recoveryAction))
    .limit(1);
  if (alreadyUsed[0])
    throw new Error(
      "انتهت صلاحية رمز الاستعادة. اطلب رمزًا جديدًا من مسؤول الاستضافة."
    );
  const passwordHash = await hashPassword(input.newPassword);
  await db
    .update(users)
    .set({ passwordHash, mustChangePassword: false })
    .where(eq(users.id, target.id));
  await db.insert(auditLogs).values({
    actorUserId: target.id,
    action: recoveryAction,
    entityType: "user",
    entityId: String(target.id),
    afterJson: JSON.stringify({
      civilId: target.civilId,
      role: target.role,
      method: "one_time_admin_recovery",
    }),
  });
  return { success: true as const };
}

export async function verifyLocalCredentials(
  civilId: string,
  password: string
) {
  const db = await getDb();
  if (!db) return undefined;
  return verifyLocalCredentialsWithDb(db, civilId, password);
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(users)
    .where(eq(users.openId, openId))
    .limit(1);
  return result[0];
}

export async function listUsers(page = 1, pageSize = 25) {
  const db = await getDb();
  if (!db) return { items: [], total: 0 };
  const offset = Math.max(0, (page - 1) * pageSize);
  const [items, totalRows] = await Promise.all([
    db
      .select({
        id: users.id,
        name: users.name,
        email: users.email,
        phone: users.phone,
        civilId: users.civilId,
        role: users.role,
        status: users.status,
        approvalStatus: users.approvalStatus,
        requestedRole: users.requestedRole,
        preferredLanguage: users.preferredLanguage,
        createdAt: users.createdAt,
        companyId: companyUsers.companyId,
      })
      .from(users)
      .leftJoin(companyUsers, eq(users.id, companyUsers.userId))
      .orderBy(desc(users.createdAt))
      .limit(pageSize)
      .offset(offset),
    db.select({ count: sql<number>`count(*)` }).from(users),
  ]);
  const roleRows = items.length
    ? await db
        .select({ userId: userRoles.userId, role: userRoles.role })
        .from(userRoles)
        .where(
          inArray(
            userRoles.userId,
            items.map(item => item.id)
          )
        )
    : [];
  const roleMap = new Map<number, string[]>();
  for (const row of roleRows)
    roleMap.set(row.userId, [...(roleMap.get(row.userId) ?? []), row.role]);
  return {
    items: items.map(item => ({
      ...item,
      roles: Array.from(new Set([item.role, ...(roleMap.get(item.id) ?? [])])),
    })),
    total: Number(totalRows[0]?.count ?? 0),
  };
}

export async function setOwnCivilId(userId: number, civilIdInput: string) {
  const civilId = normalizeCivilId(civilIdInput);
  if (!/^\\d{12}$/.test(civilId))
    throw new Error("الرقم المدني يجب أن يتكون من 12 رقماً");
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const existing = await db
    .select({ id: users.id })
    .from(users)
    .where(eq(users.civilId, civilId))
    .limit(1);
  if (existing[0] && existing[0].id !== userId)
    throw new Error("هذا الرقم المدني مستخدم في حساب آخر");
  const before = await db
    .select({ id: users.id, civilId: users.civilId })
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);
  if (!before[0]) throw new Error("الحساب غير موجود");
  await db.update(users).set({ civilId }).where(eq(users.id, userId));
  await db.insert(auditLogs).values({
    actorUserId: userId,
    action: "user.civil_id_linked",
    entityType: "user",
    entityId: String(userId),
    beforeJson: JSON.stringify({ civilId: before[0].civilId }),
    afterJson: JSON.stringify({ civilId }),
  });
  return { civilId };
}

export async function updateUserProfile(
  userId: number,
  input: { name: string; phone: string; email?: string; companyId?: number },
  actorUserId: number
) {
  const name = input.name.trim();
  const phone = input.phone.trim();
  const email = input.email?.trim() || null;
  if (name.length < 2 || name.length > 160)
    throw new Error("الاسم يجب أن يكون بين حرفين و160 حرفاً");
  if (phone.length < 5 || phone.length > 40)
    throw new Error("رقم الهاتف غير صالح");
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const before = await db
    .select()
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);
  if (!before[0]) throw new Error("الحساب غير موجود");
  await db
    .update(users)
    .set({ name, phone, email })
    .where(eq(users.id, userId));
  await db.delete(companyUsers).where(eq(companyUsers.userId, userId));
  if (input.companyId)
    await db
      .insert(companyUsers)
      .values({ userId, companyId: input.companyId });
  const after = await db
    .select({
      id: users.id,
      name: users.name,
      phone: users.phone,
      email: users.email,
    })
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);
  await db.insert(auditLogs).values({
    actorUserId,
    action: "user.profile_updated",
    entityType: "user",
    entityId: String(userId),
    beforeJson: JSON.stringify({
      name: before[0].name,
      phone: before[0].phone,
      email: before[0].email,
    }),
    afterJson: JSON.stringify({
      ...after[0],
      companyId: input.companyId ?? null,
    }),
  });
  return { ...after[0], companyId: input.companyId ?? null };
}

export async function createDriverProfile(
  userId: number,
  input: {
    vehicleLabel: string;
    licenseNumber?: string;
    vehicleType:
      | "car"
      | "refrigerated_car"
      | "motorcycle"
      | "semi_truck"
      | "refrigerated_semi_truck"
      | "truck"
      | "refrigerated_truck";
  },
  actorUserId: number
) {
  const vehicleLabel = input.vehicleLabel.trim();
  const licenseNumber = input.licenseNumber?.trim() || null;
  if (vehicleLabel.length < 2 || vehicleLabel.length > 120)
    throw new Error("Vehicle label is required");
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const user = await db
    .select()
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);
  if (!user[0]) throw new Error("User not found");
  const existing = await db
    .select()
    .from(drivers)
    .where(eq(drivers.userId, userId))
    .limit(1);
  const driverId =
    existing[0]?.id ??
    Number(
      (
        await db.insert(drivers).values({
          userId,
          vehicleLabel,
          licenseNumber,
          vehicleType: input.vehicleType,
        })
      )[0].insertId
    );
  if (existing[0])
    await db
      .update(drivers)
      .set({
        vehicleLabel,
        licenseNumber,
        vehicleType: input.vehicleType,
        active: true,
      })
      .where(eq(drivers.userId, userId));
  await db
    .update(users)
    .set({ role: "driver", status: "active", approvalStatus: "approved" })
    .where(eq(users.id, userId));
  await db.insert(auditLogs).values({
    actorUserId,
    action: "driver.profile_created",
    entityType: "driver",
    entityId: String(driverId),
    afterJson: JSON.stringify({ userId, ...input }),
  });
  return { driverId, userId };
}

export async function hasUserPermission(userId: number, permissionKey: string) {
  const db = await getDb();
  if (!db) return false;
  const rows = await db
    .select({ granted: userPermissions.granted })
    .from(userPermissions)
    .where(
      and(
        eq(userPermissions.userId, userId),
        eq(userPermissions.permissionKey, permissionKey)
      )
    )
    .limit(1);
  return rows[0]?.granted === true;
}

export async function setUserPermissionWithDb(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>,
  userId: number,
  permissionKey: string,
  granted: boolean,
  actorUserId: number
) {
  const target = await db
    .select({ id: users.id, role: users.role })
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);
  if (!target[0]) throw new Error("User not found");
  await db
    .insert(userPermissions)
    .values({ userId, permissionKey, granted, grantedByUserId: actorUserId })
    .onDuplicateKeyUpdate({
      set: { granted, grantedByUserId: actorUserId, updatedAt: new Date() },
    });
  await db.insert(auditLogs).values({
    actorUserId,
    action: granted ? "user.permission_granted" : "user.permission_revoked",
    entityType: "user_permission",
    entityId: `${userId}:${permissionKey}`,
    afterJson: JSON.stringify({ userId, permissionKey, granted }),
  });
  return { userId, permissionKey, granted };
}

export async function setUserPermission(
  userId: number,
  permissionKey: string,
  granted: boolean,
  actorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  return setUserPermissionWithDb(
    db,
    userId,
    permissionKey,
    granted,
    actorUserId
  );
}

export async function getUserRolesWithDb(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>,
  userId: number
) {
  const user = await db
    .select({ role: users.role })
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);
  if (!user[0]) return [] as string[];
  const assigned = await db
    .select({ role: userRoles.role })
    .from(userRoles)
    .where(eq(userRoles.userId, userId));
  return Array.from(
    new Set([user[0].role, ...assigned.map(item => item.role)])
  );
}

export async function getUserRoles(userId: number) {
  const db = await getDb();
  if (!db) return [] as string[];
  return getUserRolesWithDb(db, userId);
}

export async function listUserRoles(userId: number) {
  return getUserRoles(userId);
}

export async function setUserRoleWithDb(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>,
  userId: number,
  role: "supervisor" | "accountant" | "driver" | "company" | "trader",
  granted: boolean,
  actorUserId: number
) {
  if (actorUserId === userId)
    throw new Error("لا يمكنك تعديل أدوار حسابك الحالي");
  const target = await db
    .select({ id: users.id, role: users.role })
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);
  if (!target[0]) throw new Error("الحساب غير موجود");
  if (target[0].role === "admin")
    throw new Error("لا يمكن تعديل أدوار حساب المدير المحمي");
  const driver =
    role === "driver"
      ? await db
          .select({ id: drivers.id, active: drivers.active })
          .from(drivers)
          .where(eq(drivers.userId, userId))
          .limit(1)
      : [];
  if (role === "driver" && !driver[0])
    throw new Error("أنشئ ملف السائق ومعلومات المركبة أولاً");
  if (role === "driver" && !granted && driver[0]?.active) {
    const activeShift = await db
      .select({ id: shifts.id })
      .from(shifts)
      .where(and(eq(shifts.driverId, driver[0].id), isNull(shifts.endedAt)))
      .limit(1);
    if (activeShift[0])
      throw new Error("أنه الوردية النشطة أولاً قبل سحب دور السائق");
  }
  if (granted) {
    await db
      .insert(userRoles)
      .values({ userId, role, grantedByUserId: actorUserId })
      .onDuplicateKeyUpdate({
        set: { grantedByUserId: actorUserId, updatedAt: new Date() },
      });
  } else {
    if (target[0].role === role)
      throw new Error(
        "لا يمكن سحب الدور الأساسي للحساب؛ غيّر الدور الأساسي أولاً"
      );
    await db
      .delete(userRoles)
      .where(and(eq(userRoles.userId, userId), eq(userRoles.role, role)));
  }
  if (role === "driver" && driver[0])
    await db
      .update(drivers)
      .set({ active: granted })
      .where(eq(drivers.id, driver[0].id));
  const roles = await getUserRolesWithDb(db, userId);
  await db.insert(auditLogs).values({
    actorUserId,
    action: granted ? "user.role_granted" : "user.role_revoked",
    entityType: "user_role",
    entityId: `${userId}:${role}`,
    beforeJson: JSON.stringify({ userId, role, granted: !granted }),
    afterJson: JSON.stringify({ userId, role, granted, roles }),
  });
  return { userId, role, granted, roles };
}

export async function setUserRole(
  userId: number,
  role: "supervisor" | "accountant" | "driver" | "company" | "trader",
  granted: boolean,
  actorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  return setUserRoleWithDb(db, userId, role, granted, actorUserId);
}

export async function listUserPermissions(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      permissionKey: userPermissions.permissionKey,
      granted: userPermissions.granted,
    })
    .from(userPermissions)
    .where(eq(userPermissions.userId, userId));
}

export async function updateUserAccessWithDb(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>,
  userId: number,
  input: {
    role?:
      | "admin"
      | "supervisor"
      | "accountant"
      | "driver"
      | "company"
      | "trader";
    status?: "active" | "inactive";
    approvalStatus?: "pending" | "approved" | "rejected";
  },
  actorUserId: number
) {
  const before = await db
    .select()
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);
  if (!before[0]) throw new Error("User not found");
  if (userId === actorUserId && input.role && input.role !== before[0].role)
    throw new Error("لا يمكنك تغيير دور حسابك الحالي من هذه الشاشة");
  const driver = await db
    .select({ id: drivers.id, active: drivers.active })
    .from(drivers)
    .where(eq(drivers.userId, userId))
    .limit(1);
  if (input.role === "driver" && before[0].role !== "driver" && !driver[0])
    throw new Error("أنشئ ملف السائق ومعلومات المركبة أولاً");
  const changingAwayFromDriver = Boolean(
    input.role && input.role !== "driver" && before[0].role === "driver"
  );
  if (changingAwayFromDriver && driver[0]?.active) {
    const activeShift = await db
      .select({ id: shifts.id })
      .from(shifts)
      .where(and(eq(shifts.driverId, driver[0].id), isNull(shifts.endedAt)))
      .limit(1);
    if (activeShift[0])
      throw new Error("أنه الوردية النشطة أولاً قبل إزالة دور السائق");
  }
  await db.update(users).set(input).where(eq(users.id, userId));
  if (input.role && input.role !== "driver" && driver[0])
    await db
      .update(drivers)
      .set({ active: false })
      .where(eq(drivers.id, driver[0].id));
  if (
    input.role === "driver" &&
    driver[0] &&
    input.status !== "inactive" &&
    input.approvalStatus !== "rejected"
  )
    await db
      .update(drivers)
      .set({ active: true })
      .where(eq(drivers.id, driver[0].id));
  const after = await db
    .select()
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);
  await db.insert(auditLogs).values({
    actorUserId,
    action: "user.access_updated",
    entityType: "user",
    entityId: String(userId),
    beforeJson: JSON.stringify({
      ...before[0],
      driverProfileActive: driver[0]?.active ?? null,
    }),
    afterJson: JSON.stringify({
      ...after[0],
      driverProfileActive:
        input.role && input.role !== "driver"
          ? false
          : (driver[0]?.active ?? null),
    }),
  });
  return after[0];
}

export async function updateUserAccess(
  userId: number,
  input: {
    role?:
      | "admin"
      | "supervisor"
      | "accountant"
      | "driver"
      | "company"
      | "trader";
    status?: "active" | "inactive";
    approvalStatus?: "pending" | "approved" | "rejected";
  },
  actorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  return updateUserAccessWithDb(db, userId, input, actorUserId);
}

export async function getBackupSchedule() {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(backupSchedules)
    .orderBy(desc(backupSchedules.createdAt))
    .limit(1);
  return result[0];
}

export async function getBackupScheduleByTaskUid(taskUid: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(backupSchedules)
    .where(eq(backupSchedules.cronTaskUid, taskUid))
    .limit(1);
  return result[0];
}

export async function createBackupSnapshot() {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const [
    userRows,
    companyRows,
    driverRows,
    orderRows,
    eventRows,
    mediaRows,
    shiftRows,
    tripRows,
    auditRows,
  ] = await Promise.all([
    db.select().from(users),
    db.select().from(companies),
    db.select().from(drivers),
    db.select().from(orders),
    db.select().from(orderEvents),
    db.select().from(orderMedia),
    db.select().from(shifts),
    db.select().from(trips),
    db.select().from(auditLogs),
  ]);
  const secureUsers = encryptBackupData(
    JSON.stringify(
      userRows.map(
        ({
          id,
          civilId,
          passwordHash,
          approvalStatus,
          role,
          status,
          mustChangePassword,
        }) => ({
          id,
          civilId,
          passwordHash,
          approvalStatus,
          role,
          status,
          mustChangePassword,
        })
      )
    )
  );
  return {
    format: "city-center-delivery-backup",
    version: 2,
    generatedAt: new Date().toISOString(),
    secureUsers,
    tables: {
      users: userRows.map(({ passwordHash: _passwordHash, ...safe }) => safe),
      companies: companyRows,
      companyUsers: await db.select().from(companyUsers),
      drivers: driverRows,
      driverLocations: await db.select().from(driverLocations),
      financialEntries: await db.select().from(financialEntries),
      messageThreads: await db.select().from(messageThreads),
      threadMembers: await db.select().from(threadMembers),
      messages: await db.select().from(messages),
      orders: orderRows,
      orderEvents: eventRows,
      orderMedia: mediaRows,
      orderTransfers: await db.select().from(orderTransfers),
      shifts: shiftRows,
      trips: tripRows,
      auditLogs: auditRows,
      notifications: await db.select().from(notifications),
      userPermissions: await db.select().from(userPermissions),
      userRoles: await db.select().from(userRoles),
    },
  };
}

export async function listBackupSnapshots() {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(backupSnapshots)
    .orderBy(desc(backupSnapshots.createdAt))
    .limit(50);
}

export async function createBackupSnapshotRecord(input: {
  scheduleId?: number | null;
  storageKey: string;
  downloadUrl: string;
  generatedAt: Date;
  sizeBytes: number;
  createdByUserId: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  await db.insert(backupSnapshots).values({ ...input, status: "ready" });
  const rows = await db
    .select()
    .from(backupSnapshots)
    .where(eq(backupSnapshots.storageKey, input.storageKey))
    .limit(1);
  return rows[0];
}

export async function restoreBackupSnapshot(
  payload: string,
  actorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const parsed = JSON.parse(payload) as {
    format?: string;
    version?: number;
    secureUsers?: string;
    tables?: Record<string, unknown[]>;
  };
  if (
    parsed.format !== "city-center-delivery-backup" ||
    parsed.version !== 2 ||
    !parsed.secureUsers ||
    !parsed.tables
  )
    throw new Error("Invalid or unsupported backup format");
  const secureUsers = JSON.parse(
    decryptBackupData(parsed.secureUsers)
  ) as Array<{
    id: number;
    civilId?: string | null;
    passwordHash?: string | null;
    approvalStatus: string;
    role: string;
    status: string;
    mustChangePassword: boolean;
  }>;
  const tables = parsed.tables;
  const usersWithSecrets = (tables.users ?? []).map(row => {
    const user = row as Record<string, unknown>;
    const secret = secureUsers.find(item => item.id === user.id);
    return { ...user, passwordHash: secret?.passwordHash ?? null };
  });
  const insertIfAny = async (table: any, rows: unknown[]) => {
    if (rows.length) await db.insert(table).values(rows as never[]);
  };
  await db.transaction(async tx => {
    for (const table of [
      userPermissions,
      userRoles,
      notifications,
      messages,
      threadMembers,
      messageThreads,
      orderMedia,
      orderEvents,
      orderTransfers,
      orders,
      driverLocations,
      shifts,
      trips,
      financialEntries,
      auditLogs,
      companyUsers,
      drivers,
      companies,
      users,
    ])
      await tx.delete(table);
    const put = async (table: any, rows: unknown[]) => {
      if (rows.length) await tx.insert(table).values(rows as never[]);
    };
    await put(users, usersWithSecrets);
    await put(companies, tables.companies ?? []);
    await put(companyUsers, tables.companyUsers ?? []);
    await put(drivers, tables.drivers ?? []);
    await put(driverLocations, tables.driverLocations ?? []);
    await put(financialEntries, tables.financialEntries ?? []);
    await put(messageThreads, tables.messageThreads ?? []);
    await put(threadMembers, tables.threadMembers ?? []);
    await put(messages, tables.messages ?? []);
    await put(orders, tables.orders ?? []);
    await put(orderEvents, tables.orderEvents ?? []);
    await put(orderMedia, tables.orderMedia ?? []);
    await put(orderTransfers, tables.orderTransfers ?? []);
    await put(shifts, tables.shifts ?? []);
    await put(trips, tables.trips ?? []);
    await put(auditLogs, tables.auditLogs ?? []);
    await put(notifications, tables.notifications ?? []);
    await put(userPermissions, tables.userPermissions ?? []);
    await put(userRoles, tables.userRoles ?? []);
    await tx.insert(auditLogs).values({
      actorUserId,
      action: "backup.restored",
      entityType: "backup",
      entityId: String(parsed.version),
      beforeJson: null,
      afterJson: JSON.stringify({
        version: parsed.version,
        tables: Object.keys(tables),
      }),
    });
  });
  return {
    restored: true,
    tables: Object.keys(tables),
    userCount: usersWithSecrets.length,
  };
}

export async function markBackupRun(scheduleId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  await db
    .update(backupSchedules)
    .set({ lastRunAt: new Date() })
    .where(eq(backupSchedules.id, scheduleId));
}

export async function updateBackupSchedule(
  input: {
    frequency: string;
    destinationLabel: string;
    enabled: boolean;
    cronTaskUid?: string | null;
  },
  actorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const current = await getBackupSchedule();
  if (current) {
    await db
      .update(backupSchedules)
      .set(input)
      .where(eq(backupSchedules.id, current.id));
  } else {
    await db.insert(backupSchedules).values(input);
  }
  const after = await getBackupSchedule();
  await db.insert(auditLogs).values({
    actorUserId,
    action: "backup.schedule_updated",
    entityType: "backup_schedule",
    entityId: String(after?.id ?? ""),
    beforeJson: JSON.stringify(current ?? null),
    afterJson: JSON.stringify(after ?? input),
  });
  return after;
}

export async function createNotification(input: {
  userId: number;
  title: string;
  body: string;
  kind?: "info" | "warning" | "success" | "urgent";
}) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const result = await db
    .insert(notifications)
    .values({ userId: input.userId, title: input.title, body: input.body });
  return { id: Number(result[0].insertId) };
}

export async function listNotifications(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, userId))
    .orderBy(desc(notifications.createdAt))
    .limit(100);
}

export async function markNotificationRead(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  await db
    .update(notifications)
    .set({ readAt: new Date() })
    .where(and(eq(notifications.id, id), eq(notifications.userId, userId)));
  return { id };
}

export async function createMessageThread(
  input: {
    type: "direct" | "group" | "order" | "company";
    title?: string;
    orderId?: number;
    companyId?: number;
    memberIds: number[];
  },
  creatorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const result = await db.insert(messageThreads).values({
    type: input.type,
    title: input.title,
    orderId: input.orderId,
    companyId: input.companyId,
    createdByUserId: creatorUserId,
  });
  const threadId = Number(result[0].insertId);
  const members = Array.from(new Set([creatorUserId, ...input.memberIds])).map(
    userId => ({ threadId, userId })
  );
  if (members.length) await db.insert(threadMembers).values(members);
  return { threadId };
}

export async function listMessageRecipients(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const rows = await db
    .select({ id: users.id, name: users.name, role: users.role })
    .from(users)
    .where(
      and(eq(users.status, "active"), eq(users.approvalStatus, "approved"))
    )
    .orderBy(users.name)
    .limit(200);
  return rows.filter(row => row.id !== userId);
}

export async function listMessageThreads(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: messageThreads.id,
      type: messageThreads.type,
      title: messageThreads.title,
      orderId: messageThreads.orderId,
      companyId: messageThreads.companyId,
      createdByUserId: messageThreads.createdByUserId,
      createdAt: messageThreads.createdAt,
    })
    .from(messageThreads)
    .innerJoin(threadMembers, eq(messageThreads.id, threadMembers.threadId))
    .where(eq(threadMembers.userId, userId))
    .orderBy(desc(messageThreads.createdAt))
    .limit(100);
}

async function assertThreadMemberWithDb(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>,
  threadId: number,
  userId: number
) {
  const member = await db
    .select({ id: threadMembers.id })
    .from(threadMembers)
    .where(
      and(
        eq(threadMembers.threadId, threadId),
        eq(threadMembers.userId, userId)
      )
    )
    .limit(1);
  if (!member.length) throw new Error("لا يمكنك الوصول إلى هذه المحادثة");
}

async function assertThreadMember(threadId: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  return assertThreadMemberWithDb(db, threadId, userId);
}

export type MessageAttachmentInput = {
  type: "image" | "audio";
  fileKey: string;
  fileUrl: string;
  fileName: string;
  mimeType: string;
  sizeBytes: number;
};

export async function listThreadMessages(
  threadId: number,
  userId: number,
  limit = 50
) {
  await assertThreadMember(threadId, userId);
  const db = await getDb();
  if (!db) return [];
  const messageRows = await db
    .select()
    .from(messages)
    .where(eq(messages.threadId, threadId))
    .orderBy(desc(messages.createdAt))
    .limit(limit);
  const messageIds = messageRows.map(message => message.id);
  const attachmentRows = messageIds.length
    ? await db
        .select()
        .from(messageAttachments)
        .where(inArray(messageAttachments.messageId, messageIds))
        .orderBy(asc(messageAttachments.createdAt))
    : [];
  const attachmentsByMessage = new Map<number, typeof attachmentRows>();
  for (const attachment of attachmentRows)
    attachmentsByMessage.set(attachment.messageId, [
      ...(attachmentsByMessage.get(attachment.messageId) ?? []),
      attachment,
    ]);
  return messageRows.map(message => ({
    ...message,
    attachments: attachmentsByMessage.get(message.id) ?? [],
  }));
}

export async function sendThreadMessageWithDb(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>,
  threadId: number,
  senderUserId: number,
  body: string,
  attachments: MessageAttachmentInput[] = []
) {
  await assertThreadMemberWithDb(db, threadId, senderUserId);
  if (!body.trim() && !attachments.length)
    throw new Error("أدخل رسالة أو أرفق ملفاً");
  const result = await db
    .insert(messages)
    .values({ threadId, senderUserId, body: body.trim() });
  const messageId = Number(result[0].insertId);
  if (attachments.length)
    await db
      .insert(messageAttachments)
      .values(attachments.map(attachment => ({ ...attachment, messageId })));
  const members = await db
    .select({ userId: threadMembers.userId })
    .from(threadMembers)
    .where(eq(threadMembers.threadId, threadId));
  const recipients = members.filter(member => member.userId !== senderUserId);
  const attachmentSummary = attachments.some(
    attachment => attachment.type === "audio"
  )
    ? "أرسل تسجيلاً صوتياً"
    : "أرسل صورة";
  if (recipients.length)
    await db.insert(notifications).values(
      recipients.map(member => ({
        userId: member.userId,
        title: "رسالة داخلية جديدة",
        body: (body.trim() || attachmentSummary).slice(0, 240),
        link: "/messaging",
      }))
    );
  return { id: messageId };
}

export async function sendThreadMessage(
  threadId: number,
  senderUserId: number,
  body: string,
  attachments: MessageAttachmentInput[] = []
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  return sendThreadMessageWithDb(db, threadId, senderUserId, body, attachments);
}

export async function listAuditLogs(page = 1, pageSize = 50) {
  const db = await getDb();
  if (!db) return { items: [], total: 0 };
  const offset = Math.max(0, (page - 1) * pageSize);
  const [items, totalRows] = await Promise.all([
    db
      .select()
      .from(auditLogs)
      .orderBy(desc(auditLogs.createdAt))
      .limit(pageSize)
      .offset(offset),
    db.select({ count: sql<number>`count(*)` }).from(auditLogs),
  ]);
  return { items, total: Number(totalRows[0]?.count ?? 0) };
}

export async function recordDriverLocation(
  driverId: number,
  latitude: string,
  longitude: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  await db.insert(driverLocations).values({ driverId, latitude, longitude });
  return { driverId, latitude, longitude };
}

export async function listLatestDriverLocations() {
  const db = await getDb();
  if (!db) return [];
  const freshnessCutoff = new Date(Date.now() - 6 * 60 * 60 * 1000);
  const rows = await db
    .select({
      driverId: driverLocations.driverId,
      latitude: driverLocations.latitude,
      longitude: driverLocations.longitude,
      recordedAt: driverLocations.recordedAt,
      driverName: users.name,
    })
    .from(driverLocations)
    .innerJoin(drivers, eq(driverLocations.driverId, drivers.id))
    .innerJoin(
      shifts,
      and(eq(shifts.driverId, drivers.id), isNull(shifts.endedAt))
    )
    .leftJoin(users, eq(drivers.userId, users.id))
    .where(gte(driverLocations.recordedAt, freshnessCutoff))
    .orderBy(desc(driverLocations.recordedAt))
    .limit(100);
  const seen = new Set<number>();
  return rows.filter(row => {
    if (seen.has(row.driverId)) return false;
    seen.add(row.driverId);
    return true;
  });
}

export async function getDashboardSummary() {
  const db = await getDb();
  if (!db)
    return {
      ordersToday: 0,
      inTransit: 0,
      delivered: 0,
      activeDrivers: 0,
      activeCompanies: 0,
    };
  const [orderCounts, driverCounts, companyCounts] = await Promise.all([
    db
      .select({ status: orders.status, count: sql<number>`count(*)` })
      .from(orders)
      .groupBy(orders.status),
    db
      .select({ count: sql<number>`count(*)` })
      .from(users)
      .where(and(eq(users.role, "driver"), eq(users.status, "active"))),
    db
      .select({ count: sql<number>`count(*)` })
      .from(companies)
      .where(eq(companies.status, "active")),
  ]);
  const counts = new Map(
    orderCounts.map(row => [row.status, Number(row.count)])
  );
  return {
    ordersToday: orderCounts.reduce((sum, row) => sum + Number(row.count), 0),
    inTransit:
      (counts.get("assigned") ?? 0) +
      (counts.get("picked_up") ?? 0) +
      (counts.get("in_transit") ?? 0),
    delivered: counts.get("delivered") ?? 0,
    activeDrivers: Number(driverCounts[0]?.count ?? 0),
    activeCompanies: Number(companyCounts[0]?.count ?? 0),
  };
}

export async function updateCompany(
  companyId: number,
  input: {
    name?: string;
    phone?: string;
    whatsapp?: string;
    address?: string;
    defaultDeliveryFee?: string;
    status?: "active" | "inactive";
    portalEnabled?: boolean;
  },
  actorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const before = await db
    .select()
    .from(companies)
    .where(eq(companies.id, companyId))
    .limit(1);
  if (!before[0]) throw new Error("Company not found");
  await db.update(companies).set(input).where(eq(companies.id, companyId));
  const after = await db
    .select()
    .from(companies)
    .where(eq(companies.id, companyId))
    .limit(1);
  await db.insert(auditLogs).values({
    actorUserId,
    action: "company.updated",
    entityType: "company",
    entityId: String(companyId),
    beforeJson: JSON.stringify(before[0]),
    afterJson: JSON.stringify(after[0]),
  });
  return after[0];
}

export async function listCompanies(page = 1, pageSize = 20) {
  const db = await getDb();
  if (!db) return { items: [], total: 0 };
  const offset = Math.max(0, (page - 1) * pageSize);
  const [items, totalRows] = await Promise.all([
    db
      .select()
      .from(companies)
      .orderBy(desc(companies.createdAt))
      .limit(pageSize)
      .offset(offset),
    db.select({ count: sql<number>`count(*)` }).from(companies),
  ]);
  return { items, total: Number(totalRows[0]?.count ?? 0) };
}

export async function createCompany(
  input: {
    name: string;
    code?: string;
    defaultDeliveryFee?: string;
    phone?: string;
    whatsapp?: string;
    address?: string;
    locationUrl?: string;
    pickupContactName?: string;
    governorateId?: number;
    areaId?: number;
  },
  actorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  // Business codes are generated on the server so users cannot reuse a code.
  const companyCount = await db
    .select({ count: sql<number>`count(*)` })
    .from(companies);
  let nextNumber = Number(companyCount[0]?.count ?? 0) + 1;
  let code = `C${String(nextNumber).padStart(5, "0")}`;
  for (let attempt = 0; attempt < 20; attempt += 1) {
    const existing = await db
      .select({ id: companies.id })
      .from(companies)
      .where(eq(companies.code, code))
      .limit(1);
    if (!existing[0]) break;
    nextNumber += 1;
    code = `C${String(nextNumber).padStart(5, "0")}`;
  }
  if (input.areaId) {
    const area = await db
      .select({
        id: deliveryAreas.id,
        governorateId: deliveryAreas.governorateId,
      })
      .from(deliveryAreas)
      .where(eq(deliveryAreas.id, input.areaId))
      .limit(1);
    if (
      !area[0] ||
      (input.governorateId && area[0].governorateId !== input.governorateId)
    )
      throw new Error("المنطقة لا تتبع المحافظة المختارة");
  }
  const result = await db.insert(companies).values({
    name: input.name,
    code,
    defaultDeliveryFee: input.defaultDeliveryFee ?? "0.000",
    phone: input.phone,
    whatsapp: input.whatsapp,
    address: input.address?.trim() || null,
  });
  const companyId = Number(result[0].insertId);
  if (input.address?.trim()) {
    try {
      await db.insert(companyAddresses).values({
        companyId,
        label: "العنوان الرئيسي",
        address: input.address.trim(),
        phone: input.phone?.trim() || null,
        pickupContactName: input.pickupContactName?.trim() || null,
        locationUrl: input.locationUrl?.trim() || null,
        governorateId: input.governorateId ?? null,
        areaId: input.areaId ?? null,
        isDefault: true,
      });
    } catch (error) {
      // Older Hostinger databases may still have the original address table
      // without the optional location columns. Preserve company creation and
      // retry with the legacy columns instead of returning a generic failure.
      const cause =
        error && typeof error === "object" && "cause" in error
          ? (error as { cause?: unknown }).cause
          : undefined;
      const message = `${error instanceof Error ? error.message : String(error)} ${cause instanceof Error ? cause.message : String(cause ?? "")}`;
      if (
        !/unknown column|column .* does not exist|ER_BAD_FIELD_ERROR/i.test(
          message
        )
      )
        throw error;
      await db.insert(companyAddresses).values({
        companyId,
        label: "العنوان الرئيسي",
        address: input.address.trim(),
        phone: input.phone?.trim() || null,
        isDefault: true,
      });
      console.warn("[Database] Saved company address using legacy columns", {
        companyId,
      });
    }
  }
  await db.insert(auditLogs).values({
    actorUserId,
    action: "company.created",
    entityType: "company",
    entityId: String(companyId),
    afterJson: JSON.stringify(input),
  });
  return companyId;
}

export async function listCompanyAddresses(
  companyId: number,
  activeOnly = false
) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [eq(companyAddresses.companyId, companyId)];
  if (activeOnly) conditions.push(eq(companyAddresses.active, true));
  return db
    .select()
    .from(companyAddresses)
    .where(and(...conditions))
    .orderBy(desc(companyAddresses.isDefault), asc(companyAddresses.label));
}

const locationSeedInFlight = new WeakMap<object, Promise<void>>();
const locationSeeded = new WeakSet<object>();

async function ensureKuwaitLocationSeed(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>
) {
  if (locationSeeded.has(db)) return;
  const existingTask = locationSeedInFlight.get(db);
  if (existingTask) return existingTask;
  const task = (async () => {
    const [governorateRows, areaRows] = await Promise.all([
      db
        .select({ id: governorates.id, nameAr: governorates.nameAr })
        .from(governorates),
      db
        .select({
          governorateId: deliveryAreas.governorateId,
          nameAr: deliveryAreas.nameAr,
        })
        .from(deliveryAreas),
    ]);
    const governorateIds = new Map(
      governorateRows.map(row => [row.nameAr, row.id])
    );
    const existingAreas = new Set(
      areaRows.map(row => `${row.governorateId}:${row.nameAr}`)
    );
    const complete = KUWAIT_GOVERNORATES.every(governorate => {
      const governorateId = governorateIds.get(governorate.nameAr);
      return (
        governorateId !== undefined &&
        governorate.areas.every(area =>
          existingAreas.has(`${governorateId}:${area.nameAr}`)
        )
      );
    });
    if (complete) {
      locationSeeded.add(db);
      return;
    }
    for (const governorate of KUWAIT_GOVERNORATES) {
      await db
        .insert(governorates)
        .values({ nameAr: governorate.nameAr, nameEn: governorate.nameEn })
        .onDuplicateKeyUpdate({ set: { nameEn: governorate.nameEn } });
      const rows = await db
        .select({ id: governorates.id })
        .from(governorates)
        .where(eq(governorates.nameAr, governorate.nameAr))
        .limit(1);
      const governorateId = rows[0]?.id;
      if (!governorateId)
        throw new Error(`تعذر تهيئة محافظة ${governorate.nameAr}`);
      for (const area of governorate.areas) {
        await db
          .insert(deliveryAreas)
          .values({ governorateId, nameAr: area.nameAr, nameEn: area.nameEn })
          .onDuplicateKeyUpdate({ set: { nameEn: area.nameEn } });
      }
    }
  })();
  locationSeedInFlight.set(db, task);
  try {
    await task;
    locationSeeded.add(db);
  } finally {
    locationSeedInFlight.delete(db);
  }
}

export async function listLocationDirectory() {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  await ensureKuwaitLocationSeed(db);
  const [governorateRows, areaRows] = await Promise.all([
    db
      .select()
      .from(governorates)
      .where(eq(governorates.active, true))
      .orderBy(asc(governorates.nameAr)),
    db
      .select()
      .from(deliveryAreas)
      .where(eq(deliveryAreas.active, true))
      .orderBy(asc(deliveryAreas.nameAr)),
  ]);
  return governorateRows.map(governorate => ({
    ...governorate,
    areas: areaRows.filter(area => area.governorateId === governorate.id),
  }));
}

export async function listAllLocations() {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  await ensureKuwaitLocationSeed(db);
  const [governoratesList, areas] = await Promise.all([
    db.select().from(governorates).orderBy(asc(governorates.nameAr)),
    db.select().from(deliveryAreas).orderBy(asc(deliveryAreas.nameAr)),
  ]);
  return governoratesList.map(governorate => ({
    ...governorate,
    areas: areas.filter(area => area.governorateId === governorate.id),
  }));
}

export async function createGovernorate(
  input: { nameAr: string; nameEn?: string },
  actorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const nameAr = input.nameAr.trim();
  if (nameAr.length < 2) throw new Error("اسم المحافظة غير صالح");
  const nameEn = input.nameEn?.trim() || nameAr;
  const result = await db.insert(governorates).values({ nameAr, nameEn });
  const id = Number(result[0].insertId);
  await db.insert(auditLogs).values({
    actorUserId,
    action: "location.governorate_created",
    entityType: "governorate",
    entityId: String(id),
    afterJson: JSON.stringify({ nameAr, nameEn }),
  });
  return { id, nameAr, nameEn };
}

export async function createDeliveryArea(
  input: { governorateId: number; nameAr: string; nameEn?: string },
  actorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const parent = await db
    .select({ id: governorates.id })
    .from(governorates)
    .where(eq(governorates.id, input.governorateId))
    .limit(1);
  if (!parent[0]) throw new Error("المحافظة غير موجودة");
  const nameAr = input.nameAr.trim();
  if (nameAr.length < 2) throw new Error("اسم المنطقة غير صالح");
  const nameEn = input.nameEn?.trim() || nameAr;
  const result = await db
    .insert(deliveryAreas)
    .values({ governorateId: input.governorateId, nameAr, nameEn });
  const id = Number(result[0].insertId);
  await db.insert(auditLogs).values({
    actorUserId,
    action: "location.area_created",
    entityType: "delivery_area",
    entityId: String(id),
    afterJson: JSON.stringify({ ...input, nameAr, nameEn }),
  });
  return { id, governorateId: input.governorateId, nameAr, nameEn };
}

export async function setLocationActive(
  input: { kind: "governorate" | "area"; id: number; active: boolean },
  actorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const table = input.kind === "governorate" ? governorates : deliveryAreas;
  const before = await db
    .select()
    .from(table)
    .where(eq(table.id, input.id))
    .limit(1);
  if (!before[0]) throw new Error("العنصر غير موجود");
  await db
    .update(table)
    .set({ active: input.active })
    .where(eq(table.id, input.id));
  await db.insert(auditLogs).values({
    actorUserId,
    action: `location.${input.kind}_updated`,
    entityType: input.kind,
    entityId: String(input.id),
    beforeJson: JSON.stringify(before[0]),
    afterJson: JSON.stringify({ ...before[0], active: input.active }),
  });
  return { id: input.id, active: input.active };
}

export async function listCompanyAreaRates(companyId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: companyAreaRates.id,
      companyId: companyAreaRates.companyId,
      areaId: companyAreaRates.areaId,
      amount: companyAreaRates.amount,
      areaName: deliveryAreas.nameAr,
      governorateId: deliveryAreas.governorateId,
      createdAt: companyAreaRates.createdAt,
      updatedAt: companyAreaRates.updatedAt,
    })
    .from(companyAreaRates)
    .innerJoin(deliveryAreas, eq(companyAreaRates.areaId, deliveryAreas.id))
    .where(eq(companyAreaRates.companyId, companyId))
    .orderBy(asc(deliveryAreas.nameAr));
}

export async function setCompanyAreaRate(
  input: { companyId: number; areaId: number; amount: string },
  actorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const before = await db
    .select()
    .from(companyAreaRates)
    .where(
      and(
        eq(companyAreaRates.companyId, input.companyId),
        eq(companyAreaRates.areaId, input.areaId)
      )
    )
    .limit(1);
  if (before[0])
    await db
      .update(companyAreaRates)
      .set({ amount: input.amount })
      .where(eq(companyAreaRates.id, before[0].id));
  else
    await db
      .insert(companyAreaRates)
      .values({ ...input, createdByUserId: actorUserId });
  const after = await db
    .select()
    .from(companyAreaRates)
    .where(
      and(
        eq(companyAreaRates.companyId, input.companyId),
        eq(companyAreaRates.areaId, input.areaId)
      )
    )
    .limit(1);
  await db.insert(auditLogs).values({
    actorUserId,
    action: "company.area_rate_updated",
    entityType: "company_area_rate",
    entityId: `${input.companyId}:${input.areaId}`,
    beforeJson: before[0] ? JSON.stringify(before[0]) : null,
    afterJson: JSON.stringify(after[0]),
  });
  return after[0];
}

export async function listCompanyGovernorateRates(companyId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: companyGovernorateRates.id,
      companyId: companyGovernorateRates.companyId,
      governorateId: companyGovernorateRates.governorateId,
      amount: companyGovernorateRates.amount,
      governorateName: governorates.nameAr,
      createdAt: companyGovernorateRates.createdAt,
      updatedAt: companyGovernorateRates.updatedAt,
    })
    .from(companyGovernorateRates)
    .innerJoin(
      governorates,
      eq(companyGovernorateRates.governorateId, governorates.id)
    )
    .where(eq(companyGovernorateRates.companyId, companyId))
    .orderBy(asc(governorates.nameAr));
}

export async function setCompanyGovernorateRate(
  input: { companyId: number; governorateId: number; amount: string },
  actorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const [company] = await db
    .select({ id: companies.id })
    .from(companies)
    .where(eq(companies.id, input.companyId))
    .limit(1);
  const [governorate] = await db
    .select({ id: governorates.id })
    .from(governorates)
    .where(eq(governorates.id, input.governorateId))
    .limit(1);
  if (!company || !governorate)
    throw new Error("الشركة أو المحافظة غير موجودة");
  const before = await db
    .select()
    .from(companyGovernorateRates)
    .where(
      and(
        eq(companyGovernorateRates.companyId, input.companyId),
        eq(companyGovernorateRates.governorateId, input.governorateId)
      )
    )
    .limit(1);
  if (before[0])
    await db
      .update(companyGovernorateRates)
      .set({ amount: input.amount })
      .where(eq(companyGovernorateRates.id, before[0].id));
  else
    await db
      .insert(companyGovernorateRates)
      .values({ ...input, createdByUserId: actorUserId });
  const after = await db
    .select()
    .from(companyGovernorateRates)
    .where(
      and(
        eq(companyGovernorateRates.companyId, input.companyId),
        eq(companyGovernorateRates.governorateId, input.governorateId)
      )
    )
    .limit(1);
  await db.insert(auditLogs).values({
    actorUserId,
    action: "company.governorate_rate_updated",
    entityType: "company_governorate_rate",
    entityId: `${input.companyId}:${input.governorateId}`,
    beforeJson: before[0] ? JSON.stringify(before[0]) : null,
    afterJson: JSON.stringify(after[0]),
  });
  return after[0];
}

export async function resolveCompanyDeliveryFee(
  companyId: number | null | undefined,
  areaId: number | null | undefined,
  fallback = "0.000",
  governorateId?: number | null
) {
  const db = await getDb();
  if (!db) return fallback;
  if (!companyId) return fallback;
  if (areaId) {
    const savedArea = await db
      .select({ amount: companyAreaRates.amount })
      .from(companyAreaRates)
      .where(
        and(
          eq(companyAreaRates.companyId, companyId),
          eq(companyAreaRates.areaId, areaId)
        )
      )
      .limit(1);
    if (savedArea[0])
      return resolveCompanyDeliveryRate(savedArea[0].amount, null, fallback);
    if (!governorateId) {
      const area = await db
        .select({ governorateId: deliveryAreas.governorateId })
        .from(deliveryAreas)
        .where(eq(deliveryAreas.id, areaId))
        .limit(1);
      governorateId = area[0]?.governorateId;
    }
  }
  if (governorateId) {
    const savedGovernorate = await db
      .select({ amount: companyGovernorateRates.amount })
      .from(companyGovernorateRates)
      .where(
        and(
          eq(companyGovernorateRates.companyId, companyId),
          eq(companyGovernorateRates.governorateId, governorateId)
        )
      )
      .limit(1);
    return resolveCompanyDeliveryRate(
      null,
      savedGovernorate[0]?.amount,
      fallback
    );
  }
  return resolveCompanyDeliveryRate(null, null, fallback);
}

export async function listDriverCompensation() {
  const db = await getDb();
  if (!db) return [];
  const rows = await db
    .select({
      id: drivers.id,
      userId: drivers.userId,
      name: users.name,
      payType: drivers.payType,
      baseSalary: drivers.baseSalary,
      defaultCommission: drivers.defaultCommission,
      vehicleLabel: drivers.vehicleLabel,
      active: drivers.active,
    })
    .from(drivers)
    .innerJoin(users, eq(drivers.userId, users.id))
    .orderBy(asc(users.name));
  return rows;
}

export async function updateDriverCompensation(
  input: {
    driverId: number;
    payType: DriverPayType;
    baseSalary: string;
    defaultCommission: string;
  },
  actorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const before = await db
    .select()
    .from(drivers)
    .where(eq(drivers.id, input.driverId))
    .limit(1);
  if (!before[0]) throw new Error("السائق غير موجود");
  await db
    .update(drivers)
    .set({
      payType: input.payType,
      baseSalary: input.baseSalary,
      defaultCommission: input.defaultCommission,
    })
    .where(eq(drivers.id, input.driverId));
  await db.insert(auditLogs).values({
    actorUserId,
    action: "driver.compensation_updated",
    entityType: "driver",
    entityId: String(input.driverId),
    beforeJson: JSON.stringify({
      payType: before[0].payType,
      baseSalary: before[0].baseSalary,
      defaultCommission: before[0].defaultCommission,
    }),
    afterJson: JSON.stringify(input),
  });
  return {
    driverId: input.driverId,
    payType: input.payType,
    baseSalary: input.baseSalary,
    defaultCommission: input.defaultCommission,
  };
}

export async function listDriverCommissionRates(driverId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: driverCommissionRates.id,
      driverId: driverCommissionRates.driverId,
      companyId: driverCommissionRates.companyId,
      areaId: driverCommissionRates.areaId,
      amount: driverCommissionRates.amount,
      companyName: companies.name,
      areaName: deliveryAreas.nameAr,
      governorateId: deliveryAreas.governorateId,
    })
    .from(driverCommissionRates)
    .leftJoin(companies, eq(driverCommissionRates.companyId, companies.id))
    .leftJoin(deliveryAreas, eq(driverCommissionRates.areaId, deliveryAreas.id))
    .where(eq(driverCommissionRates.driverId, driverId))
    .orderBy(asc(driverCommissionRates.id));
}

export async function setDriverCommissionRate(
  input: {
    driverId: number;
    companyId?: number;
    areaId?: number;
    amount: string;
  },
  actorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const driver = await db
    .select({ id: drivers.id })
    .from(drivers)
    .where(eq(drivers.id, input.driverId))
    .limit(1);
  if (!driver[0]) throw new Error("السائق غير موجود");
  const companyCondition = input.companyId
    ? eq(driverCommissionRates.companyId, input.companyId)
    : isNull(driverCommissionRates.companyId);
  const areaCondition = input.areaId
    ? eq(driverCommissionRates.areaId, input.areaId)
    : isNull(driverCommissionRates.areaId);
  const where = and(
    eq(driverCommissionRates.driverId, input.driverId),
    companyCondition,
    areaCondition
  );
  const before = await db
    .select()
    .from(driverCommissionRates)
    .where(where)
    .limit(1);
  const values = { amount: input.amount };
  if (before[0])
    await db
      .update(driverCommissionRates)
      .set(values)
      .where(eq(driverCommissionRates.id, before[0].id));
  else
    await db.insert(driverCommissionRates).values({
      driverId: input.driverId,
      companyId: input.companyId ?? null,
      areaId: input.areaId ?? null,
      amount: input.amount,
      createdByUserId: actorUserId,
    });
  const after = await db
    .select()
    .from(driverCommissionRates)
    .where(where)
    .limit(1);
  await db.insert(auditLogs).values({
    actorUserId,
    action: "driver.commission_rate_updated",
    entityType: "driver_commission_rate",
    entityId: `${input.driverId}:${input.companyId ?? "*"}:${input.areaId ?? "*"}`,
    beforeJson: before[0] ? JSON.stringify(before[0]) : null,
    afterJson: JSON.stringify(after[0]),
  });
  return after[0];
}

async function getCommissionForOrder(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>,
  driverId: number | null | undefined,
  companyId: number | null | undefined,
  areaId: number | null | undefined
) {
  if (!driverId) return 0;
  const driver = await db
    .select({
      payType: drivers.payType,
      defaultCommission: drivers.defaultCommission,
    })
    .from(drivers)
    .where(eq(drivers.id, driverId))
    .limit(1);
  if (!driver[0]) return 0;
  const rates = await db
    .select({
      companyId: driverCommissionRates.companyId,
      areaId: driverCommissionRates.areaId,
      amount: driverCommissionRates.amount,
    })
    .from(driverCommissionRates)
    .where(eq(driverCommissionRates.driverId, driverId));
  return resolveDriverCommission({
    payType: driver[0].payType,
    defaultCommission: driver[0].defaultCommission,
    companyId: companyId ?? null,
    areaId: areaId ?? null,
    rates,
  });
}

export async function createCompanyAddress(
  input: {
    companyId: number;
    label: string;
    address: string;
    phone?: string;
    pickupContactName?: string;
    locationUrl?: string;
    governorateId?: number;
    areaId?: number;
    isDefault?: boolean;
  },
  actorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const company = await db
    .select({ id: companies.id })
    .from(companies)
    .where(eq(companies.id, input.companyId))
    .limit(1);
  if (!company[0]) throw new Error("Company not found");
  if (input.areaId) {
    const area = await db
      .select({
        id: deliveryAreas.id,
        governorateId: deliveryAreas.governorateId,
      })
      .from(deliveryAreas)
      .where(eq(deliveryAreas.id, input.areaId))
      .limit(1);
    if (
      !area[0] ||
      (input.governorateId && area[0].governorateId !== input.governorateId)
    )
      throw new Error("المنطقة لا تتبع المحافظة المختارة");
  }
  if (input.isDefault)
    await db
      .update(companyAddresses)
      .set({ isDefault: false })
      .where(eq(companyAddresses.companyId, input.companyId));
  const result = await db.insert(companyAddresses).values({
    companyId: input.companyId,
    label: input.label.trim(),
    address: input.address.trim(),
    phone: input.phone?.trim() || null,
    pickupContactName: input.pickupContactName?.trim() || null,
    locationUrl: input.locationUrl?.trim() || null,
    governorateId: input.governorateId ?? null,
    areaId: input.areaId ?? null,
    isDefault: Boolean(input.isDefault),
  });
  const id = Number(result[0].insertId);
  await db.insert(auditLogs).values({
    actorUserId,
    action: "company.address_created",
    entityType: "companyAddress",
    entityId: String(id),
    afterJson: JSON.stringify(input),
  });
  return id;
}

export async function updateCompanyAddress(
  addressId: number,
  input: {
    label?: string;
    address?: string;
    phone?: string;
    pickupContactName?: string | null;
    locationUrl?: string | null;
    governorateId?: number | null;
    areaId?: number | null;
    isDefault?: boolean;
    active?: boolean;
  },
  actorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const before = await db
    .select()
    .from(companyAddresses)
    .where(eq(companyAddresses.id, addressId))
    .limit(1);
  if (!before[0]) throw new Error("Company address not found");
  const nextGovernorateId =
    input.governorateId === undefined
      ? before[0].governorateId
      : input.governorateId;
  const nextAreaId =
    input.areaId === undefined ? before[0].areaId : input.areaId;
  if (nextAreaId) {
    const area = await db
      .select({
        id: deliveryAreas.id,
        governorateId: deliveryAreas.governorateId,
      })
      .from(deliveryAreas)
      .where(eq(deliveryAreas.id, nextAreaId))
      .limit(1);
    if (
      !area[0] ||
      (nextGovernorateId && area[0].governorateId !== nextGovernorateId)
    )
      throw new Error("المنطقة لا تتبع المحافظة المختارة");
  }
  if (input.isDefault)
    await db
      .update(companyAddresses)
      .set({ isDefault: false })
      .where(eq(companyAddresses.companyId, before[0].companyId));
  await db
    .update(companyAddresses)
    .set({
      ...input,
      ...(input.governorateId !== undefined
        ? { governorateId: input.governorateId }
        : {}),
      ...(input.areaId !== undefined ? { areaId: input.areaId } : {}),
    })
    .where(eq(companyAddresses.id, addressId));
  const after = await db
    .select()
    .from(companyAddresses)
    .where(eq(companyAddresses.id, addressId))
    .limit(1);
  await db.insert(auditLogs).values({
    actorUserId,
    action: "company.address_updated",
    entityType: "companyAddress",
    entityId: String(addressId),
    beforeJson: JSON.stringify(before[0]),
    afterJson: JSON.stringify(after[0]),
  });
  return after[0];
}

export async function ensureApprovedDriverProfilesWithDb(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>
) {
  const approvedUsers = await db
    .select({ id: users.id })
    .from(users)
    .where(
      and(
        eq(users.role, "driver"),
        eq(users.status, "active"),
        eq(users.approvalStatus, "approved")
      )
    );
  let readyProfiles = 0;
  for (const user of approvedUsers) {
    const profile = await db
      .select({
        id: drivers.id,
        vehicleLabel: drivers.vehicleLabel,
        licenseNumber: drivers.licenseNumber,
      })
      .from(drivers)
      .where(eq(drivers.userId, user.id))
      .limit(1);
    if (profile[0]?.vehicleLabel?.trim() && profile[0]?.licenseNumber?.trim()) {
      await db
        .update(drivers)
        .set({ active: true })
        .where(eq(drivers.userId, user.id));
      readyProfiles += 1;
    }
  }
  return readyProfiles;
}

export async function listActiveDriversWithDb(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>
) {
  await ensureApprovedDriverProfilesWithDb(db);
  const rows = await db
    .select({
      id: drivers.id,
      userId: users.id,
      name: users.name,
      civilId: users.civilId,
      phone: users.phone,
      vehicleLabel: drivers.vehicleLabel,
      licenseNumber: drivers.licenseNumber,
      vehicleType: drivers.vehicleType,
    })
    .from(drivers)
    .innerJoin(users, eq(drivers.userId, users.id))
    .where(
      and(
        eq(drivers.active, true),
        eq(users.role, "driver"),
        eq(users.status, "active"),
        eq(users.approvalStatus, "approved")
      )
    )
    .orderBy(desc(users.name));
  return rows.filter(row => Boolean(row.vehicleLabel?.trim()));
}

export async function listActiveDrivers() {
  const db = await getDb();
  if (!db) return [];
  return listActiveDriversWithDb(db);
}

export async function listFinanceFilterOptions() {
  const db = await getDb();
  if (!db) return { companies: [], drivers: [] };
  const [companyRows, driverRows] = await Promise.all([
    db
      .select({ id: companies.id, name: companies.name })
      .from(companies)
      .orderBy(asc(companies.name)),
    db
      .select({ id: drivers.id, name: users.name })
      .from(drivers)
      .innerJoin(users, eq(drivers.userId, users.id))
      .orderBy(asc(users.name)),
  ]);
  return {
    companies: companyRows,
    drivers: driverRows.map(driver => ({
      id: driver.id,
      name: driver.name ?? "—",
    })),
  };
}

export async function listActiveShiftDrivers() {
  const db = await getDb();
  if (!db) return [];
  const rows = await db
    .select({
      id: drivers.id,
      userId: users.id,
      name: users.name,
      phone: users.phone,
      vehicleLabel: drivers.vehicleLabel,
      licenseNumber: drivers.licenseNumber,
      vehicleType: drivers.vehicleType,
      shiftStartedAt: shifts.startedAt,
    })
    .from(drivers)
    .innerJoin(users, eq(drivers.userId, users.id))
    .innerJoin(shifts, eq(shifts.driverId, drivers.id))
    .where(
      and(
        eq(drivers.active, true),
        eq(users.role, "driver"),
        eq(users.status, "active"),
        eq(users.approvalStatus, "approved"),
        isNull(shifts.endedAt)
      )
    )
    .orderBy(desc(users.name));
  return rows
    .filter(row =>
      Boolean(row.vehicleLabel?.trim() && row.licenseNumber?.trim())
    )
    .filter(
      (row, index, all) =>
        all.findIndex(candidate => candidate.id === row.id) === index
    );
}

export async function listActiveCompanies() {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: companies.id,
      name: companies.name,
      code: companies.code,
      address: companies.address,
      phone: companies.phone,
      defaultDeliveryFee: companies.defaultDeliveryFee,
    })
    .from(companies)
    .where(eq(companies.status, "active"))
    .orderBy(asc(companies.name));
}

export async function getDriverForUser(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(drivers)
    .where(eq(drivers.userId, userId))
    .limit(1);
  return result[0];
}

export async function driverOwnsOrder(userId: number, orderId: number) {
  const db = await getDb();
  if (!db) return false;
  const result = await db
    .select({ id: orders.id })
    .from(orders)
    .innerJoin(drivers, eq(orders.assignedDriverId, drivers.id))
    .where(and(eq(orders.id, orderId), eq(drivers.userId, userId)))
    .limit(1);
  return Boolean(result[0]);
}

export async function driverOwnsShift(userId: number, shiftId: number) {
  const db = await getDb();
  if (!db) return false;
  const result = await db
    .select({ id: shifts.id })
    .from(shifts)
    .innerJoin(drivers, eq(shifts.driverId, drivers.id))
    .where(and(eq(shifts.id, shiftId), eq(drivers.userId, userId)))
    .limit(1);
  return Boolean(result[0]);
}

export async function createTrip(
  driverId: number,
  label: string | undefined,
  actorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const driver = await db
    .select({ id: drivers.id })
    .from(drivers)
    .where(eq(drivers.id, driverId))
    .limit(1);
  if (!driver[0]) throw new Error("Driver not found");
  const result = await db
    .insert(trips)
    .values({ driverId, label, status: "open" });
  const tripId = Number(result[0].insertId);
  await db.insert(auditLogs).values({
    actorUserId,
    action: "trip.created",
    entityType: "trip",
    entityId: String(tripId),
    afterJson: JSON.stringify({ driverId, label }),
  });
  return { tripId, driverId, label, status: "open" as const };
}

export async function listDriverTrips(driverId: number) {
  const db = await getDb();
  if (!db) return [];
  const tripRows = await db
    .select()
    .from(trips)
    .where(eq(trips.driverId, driverId))
    .orderBy(desc(trips.createdAt))
    .limit(50);
  if (!tripRows.length) return [];
  const tripOrders = await db
    .select()
    .from(orders)
    .where(
      inArray(
        orders.tripId,
        tripRows.map(trip => trip.id)
      )
    )
    .orderBy(desc(orders.createdAt));
  return tripRows.map(trip => ({
    ...trip,
    orders: tripOrders.filter(order => order.tripId === trip.id),
  }));
}

export async function updateTripStatus(
  tripId: number,
  status: "active" | "closed",
  actorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const before = await db
    .select()
    .from(trips)
    .where(eq(trips.id, tripId))
    .limit(1);
  if (!before[0]) throw new Error("Trip not found");
  if (!canTransitionTrip(before[0].status, status))
    throw new Error("انتقال حالة الرحلة غير مسموح");
  const patch =
    status === "active"
      ? { status, startedAt: new Date() }
      : { status, endedAt: new Date() };
  await db.update(trips).set(patch).where(eq(trips.id, tripId));
  await db.insert(auditLogs).values({
    actorUserId,
    action: `trip.${status}`,
    entityType: "trip",
    entityId: String(tripId),
    beforeJson: JSON.stringify(before[0]),
    afterJson: JSON.stringify(patch),
  });
  return { tripId, status };
}

export async function addOrderToTrip(
  orderId: number,
  tripId: number,
  actorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const trip = await db
    .select()
    .from(trips)
    .where(eq(trips.id, tripId))
    .limit(1);
  const order = await db
    .select()
    .from(orders)
    .where(eq(orders.id, orderId))
    .limit(1);
  if (!trip[0] || !order[0]) throw new Error("Trip or order not found");
  if (!canAddOrderToTrip(order[0].status, trip[0].status))
    throw new Error("لا يمكن إضافة الطلب إلى هذه الرحلة في حالته الحالية");
  await db
    .update(orders)
    .set({ tripId, assignedDriverId: trip[0].driverId, status: "assigned" })
    .where(eq(orders.id, orderId));
  await db.insert(orderEvents).values({
    orderId,
    type: "assigned",
    actorUserId,
    note: `Added to trip ${tripId}`,
  });
  await db.insert(auditLogs).values({
    actorUserId,
    action: "trip.order_added",
    entityType: "trip",
    entityId: String(tripId),
    beforeJson: JSON.stringify({ orderId, tripId: order[0].tripId }),
    afterJson: JSON.stringify({
      orderId,
      tripId,
      driverId: trip[0].driverId,
    }),
  });
  return { orderId, tripId, driverId: trip[0].driverId };
}

export async function listDriverOrders(
  driverId: number,
  includeDeliveryFee = false
) {
  const db = await getDb();
  if (!db) return [];
  const joinedRows = await db
    .select({
      order: orders,
      companyName: companies.name,
      companyPhone: companies.phone,
      driverName: users.name,
      driverPhone: users.phone,
    })
    .from(orders)
    .leftJoin(companies, eq(orders.companyId, companies.id))
    .leftJoin(drivers, eq(orders.assignedDriverId, drivers.id))
    .leftJoin(users, eq(drivers.userId, users.id))
    .where(eq(orders.assignedDriverId, driverId))
    .orderBy(desc(orders.createdAt))
    .limit(100);
  if (!joinedRows.length) return [];
  const locatedOrders = await attachOrderLocationNames(
    db,
    joinedRows.map(({ order }) => order)
  );
  const rows = joinedRows.map(
    ({ companyName, companyPhone, driverName, driverPhone }, index) => {
      const {
        deliveryFee,
        companyShare: _hiddenCompanyShare,
        driverCommissionManual: _commissionPolicy,
        companyShareManual: _sharePolicy,
        compensationInitialized: _initialized,
        returnedToCompany: _returnState,
        ...operationalOrder
      } = locatedOrders[index];
      return {
        ...operationalOrder,
        ...(includeDeliveryFee ? { deliveryFee } : {}),
        companyName: companyName ?? null,
        companyPhone: companyPhone ?? null,
        driverName: driverName ?? null,
        driverPhone: driverPhone ?? null,
      };
    }
  );
  const orderIds = rows.map(row => row.id);
  const media = await db
    .select({
      orderId: orderMedia.orderId,
      kind: orderMedia.kind,
      fileUrl: orderMedia.fileUrl,
      createdAt: orderMedia.createdAt,
    })
    .from(orderMedia)
    .where(inArray(orderMedia.orderId, orderIds))
    .orderBy(desc(orderMedia.createdAt));
  const events = await db
    .select({
      orderId: orderEvents.orderId,
      action: orderEvents.type,
      createdAt: orderEvents.occurredAt,
      note: orderEvents.note,
    })
    .from(orderEvents)
    .where(inArray(orderEvents.orderId, orderIds))
    .orderBy(desc(orderEvents.occurredAt));
  const audit = await db
    .select({
      orderId: sql<number>`cast(${auditLogs.entityId} as unsigned)`,
      action: auditLogs.action,
      createdAt: auditLogs.createdAt,
      afterJson: auditLogs.afterJson,
    })
    .from(auditLogs)
    .where(
      and(
        eq(auditLogs.entityType, "order"),
        inArray(auditLogs.entityId, orderIds.map(String))
      )
    )
    .orderBy(desc(auditLogs.createdAt));
  const transferRows = await db
    .select({
      orderId: orderTransfers.orderId,
      transferredAt: orderTransfers.transferredAt,
      transferredByName: users.name,
    })
    .from(orderTransfers)
    .leftJoin(users, eq(orderTransfers.transferredByUserId, users.id))
    .where(inArray(orderTransfers.orderId, orderIds))
    .orderBy(desc(orderTransfers.transferredAt));
  const latestTransferByOrder = new Map<
    number,
    { transferredAt: Date; transferredByName: string | null }
  >();
  for (const transfer of transferRows)
    if (!latestTransferByOrder.has(transfer.orderId))
      latestTransferByOrder.set(transfer.orderId, {
        transferredAt: transfer.transferredAt,
        transferredByName: transfer.transferredByName ?? null,
      });
  return rows.map(row => {
    const transfer = latestTransferByOrder.get(row.id);
    return {
      ...row,
      transferredByName: transfer?.transferredByName ?? null,
      transferredAt: transfer?.transferredAt ?? null,
      media: media.filter(item => item.orderId === row.id),
      history: [
        ...events
          .filter(item => item.orderId === row.id)
          .map(item => ({
            action: String(item.action),
            createdAt: item.createdAt,
            detail: item.note,
          })),
        ...audit
          .filter(item => item.orderId === row.id)
          .map(item => ({
            action: item.action,
            createdAt: item.createdAt,
            detail: item.afterJson,
          })),
      ]
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
        .slice(0, 12),
    };
  });
}

async function getShiftCashCollectionSummary(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>,
  shiftId: number
) {
  const rows = await db
    .select({
      cashCollectedAmount: orders.cashCollectedAmount,
      cashCollectionRecorded: orders.cashCollectionRecorded,
    })
    .from(orders)
    .where(
      and(
        eq(orders.cashCollectedShiftId, shiftId),
        eq(orders.cashCollectionRecorded, true)
      )
    );
  return summarizeCashCollections(rows);
}

export async function getActiveDriverShift(driverId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db
    .select()
    .from(shifts)
    .where(and(eq(shifts.driverId, driverId), isNull(shifts.endedAt)))
    .orderBy(desc(shifts.startedAt))
    .limit(1);
  if (!result[0]) return undefined;
  return {
    ...result[0],
    ...(await getShiftCashCollectionSummary(db, result[0].id)),
  };
}

export async function startDriverShift(
  driverId: number,
  latitude: string | undefined,
  longitude: string | undefined
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const existing = await db
    .select({ id: shifts.id })
    .from(shifts)
    .where(and(eq(shifts.driverId, driverId), isNull(shifts.endedAt)))
    .limit(1);
  if (!canStartDriverShift(Boolean(existing[0])))
    throw new Error("لديك وردية مفعلة بالفعل");
  const result = await db
    .insert(shifts)
    .values(buildShiftStartValues(driverId, latitude, longitude));
  if (latitude && longitude)
    await db.insert(driverLocations).values({ driverId, latitude, longitude });
  return Number(result[0].insertId);
}

export async function endDriverShift(
  shiftId: number,
  latitude: string | undefined,
  longitude: string | undefined
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const current = await db
    .select({ driverId: shifts.driverId })
    .from(shifts)
    .where(eq(shifts.id, shiftId))
    .limit(1);
  if (!current[0]) throw new Error("Shift not found");
  await db
    .update(shifts)
    .set(buildShiftEndValues(latitude, longitude))
    .where(eq(shifts.id, shiftId));
  if (latitude && longitude)
    await db
      .insert(driverLocations)
      .values({ driverId: current[0].driverId, latitude, longitude });
  return { shiftId, ...(await getShiftCashCollectionSummary(db, shiftId)) };
}

export async function updateOrderFee(
  orderId: number,
  deliveryFee: string,
  actorUserId: number
) {
  return updateOrderCompensation({ orderId, deliveryFee }, actorUserId);
}

export async function updateOrderCompensation(
  input: {
    orderId: number;
    deliveryFee?: string;
    driverCommission?: string;
    companyShare?: string;
    deliveryFeeChargeOnFailure?: boolean;
  },
  actorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const before = await db
    .select()
    .from(orders)
    .where(eq(orders.id, input.orderId))
    .limit(1);
  if (!before[0]) throw new Error("Order not found");
  const deliveryFee = input.deliveryFee ?? before[0].deliveryFee;
  const driverCommission = input.driverCommission ?? before[0].driverCommission;
  const share =
    input.companyShare ??
    (!before[0].companyShareManual &&
    !before[0].returnedToCompany &&
    before[0].status === "delivered"
      ? Math.max(0, Number(deliveryFee) - Number(driverCommission)).toFixed(3)
      : before[0].companyShare);
  const changes = {
    ...(input.deliveryFee !== undefined
      ? { deliveryFee, deliveryFeeManual: true }
      : {}),
    ...(input.deliveryFeeChargeOnFailure !== undefined
      ? { deliveryFeeChargeOnFailure: input.deliveryFeeChargeOnFailure }
      : {}),
    ...(input.driverCommission !== undefined
      ? { driverCommission, driverCommissionManual: true }
      : {}),
    ...(input.companyShare !== undefined
      ? { companyShare: input.companyShare, companyShareManual: true }
      : !before[0].companyShareManual &&
          before[0].status === "delivered" &&
          !before[0].returnedToCompany &&
          input.deliveryFee !== undefined
        ? { companyShare: share }
        : {}),
    compensationInitialized: true,
  };
  await db.update(orders).set(changes).where(eq(orders.id, input.orderId));
  await db.insert(orderEvents).values({
    orderId: input.orderId,
    type: "fee_updated",
    actorUserId,
    feeBefore: before[0].deliveryFee,
    feeAfter: deliveryFee,
    note: "Delivery fee and order shares updated",
  });
  const after = {
    deliveryFee,
    driverCommission,
    companyShare: input.companyShare ?? share,
    deliveryFeeChargeOnFailure:
      input.deliveryFeeChargeOnFailure ?? before[0].deliveryFeeChargeOnFailure,
  };
  await db.insert(auditLogs).values({
    actorUserId,
    action: "order.compensation_updated",
    entityType: "order",
    entityId: String(input.orderId),
    beforeJson: JSON.stringify({
      deliveryFee: before[0].deliveryFee,
      driverCommission: before[0].driverCommission,
      companyShare: before[0].companyShare,
      returnedToCompany: before[0].returnedToCompany,
    }),
    afterJson: JSON.stringify(after),
  });
  return { orderId: input.orderId, ...after };
}

export async function updateOrderAddressesWithDb(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>,
  orderId: number,
  input: {
    pickupAddress?: string;
    pickupGovernorateId?: number | null;
    pickupAreaId?: number | null;
    deliveryAddress: string;
    deliveryGovernorateId?: number | null;
    deliveryAreaId?: number | null;
    reason?: string;
  },
  actorUserId: number
) {
  const deliveryAddress = input.deliveryAddress.trim();
  if (deliveryAddress.length < 5)
    throw new Error("عنوان التسليم مطلوب ويجب أن يكون واضحاً");
  const before = await db
    .select({
      id: orders.id,
      pickupAddress: orders.pickupAddress,
      pickupGovernorateId: orders.pickupGovernorateId,
      pickupAreaId: orders.pickupAreaId,
      deliveryAddress: orders.deliveryAddress,
      deliveryGovernorateId: orders.deliveryGovernorateId,
      deliveryAreaId: orders.deliveryAreaId,
    })
    .from(orders)
    .where(eq(orders.id, orderId))
    .limit(1);
  if (!before[0]) throw new Error("Order not found");
  const pickupAddress =
    input.pickupAddress === undefined
      ? before[0].pickupAddress
      : input.pickupAddress.trim() || null;
  if (
    input.pickupAddress !== undefined &&
    pickupAddress &&
    pickupAddress.length < 5
  )
    throw new Error("عنوان الاستلام يجب أن يكون واضحاً");
  for (const [areaId, governorateId] of [
    [input.pickupAreaId, input.pickupGovernorateId],
    [input.deliveryAreaId, input.deliveryGovernorateId],
  ] as const) {
    if (!areaId) continue;
    const area = await db
      .select({ governorateId: deliveryAreas.governorateId })
      .from(deliveryAreas)
      .where(eq(deliveryAreas.id, areaId))
      .limit(1);
    if (!area[0] || (governorateId && area[0].governorateId !== governorateId))
      throw new Error("المنطقة لا تتبع المحافظة المختارة");
  }
  const pickupGovernorateId =
    input.pickupGovernorateId === undefined
      ? before[0].pickupGovernorateId
      : input.pickupGovernorateId;
  const pickupAreaId =
    input.pickupAreaId === undefined
      ? before[0].pickupAreaId
      : input.pickupAreaId;
  const deliveryGovernorateId =
    input.deliveryGovernorateId === undefined
      ? before[0].deliveryGovernorateId
      : input.deliveryGovernorateId;
  const deliveryAreaId =
    input.deliveryAreaId === undefined
      ? before[0].deliveryAreaId
      : input.deliveryAreaId;
  await db
    .update(orders)
    .set({
      pickupAddress,
      pickupGovernorateId,
      pickupAreaId,
      deliveryAddress,
      deliveryGovernorateId,
      deliveryAreaId,
    })
    .where(eq(orders.id, orderId));
  const beforeJson = {
    pickupAddress: before[0].pickupAddress,
    pickupGovernorateId: before[0].pickupGovernorateId,
    pickupAreaId: before[0].pickupAreaId,
    deliveryAddress: before[0].deliveryAddress,
    deliveryGovernorateId: before[0].deliveryGovernorateId,
    deliveryAreaId: before[0].deliveryAreaId,
  };
  const afterJson = {
    pickupAddress,
    pickupGovernorateId,
    pickupAreaId,
    deliveryAddress,
    deliveryGovernorateId,
    deliveryAreaId,
    reason: input.reason?.trim() || null,
  };
  await db.insert(orderEvents).values({
    orderId,
    type: "address_updated",
    actorUserId,
    addressBefore: JSON.stringify(beforeJson),
    addressAfter: JSON.stringify(afterJson),
    note: input.reason?.trim() || "Order addresses updated",
  });
  await db.insert(auditLogs).values({
    actorUserId,
    action: "order.address_updated",
    entityType: "order",
    entityId: String(orderId),
    beforeJson: JSON.stringify(beforeJson),
    afterJson: JSON.stringify(afterJson),
  });
  return { orderId, pickupAddress, deliveryAddress };
}

export async function updateOrderAddresses(
  orderId: number,
  input: {
    pickupAddress?: string;
    pickupGovernorateId?: number | null;
    pickupAreaId?: number | null;
    deliveryAddress: string;
    deliveryGovernorateId?: number | null;
    deliveryAreaId?: number | null;
    reason?: string;
  },
  actorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  return updateOrderAddressesWithDb(db, orderId, input, actorUserId);
}

export async function getFinancialSummary() {
  const db = await getDb();
  if (!db) return { deliveredOrders: 0, totalFees: "0.000", byArea: [] };
  const [totals, byArea, recentDelivered] = await Promise.all([
    db
      .select({
        count: sql<number>`count(*)`,
        total: sql<string>`coalesce(sum(deliveryFee), 0)`,
      })
      .from(orders)
      .where(eq(orders.status, "delivered")),
    db
      .select({
        area: orders.area,
        count: sql<number>`count(*)`,
        total: sql<string>`coalesce(sum(deliveryFee), 0)`,
      })
      .from(orders)
      .where(eq(orders.status, "delivered"))
      .groupBy(orders.area)
      .orderBy(desc(sql`count(*)`))
      .limit(20),
    db
      .select({
        id: orders.id,
        orderNumber: orders.orderNumber,
        pickupAddress: orders.pickupAddress,
        deliveryAddress: orders.deliveryAddress,
        deliveryFee: orders.deliveryFee,
        area: orders.area,
      })
      .from(orders)
      .where(eq(orders.status, "delivered"))
      .orderBy(desc(orders.updatedAt))
      .limit(10),
  ]);
  return {
    deliveredOrders: Number(totals[0]?.count ?? 0),
    totalFees: String(totals[0]?.total ?? "0.000"),
    byArea: byArea.map(row => ({
      area: row.area ?? "غير محدد",
      count: Number(row.count),
      total: String(row.total),
    })),
    recentDelivered,
  };
}

export async function getFinancialReport(
  filters: {
    area?: string;
    status?: "assigned" | "picked_up" | "in_transit" | "delivered" | "failed";
    fromDate?: string;
    toDate?: string;
  } = {}
) {
  const db = await getDb();
  if (!db)
    return { deliveredOrders: 0, totalFees: "0.000", rows: [], history: [] };
  const conditions = [] as ReturnType<typeof eq>[];
  if (filters.area && filters.area !== "all")
    conditions.push(eq(orders.area, filters.area));
  if (filters.status) conditions.push(eq(orders.status, filters.status));
  if (filters.fromDate)
    conditions.push(
      gte(orders.updatedAt, new Date(`${filters.fromDate}T00:00:00.000Z`))
    );
  if (filters.toDate)
    conditions.push(
      lte(orders.updatedAt, new Date(`${filters.toDate}T23:59:59.999Z`))
    );
  const where = conditions.length ? and(...conditions) : undefined;
  const rows = await db
    .select({
      id: orders.id,
      orderNumber: orders.orderNumber,
      status: orders.status,
      area: orders.area,
      companyId: orders.companyId,
      assignedDriverId: orders.assignedDriverId,
      pickupAddress: orders.pickupAddress,
      deliveryAddress: orders.deliveryAddress,
      deliveryFee: orders.deliveryFee,
      updatedAt: orders.updatedAt,
      requestedVehicleType: orders.requestedVehicleType,
    })
    .from(orders)
    .where(where)
    .orderBy(desc(orders.updatedAt))
    .limit(200);
  const totals = await db
    .select({
      count: sql<number>`count(*)`,
      total: sql<string>`coalesce(sum(${orders.deliveryFee}), 0)`,
    })
    .from(orders)
    .where(where);
  const history = await db
    .select({
      id: auditLogs.id,
      actorUserId: auditLogs.actorUserId,
      actorName: users.name,
      entityId: auditLogs.entityId,
      beforeJson: auditLogs.beforeJson,
      afterJson: auditLogs.afterJson,
      createdAt: auditLogs.createdAt,
    })
    .from(auditLogs)
    .leftJoin(users, eq(auditLogs.actorUserId, users.id))
    .where(eq(auditLogs.action, "order.fee_updated"))
    .orderBy(desc(auditLogs.createdAt))
    .limit(100);
  return {
    deliveredOrders: Number(totals[0]?.count ?? 0),
    totalFees: String(totals[0]?.total ?? "0.000"),
    rows,
    history,
  };
}

async function findOrCreateAutomaticTrip(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>,
  order: typeof orders.$inferSelect,
  driverId: number,
  actorUserId: number
) {
  const openTrips = await db
    .select()
    .from(trips)
    .where(and(eq(trips.driverId, driverId), eq(trips.status, "open")))
    .orderBy(desc(trips.createdAt))
    .limit(20);
  const pickup = order.pickupAddress;
  const candidateTripIds = openTrips.map(trip => trip.id);
  const existingOrders = candidateTripIds.length
    ? await db
        .select()
        .from(orders)
        .where(inArray(orders.tripId, candidateTripIds))
        .orderBy(orders.createdAt)
    : [];
  const matchingTrip = openTrips.find(trip => {
    const tripOrders = existingOrders.filter(item => item.tripId === trip.id);
    if (!tripOrders.length) return true;
    return tripOrders.some(item =>
      canGroupOrdersInAutomaticTrip({
        pickupAddress: pickup,
        candidatePickupAddress: item.pickupAddress,
        pickupScheduledAt: order.pickupScheduledAt,
        candidatePickupScheduledAt: item.pickupScheduledAt,
      })
    );
  });
  if (matchingTrip) return matchingTrip.id;
  const label = `رحلة تلقائية${order.area ? ` · ${order.area}` : pickup ? ` · ${order.pickupAddress?.slice(0, 48)}` : ""}`;
  const created = await db
    .insert(trips)
    .values({ driverId, label, status: "open" });
  const automaticTripId = Number(created[0].insertId);
  await db.insert(auditLogs).values({
    actorUserId,
    action: "trip.auto_created",
    entityType: "trip",
    entityId: String(automaticTripId),
    afterJson: JSON.stringify({
      driverId,
      orderId: order.id,
      pickupAddress: order.pickupAddress,
      pickupScheduledAt: order.pickupScheduledAt,
      deliveryScheduledAt: order.deliveryScheduledAt,
    }),
  });
  return automaticTripId;
}

export async function assignOrderWithDb(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>,
  orderId: number,
  driverId: number,
  actorUserId: number,
  tripId?: number
) {
  const before = await db
    .select()
    .from(orders)
    .where(eq(orders.id, orderId))
    .limit(1);
  if (!before[0]) throw new Error("Order not found");
  const commission = await getCommissionForOrder(
    db,
    driverId,
    before[0].companyId,
    before[0].deliveryAreaId
  );
  const shares = initialOrderShares({
    deliveryFee: before[0].deliveryFee,
    driverCommission: commission,
  });
  await db
    .update(orders)
    .set({
      assignedDriverId: driverId,
      tripId: null,
      status: "assigned",
      returnedToCompany: false,
      driverCommission: shares.driverCommission,
      companyShare: shares.companyShare,
      driverCommissionManual: false,
      companyShareManual: false,
      compensationInitialized: true,
    })
    .where(eq(orders.id, orderId));
  await db.insert(orderEvents).values({
    orderId,
    type: "assigned",
    actorUserId,
    note: `تم إسناد الطلب للسائق ${driverId}`,
  });
  await db.insert(auditLogs).values({
    actorUserId,
    action: "order.assigned",
    entityType: "order",
    entityId: String(orderId),
    beforeJson: JSON.stringify(before[0]),
    afterJson: JSON.stringify({
      driverId,
      tripId: null,
      automaticTrip: false,
    }),
  });
  const driver = await db
    .select({ userId: drivers.userId })
    .from(drivers)
    .where(eq(drivers.id, driverId))
    .limit(1);
  if (driver[0]?.userId)
    await db.insert(notifications).values({
      userId: driver[0].userId,
      title: "طلب جديد مسند إليك",
      body: `تم إسناد الطلب رقم ${before[0].orderNumber} إليك.`,
      link: `/orders/${orderId}`,
    });
  return { orderId, driverId, tripId: null, automaticTrip: false };
}

export async function assignOrder(
  orderId: number,
  driverId: number,
  actorUserId: number,
  tripId?: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  return assignOrderWithDb(db, orderId, driverId, actorUserId, tripId);
}

export async function listOrderEvents(orderId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(orderEvents)
    .where(eq(orderEvents.orderId, orderId))
    .orderBy(desc(orderEvents.occurredAt));
}

export async function listOrderTransfers(orderId: number) {
  const db = await getDb();
  if (!db) return [];
  const rows = await db
    .select()
    .from(orderTransfers)
    .where(eq(orderTransfers.orderId, orderId))
    .orderBy(desc(orderTransfers.transferredAt));
  const driverIds = Array.from(
    new Set(
      rows
        .flatMap(row => [row.fromDriverId, row.toDriverId])
        .filter((id): id is number => Boolean(id))
    )
  );
  const names = driverIds.length
    ? await db
        .select({ id: drivers.id, name: users.name })
        .from(drivers)
        .innerJoin(users, eq(drivers.userId, users.id))
        .where(inArray(drivers.id, driverIds))
    : [];
  return rows.map(row => ({
    ...row,
    fromDriverName:
      names.find(item => item.id === row.fromDriverId)?.name ?? null,
    toDriverName: names.find(item => item.id === row.toDriverId)?.name ?? null,
  }));
}

export async function transferOrderWithDb(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>,
  orderId: number,
  toDriverId: number,
  actorUserId: number,
  reason?: string,
  tripId?: number | null
) {
  const before = await db
    .select()
    .from(orders)
    .where(eq(orders.id, orderId))
    .limit(1);
  if (!before[0]) throw new Error("Order not found");
  const fromDriverId = before[0].assignedDriverId ?? undefined;
  const transferor = await db
    .select({ name: users.name })
    .from(users)
    .where(eq(users.id, actorUserId))
    .limit(1);
  const transferorName = transferor[0]?.name?.trim() || "مسؤول التشغيل";
  await db
    .update(orders)
    .set({
      assignedDriverId: toDriverId,
      tripId: null,
      status: before[0].status,
    })
    .where(eq(orders.id, orderId));
  await db.insert(orderTransfers).values({
    orderId,
    fromDriverId,
    toDriverId,
    transferredByUserId: actorUserId,
    reason,
  });
  await db.insert(orderEvents).values({
    orderId,
    type: "transferred",
    actorUserId,
    note: `تم تحويل الطلب من ${transferorName}${reason ? `: ${reason}` : ""}`,
  });
  const transferDriverIds = [fromDriverId, toDriverId].filter(
    (id): id is number => Boolean(id)
  );
  const transferDrivers = transferDriverIds.length
    ? await db
        .select({ id: drivers.id, name: users.name })
        .from(drivers)
        .innerJoin(users, eq(drivers.userId, users.id))
        .where(inArray(drivers.id, transferDriverIds))
    : [];
  const fromDriverName =
    transferDrivers.find(driver => driver.id === fromDriverId)?.name ?? null;
  const toDriverName =
    transferDrivers.find(driver => driver.id === toDriverId)?.name ?? null;
  await db.insert(auditLogs).values({
    actorUserId,
    action: "order.transferred",
    entityType: "order",
    entityId: String(orderId),
    beforeJson: JSON.stringify(before[0]),
    afterJson: JSON.stringify({
      fromDriverId,
      fromDriverName,
      toDriverId,
      toDriverName,
      transferredByName: transferorName,
      tripId: null,
      reason,
      preservedMediaAndHistory: true,
    }),
  });
  const driver = await db
    .select({ userId: drivers.userId })
    .from(drivers)
    .where(eq(drivers.id, toDriverId))
    .limit(1);
  if (driver[0]?.userId)
    await db.insert(notifications).values({
      userId: driver[0].userId,
      title: "تم تحويل طلب إليك",
      body: `الطلب رقم ${before[0].orderNumber} محول من ${transferorName}.`,
      link: `/orders/${orderId}`,
    });
  return { orderId, fromDriverId, toDriverId, transferorName };
}

export async function transferOrder(
  orderId: number,
  toDriverId: number,
  actorUserId: number,
  reason?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  return transferOrderWithDb(db, orderId, toDriverId, actorUserId, reason);
}

export async function transferDriverOrder(
  orderId: number,
  fromDriverId: number,
  toDriverId: number,
  actorUserId: number,
  reason?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  if (fromDriverId === toDriverId)
    throw new Error("لا يمكن تحويل الطلب إلى نفس السائق");
  const order = await db
    .select({ id: orders.id, assignedDriverId: orders.assignedDriverId })
    .from(orders)
    .where(eq(orders.id, orderId))
    .limit(1);
  if (!order[0]) throw new Error("Order not found");
  if (order[0].assignedDriverId !== fromDriverId)
    throw new Error("الطلب غير مسند إلى حسابك");
  const currentStatus = await db
    .select({ status: orders.status })
    .from(orders)
    .where(eq(orders.id, orderId))
    .limit(1);
  if (
    currentStatus[0]?.status === "delivered" ||
    currentStatus[0]?.status === "failed"
  )
    throw new Error("لا يمكن تحويل طلب مكتمل أو مغلق");
  const target = await db
    .select({ driverId: drivers.id })
    .from(drivers)
    .innerJoin(users, eq(drivers.userId, users.id))
    .innerJoin(shifts, eq(shifts.driverId, drivers.id))
    .where(
      and(
        eq(drivers.id, toDriverId),
        eq(drivers.active, true),
        eq(users.role, "driver"),
        eq(users.status, "active"),
        eq(users.approvalStatus, "approved"),
        isNull(shifts.endedAt)
      )
    )
    .limit(1);
  if (!target[0])
    throw new Error("السائق المختار ليس لديه وردية مفتوحة أو غير معتمد");
  return transferOrderWithDb(
    db,
    orderId,
    toDriverId,
    actorUserId,
    reason,
    null
  );
}

export async function updateOrderStatusWithDb(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>,
  orderId: number,
  status: "assigned" | "picked_up" | "in_transit" | "delivered" | "failed",
  actorUserId: number,
  failureReason?:
    | "no_answer"
    | "not_present"
    | "wrong_address"
    | "postponed"
    | "refused"
    | "address_changed"
    | "other",
  latitude?: string,
  longitude?: string,
  note?: string,
  cashCollectedAmount?: string
) {
  const before = await db
    .select()
    .from(orders)
    .where(eq(orders.id, orderId))
    .limit(1);
  if (!before[0]) throw new Error("Order not found");
  const changes: Partial<typeof orders.$inferInsert> = { status };
  if (cashCollectedAmount !== undefined) {
    if (status !== "delivered" || before[0].status !== "in_transit")
      throw new Error("لا يمكن تسجيل التحصيل إلا عند إتمام تسليم الطلب");
    if (
      !/^\d{1,9}(\.\d{1,3})?$/.test(cashCollectedAmount) ||
      !Number.isFinite(Number(cashCollectedAmount)) ||
      Number(cashCollectedAmount) >= 1_000_000_000
    )
      throw new Error("مبلغ التحصيل غير صالح");
    const openShift = before[0].assignedDriverId
      ? await db
          .select({ id: shifts.id })
          .from(shifts)
          .where(
            and(
              eq(shifts.driverId, before[0].assignedDriverId),
              isNull(shifts.endedAt)
            )
          )
          .orderBy(desc(shifts.startedAt))
          .limit(1)
      : [];
    if (!openShift[0])
      throw new Error(
        "ابدأ النوبة قبل إنهاء الطلب حتى يُسجل مبلغ التحصيل ضمن حساب النوبة"
      );
    changes.cashCollectedAmount = cashCollectedAmount;
    changes.cashCollectionRecorded = true;
    changes.cashCollectedAt = new Date();
    changes.cashCollectedByUserId = actorUserId;
    changes.cashCollectedShiftId = openShift[0]?.id ?? null;
  }
  if (status === "delivered") {
    changes.returnedToCompany = false;
    if (!before[0].driverCommissionManual)
      changes.driverCommission = (
        await getCommissionForOrder(
          db,
          before[0].assignedDriverId,
          before[0].companyId,
          before[0].deliveryAreaId
        )
      ).toFixed(3);
    const commission = changes.driverCommission ?? before[0].driverCommission;
    if (!before[0].companyShareManual)
      changes.companyShare = Math.max(
        0,
        Number(before[0].deliveryFee) - Number(commission)
      ).toFixed(3);
    changes.compensationInitialized = true;
  }
  if (status === "failed") {
    changes.failureReason = failureReason ?? "other";
    changes.failureNote = note?.trim() || null;
    if (!before[0].driverCommissionManual) changes.driverCommission = "0.000";
    if (!before[0].companyShareManual) changes.companyShare = "0.000";
    changes.compensationInitialized = true;
  }
  await db.update(orders).set(changes).where(eq(orders.id, orderId));
  const eventType = status === "assigned" ? "assigned" : status;
  await db.insert(orderEvents).values({
    orderId,
    type: eventType,
    actorUserId,
    latitude,
    longitude,
    note,
  });
  await db.insert(auditLogs).values({
    actorUserId,
    action: `order.${status}`,
    entityType: "order",
    entityId: String(orderId),
    beforeJson: JSON.stringify(before[0]),
    afterJson: JSON.stringify({ status, latitude, longitude, note }),
  });
  return { orderId, status };
}

export async function returnOrderToCompany(
  orderId: number,
  actorUserId: number,
  note?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const before = await db
    .select()
    .from(orders)
    .where(eq(orders.id, orderId))
    .limit(1);
  if (!before[0]) throw new Error("Order not found");
  if (!["picked_up", "in_transit"].includes(before[0].status))
    throw new Error("يمكن إرجاع الطلب بعد استلامه فقط");
  await db
    .update(orders)
    .set({
      status: "failed",
      returnedToCompany: true,
      driverCommission: "0.000",
      companyShare: "0.000",
      driverCommissionManual: false,
      companyShareManual: false,
      compensationInitialized: true,
      failureNote: note?.trim() || "تم إرجاع الطلب إلى الشركة",
    })
    .where(eq(orders.id, orderId));
  await db.insert(orderEvents).values({
    orderId,
    type: "failed",
    actorUserId,
    note: note?.trim() || "تم إرجاع الطلب إلى الشركة",
  });
  await db.insert(auditLogs).values({
    actorUserId,
    action: "order.returned_to_company",
    entityType: "order",
    entityId: String(orderId),
    beforeJson: JSON.stringify(before[0]),
    afterJson: JSON.stringify({
      status: "failed",
      returnedToCompany: true,
      driverCommission: "0.000",
      companyShare: "0.000",
    }),
  });
  return { orderId, status: "failed" as const, returnedToCompany: true };
}

export async function updateOrderStatus(
  orderId: number,
  status: "assigned" | "picked_up" | "in_transit" | "delivered" | "failed",
  actorUserId: number,
  failureReason?:
    | "no_answer"
    | "not_present"
    | "wrong_address"
    | "postponed"
    | "refused"
    | "address_changed"
    | "other",
  latitude?: string,
  longitude?: string,
  note?: string,
  cashCollectedAmount?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  return updateOrderStatusWithDb(
    db,
    orderId,
    status,
    actorUserId,
    failureReason,
    latitude,
    longitude,
    note,
    cashCollectedAmount
  );
}

export async function attachOrderMediaWithDb(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>,
  input: {
    orderId: number;
    kind: "order" | "invoice" | "delivery";
    fileKey: string;
    fileUrl: string;
  },
  actorUserId: number
) {
  await db.insert(orderMedia).values({
    orderId: input.orderId,
    kind: input.kind,
    fileKey: input.fileKey,
    fileUrl: input.fileUrl,
    uploadedByUserId: actorUserId,
  });
  await db.insert(auditLogs).values({
    actorUserId,
    action: "order.media_attached",
    entityType: "order",
    entityId: String(input.orderId),
    afterJson: JSON.stringify({ kind: input.kind, fileKey: input.fileKey }),
  });
}

export async function attachOrderMedia(
  input: {
    orderId: number;
    kind: "order" | "invoice" | "delivery";
    fileKey: string;
    fileUrl: string;
  },
  actorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  return attachOrderMediaWithDb(db, input, actorUserId);
}

async function allocateNextOrderNumber(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>
) {
  await getPlatformSettingsWithDb(db);
  let allocated = "";
  await db.transaction(async tx => {
    const rows = await tx
      .select({
        orderNumberFormat: platformSettings.orderNumberFormat,
        nextOrderNumber: platformSettings.nextOrderNumber,
      })
      .from(platformSettings)
      .where(eq(platformSettings.id, 1))
      .for("update")
      .limit(1);
    const settings = rows[0];
    if (!settings) throw new Error("تعذر تحميل إعدادات تسلسل الطلبات");

    let candidate = Math.max(1, Number(settings.nextOrderNumber));
    for (let attempt = 0; attempt < 10_000; attempt += 1) {
      if (candidate >= 2_147_483_647)
        throw new Error(
          "وصل تسلسل الطلبات إلى الحد الأعلى؛ غيّر رقم البداية من الإعدادات"
        );
      const orderNumber = formatOrderNumber(
        candidate,
        settings.orderNumberFormat
      );
      const existing = await tx
        .select({ id: orders.id })
        .from(orders)
        .where(eq(orders.orderNumber, orderNumber))
        .limit(1);
      if (!existing[0]) {
        await tx
          .update(platformSettings)
          .set({ nextOrderNumber: candidate + 1 })
          .where(eq(platformSettings.id, 1));
        allocated = orderNumber;
        return;
      }
      candidate += 1;
    }
    throw new Error("تعذر العثور على رقم طلب متاح");
  });
  return allocated;
}

export async function createOrder(
  input: {
    companyId?: number;
    source: "supervisor" | "company" | "external";
    customerName?: string;
    customerPhone?: string;
    pickupContactName?: string;
    pickupAddress?: string;
    pickupPhone?: string;
    pickupLocationUrl?: string;
    pickupGovernorateId?: number;
    pickupAreaId?: number;
    pickupScheduledAt?: string;
    deliveryAddress: string;
    deliveryScheduledAt?: string;
    deliveryGovernorateId?: number;
    deliveryAreaId?: number;
    area?: string;
    notes?: string;
    cashToCollectAmount?: string;
    cashCollectionNote?: string;
    deliveryFee?: string;
    deliveryFeeChargeOnFailure?: boolean;
    driverCommission?: string;
    companyShare?: string;
    driverId?: number;
  },
  actorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  if (input.driverId) {
    const driver = await db
      .select({ id: drivers.id })
      .from(drivers)
      .innerJoin(users, eq(drivers.userId, users.id))
      .where(
        and(
          eq(drivers.id, input.driverId),
          eq(drivers.active, true),
          eq(users.role, "driver"),
          eq(users.status, "active"),
          eq(users.approvalStatus, "approved")
        )
      )
      .limit(1);
    if (!driver[0]) throw new Error("السائق غير متاح أو غير معتمد");
  }
  if (
    input.source === "external" &&
    (!input.pickupAddress || input.pickupAddress.trim().length < 5)
  )
    throw new Error("عنوان الاستلام مطلوب للطلب الخارجي");
  const company = input.companyId
    ? await db
        .select({
          id: companies.id,
          address: companies.address,
          status: companies.status,
          defaultDeliveryFee: companies.defaultDeliveryFee,
        })
        .from(companies)
        .where(
          and(eq(companies.id, input.companyId), eq(companies.status, "active"))
        )
        .limit(1)
    : [];
  if (input.companyId && !company[0])
    throw new Error("الشركة غير موجودة أو غير نشطة");
  const pickupAddress =
    input.pickupAddress ??
    (input.source === "supervisor"
      ? (company[0]?.address ?? undefined)
      : undefined);
  const deliveryFee =
    input.deliveryFee ??
    (await resolveCompanyDeliveryFee(
      input.companyId,
      input.deliveryAreaId,
      company[0]?.defaultDeliveryFee ?? "0.000",
      input.deliveryGovernorateId
    ));
  const defaultCommission = input.driverId
    ? await getCommissionForOrder(
        db,
        input.driverId,
        input.companyId,
        input.deliveryAreaId
      )
    : 0;
  const shares = initialOrderShares({
    deliveryFee,
    driverCommission: input.driverCommission ?? defaultCommission,
  });
  if (input.companyShare !== undefined)
    shares.companyShare = Number(input.companyShare).toFixed(3);
  const orderNumber = await allocateNextOrderNumber(db);
  const result = await db.insert(orders).values({
    orderNumber,
    companyId: input.companyId,
    source: input.source,
    status: input.driverId ? "assigned" : "pending",
    assignedDriverId: input.driverId,
    customerName: input.customerName?.trim() || null,
    customerPhone: input.customerPhone,
    pickupContactName: input.pickupContactName,
    pickupAddress,
    pickupPhone: input.pickupPhone,
    pickupLocationUrl: input.pickupLocationUrl?.trim() || null,
    pickupGovernorateId: input.pickupGovernorateId,
    pickupAreaId: input.pickupAreaId,
    deliveryAddress: input.deliveryAddress,
    deliveryGovernorateId: input.deliveryGovernorateId,
    deliveryAreaId: input.deliveryAreaId,
    pickupScheduledAt: input.pickupScheduledAt
      ? new Date(input.pickupScheduledAt)
      : undefined,
    deliveryScheduledAt: input.deliveryScheduledAt
      ? new Date(input.deliveryScheduledAt)
      : undefined,
    area: input.area,
    notes: input.notes,
    cashToCollectAmount: input.cashToCollectAmount ?? "0.000",
    cashCollectionNote: input.cashCollectionNote?.trim() || null,
    deliveryFee,
    deliveryFeeManual: input.deliveryFee !== undefined,
    deliveryFeeChargeOnFailure: input.deliveryFeeChargeOnFailure ?? false,
    driverCommission: shares.driverCommission,
    companyShare: shares.companyShare,
    driverCommissionManual: input.driverCommission !== undefined,
    companyShareManual: input.companyShare !== undefined,
    compensationInitialized: true,
    createdByUserId: actorUserId,
  });
  const orderId = Number(result[0].insertId);
  await db.insert(orderEvents).values({
    orderId,
    type: "created",
    actorUserId,
    note: `Order created from ${input.source}`,
  });
  await db.insert(auditLogs).values({
    actorUserId,
    action: "order.created",
    entityType: "order",
    entityId: String(orderId),
    afterJson: JSON.stringify({ ...input, orderNumber }),
  });
  return { id: orderId, orderNumber };
}

export async function createCompanyPortalOrder(
  userId: number,
  input: {
    customerName?: string;
    customerPhone?: string;
    pickupAddress: string;
    pickupGovernorateId?: number;
    pickupAreaId?: number;
    pickupScheduledAt?: string;
    deliveryAddress: string;
    deliveryGovernorateId?: number;
    deliveryAreaId?: number;
    deliveryScheduledAt?: string;
    area?: string;
    notes?: string;
    cashToCollectAmount?: string;
    cashCollectionNote?: string;
    requestedVehicleType?:
      | "car"
      | "refrigerated_car"
      | "motorcycle"
      | "semi_truck"
      | "refrigerated_semi_truck"
      | "truck"
      | "refrigerated_truck";
    assignedDriverId?: number;
  }
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const membership = await db
    .select({ companyId: companyUsers.companyId })
    .from(companyUsers)
    .where(eq(companyUsers.userId, userId))
    .limit(1);
  if (!membership[0]) throw new Error("حساب الشركة غير مرتبط بشركة");
  const company = await db
    .select({
      id: companies.id,
      defaultDeliveryFee: companies.defaultDeliveryFee,
      status: companies.status,
      portalEnabled: companies.portalEnabled,
    })
    .from(companies)
    .where(eq(companies.id, membership[0].companyId))
    .limit(1);
  if (
    !company[0] ||
    company[0].status !== "active" ||
    !company[0].portalEnabled
  )
    throw new Error("بوابة الشركة غير مفعلة");
  const deliveryFee = await resolveCompanyDeliveryFee(
    company[0].id,
    input.deliveryAreaId,
    company[0].defaultDeliveryFee,
    input.deliveryGovernorateId
  );
  const orderNumber = await allocateNextOrderNumber(db);
  const result = await db.insert(orders).values({
    orderNumber,
    companyId: company[0].id,
    source: "company",
    status: input.assignedDriverId ? "assigned" : "pending",
    assignedDriverId: input.assignedDriverId,
    requestedVehicleType: input.requestedVehicleType,
    customerName: input.customerName?.trim() || null,
    customerPhone: input.customerPhone,
    pickupAddress: input.pickupAddress,
    pickupGovernorateId: input.pickupGovernorateId,
    pickupAreaId: input.pickupAreaId,
    pickupScheduledAt: input.pickupScheduledAt
      ? new Date(input.pickupScheduledAt)
      : undefined,
    deliveryAddress: input.deliveryAddress,
    deliveryGovernorateId: input.deliveryGovernorateId,
    deliveryAreaId: input.deliveryAreaId,
    deliveryScheduledAt: input.deliveryScheduledAt
      ? new Date(input.deliveryScheduledAt)
      : undefined,
    area: input.area,
    notes: input.notes,
    cashToCollectAmount: input.cashToCollectAmount ?? "0.000",
    cashCollectionNote: input.cashCollectionNote?.trim() || null,
    deliveryFee,
    companyShare: deliveryFee,
    compensationInitialized: true,
    createdByUserId: userId,
  });
  const orderId = Number(result[0].insertId);
  await db.insert(orderEvents).values({
    orderId,
    type: "created",
    actorUserId: userId,
    note: "Order created from company portal",
  });
  await db.insert(auditLogs).values({
    actorUserId: userId,
    action: "company.order_created",
    entityType: "order",
    entityId: String(orderId),
    afterJson: JSON.stringify({
      companyId: company[0].id,
      orderNumber,
      source: "company",
    }),
  });
  return { id: orderId, orderNumber };
}

export async function listCompanyOrdersForPortalWithDb(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>,
  userId: number,
  permissions: string[]
) {
  const memberships = await db
    .select({ companyId: companyUsers.companyId })
    .from(companyUsers)
    .where(eq(companyUsers.userId, userId));
  const companyIds = memberships.map(membership => membership.companyId);
  if (!companyIds.length) return [];
  const rows = await db
    .select({
      id: orders.id,
      orderNumber: orders.orderNumber,
      companyId: orders.companyId,
      status: orders.status,
      customerName: orders.customerName,
      customerPhone: orders.customerPhone,
      pickupContactName: orders.pickupContactName,
      pickupPhone: orders.pickupPhone,
      pickupAddress: orders.pickupAddress,
      pickupGovernorateId: orders.pickupGovernorateId,
      pickupAreaId: orders.pickupAreaId,
      deliveryAddress: orders.deliveryAddress,
      deliveryGovernorateId: orders.deliveryGovernorateId,
      deliveryAreaId: orders.deliveryAreaId,
      area: orders.area,
      notes: orders.notes,
      cashToCollectAmount: orders.cashToCollectAmount,
      cashCollectionNote: orders.cashCollectionNote,
      cashCollectedAmount: orders.cashCollectedAmount,
      cashCollectionRecorded: orders.cashCollectionRecorded,
      cashCollectedAt: orders.cashCollectedAt,
      createdAt: orders.createdAt,
      updatedAt: orders.updatedAt,
      deliveryFee: orders.deliveryFee,
      requestedVehicleType: orders.requestedVehicleType,
    })
    .from(orders)
    .where(inArray(orders.companyId, companyIds))
    .orderBy(desc(orders.createdAt))
    .limit(100);
  if (!rows.length) return [];
  const allowedKinds = (
    [
      permissions.includes("company_media_pickup") ? "order" : null,
      permissions.includes("company_media_invoice") ? "invoice" : null,
      permissions.includes("company_media_delivery") ? "delivery" : null,
    ] as const
  ).filter((kind): kind is "order" | "invoice" | "delivery" => Boolean(kind));
  if (!allowedKinds.length) {
    const locatedRows = await attachOrderLocationNames(db, rows);
    return locatedRows.map(row => ({ ...row, media: [] }));
  }
  const media = await db
    .select({
      orderId: orderMedia.orderId,
      kind: orderMedia.kind,
      fileUrl: orderMedia.fileUrl,
    })
    .from(orderMedia)
    .where(
      and(
        inArray(
          orderMedia.orderId,
          rows.map(row => row.id)
        ),
        inArray(orderMedia.kind, allowedKinds)
      )
    )
    .orderBy(desc(orderMedia.createdAt));
  const filteredMedia = filterCompanyMediaForPortal(media, permissions);
  const locatedRows = await attachOrderLocationNames(db, rows);
  return locatedRows.map(row => ({
    ...row,
    media: filteredMedia.filter(item => item.orderId === row.id),
  }));
}

export async function listCompanyOrdersForPortal(
  userId: number,
  permissions: string[]
) {
  const db = await getDb();
  if (!db) return [];
  return listCompanyOrdersForPortalWithDb(db, userId, permissions);
}

async function attachOrderLocationNames<
  T extends {
    pickupGovernorateId: number | null;
    pickupAreaId: number | null;
    deliveryGovernorateId: number | null;
    deliveryAreaId: number | null;
  },
>(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>,
  rows: T[]
): Promise<
  Array<
    T & {
      pickupGovernorateName: string | null;
      pickupAreaName: string | null;
      deliveryGovernorateName: string | null;
      deliveryAreaName: string | null;
    }
  >
> {
  if (!rows.length) return [];
  const areaIds = Array.from(
    new Set(
      rows
        .flatMap(row => [row.pickupAreaId, row.deliveryAreaId])
        .filter((id): id is number => Boolean(id))
    )
  );
  const explicitGovernorateIds = rows
    .flatMap(row => [row.pickupGovernorateId, row.deliveryGovernorateId])
    .filter((id): id is number => Boolean(id));
  const areas = areaIds.length
    ? await db
        .select({
          id: deliveryAreas.id,
          governorateId: deliveryAreas.governorateId,
          nameAr: deliveryAreas.nameAr,
        })
        .from(deliveryAreas)
        .where(inArray(deliveryAreas.id, areaIds))
    : [];
  const governorateIds = Array.from(
    new Set([
      ...explicitGovernorateIds,
      ...areas.map(area => area.governorateId),
    ])
  );
  const governorateRows = governorateIds.length
    ? await db
        .select({ id: governorates.id, nameAr: governorates.nameAr })
        .from(governorates)
        .where(inArray(governorates.id, governorateIds))
    : [];
  const labels = buildLocationLabelMaps(
    rows.flatMap(row => [
      { governorateId: row.pickupGovernorateId, areaId: row.pickupAreaId },
      { governorateId: row.deliveryGovernorateId, areaId: row.deliveryAreaId },
    ]),
    governorateRows,
    areas
  );
  return rows.map(row => {
    const pickup = labels.get(
      locationLabelKey({
        governorateId: row.pickupGovernorateId,
        areaId: row.pickupAreaId,
      })
    );
    const delivery = labels.get(
      locationLabelKey({
        governorateId: row.deliveryGovernorateId,
        areaId: row.deliveryAreaId,
      })
    );
    return {
      ...row,
      pickupGovernorateName: pickup?.governorateName ?? null,
      pickupAreaName: pickup?.areaName ?? null,
      deliveryGovernorateName: delivery?.governorateName ?? null,
      deliveryAreaName: delivery?.areaName ?? null,
    };
  });
}

export async function getOrderDetailsWithDb(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>,
  orderId: number
) {
  const order = await db
    .select()
    .from(orders)
    .where(eq(orders.id, orderId))
    .limit(1);
  if (!order[0]) return undefined;
  const media = await db
    .select({
      id: orderMedia.id,
      kind: orderMedia.kind,
      fileUrl: orderMedia.fileUrl,
      uploadedByUserId: orderMedia.uploadedByUserId,
      createdAt: orderMedia.createdAt,
    })
    .from(orderMedia)
    .where(eq(orderMedia.orderId, orderId))
    .orderBy(desc(orderMedia.createdAt));
  const [located] = await attachOrderLocationNames(db, [order[0]]);
  return { ...located, media };
}

export async function getOrderDetails(orderId: number) {
  const db = await getDb();
  if (!db) return undefined;
  return getOrderDetailsWithDb(db, orderId);
}

export async function listRecentOrders(limit = 10) {
  const db = await getDb();
  if (!db) return [];
  const rows = await db
    .select()
    .from(orders)
    .orderBy(desc(orders.createdAt))
    .limit(limit);
  return attachOrderLocationNames(db, rows);
}

export async function getSupervisorOperationalReport(
  filters: {
    fromDate?: string;
    toDate?: string;
    companyId?: number;
    driverId?: number;
    vehicleType?:
      | "car"
      | "refrigerated_car"
      | "motorcycle"
      | "semi_truck"
      | "refrigerated_semi_truck"
      | "truck"
      | "refrigerated_truck";
    unassigned?: boolean;
    governorateId?: number;
    areaId?: number;
    status?:
      | "pending"
      | "assigned"
      | "picked_up"
      | "in_transit"
      | "delivered"
      | "failed";
    paymentMethod?: "paid" | "cash_on_delivery";
    paymentCollection?: "collected" | "not_collected";
    search?: string;
    source?: "supervisor" | "company" | "external";
  } = {}
) {
  const db = await getDb();
  if (!db)
    return {
      filters,
      companySummaries: [],
      driverSummaries: [],
      orderRows: [],
      shiftRows: [],
    };
  const conditions = [] as ReturnType<typeof eq>[];
  if (filters.companyId)
    conditions.push(eq(orders.companyId, filters.companyId));
  if (filters.driverId)
    conditions.push(eq(orders.assignedDriverId, filters.driverId));
  if (filters.vehicleType)
    conditions.push(eq(drivers.vehicleType, filters.vehicleType));
  if (filters.unassigned) conditions.push(isNull(orders.assignedDriverId));
  if (filters.governorateId)
    conditions.push(
      or(
        eq(deliveryAreas.governorateId, filters.governorateId),
        eq(orders.deliveryGovernorateId, filters.governorateId)
      )!
    );
  if (filters.areaId)
    conditions.push(eq(orders.deliveryAreaId, filters.areaId));
  if (filters.status) conditions.push(eq(orders.status, filters.status));
  if (filters.paymentMethod === "cash_on_delivery")
    conditions.push(sql`${orders.cashToCollectAmount} > 0`);
  if (filters.paymentMethod === "paid")
    conditions.push(eq(orders.cashToCollectAmount, "0.000"));
  if (filters.paymentCollection === "collected")
    conditions.push(eq(orders.cashCollectionRecorded, true));
  if (filters.paymentCollection === "not_collected")
    conditions.push(eq(orders.cashCollectionRecorded, false));
  if (filters.search?.trim()) {
    const term = `%${filters.search.trim()}%`;
    conditions.push(
      or(
        like(orders.orderNumber, term),
        like(orders.customerName, term),
        like(orders.customerPhone, term)
      )!
    );
  }
  if (filters.source) conditions.push(eq(orders.source, filters.source));
  if (filters.fromDate)
    conditions.push(
      gte(orders.createdAt, new Date(`${filters.fromDate}T00:00:00.000Z`))
    );
  if (filters.toDate)
    conditions.push(
      lte(orders.createdAt, new Date(`${filters.toDate}T23:59:59.999Z`))
    );
  const where = conditions.length ? and(...conditions) : undefined;
  const rawRows = await db
    .select({
      id: orders.id,
      orderNumber: orders.orderNumber,
      companyId: orders.companyId,
      companyName: companies.name,
      source: orders.source,
      status: orders.status,
      assignedDriverId: orders.assignedDriverId,
      driverName: users.name,
      driverVehicleType: drivers.vehicleType,
      customerName: orders.customerName,
      customerPhone: orders.customerPhone,
      pickupContactName: orders.pickupContactName,
      pickupAddress: orders.pickupAddress,
      pickupPhone: orders.pickupPhone,
      pickupGovernorateId: orders.pickupGovernorateId,
      pickupAreaId: orders.pickupAreaId,
      deliveryAddress: orders.deliveryAddress,
      deliveryGovernorateId: orders.deliveryGovernorateId,
      deliveryAreaId: orders.deliveryAreaId,
      area: orders.area,
      cashToCollectAmount: orders.cashToCollectAmount,
      cashCollectionNote: orders.cashCollectionNote,
      cashCollectedAmount: orders.cashCollectedAmount,
      cashCollectionRecorded: orders.cashCollectionRecorded,
      cashCollectedAt: orders.cashCollectedAt,
      cashCollectedShiftId: orders.cashCollectedShiftId,
      deliveryFee: orders.deliveryFee,
      driverCommission: orders.driverCommission,
      companyShare: orders.companyShare,
      failureReason: orders.failureReason,
      failureNote: orders.failureNote,
      returnedToCompany: orders.returnedToCompany,
      createdByUserId: orders.createdByUserId,
      createdAt: orders.createdAt,
      updatedAt: orders.updatedAt,
    })
    .from(orders)
    .leftJoin(companies, eq(orders.companyId, companies.id))
    .leftJoin(deliveryAreas, eq(orders.deliveryAreaId, deliveryAreas.id))
    .leftJoin(drivers, eq(orders.assignedDriverId, drivers.id))
    .leftJoin(users, eq(drivers.userId, users.id))
    .where(where)
    .orderBy(desc(orders.createdAt))
    .limit(500);
  const rows = await attachOrderLocationNames(db, rawRows);
  if (!rows.length)
    return {
      filters,
      companySummaries: [],
      driverSummaries: [],
      orderRows: [],
      shiftRows: [],
    };
  const orderIds = rows.map(row => row.id);
  const driverIds = Array.from(
    new Set(
      rows
        .map(row => row.assignedDriverId)
        .filter((id): id is number => Boolean(id))
    )
  );
  const [events, media, transfers, creators, shiftsRows] = await Promise.all([
    db
      .select()
      .from(orderEvents)
      .where(
        and(
          inArray(orderEvents.orderId, orderIds),
          ne(orderEvents.type, "fee_updated")
        )
      )
      .orderBy(desc(orderEvents.occurredAt)),
    db
      .select({
        orderId: orderMedia.orderId,
        kind: orderMedia.kind,
        fileUrl: orderMedia.fileUrl,
        uploadedByUserId: orderMedia.uploadedByUserId,
        createdAt: orderMedia.createdAt,
      })
      .from(orderMedia)
      .where(inArray(orderMedia.orderId, orderIds))
      .orderBy(desc(orderMedia.createdAt)),
    db
      .select()
      .from(orderTransfers)
      .where(inArray(orderTransfers.orderId, orderIds))
      .orderBy(desc(orderTransfers.transferredAt)),
    db
      .select({ id: users.id, name: users.name })
      .from(users)
      .where(
        inArray(
          users.id,
          Array.from(new Set(rows.map(row => row.createdByUserId)))
        )
      ),
    driverIds.length
      ? db
          .select()
          .from(shifts)
          .where(
            and(
              inArray(shifts.driverId, driverIds),
              ...(filters.fromDate
                ? [
                    gte(
                      shifts.startedAt,
                      new Date(`${filters.fromDate}T00:00:00.000Z`)
                    ),
                  ]
                : []),
              ...(filters.toDate
                ? [
                    lte(
                      shifts.startedAt,
                      new Date(`${filters.toDate}T23:59:59.999Z`)
                    ),
                  ]
                : [])
            )
          )
          .orderBy(desc(shifts.startedAt))
      : Promise.resolve([]),
  ]);
  const allDriverIds = Array.from(
    new Set([
      ...driverIds,
      ...transfers.flatMap(item =>
        [item.fromDriverId, item.toDriverId].filter((id): id is number =>
          Boolean(id)
        )
      ),
    ])
  );
  const driverNames = allDriverIds.length
    ? await db
        .select({ id: drivers.id, userId: drivers.userId, name: users.name })
        .from(drivers)
        .innerJoin(users, eq(drivers.userId, users.id))
        .where(inArray(drivers.id, allDriverIds))
    : [];
  const driverName = (id: number | null | undefined) =>
    driverNames.find(item => item.id === id)?.name ?? null;
  const creatorName = (id: number) =>
    creators.find(item => item.id === id)?.name ?? null;
  const orderRows = rows.map(row => {
    const rowEvents = events
      .filter(event => event.orderId === row.id)
      .sort((a, b) => a.occurredAt.getTime() - b.occurredAt.getTime());
    const rowTransfers = transfers
      .filter(transfer => transfer.orderId === row.id)
      .map(transfer => ({
        ...transfer,
        fromDriverName: driverName(transfer.fromDriverId),
        toDriverName: driverName(transfer.toDriverId),
      }));
    return {
      ...row,
      creatorName: creatorName(row.createdByUserId),
      assignedDriverName: row.driverName ?? driverName(row.assignedDriverId),
      pickupAt:
        rowEvents.find(event => event.type === "picked_up")?.occurredAt ?? null,
      deliveryAt:
        rowEvents.find(event => event.type === "delivered")?.occurredAt ?? null,
      events: rowEvents,
      media: media.filter(item => item.orderId === row.id),
      transfers: rowTransfers,
    };
  });
  const companyMap = new Map<
    string,
    {
      companyId: number | null;
      companyName: string;
      source: string;
      orders: number;
      pickedUp: number;
      delivered: number;
    }
  >();
  for (const row of orderRows) {
    const key = row.companyId
      ? `company:${row.companyId}`
      : `source:${row.source}`;
    const current = companyMap.get(key) ?? {
      companyId: row.companyId,
      companyName:
        row.companyName ??
        (row.source === "external" ? "طلب خارجي" : "غير مرتبط بشركة"),
      source: row.source,
      orders: 0,
      pickedUp: 0,
      delivered: 0,
    };
    current.orders += 1;
    current.pickedUp += row.pickupAt ? 1 : 0;
    current.delivered += row.deliveryAt ? 1 : 0;
    companyMap.set(key, current);
  }
  const driverMap = new Map<
    number,
    {
      driverId: number;
      driverName: string;
      assignedOrders: number;
      pickedUp: number;
      delivered: number;
      cashCollectedTotal: string;
      cashCollectionCount: number;
      createdOrders: number;
      transferredIn: number;
      transferredOut: number;
    }
  >();
  const ensureDriver = (driverId: number) => {
    const current = driverMap.get(driverId) ?? {
      driverId,
      driverName: driverName(driverId) ?? "غير معروف",
      assignedOrders: 0,
      pickedUp: 0,
      delivered: 0,
      cashCollectedTotal: "0.000",
      cashCollectionCount: 0,
      createdOrders: 0,
      transferredIn: 0,
      transferredOut: 0,
    };
    driverMap.set(driverId, current);
    return current;
  };
  for (const row of orderRows) {
    if (row.assignedDriverId) {
      const current = ensureDriver(row.assignedDriverId);
      current.assignedOrders += 1;
      current.pickedUp += row.pickupAt ? 1 : 0;
      current.delivered += row.deliveryAt ? 1 : 0;
    }
    const creatorDriver = driverNames.find(
      item => item.userId === row.createdByUserId
    );
    if (creatorDriver) ensureDriver(creatorDriver.id).createdOrders += 1;
    for (const transfer of row.transfers) {
      if (transfer.fromDriverId)
        ensureDriver(transfer.fromDriverId).transferredOut += 1;
      ensureDriver(transfer.toDriverId).transferredIn += 1;
    }
  }
  for (const driver of Array.from(driverMap.values())) {
    const collections = summarizeCashCollections(
      orderRows.filter(row => row.assignedDriverId === driver.driverId)
    );
    driver.cashCollectedTotal = collections.cashCollectedTotal;
    driver.cashCollectionCount = collections.cashCollectionCount;
  }
  const shiftRows = shiftsRows.map(shift => {
    const end = shift.endedAt ?? new Date();
    const hours = Math.max(
      0,
      (end.getTime() - shift.startedAt.getTime()) / 3600000
    );
    const shiftOrders = orderRows.filter(
      row => row.cashCollectedShiftId === shift.id
    );
    const collection = summarizeCashCollections(shiftOrders);
    const deliveredCount = orderRows.filter(
      row =>
        row.assignedDriverId === shift.driverId &&
        row.deliveryAt &&
        row.deliveryAt >= shift.startedAt &&
        row.deliveryAt <= end
    ).length;
    return {
      ...shift,
      driverName: driverName(shift.driverId),
      hoursWorked: Number(hours.toFixed(2)),
      deliveredCount,
      ...collection,
    };
  });
  const statusPriority: Record<string, number> = {
    in_transit: 0,
    picked_up: 1,
    assigned: 1,
    pending: 2,
    failed: 3,
    delivered: 4,
  };
  orderRows.sort(
    (a, b) =>
      (statusPriority[a.status] ?? 2) - (statusPriority[b.status] ?? 2) ||
      new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
  );
  return {
    filters,
    companySummaries: Array.from(companyMap.values()).sort(
      (a, b) => b.orders - a.orders
    ),
    driverSummaries: Array.from(driverMap.values()).sort(
      (a, b) => b.delivered - a.delivered
    ),
    orderRows,
    shiftRows,
  };
}

export async function createFinancialEntry(
  input: {
    type: "income" | "expense";
    category:
      | "company_payment"
      | "delivery_revenue"
      | "salary"
      | "rent"
      | "installment"
      | "utilities"
      | "insurance"
      | "fuel"
      | "marketing"
      | "maintenance"
      | "purchase"
      | "sale"
      | "other";
    companyId?: number;
    orderId?: number;
    amount: string;
    description: string;
    reference?: string;
    transactionDate: string;
  },
  actorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const amount = input.amount.trim();
  if (!/^\d+(\.\d{1,3})?$/.test(amount) || Number(amount) <= 0)
    throw new Error("المبلغ يجب أن يكون رقماً موجباً وبحد أقصى 3 منازل عشرية");
  const description = input.description.trim();
  if (description.length < 2) throw new Error("وصف القيد مطلوب");
  const date = new Date(input.transactionDate);
  if (Number.isNaN(date.getTime())) throw new Error("تاريخ القيد غير صالح");
  if (input.companyId) {
    const company = await db
      .select({ id: companies.id })
      .from(companies)
      .where(eq(companies.id, input.companyId))
      .limit(1);
    if (!company[0]) throw new Error("الشركة غير موجودة");
  }
  if (input.orderId) {
    const order = await db
      .select({ id: orders.id })
      .from(orders)
      .where(eq(orders.id, input.orderId))
      .limit(1);
    if (!order[0]) throw new Error("الطلب غير موجود");
  }
  const result = await db.insert(financialEntries).values({
    type: input.type,
    category: input.category,
    companyId: input.companyId ?? null,
    orderId: input.orderId ?? null,
    amount,
    description,
    reference: input.reference?.trim() || null,
    transactionDate: date,
    createdByUserId: actorUserId,
  });
  const id = Number(result[0].insertId);
  await db.insert(auditLogs).values({
    actorUserId,
    action: "finance.entry_created",
    entityType: "financial_entry",
    entityId: String(id),
    afterJson: JSON.stringify({ ...input, amount }),
  });
  return { id };
}

export async function getAccountingReport(
  filters: {
    fromDate?: string;
    toDate?: string;
    companyId?: number;
    driverId?: number;
    unassigned?: boolean;
    governorateId?: number;
    areaId?: number;
    status?:
      | "pending"
      | "assigned"
      | "picked_up"
      | "in_transit"
      | "delivered"
      | "failed";
    scope?: "all" | "company" | "external";
  } = {}
) {
  const db = await getDb();
  const emptyTotals = {
    sales: "0.000",
    deliveryFees: "0.000",
    driverCommissions: "0.000",
    cashToCollect: "0.000",
    cashCollected: "0.000",
    cashCollectionCount: 0,
    income: "0.000",
    revenue: "0.000",
    expense: "0.000",
    balance: "0.000",
    orders: 0,
    deliveredOrders: 0,
  };
  if (!db)
    return {
      filters,
      totals: emptyTotals,
      entries: [],
      companyStatements: [],
      externalOrders: [],
      orderLedger: [],
      categoryTotals: [],
      periodSeries: [],
    };

  const entryConditions = [] as ReturnType<typeof eq>[];
  const orderConditions = [] as ReturnType<typeof eq>[];
  if (filters.companyId) {
    entryConditions.push(eq(financialEntries.companyId, filters.companyId));
    orderConditions.push(eq(orders.companyId, filters.companyId));
  }
  if (filters.driverId)
    orderConditions.push(eq(orders.assignedDriverId, filters.driverId));
  if (filters.governorateId)
    orderConditions.push(
      or(
        eq(deliveryAreas.governorateId, filters.governorateId),
        eq(orders.deliveryGovernorateId, filters.governorateId)
      )!
    );
  if (filters.areaId)
    orderConditions.push(eq(orders.deliveryAreaId, filters.areaId));
  if (filters.status) orderConditions.push(eq(orders.status, filters.status));
  if (filters.scope === "external") {
    entryConditions.push(isNull(financialEntries.companyId));
    orderConditions.push(eq(orders.source, "external"));
  }
  if (filters.scope === "company") {
    entryConditions.push(isNotNull(financialEntries.companyId));
    orderConditions.push(isNotNull(orders.companyId));
  }
  if (filters.fromDate) {
    entryConditions.push(
      gte(
        financialEntries.transactionDate,
        new Date(`${filters.fromDate}T00:00:00.000Z`)
      )
    );
    orderConditions.push(
      gte(orders.updatedAt, new Date(`${filters.fromDate}T00:00:00.000Z`))
    );
  }
  if (filters.toDate) {
    entryConditions.push(
      lte(
        financialEntries.transactionDate,
        new Date(`${filters.toDate}T23:59:59.999Z`)
      )
    );
    orderConditions.push(
      lte(orders.updatedAt, new Date(`${filters.toDate}T23:59:59.999Z`))
    );
  }
  const entryWhere = entryConditions.length
    ? and(...entryConditions)
    : undefined;
  const orderWhere = orderConditions.length
    ? and(...orderConditions)
    : undefined;

  const [entryRows, orderRows] = await Promise.all([
    db
      .select({
        entry: financialEntries,
        companyName: companies.name,
        creatorName: users.name,
      })
      .from(financialEntries)
      .leftJoin(companies, eq(financialEntries.companyId, companies.id))
      .leftJoin(users, eq(financialEntries.createdByUserId, users.id))
      .where(entryWhere)
      .orderBy(desc(financialEntries.transactionDate))
      .limit(500),
    db
      .select({
        id: orders.id,
        orderNumber: orders.orderNumber,
        companyId: orders.companyId,
        companyName: companies.name,
        source: orders.source,
        status: orders.status,
        assignedDriverId: orders.assignedDriverId,
        driverId: drivers.id,
        driverName: users.name,
        customerName: orders.customerName,
        customerPhone: orders.customerPhone,
        pickupContactName: orders.pickupContactName,
        pickupAddress: orders.pickupAddress,
        deliveryAddress: orders.deliveryAddress,
        area: orders.area,
        deliveryGovernorateId: orders.deliveryGovernorateId,
        deliveryAreaId: orders.deliveryAreaId,
        deliveryGovernorateName: governorates.nameAr,
        deliveryAreaName: deliveryAreas.nameAr,
        cashToCollectAmount: orders.cashToCollectAmount,
        cashCollectionNote: orders.cashCollectionNote,
        cashCollectedAmount: orders.cashCollectedAmount,
        cashCollectionRecorded: orders.cashCollectionRecorded,
        cashCollectedAt: orders.cashCollectedAt,
        deliveryFee: orders.deliveryFee,
        deliveryFeeChargeOnFailure: orders.deliveryFeeChargeOnFailure,
        driverCommission: orders.driverCommission,
        companyShare: orders.companyShare,
        driverCommissionManual: orders.driverCommissionManual,
        companyShareManual: orders.companyShareManual,
        returnedToCompany: orders.returnedToCompany,
        createdAt: orders.createdAt,
        updatedAt: orders.updatedAt,
      })
      .from(orders)
      .leftJoin(companies, eq(orders.companyId, companies.id))
      .leftJoin(deliveryAreas, eq(orders.deliveryAreaId, deliveryAreas.id))
      .leftJoin(governorates, eq(deliveryAreas.governorateId, governorates.id))
      .leftJoin(drivers, eq(orders.assignedDriverId, drivers.id))
      .leftJoin(users, eq(drivers.userId, users.id))
      .where(orderWhere)
      .orderBy(desc(orders.updatedAt))
      .limit(500),
  ]);

  const orderIds = orderRows.map(row => row.id);
  const mediaRows = orderIds.length
    ? await db
        .select({
          id: orderMedia.id,
          orderId: orderMedia.orderId,
          kind: orderMedia.kind,
          fileUrl: orderMedia.fileUrl,
          createdAt: orderMedia.createdAt,
        })
        .from(orderMedia)
        .where(inArray(orderMedia.orderId, orderIds))
        .orderBy(desc(orderMedia.createdAt))
    : [];
  const mediaByOrder = new Map<number, typeof mediaRows>();
  for (const media of mediaRows)
    mediaByOrder.set(media.orderId, [
      ...(mediaByOrder.get(media.orderId) ?? []),
      media,
    ]);
  const orderLedger = orderRows.map(row => ({
    ...row,
    media: mediaByOrder.get(row.id) ?? [],
  }));

  const income = entryRows
    .filter(({ entry }) => entry.type === "income")
    .reduce((sum, { entry }) => sum + Number(entry.amount), 0);
  const expense = entryRows
    .filter(({ entry }) => entry.type === "expense")
    .reduce((sum, { entry }) => sum + Number(entry.amount), 0);
  const deliveredOrders = orderLedger.filter(row => row.status === "delivered");
  const feeBearingOrders = orderLedger.filter(shouldCountDeliveryFee);
  const payableCommissions = orderLedger.filter(shouldCountDriverCommission);
  const companyShareOrders = orderLedger.filter(shouldCountCompanyShare);
  const feeBearingIds = new Set(feeBearingOrders.map(row => row.id));
  const payableCommissionIds = new Set(payableCommissions.map(row => row.id));
  const companyShareIds = new Set(companyShareOrders.map(row => row.id));
  const deliveryFees = feeBearingOrders.reduce(
    (sum, row) => sum + Number(row.deliveryFee),
    0
  );
  const cashToCollect = orderLedger.reduce(
    (sum, row) => sum + Number(row.cashToCollectAmount ?? 0),
    0
  );
  const recordedCollections = summarizeCashCollections(orderLedger);
  const driverCommissions = payableCommissions.reduce(
    (sum, row) => sum + Number(row.driverCommission),
    0
  );
  const sales = companyShareOrders.reduce(
    (sum, row) => sum + Number(row.companyShare),
    0
  );
  const revenue = sales + income;
  const driverProfiles = await db
    .select({
      driverId: drivers.id,
      driverName: users.name,
      payType: drivers.payType,
      baseSalary: drivers.baseSalary,
      defaultCommission: drivers.defaultCommission,
    })
    .from(drivers)
    .leftJoin(users, eq(drivers.userId, users.id));
  const commissionByDriver = new Map<
    number,
    { commission: number; orders: number }
  >();
  for (const row of payableCommissions) {
    if (!row.driverId) continue;
    const current = commissionByDriver.get(row.driverId) ?? {
      commission: 0,
      orders: 0,
    };
    current.commission += Number(row.driverCommission);
    current.orders += 1;
    commissionByDriver.set(row.driverId, current);
  }
  const driverStatements = driverProfiles
    .map(driver => ({
      driverId: driver.driverId,
      driverName: driver.driverName ?? "غير معروف",
      payType: driver.payType,
      baseSalary: Number(driver.baseSalary).toFixed(3),
      defaultCommission: Number(driver.defaultCommission).toFixed(3),
      earnedCommission: (
        commissionByDriver.get(driver.driverId)?.commission ?? 0
      ).toFixed(3),
      commissionOrders: commissionByDriver.get(driver.driverId)?.orders ?? 0,
      ...summarizeCashCollections(
        orderLedger.filter(row => row.driverId === driver.driverId)
      ),
    }))
    .sort((a, b) => Number(b.earnedCommission) - Number(a.earnedCommission));

  const statementMap = new Map<
    number,
    {
      companyId: number;
      companyName: string;
      sales: number;
      deliveryFees: number;
      driverCommissions: number;
      cashToCollect: number;
      cashCollected: number;
      cashCollectionCount: number;
      income: number;
      expense: number;
      balance: number;
      orders: number;
      deliveredOrders: number;
      entries: number;
    }
  >();
  const ensureStatement = (companyId: number, companyName: string) => {
    const current = statementMap.get(companyId) ?? {
      companyId,
      companyName,
      sales: 0,
      deliveryFees: 0,
      driverCommissions: 0,
      cashToCollect: 0,
      cashCollected: 0,
      cashCollectionCount: 0,
      income: 0,
      expense: 0,
      balance: 0,
      orders: 0,
      deliveredOrders: 0,
      entries: 0,
    };
    statementMap.set(companyId, current);
    return current;
  };
  for (const row of orderLedger) {
    if (!row.companyId) continue;
    const current = ensureStatement(
      row.companyId,
      row.companyName ?? "غير معروف"
    );
    current.orders += 1;
    if (row.status === "delivered") {
      current.deliveredOrders += 1;
    }
    if (feeBearingIds.has(row.id))
      current.deliveryFees += Number(row.deliveryFee);
    if (payableCommissionIds.has(row.id))
      current.driverCommissions += Number(row.driverCommission);
    if (companyShareIds.has(row.id)) current.sales += Number(row.companyShare);
    current.cashToCollect += Number(row.cashToCollectAmount ?? 0);
    if (row.cashCollectionRecorded) {
      current.cashCollected += Number(row.cashCollectedAmount ?? 0);
      current.cashCollectionCount += 1;
    }
  }
  for (const { entry, companyName } of entryRows) {
    if (!entry.companyId) continue;
    const current = ensureStatement(
      entry.companyId,
      companyName ?? "غير معروف"
    );
    current.entries += 1;
    if (entry.type === "income") current.income += Number(entry.amount);
    else current.expense += Number(entry.amount);
  }
  for (const statement of Array.from(statementMap.values()))
    statement.balance = statement.sales + statement.income - statement.expense;

  const categoryMap = new Map<
    string,
    {
      category: string;
      income: number;
      expense: number;
      balance: number;
      entries: number;
    }
  >();
  for (const { entry } of entryRows) {
    const current = categoryMap.get(entry.category) ?? {
      category: entry.category,
      income: 0,
      expense: 0,
      balance: 0,
      entries: 0,
    };
    current.entries += 1;
    if (entry.type === "income") current.income += Number(entry.amount);
    else current.expense += Number(entry.amount);
    current.balance = current.income - current.expense;
    categoryMap.set(entry.category, current);
  }

  const periodMap = new Map<
    string,
    {
      period: string;
      sales: number;
      income: number;
      expense: number;
      revenue: number;
      balance: number;
    }
  >();
  const ensurePeriod = (date: Date) => {
    const period = date.toISOString().slice(0, 7);
    const current = periodMap.get(period) ?? {
      period,
      sales: 0,
      income: 0,
      expense: 0,
      revenue: 0,
      balance: 0,
    };
    periodMap.set(period, current);
    return current;
  };
  for (const row of companyShareOrders)
    ensurePeriod(row.updatedAt).sales += Number(row.companyShare);
  for (const { entry } of entryRows) {
    const current = ensurePeriod(entry.transactionDate);
    if (entry.type === "income") current.income += Number(entry.amount);
    else current.expense += Number(entry.amount);
  }
  for (const period of Array.from(periodMap.values())) {
    period.revenue = period.sales + period.income;
    period.balance = period.revenue - period.expense;
  }

  const externalOrders = orderLedger.filter(
    row => row.source === "external" && row.status === "delivered"
  );
  return {
    filters,
    totals: {
      sales: sales.toFixed(3),
      deliveryFees: deliveryFees.toFixed(3),
      driverCommissions: driverCommissions.toFixed(3),
      cashToCollect: cashToCollect.toFixed(3),
      cashCollected: recordedCollections.cashCollectedTotal,
      cashCollectionCount: recordedCollections.cashCollectionCount,
      income: income.toFixed(3),
      revenue: revenue.toFixed(3),
      expense: expense.toFixed(3),
      balance: (revenue - expense).toFixed(3),
      orders: orderLedger.length,
      deliveredOrders: deliveredOrders.length,
    },
    entries: entryRows.map(({ entry, companyName, creatorName }) => ({
      ...entry,
      companyName,
      creatorName,
    })),
    companyStatements: Array.from(statementMap.values()).sort(
      (a, b) => b.balance - a.balance
    ),
    driverStatements,
    externalOrders,
    orderLedger,
    categoryTotals: Array.from(categoryMap.values()).sort(
      (a, b) => Math.abs(b.balance) - Math.abs(a.balance)
    ),
    periodSeries: Array.from(periodMap.values()).sort((a, b) =>
      a.period.localeCompare(b.period)
    ),
  };
}

export async function updateFinancialEntry(
  input: {
    id: number;
    type: "income" | "expense";
    category:
      | "company_payment"
      | "delivery_revenue"
      | "salary"
      | "rent"
      | "installment"
      | "utilities"
      | "insurance"
      | "fuel"
      | "marketing"
      | "maintenance"
      | "purchase"
      | "sale"
      | "other";
    companyId?: number;
    amount: string;
    description: string;
    reference?: string;
    transactionDate: string;
  },
  actorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const amount = input.amount.trim();
  if (!/^\d+(\.\d{1,3})?$/.test(amount) || Number(amount) <= 0)
    throw new Error("المبلغ يجب أن يكون رقماً موجباً وبحد أقصى 3 منازل عشرية");
  const date = new Date(input.transactionDate);
  if (Number.isNaN(date.getTime())) throw new Error("تاريخ القيد غير صالح");
  const before = await db
    .select()
    .from(financialEntries)
    .where(eq(financialEntries.id, input.id))
    .limit(1);
  if (!before[0]) throw new Error("القيد المالي غير موجود");
  await db
    .update(financialEntries)
    .set({
      type: input.type,
      category: input.category,
      companyId: input.companyId ?? null,
      amount,
      description: input.description.trim(),
      reference: input.reference?.trim() || null,
      transactionDate: date,
    })
    .where(eq(financialEntries.id, input.id));
  const after = await db
    .select()
    .from(financialEntries)
    .where(eq(financialEntries.id, input.id))
    .limit(1);
  await db.insert(auditLogs).values({
    actorUserId,
    action: "finance.entry_updated",
    entityType: "financial_entry",
    entityId: String(input.id),
    beforeJson: JSON.stringify(before[0]),
    afterJson: JSON.stringify(after[0]),
  });
  return after[0];
}

export async function listCompanyPortalDrivers(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const membership = await db
    .select({ companyId: companyUsers.companyId })
    .from(companyUsers)
    .where(eq(companyUsers.userId, userId))
    .limit(1);
  if (!membership[0]) return [];
  try {
    return await db
      .select({
        id: drivers.id,
        name: users.name,
        vehicleType: drivers.vehicleType,
        vehicleLabel: drivers.vehicleLabel,
      })
      .from(companyDriverAssignments)
      .innerJoin(drivers, eq(companyDriverAssignments.driverId, drivers.id))
      .innerJoin(users, eq(drivers.userId, users.id))
      .where(
        and(
          eq(companyDriverAssignments.companyId, membership[0].companyId),
          eq(drivers.active, true),
          eq(users.status, "active"),
          eq(users.approvalStatus, "approved")
        )
      );
  } catch {
    return [];
  }
}

export async function bulkCreateCompanyPortalOrders(
  userId: number,
  inputs: Array<Parameters<typeof createCompanyPortalOrder>[1]>
) {
  if (!inputs.length) throw new Error("ملف Excel لا يحتوي على طلبات");
  if (inputs.length > 500)
    throw new Error("الحد الأقصى للاستيراد هو 500 طلب في المرة الواحدة");
  for (let index = 0; index < inputs.length; index += 1) {
    const input = inputs[index];
    if (!input.pickupAddress || input.pickupAddress.trim().length < 5)
      throw new Error(`عنوان الاستلام ناقص في الصف ${index + 2}`);
    if (!input.deliveryAddress || input.deliveryAddress.trim().length < 5)
      throw new Error(`عنوان التسليم ناقص في الصف ${index + 2}`);
  }
  const created: Array<{ id: number; orderNumber: string }> = [];
  for (const input of inputs)
    created.push(await createCompanyPortalOrder(userId, input));
  return { count: created.length, orders: created };
}

export async function createBusinessAccount(
  input: {
    companyId?: number;
    companyName?: string;
    companyPhone?: string;
    companyAddress?: string;
    username?: string;
    password?: string;
    role: "company" | "trader";
  },
  actorUserId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  let company = input.companyId
    ? await db
        .select({ id: companies.id, name: companies.name })
        .from(companies)
        .where(eq(companies.id, input.companyId))
        .limit(1)
    : [];
  if (!company[0]) {
    const companyName = input.companyName?.trim();
    if (!companyName) throw new Error("أدخل اسم الشركة أو التاجر");
    const countRows = await db.select({ count: sql<number>`count(*)` }).from(companies);
    const code = `C${String(Number(countRows[0]?.count ?? 0) + 1).padStart(5, "0")}`;
    const companyResult = await db.insert(companies).values({
      name: companyName,
      code,
      phone: input.companyPhone?.trim() || null,
      address: input.companyAddress?.trim() || null,
      status: "active",
      portalEnabled: false,
    });
    company = [{ id: Number(companyResult[0].insertId), name: companyName }];
  }
  if (!input.username && !input.password)
    return { companyId: company[0].id, companyName: company[0].name, accountCreated: false as const };
  if (!input.username || !input.password)
    throw new Error("أدخل اسم المستخدم وكلمة المرور معاً");
  const username = input.username.trim().toLowerCase();
  const duplicate = await db
    .select({ id: users.id })
    .from(users)
    .where(eq(users.email, username))
    .limit(1);
  if (duplicate[0]) throw new Error("اسم المستخدم مستخدم مسبقاً");
  const passwordHash = await hashPassword(input.password);
  const result = await db.insert(users).values({
    openId: null,
    civilId: null,
    passwordHash,
    name: company[0].name,
    phone: null,
    email: username,
    role: input.role,
    requestedRole: input.role,
    approvalStatus: "approved",
    status: "active",
    loginMethod: "local-identifier",
    mustChangePassword: true,
    preferredLanguage: "ar",
  });
  const userId = Number(result[0].insertId);
  await db.insert(companyUsers).values({ userId, companyId: company[0].id });
  await db.insert(auditLogs).values({
    actorUserId,
    action: "account.business_created",
    entityType: "user",
    entityId: String(userId),
    afterJson: JSON.stringify({
      companyId: company[0].id,
      username,
      role: input.role,
    }),
  });
  return {
    userId,
    username,
    password: input.password,
    role: input.role,
    companyId: company[0].id,
    companyName: company[0].name,
    accountCreated: true as const,
  };
}
