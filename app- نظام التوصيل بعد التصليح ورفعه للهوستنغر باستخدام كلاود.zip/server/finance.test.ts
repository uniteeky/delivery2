import { readFileSync } from "node:fs";
import { describe, expect, it, vi } from "vitest";
import * as db from "./db";
import { appRouter } from "./routers";

const admin = { id: 1, role: "admin" as const, status: "active" as const, approvalStatus: "approved" as const, name: "Admin" };
const driver = { id: 7, role: "driver" as const, status: "active" as const, approvalStatus: "approved" as const, name: "Driver", civilId: "123456789012", loginMethod: "local-civil-id" as const };
const caller = (user: typeof admin | typeof driver) => appRouter.createCaller({ user, req: {} as never, res: {} as never });

describe("finance fee editing", () => {
  it("keeps summary totals aligned to delivered orders", () => {
    const dbSource = readFileSync(new URL("./db.ts", import.meta.url), "utf8");
    expect(dbSource).toContain("area: orders.area, count: sql<number>`count(*)`, total: sql<string>`coalesce(sum(deliveryFee), 0)` }).from(orders).where(eq(orders.status, \"delivered\"))");
  });
  it("allows an admin to update a delivery fee through the audited route", async () => {
    const update = vi.spyOn(db, "updateOrderFee").mockResolvedValue({ orderId: 15, deliveryFee: "3.500" });
    try {
      await expect(caller(admin).finance.updateFee({ orderId: 15, deliveryFee: "3.500" })).resolves.toMatchObject({ deliveryFee: "3.500" });
      expect(update).toHaveBeenCalledWith(15, "3.500", 1);
    } finally { update.mockRestore(); }
  });

  it("passes server-backed report filters and returns financial history to an admin", async () => {
    const report = vi.spyOn(db, "getFinancialReport").mockResolvedValue({ deliveredOrders: 1, totalFees: "3.500", rows: [], history: [{ id: 1, actorUserId: 1, actorName: "Admin", entityId: "15", beforeJson: JSON.stringify({ deliveryFee: "2.000" }), afterJson: JSON.stringify({ deliveryFee: "3.500" }), createdAt: new Date() }] });
    try {
      await expect(caller(admin).finance.report({ area: "حولي", status: "delivered", fromDate: "2026-08-01", toDate: "2026-08-20" })).resolves.toMatchObject({ totalFees: "3.500", history: [{ actorName: "Admin" }] });
      expect(report).toHaveBeenCalledWith({ area: "حولي", status: "delivered", fromDate: "2026-08-01", toDate: "2026-08-20" });
    } finally { report.mockRestore(); }
  });

  it("rejects report access for a driver", async () => {
    const report = vi.spyOn(db, "getFinancialReport");
    try {
      await expect(caller(driver).finance.report({ status: "delivered" })).rejects.toMatchObject({ code: "FORBIDDEN" });
      expect(report).not.toHaveBeenCalled();
    } finally { report.mockRestore(); }
  });

  it("rejects fee editing for a driver", async () => {
    const update = vi.spyOn(db, "updateOrderFee");
    try {
      await expect(caller(driver).finance.updateFee({ orderId: 15, deliveryFee: "3.500" })).rejects.toMatchObject({ code: "FORBIDDEN" });
      expect(update).not.toHaveBeenCalled();
    } finally { update.mockRestore(); }
  });
});

  it("protects the accounting ledger and date-range report by capability", async () => {
    const report = vi.spyOn(db, "getAccountingReport");
    try {
      await expect(caller(driver).finance.accountingReport({ fromDate: "2026-08-01", toDate: "2026-08-20", scope: "all" })).rejects.toMatchObject({ code: "FORBIDDEN" });
      expect(report).not.toHaveBeenCalled();
    } finally { report.mockRestore(); }
  });

  it("passes company, driver, status, and date filters to the protected accounting ledger", async () => {
    const report = vi.spyOn(db, "getAccountingReport").mockResolvedValue({
      filters: { fromDate: "2026-08-01", toDate: "2026-08-31", companyId: 3, driverId: 9, status: "delivered", scope: "company" },
      totals: { sales: "3.500", income: "0.000", revenue: "3.500", expense: "1.000", balance: "2.500", orders: 1, deliveredOrders: 1 },
      entries: [], companyStatements: [], externalOrders: [], orderLedger: [], categoryTotals: [], periodSeries: [],
    });
    const input = { fromDate: "2026-08-01", toDate: "2026-08-31", companyId: 3, driverId: 9, status: "delivered" as const, scope: "company" as const };
    try {
      await expect(caller(admin).finance.accountingReport(input)).resolves.toMatchObject({ totals: { sales: "3.500" } });
      expect(report).toHaveBeenCalledWith(input);
    } finally { report.mockRestore(); }
  });

  it("returns ledger, media, category, and period-report fields only from the protected finance contract", () => {
    const dbSource = readFileSync(new URL("./db.ts", import.meta.url), "utf8");
    const routersSource = readFileSync(new URL("./routers.ts", import.meta.url), "utf8");
    expect(dbSource).toContain("orderLedger");
    expect(dbSource).toContain("media: mediaByOrder.get(row.id)");
    expect(dbSource).toContain("categoryTotals");
    expect(dbSource).toContain("periodSeries");
    expect(routersSource).toContain("filterOptions");
    expect(routersSource).toContain("driverId: z.number().int().positive().optional()");
  });


describe("operational price privacy", () => {
  it("does not expose delivery fees in supervisor or driver operational surfaces", () => {
    const reportSource = readFileSync(new URL("./db.ts", import.meta.url), "utf8");
    const operationsSource = readFileSync(new URL("../client/src/pages/OperationsRoom.tsx", import.meta.url), "utf8");
    const newOrderSource = readFileSync(new URL("../client/src/pages/NewOrder.tsx", import.meta.url), "utf8");
    const driverOrderSource = readFileSync(new URL("../client/src/pages/DriverNewOrder.tsx", import.meta.url), "utf8");
    expect(reportSource).not.toContain("deliveryFee: orders.deliveryFee, createdByUserId: orders.createdByUserId");
    expect(operationsSource).not.toContain("item.totalFees");
    expect(newOrderSource).not.toContain('htmlFor="deliveryFee"');
    expect(driverOrderSource).not.toContain("deliveryFee");
  });

  it("exposes pricing capability only to admin or accountant effective roles", async () => {
    const routersSource = readFileSync(new URL("./routers.ts", import.meta.url), "utf8");
    expect(routersSource).toContain("export function canViewOrderPricing");
    expect(routersSource).toContain('hasEffectiveRole(user, "accountant")');
    await expect(caller(driver).finance.summary()).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller(driver).finance.createEntry({ type: "income", category: "other", amount: "1.000", description: "test", transactionDate: "2026-08-21T00:00:00.000Z" })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});


describe("dashboard price privacy", () => {
  it("sanitizes recent operational orders for non-finance users", () => {
    const routersSource = readFileSync(new URL("./routers.ts", import.meta.url), "utf8");
    expect(routersSource).toContain("orders.map((order) => hideOrderPricing(order))");
    expect(routersSource).toContain("canViewOrderPricing(ctx.user) ? orders");
  });

  it("keeps company pricing controls behind the finance visibility boundary", () => {
    const companiesSource = readFileSync(new URL("../client/src/pages/Companies.tsx", import.meta.url), "utf8");
    expect(companiesSource).toContain("const canViewPricing");
    expect(companiesSource).toContain("canViewPricing ?");
    expect(companiesSource).toContain("defaultDeliveryFee");
  });
});
