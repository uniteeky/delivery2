import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";

describe("finance ledger contract", () => {
  it("exposes protected accounting procedures and the filterable analytical ledger interface", () => {
    const routerSource = readFileSync(new URL("./routers.ts", import.meta.url), "utf8");
    const financePage = readFileSync(new URL("../client/src/pages/Finance.tsx", import.meta.url), "utf8");
    expect(routerSource).toContain("accountingReport:");
    expect(routerSource).toContain("filterOptions:");
    expect(routerSource).toContain("createEntry:");
    expect(routerSource).toContain("updateEntry:");
    expect(routerSource).toContain("finance_edit");
    expect(financePage).toContain("companyStatements");
    expect(financePage).toContain("orderLedger");
    expect(financePage).toContain("categoryTotals");
    expect(financePage).toContain("periodSeries");
    expect(financePage).toContain("ResponsiveContainer");
    expect(financePage).toContain("سعر التوصيل");
    expect(financePage).toContain("mediaLabel");
    expect(financePage).toContain("نصف سنوي");
    expect(financePage).toContain("const isAdmin");
    expect(financePage).toContain("isAdmin || permissions.data");
    expect(financePage).toContain("event.currentTarget.select()");
    expect(financePage).toContain("min-w-[860px]");
    expect(financePage).toContain("window.print()");
    expect(financePage).toContain("type=\"date\"");
  });
});
