import { describe, expect, it } from "vitest";
import * as dbModule from "./db";

function makeFakeDb() {
  const responses: unknown[][] = [
    [{ companyId: 1 }],
    [{ id: 101, orderNumber: "CC-101", companyId: 1, status: "delivered", customerName: "عميل 1", customerPhone: "50000000", pickupAddress: "عنوان استلام 1", deliveryAddress: "عنوان تسليم 1", area: "حولي", notes: null, createdAt: new Date(), updatedAt: new Date() }],
    [{ orderId: 101, kind: "order", fileUrl: "/manus-storage/pickup.jpg" }, { orderId: 101, kind: "invoice", fileUrl: "/manus-storage/invoice.jpg" }, { orderId: 101, kind: "delivery", fileUrl: "/manus-storage/delivery.jpg" }],
  ];
  return {
    select() {
      const response = responses.shift() ?? [];
      const query = {
        from() { return query; },
        where() { return query; },
        limit() { return Promise.resolve(response); },
        orderBy() { return query; },
        then(resolve: (value: unknown) => unknown, reject?: (reason: unknown) => unknown) { return Promise.resolve(response).then(resolve, reject); },
      };
      return query;
    },
  };
}

describe("company portal query path", () => {
  it("returns only safe fields and only the granted media kind", async () => {
    const result = await dbModule.listCompanyOrdersForPortalWithDb(makeFakeDb() as never, 501, ["company_media_delivery"]);
    expect(result).toHaveLength(1);
    expect(result[0]).not.toHaveProperty("deliveryFee");
    expect(result[0].companyId).toBe(1);
    expect(result[0].pickupAddress).toBe("عنوان استلام 1");
    expect(result[0].deliveryAddress).toBe("عنوان تسليم 1");
    expect(result[0].media).toEqual([{ orderId: 101, kind: "delivery", fileUrl: "/manus-storage/delivery.jpg" }]);
  });

  it("returns no media when the company has no media-view grants", async () => {
    const result = await dbModule.listCompanyOrdersForPortalWithDb(makeFakeDb() as never, 501, []);
    expect(result[0].media).toEqual([]);
  });
});
