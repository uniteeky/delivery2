import { describe, expect, it } from "vitest";
import { canGroupOrdersInAutomaticTrip, getDriverOrderStats, normalizeTripPickup } from "../shared/operations";

describe("automatic trip grouping rules", () => {
  it("normalizes whitespace and case for pickup locations", () => {
    expect(normalizeTripPickup("  Restaurant   Gate ")).toBe("restaurant gate");
  });

  it("groups the same pickup location when one or both times are optional", () => {
    expect(canGroupOrdersInAutomaticTrip({ pickupAddress: "بوابة المطعم", candidatePickupAddress: "  بوابة   المطعم " })).toBe(true);
    expect(canGroupOrdersInAutomaticTrip({ pickupAddress: "بوابة المطعم", candidatePickupAddress: "بوابة المطعم", pickupScheduledAt: new Date("2026-08-20T08:00:00.000Z") })).toBe(true);
  });

  it("counts each driver order once even when duplicate rows are returned", () => {
    expect(getDriverOrderStats([{ id: 1, status: "assigned" }, { id: 1, status: "assigned" }, { id: 2, status: "delivered" }])).toEqual({ pickup: 1, active: 0, delivered: 1 });
  });

  it("groups compatible pickup windows and separates distant windows or locations", () => {
    const first = new Date("2026-08-20T08:00:00.000Z");
    expect(canGroupOrdersInAutomaticTrip({ pickupAddress: "بوابة المطعم", candidatePickupAddress: "بوابة المطعم", pickupScheduledAt: first, candidatePickupScheduledAt: new Date("2026-08-20T09:30:00.000Z") })).toBe(true);
    expect(canGroupOrdersInAutomaticTrip({ pickupAddress: "بوابة المطعم", candidatePickupAddress: "بوابة المطعم", pickupScheduledAt: first, candidatePickupScheduledAt: new Date("2026-08-20T10:00:01.000Z") })).toBe(false);
    expect(canGroupOrdersInAutomaticTrip({ pickupAddress: "بوابة المطعم", candidatePickupAddress: "بوابة أخرى" })).toBe(false);
  });
});
