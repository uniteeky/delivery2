import { describe, expect, it } from "vitest";
import { buildShiftEndValues, buildShiftStartValues, canAccessDashboardPath, canAddOrderToTrip, canManageCompany, canOperateOrders, canStartDriverShift, canTransitionOrder, canTransitionTrip, canViewCompanyMedia, canViewFinancials, filterCompanyMediaForPortal, getDashboardQuickActionPath, splitDriverOrders } from "../shared/operations";

describe("dashboard quick actions", () => {
  it("routes each management action to its intended screen", () => {
    expect(getDashboardQuickActionPath("newOrder")).toBe("/orders/new");
    expect(getDashboardQuickActionPath("users")).toBe("/users");
    expect(getDashboardQuickActionPath("finance")).toBe("/finance");
    expect(getDashboardQuickActionPath("operationsRoom")).toBe("/operations-room");
  });
});

describe("driver order sections", () => {
  it("keeps delivered orders out of the active screen and preserves them for Delivered Orders", () => {
    const result = splitDriverOrders([
      { id: 1, status: "assigned" as const },
      { id: 2, status: "in_transit" as const },
      { id: 3, status: "delivered" as const },
      { id: 3, status: "delivered" as const },
    ]);
    expect(result.active.map((order) => order.id)).toEqual([1, 2]);
    expect(result.delivered.map((order) => order.id)).toEqual([3]);
  });
});

describe("order lifecycle rules", () => {
  it("allows the normal pickup and delivery flow", () => {
    expect(canTransitionOrder("pending", "assigned")).toBe(true);
    expect(canTransitionOrder("assigned", "picked_up")).toBe(true);
    expect(canTransitionOrder("picked_up", "in_transit")).toBe(true);
    expect(canTransitionOrder("in_transit", "delivered")).toBe(true);
  });

  it("prevents editing a delivered order into an active state", () => {
    expect(canTransitionOrder("delivered", "in_transit")).toBe(false);
    expect(canTransitionOrder("delivered", "pending")).toBe(false);
  });

  it("keeps failed deliveries recoverable through reassignment", () => {
    expect(canTransitionOrder("failed", "assigned")).toBe(true);
    expect(canTransitionOrder("failed", "in_transit")).toBe(true);
  });
});

describe("trip lifecycle rules", () => {
  it("allows pending, assigned, and failed orders in open or active trips", () => {
    expect(canAddOrderToTrip("pending", "open")).toBe(true);
    expect(canAddOrderToTrip("assigned", "active")).toBe(true);
    expect(canAddOrderToTrip("failed", "active")).toBe(true);
    expect(canAddOrderToTrip("delivered", "active")).toBe(false);
  });

  it("rejects closed trips and invalid lifecycle transitions", () => {
    expect(canAddOrderToTrip("pending", "closed")).toBe(false);
    expect(canTransitionTrip("open", "active")).toBe(true);
    expect(canTransitionTrip("active", "closed")).toBe(true);
    expect(canTransitionTrip("closed", "active")).toBe(false);
  });

  it("supports a multi-company trip while keeping driver assignment scoped", () => {
    const assignedOrders = [
      { companyId: 10, driverId: 7, status: "assigned" as const },
      { companyId: 11, driverId: 7, status: "pending" as const },
    ];
    expect(new Set(assignedOrders.map((order) => order.companyId)).size).toBe(2);
    expect(assignedOrders.every((order) => order.driverId === 7)).toBe(true);
    expect(assignedOrders.every((order) => canAddOrderToTrip(order.status, "active"))).toBe(true);
    expect(assignedOrders.some((order) => order.driverId !== 7)).toBe(false);
    expect(canAddOrderToTrip("delivered", "closed")).toBe(false);
  });
});

describe("shift lifecycle rules", () => {
  it("rejects duplicate active shifts and preserves GPS plus UTC timestamps", () => {
    const startedAt = new Date("2026-08-19T10:00:00.000Z");
    const endedAt = new Date("2026-08-19T18:00:00.000Z");
    expect(canStartDriverShift(false)).toBe(true);
    expect(canStartDriverShift(true)).toBe(false);
    expect(buildShiftStartValues(7, "29.3759000", "47.9774000", startedAt)).toEqual({ driverId: 7, startedAt, startLatitude: "29.3759000", startLongitude: "47.9774000" });
    expect(buildShiftEndValues("29.3800000", "47.9800000", endedAt)).toEqual({ endedAt, endLatitude: "29.3800000", endLongitude: "47.9800000" });
  });
});

describe("company media isolation", () => {
  it("allows only explicitly permitted media for the company's own orders", () => {
    expect(canViewCompanyMedia("company", true, "company_media_pickup")).toBe(true);
    expect(canViewCompanyMedia("company", true, "company_media_invoice")).toBe(true);
    expect(canViewCompanyMedia("company", true, "company_media_delivery")).toBe(true);
  });

  it("filters actual portal media by granted media permissions", () => {
    const media = [{ orderId: 10, kind: "order" as const }, { orderId: 10, kind: "invoice" as const }, { orderId: 10, kind: "delivery" as const }, { orderId: 11, kind: "delivery" as const }];
    expect(filterCompanyMediaForPortal(media, ["company_media_delivery"])).toEqual([{ orderId: 10, kind: "delivery" }, { orderId: 11, kind: "delivery" }]);
    expect(filterCompanyMediaForPortal(media, ["company_media_pickup", "company_media_invoice"])).toEqual([{ orderId: 10, kind: "order" }, { orderId: 10, kind: "invoice" }]);
  });

  it("blocks other-company orders and non-company roles from the company media path", () => {
    expect(canViewCompanyMedia("company", false, "company_media_delivery")).toBe(false);
    expect(canViewCompanyMedia("company", true, "orders_view")).toBe(false);
    expect(canViewCompanyMedia("driver", true, "company_media_delivery")).toBe(false);
  });
});

describe("dashboard route isolation", () => {
  it("limits driver and company users to their own portal paths", () => {
    expect(canAccessDashboardPath("driver", "/driver", [])).toBe(true);
    expect(canAccessDashboardPath("driver", "/finance", [])).toBe(false);
    expect(canAccessDashboardPath("company", "/company", [])).toBe(true);
    expect(canAccessDashboardPath("company", "/users", [])).toBe(false);
  });

  it("requires explicit permissions for extra accountant and supervisor pages", () => {
    expect(canAccessDashboardPath("accountant", "/orders/new", [])).toBe(false);
    expect(canAccessDashboardPath("accountant", "/orders/new", ["orders_manage"])).toBe(true);
    expect(canAccessDashboardPath("supervisor", "/finance", [])).toBe(false);
    expect(canAccessDashboardPath("supervisor", "/finance", ["finance_view"])).toBe(true);
    expect(canAccessDashboardPath("supervisor", "/operations-room", ["dashboard_view"])).toBe(true);
    expect(canAccessDashboardPath("supervisor", "/operations-room", [])).toBe(false);
    expect(canAccessDashboardPath("supervisor", "/messaging", ["dashboard_view"])).toBe(true);
    expect(canAccessDashboardPath("accountant", "/messaging", [])).toBe(false);
  });
});

describe("role permissions", () => {
  it("restricts company management to admins", () => {
    expect(canManageCompany("admin")).toBe(true);
    expect(canManageCompany("supervisor")).toBe(false);
    expect(canManageCompany("accountant")).toBe(false);
  });

  it("allows operations roles to work with orders", () => {
    expect(canOperateOrders("admin")).toBe(true);
    expect(canOperateOrders("supervisor")).toBe(true);
    expect(canOperateOrders("driver")).toBe(true);
    expect(canOperateOrders("accountant")).toBe(false);
  });

  it("keeps financial reporting restricted", () => {
    expect(canViewFinancials("admin")).toBe(true);
    expect(canViewFinancials("accountant")).toBe(true);
    expect(canViewFinancials("driver")).toBe(false);
  });
});
