import { describe, expect, it } from "vitest";
import { summarizeCashCollections } from "../shared/cash-collection";

describe("cash collection ledger", () => {
  it("totals only amounts actually recorded by drivers", () => {
    expect(summarizeCashCollections([
      { cashCollectedAmount: "2.500", cashCollectionRecorded: true },
      { cashCollectedAmount: "1.125", cashCollectionRecorded: true },
      { cashCollectedAmount: "40.000", cashCollectionRecorded: false },
      { cashCollectedAmount: "90.000", cashCollectionRecorded: null },
    ])).toEqual({ cashCollectedTotal: "3.625", cashCollectionCount: 2 });
  });

  it("counts a recorded zero amount as a completed collection record", () => {
    expect(summarizeCashCollections([{ cashCollectedAmount: "0.000", cashCollectionRecorded: true }]))
      .toEqual({ cashCollectedTotal: "0.000", cashCollectionCount: 1 });
  });

  it("returns a zero ledger for empty or unrecorded rows", () => {
    expect(summarizeCashCollections([])).toEqual({ cashCollectedTotal: "0.000", cashCollectionCount: 0 });
    expect(summarizeCashCollections([{ cashCollectedAmount: "0.000", cashCollectionRecorded: false }]))
      .toEqual({ cashCollectedTotal: "0.000", cashCollectionCount: 0 });
  });
});
