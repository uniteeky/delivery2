import { describe, expect, it } from "vitest";
import { supportedLanguages, translations } from "../client/src/i18n";
import { readFileSync } from "node:fs";

describe("driver translation coverage", () => {
  it("contains driver workflow labels in every supported language", () => {
    const requiredKeys = [
      "startShiftGps",
      "finishShiftGps",
      "gpsSuccess",
      "gpsPermissionDenied",
      "enableAlerts",
      "addToHome",
      "pickupSection",
      "deliverySection",
      "invoicePhoto",
      "deliveryPhoto",
      "confirmDelivery",
      "accountSettings",
      "noActiveOrders",
      "driverAccount",
      "language",
      "driversOnMap",
      "lastUpdated",
    ] as const;

    for (const language of Object.keys(supportedLanguages) as Array<keyof typeof supportedLanguages>) {
      for (const key of requiredKeys) {
        expect(translations[language][key], `${language}.${key}`).toBeTruthy();
      }
    }
  });

  it("uses a gesture-activated repeating driver alert instead of a silent placeholder audio URI", () => {
    const audioSource = readFileSync(new URL("../client/src/lib/driverAudio.ts", import.meta.url), "utf8");
    const alertsSource = readFileSync(new URL("../client/src/components/DriverAlerts.tsx", import.meta.url), "utf8");
    const bellSource = readFileSync(new URL("../client/src/components/NotificationBell.tsx", import.meta.url), "utf8");
    expect(audioSource).toContain("/manus-storage/driver-alert_cf09249a.m4a");
    expect(audioSource).toContain("export function unlockDriverAudio");
    expect(audioSource).toContain("startRepeatingDriverAlert");
    expect(audioSource).toContain("stopRepeatingDriverAlert");
    expect(alertsSource).toContain("unlockDriverAudio");
    expect(alertsSource).toContain("startRepeatingDriverAlert");
    expect(alertsSource).not.toContain("data:audio/wav");
    expect(bellSource).toContain("playDriverAlert");
    expect(bellSource).toContain("unlockDriverAudio");
  });
});
