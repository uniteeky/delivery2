import { describe, expect, it } from "vitest";
import { supportedLanguages, translations } from "../client/src/i18n";

describe("messaging translations", () => {
  const keys = [
    "internalMessaging", "savedConversations", "messagesVisibility", "refresh", "myConversations",
    "noConversations", "newConversation", "optionalTitle", "cannotLoadConversations", "loadingRecipients",
    "cannotLoadRecipients", "noActiveRecipients", "createConversation", "chooseConversation", "messagesSaved",
    "chooseOrCreateConversation", "noSelectedConversation", "loadingMessages", "cannotLoadMessages", "noMessages",
    "writeMessage", "cannotSendMessage", "directConversation", "operationalConversation", "roleAdmin",
    "roleSupervisor", "roleAccountant", "roleDriver", "roleCompany",
  ] as const;

  it("has every messaging key in all supported languages", () => {
    for (const language of Object.keys(supportedLanguages) as Array<keyof typeof translations>) {
      for (const key of keys) {
        expect(translations[language][key]).toBeTruthy();
      }
    }
  });
});
