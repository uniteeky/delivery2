import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";

describe("mobile public home and role registration", () => {
  it("keeps public header controls responsive and exposes role selection", () => {
    const home = readFileSync(new URL("../client/src/pages/Home.tsx", import.meta.url), "utf8");
    const registration = readFileSync(new URL("../client/src/pages/DriverRegistration.tsx", import.meta.url), "utf8");
    expect(home).toContain("flex-col gap-4");
    expect(home).toContain("min-w-[8.5rem]");
    expect(registration).toContain("requestedRole");
    expect(registration).toContain("accountant");
    expect(registration).toContain("supervisor");
    expect(registration).toContain("অনুরোধ করা ভূমিকা");
    expect(registration).toContain("अनुरोधित भूमिका");
    const app = readFileSync(new URL("../client/src/App.tsx", import.meta.url), "utf8");
    expect(app).toContain('path={"/register"}');
    expect(app).toContain('path={"/operations"}');
    const unifiedAccess = readFileSync(new URL("../client/src/components/UnifiedLocalAccessDialog.tsx", import.meta.url), "utf8");
    expect(unifiedAccess).toContain("/api/auth/local-login");
    expect(unifiedAccess).toContain("unified-civil-id");
    expect(unifiedAccess).toContain("unified-password");
    expect(unifiedAccess).toContain('navigate("/register-driver")');
  });
});
