import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const routerSource = readFileSync(new URL("./routers.ts", import.meta.url), "utf8");

describe("driver query response contract", () => {
  it("never returns undefined for a missing driver profile or inactive shift", () => {
    expect(routerSource).toContain("return (await getDriverForUser(ctx.user!.id)) ?? null;");
    expect(routerSource).toContain("return driver ? ((await getActiveDriverShift(driver.id)) ?? null) : null;");
  });
});
