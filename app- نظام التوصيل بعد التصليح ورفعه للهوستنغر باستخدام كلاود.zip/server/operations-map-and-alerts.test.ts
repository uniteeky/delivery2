import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { createOpenStreetMapEmbedUrl, getOperationsMapMarkerPosition, getOperationsMapViewport } from "../client/src/lib/operationsMap";

describe("Hostinger operations map and driver alerts", () => {
  it("builds a key-free OpenStreetMap viewport that contains driver locations", () => {
    const viewport = getOperationsMapViewport([{ latitude: "29.3759", longitude: "47.9774" }]);
    const position = getOperationsMapMarkerPosition({ latitude: "29.3759", longitude: "47.9774" }, viewport);
    expect(createOpenStreetMapEmbedUrl(viewport)).toContain("openstreetmap.org/export/embed.html");
    expect(position.left).toBeGreaterThan(2);
    expect(position.top).toBeGreaterThan(2);
  });

  it("keeps an explicit web-audio handoff and device-vibration path for newly assigned orders", () => {
    const alerts = readFileSync(new URL("../client/src/components/DriverAlerts.tsx", import.meta.url), "utf8");
    const audio = readFileSync(new URL("../client/src/lib/driverAudio.ts", import.meta.url), "utf8");
    expect(alerts).toContain("navigator.vibrate([240, 100, 240, 100, 420])");
    expect(alerts).toContain("DRIVER_AUDIO_READY_EVENT");
    expect(audio).toContain('DRIVER_AUDIO_READY_EVENT = "city-center-driver-audio-ready"');
  });
});
