import { describe, expect, it } from "vitest";
import { translations } from "../client/src/i18n";

describe("operations room translation coverage", () => {
  it("contains all operations-room labels in every supported language", () => {
    const keys = [
      "operationsRoomTitle",
      "operationsRoomDescription",
      "liveDriverMapTitle",
      "liveDriverMapDescription",
      "locationsError",
      "recentOrderActivity",
      "recentOrderActivityDescription",
    ] as const;

    for (const language of ["ar", "en", "bn", "hi"] as const) {
      for (const key of keys) {
        expect(translations[language][key], `${language}.${key}`).toBeTruthy();
      }
    }
  });
});
