type SchemaDatabase = {
  execute: (statement: string) => Promise<unknown>;
};

type DatabaseErrorLike = Error & {
  code?: string;
  errno?: number;
  cause?: unknown;
};

const ensuredDatabases = new WeakSet<object>();
const inFlightByDatabase = new WeakMap<object, Promise<void>>();

const columns = [
  ["brandName", "varchar(180) NOT NULL DEFAULT 'City Center'"],
  ["logoUrl", "text NULL"],
  ["primaryColor", "varchar(16) NOT NULL DEFAULT '#f97316'"],
  ["accentColor", "varchar(16) NOT NULL DEFAULT '#0f172a'"],
  ["subscriptionStartsAt", "timestamp NULL DEFAULT NULL"],
  ["subscriptionEndsAt", "timestamp NULL DEFAULT NULL"],
  ["allowDriverTransfer", "boolean NOT NULL DEFAULT true"],
  ["allowSupervisorTransfer", "boolean NOT NULL DEFAULT true"],
  ["allowManagerTransfer", "boolean NOT NULL DEFAULT true"],
  ["hideDriverDeliveryFee", "boolean NOT NULL DEFAULT true"],
  ["orderNumberFormat", "enum('numeric','alphabetic') NOT NULL DEFAULT 'numeric'"],
  ["nextOrderNumber", "int NOT NULL DEFAULT 1"],
  ["createdAt", "timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP"],
  ["updatedAt", "timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"],
] as const;

function errorDetails(error: unknown) {
  const outer = error as DatabaseErrorLike | null;
  const cause = outer?.cause as DatabaseErrorLike | undefined;
  return {
    code: cause?.code ?? outer?.code,
    errno: cause?.errno ?? outer?.errno,
    message: `${outer?.message ?? String(error)} ${cause?.message ?? ""}`,
  };
}

function isMissingColumnError(error: unknown) {
  const details = errorDetails(error);
  return details.code === "ER_BAD_FIELD_ERROR"
    || details.errno === 1054
    || /unknown column|column .* does not exist/i.test(details.message);
}

/**
 * Ensures the settings table exists and fills in missing additive columns before
 * any query asks Drizzle to select the full current schema. Existing values and
 * rows are preserved; new permission switches default to their prior behavior.
 */
export async function ensurePlatformSettingsSchema(db: SchemaDatabase) {
  if (ensuredDatabases.has(db)) return;
  const current = inFlightByDatabase.get(db);
  if (current) return current;

  const task = (async () => {
    await db.execute(`CREATE TABLE IF NOT EXISTS \`platformSettings\` (
      \`id\` int NOT NULL DEFAULT 1,
      \`brandName\` varchar(180) NOT NULL DEFAULT 'City Center',
      \`logoUrl\` text NULL,
      \`primaryColor\` varchar(16) NOT NULL DEFAULT '#f97316',
      \`accentColor\` varchar(16) NOT NULL DEFAULT '#0f172a',
      \`subscriptionStartsAt\` timestamp NULL DEFAULT NULL,
      \`subscriptionEndsAt\` timestamp NULL DEFAULT NULL,
      \`allowDriverTransfer\` boolean NOT NULL DEFAULT true,
      \`allowSupervisorTransfer\` boolean NOT NULL DEFAULT true,
      \`allowManagerTransfer\` boolean NOT NULL DEFAULT true,
      \`hideDriverDeliveryFee\` boolean NOT NULL DEFAULT true,
      \`orderNumberFormat\` enum('numeric','alphabetic') NOT NULL DEFAULT 'numeric',
      \`nextOrderNumber\` int NOT NULL DEFAULT 1,
      \`createdAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
      \`updatedAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (\`id\`)
    )`);

    for (const [name, definition] of columns) {
      try {
        await db.execute(`SELECT \`${name}\` FROM \`platformSettings\` LIMIT 0`);
      } catch (error) {
        if (!isMissingColumnError(error)) throw error;
        await db.execute(`ALTER TABLE \`platformSettings\` ADD COLUMN \`${name}\` ${definition}`);
      }
    }
  })();

  inFlightByDatabase.set(db, task);
  try {
    await task;
    ensuredDatabases.add(db);
  } catch (error) {
    inFlightByDatabase.delete(db);
    throw error;
  }
}
