import { describe, expect, it } from "vitest";
import { supportedLanguages, translations } from "../client/src/i18n";

describe("driver map translations", () => {
  it("has marker fallback labels in every supported language", () => {
    for (const language of Object.keys(supportedLanguages) as Array<keyof typeof translations>) {
      expect(translations[language].driverNameFallback).toBeTruthy();
      expect(translations[language].lastUpdated).toBeTruthy();
      expect(translations[language].timeUnavailable).toBeTruthy();
      expect(translations[language].driversOnMap).toBeTruthy();
    }
  });
});
