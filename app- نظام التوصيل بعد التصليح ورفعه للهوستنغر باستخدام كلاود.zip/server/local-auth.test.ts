import { scryptSync } from "node:crypto";
import { describe, expect, it } from "vitest";
import { verifyLocalCredentialsWithDb } from "./db";

function makeDb(user: Record<string, unknown>) {
  return { select() { const query = { from() { return query; }, where() { return query; }, limit() { return Promise.resolve([user]); } }; return query; } };
}

const salt = "0123456789abcdef0123456789abcdef";
const passwordHash = `${salt}:${scryptSync("CorrectPass123", salt, 64).toString("hex")}`;

const baseUser = { id: 9, civilId: "123456789012", passwordHash, approvalStatus: "approved", status: "active", role: "driver" };

describe("local Civil ID authentication", () => {
  it("accepts the correct password for an approved active account", async () => {
    const result = await verifyLocalCredentialsWithDb(makeDb(baseUser) as never, "123456789012", "CorrectPass123");
    expect(result?.id).toBe(9);
  });

  it("rejects wrong passwords and pending or inactive accounts", async () => {
    expect(await verifyLocalCredentialsWithDb(makeDb(baseUser) as never, "123456789012", "WrongPass123")).toBeUndefined();
    expect(await verifyLocalCredentialsWithDb(makeDb({ ...baseUser, approvalStatus: "pending" }) as never, "123456789012", "CorrectPass123")).toBeUndefined();
    expect(await verifyLocalCredentialsWithDb(makeDb({ ...baseUser, status: "inactive" }) as never, "123456789012", "CorrectPass123")).toBeUndefined();
  });
});
