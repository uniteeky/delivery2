import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

describe("pickup phone workflow", () => {
  it("stores the pickup phone and requires it in driver and supervisor order forms", () => {
    const schema = readFileSync(resolve(process.cwd(), "drizzle/schema.ts"), "utf8");
    const db = readFileSync(resolve(process.cwd(), "server/db.ts"), "utf8");
    const router = readFileSync(resolve(process.cwd(), "server/routers.ts"), "utf8");
    const driverForm = readFileSync(resolve(process.cwd(), "client/src/pages/DriverNewOrder.tsx"), "utf8");
    const supervisorForm = readFileSync(resolve(process.cwd(), "client/src/pages/NewOrder.tsx"), "utf8");
    const driverHome = readFileSync(resolve(process.cwd(), "client/src/pages/DriverHome.tsx"), "utf8");

    expect(schema).toContain('pickupPhone: varchar("pickupPhone", { length: 40 })');
    expect(schema).toContain('pickupContactName: varchar("pickupContactName", { length: 180 })');
    expect(db).toContain("pickupPhone?: string");
    expect(db).toContain("pickupContactName?: string");
    expect(db).toContain("pickupPhone: input.pickupPhone");
    expect(db).toContain("pickupContactName: input.pickupContactName");
    expect(router).toContain('pickupPhone: z.string().trim().min(5).max(40)');
    expect(driverForm).toContain("pickupPhone");
    expect(driverForm).toContain("هاتف الاستلام *");
    expect(driverForm).toContain("اسم الاستلام *");
    expect(driverForm).toContain("هاتف المستلم *");
    expect(driverForm).toContain("ملاحظات تشغيلية");
    expect(driverForm).toContain("إرسال الطلب");
    expect(supervisorForm).toContain("هاتف الاستلام *");
    expect(supervisorForm).toContain("هاتف المستلم *");
    expect(supervisorForm).toContain("اسم الاستلام *");
    expect(supervisorForm).toContain("اسم المستلم (اختياري)");
    expect(supervisorForm).toContain("cashToCollectAmount");
    expect(supervisorForm).toContain("cashCollectionNote");
    expect(driverHome).toContain("cashCollectedTotal");
    expect(driverHome).toContain("cashCollectedAmount");
    expect(supervisorForm).toContain("ملاحظات تشغيلية");
    expect(supervisorForm).toContain("تحديد السائق *");
    expect(supervisorForm).toContain("driverId: Number(form.driverId)");
    expect(supervisorForm).toContain("اختر السائق الذي سيستلم الطلب");
    expect(driverHome).toContain('label="هاتف الاستلام"');
    expect(driverHome).toContain('label="هاتف التسليم"');
    expect(driverHome).toContain("pickupPhone={order.pickupPhone || order.companyPhone}");
    expect(driverHome).toContain("customerName={order.customerName}");
    expect(driverHome).toContain('tr("العميل")}: ${customerName}');
  });
});
