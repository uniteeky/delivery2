import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

describe("Users card layout", () => {
  it("keeps the account name on a readable standalone row before management controls", () => {
    const styles = readFileSync(new URL("../client/src/index.css", import.meta.url), "utf8");
    expect(styles).toContain("Keep the account identity readable before the management controls in Users");
    expect(styles).toContain('grid-template-areas: "icon name" "icon details"');
    expect(styles).toContain("white-space: normal;");
    expect(styles).toContain("overflow-wrap: anywhere;");
  });

  it("uses a white, high-contrast surface for the driver-profile synchronization dialog", () => {
    const styles = readFileSync(new URL("../client/src/index.css", import.meta.url), "utf8");
    expect(styles).toContain('dialog-content"]:has(#driver-vehicle)');
    expect(styles).toContain("background: #ffffff;");
    expect(styles).toContain("color: #0f172a;");
  });
});
