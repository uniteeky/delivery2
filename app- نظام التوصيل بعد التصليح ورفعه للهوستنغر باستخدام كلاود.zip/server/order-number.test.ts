import { describe, expect, it } from "vitest";
import { formatOrderNumber } from "../shared/order-number";

describe("formatOrderNumber", () => {
  it("formats padded numeric order sequences", () => {
    expect(formatOrderNumber(1, "numeric")).toBe("CC-000001");
    expect(formatOrderNumber(120045, "numeric")).toBe("CC-120045");
    expect(formatOrderNumber(1_000_000, "numeric")).toBe("CC-1000000");
  });

  it("formats alphabetical labels like spreadsheet columns", () => {
    expect(formatOrderNumber(1, "alphabetic")).toBe("CC-A");
    expect(formatOrderNumber(26, "alphabetic")).toBe("CC-Z");
    expect(formatOrderNumber(27, "alphabetic")).toBe("CC-AA");
    expect(formatOrderNumber(52, "alphabetic")).toBe("CC-AZ");
    expect(formatOrderNumber(53, "alphabetic")).toBe("CC-BA");
  });

  it("rejects zero, negative, and non-integer sequence values", () => {
    expect(() => formatOrderNumber(0, "numeric")).toThrow();
    expect(() => formatOrderNumber(-1, "alphabetic")).toThrow();
    expect(() => formatOrderNumber(1.5, "numeric")).toThrow();
  });
});
