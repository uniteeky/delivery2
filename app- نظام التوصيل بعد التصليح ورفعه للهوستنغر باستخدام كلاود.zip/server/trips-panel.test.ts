import { describe, expect, it } from "vitest";
import { canSubmitManualOrderId, filterRecentOrderOptions, manualFallbackMessage, normalizeManualOrderId, recentOrdersPickerState } from "../shared/trips-panel";

describe("TripsPanel order picker fallback", () => {
  it("keeps manual order IDs usable when recent orders fail", () => {
    const state = recentOrdersPickerState({ isLoading: false, hasError: true, optionCount: 0 });
    expect(state.disabled).toBe(true);
    expect(manualFallbackMessage(true, false)).toContain("أدخل رقم الطلب");
    expect(normalizeManualOrderId("ORD-204 الكويت")).toBe("204");
    expect(canSubmitManualOrderId("ORD-204 الكويت")).toBe(true);
  });

  it("keeps manual order IDs usable when the recent list is empty", () => {
    const state = recentOrdersPickerState({ isLoading: false, hasError: false, optionCount: 0 });
    expect(state.disabled).toBe(false);
    expect(state.manualFallback).toBe(true);
    expect(manualFallbackMessage(false, false)).toContain("أدخل رقم الطلب");
    expect(canSubmitManualOrderId("77")).toBe(true);
  });

  it("filters options while preserving loading state semantics", () => {
    expect(recentOrdersPickerState({ isLoading: true, hasError: false, optionCount: 0 })).toMatchObject({ disabled: true });
    expect(filterRecentOrderOptions([{ id: 1, orderNumber: "CC-101", status: "pending" }, { id: 2, orderNumber: "CC-202", status: "assigned" }], "202")).toEqual([{ id: 2, orderNumber: "CC-202", status: "assigned" }]);
  });
});
