import { describe, expect, it } from "vitest";
import { shouldCountCompanyShare, shouldCountDeliveryFee, shouldCountDriverCommission } from "../shared/order-accounting";

const returned = { status: "failed", deliveryFeeChargeOnFailure: false, driverCommissionManual: false, companyShareManual: false, returnedToCompany: true };

describe("order accounting allocation policy", () => {
  it("does not accrue fees, commission, or company share on a returned order by default", () => {
    expect(shouldCountDeliveryFee(returned)).toBe(false);
    expect(shouldCountDriverCommission(returned)).toBe(false);
    expect(shouldCountCompanyShare(returned)).toBe(false);
  });
  it("allows the delivery fee to be charged on an unsuccessful non-return order when explicitly enabled", () => {
    expect(shouldCountDeliveryFee({ ...returned, returnedToCompany: false, deliveryFeeChargeOnFailure: true })).toBe(true);
  });
  it("allows a separately adjusted failed-order commission/share, even after a return", () => {
    const manual = { ...returned, driverCommissionManual: true, companyShareManual: true };
    expect(shouldCountDriverCommission(manual)).toBe(true);
    expect(shouldCountCompanyShare(manual)).toBe(true);
  });
  it("counts successful deliveries regardless of manual override flags", () => {
    const delivered = { ...returned, status: "delivered" };
    expect(shouldCountDeliveryFee(delivered)).toBe(true);
    expect(shouldCountDriverCommission(delivered)).toBe(true);
    expect(shouldCountCompanyShare(delivered)).toBe(true);
  });
});
