import type { Request, Response } from "express";
import { sdk } from "./_core/sdk";
import { createBackupSnapshot, getBackupScheduleByTaskUid, markBackupRun } from "./db";
import { storageGetSignedUrl, storagePut } from "./storage";

export async function runScheduledBackup(req: Request, res: Response) {
  const context = { url: req.originalUrl, taskUid: undefined as string | undefined };
  try {
    const user = await sdk.authenticateRequest(req);
    context.taskUid = user.taskUid;
    if (!user.isCron || !user.taskUid) return res.status(403).json({ error: "cron-only" });
    const schedule = await getBackupScheduleByTaskUid(user.taskUid);
    if (!schedule || !schedule.enabled) return res.json({ ok: true, skipped: "orphan-or-disabled" });
    const snapshot = await createBackupSnapshot();
    const backupPrefix = `backups/${schedule.id}/${snapshot.generatedAt.replace(/[:.]/g, "-")}`;
    const fileBackups: Array<{ mediaId: number; sourceKey: string; backupKey: string }> = [];
    for (const media of snapshot.tables.orderMedia) {
      const signedUrl = await storageGetSignedUrl(media.fileKey);
      const response = await fetch(signedUrl);
      if (!response.ok) throw new Error(`Media backup download failed (${response.status}) for ${media.fileKey}`);
      const bytes = new Uint8Array(await response.arrayBuffer());
      const uploadedFile = await storagePut(`${backupPrefix}/files/${media.id}-${media.kind}`, bytes, "application/octet-stream");
      fileBackups.push({ mediaId: media.id, sourceKey: media.fileKey, backupKey: uploadedFile.key });
    }
    const payload = JSON.stringify({ ...snapshot, files: fileBackups, coverage: { databaseTables: Object.keys(snapshot.tables), mediaFilesCopied: fileBackups.length } });
    const uploaded = await storagePut(`${backupPrefix}/manifest.json`, payload, "application/json");
    await markBackupRun(schedule.id);
    return res.json({ ok: true, key: uploaded.key, url: uploaded.url, generatedAt: snapshot.generatedAt });
  } catch (error) {
    return res.status(500).json({ error: String(error), stack: error instanceof Error ? error.stack : undefined, context, timestamp: new Date().toISOString() });
  }
}
