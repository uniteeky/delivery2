import { describe, expect, it } from "vitest";
import { buildLocationLabelMaps, locationLabelKey } from "./location-labels";

describe("order locality labels", () => {
  it("resolves an area's governorate even when only the area ID is stored", () => {
    const input = { areaId: 8, governorateId: null };
    const labels = buildLocationLabelMaps([input], [{ id: 3, nameAr: "العاصمة" }], [{ id: 8, governorateId: 3, nameAr: "الشرق" }]);
    expect(labels.get(locationLabelKey(input))).toEqual({ governorateName: "العاصمة", areaName: "الشرق" });
  });

  it("keeps governorate-only pickup and delivery records separate", () => {
    const pickup = { governorateId: 3, areaId: null };
    const delivery = { governorateId: 5, areaId: null };
    const labels = buildLocationLabelMaps([pickup, delivery], [{ id: 3, nameAr: "العاصمة" }, { id: 5, nameAr: "الأحمدي" }], []);
    expect(labels.get(locationLabelKey(pickup))?.governorateName).toBe("العاصمة");
    expect(labels.get(locationLabelKey(delivery))?.governorateName).toBe("الأحمدي");
  });
});
