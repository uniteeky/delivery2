import { describe, expect, it, vi } from "vitest";
import * as db from "./db";
import { appRouter } from "./routers";

const admin = { id: 1, role: "admin" as const, status: "active" as const, approvalStatus: "approved" as const, name: "Admin" };
const supervisor = { id: 2, role: "supervisor" as const, status: "active" as const, approvalStatus: "approved" as const, name: "Supervisor" };
const caller = (user: typeof admin | typeof supervisor) => appRouter.createCaller({ user, req: {} as never, res: {} as never });

describe("user profile administration", () => {
  it("updates validated profile fields and optional company linkage through the manager route", async () => {
    const update = vi.spyOn(db, "updateUserProfile").mockResolvedValue({ id: 7, name: "اسم جديد", phone: "55555555", email: "new@example.com", companyId: 12 });
    try {
      await expect(caller(admin).users.updateProfile({ userId: 7, name: "اسم جديد", phone: "55555555", email: "new@example.com", companyId: 12 })).resolves.toMatchObject({ companyId: 12 });
      expect(update).toHaveBeenCalledWith(7, { userId: 7, name: "اسم جديد", phone: "55555555", email: "new@example.com", companyId: 12 }, 1);
    } finally { update.mockRestore(); }
  });

  it("rejects profile edits from delegated non-admin roles", async () => {
    const update = vi.spyOn(db, "updateUserProfile");
    try {
      await expect(caller(supervisor).users.updateProfile({ userId: 7, name: "اسم جديد", phone: "55555555" })).rejects.toMatchObject({ code: "FORBIDDEN" });
      expect(update).not.toHaveBeenCalled();
    } finally { update.mockRestore(); }
  });
});
