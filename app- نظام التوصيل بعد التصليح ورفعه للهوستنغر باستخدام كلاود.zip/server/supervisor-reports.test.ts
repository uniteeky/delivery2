import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";

describe("supervisor operational reports", () => {
  it("exposes the protected report procedure and report UI controls", () => {
    const routerSource = readFileSync(new URL("./routers.ts", import.meta.url), "utf8");
    const pageSource = readFileSync(new URL("../client/src/pages/OperationsRoom.tsx", import.meta.url), "utf8");
    expect(routerSource).toContain("supervisorReports: router");
    expect(routerSource).toContain("getSupervisorOperationalReport(input ?? {})");
    expect(pageSource).toContain("trpc.supervisorReports.get.useQuery");
    expect(pageSource).toContain("type=\"date\"");
    expect(pageSource).toContain("window.print()");
    expect(pageSource).toContain("Historical photos");
  });
});
