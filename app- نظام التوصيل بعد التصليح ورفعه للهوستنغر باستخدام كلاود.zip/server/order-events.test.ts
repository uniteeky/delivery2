import { describe, expect, it } from "vitest";
import { updateOrderStatusWithDb } from "./db";

function fakeDb() {
  const events: any[] = [];
  const order = { id: 12, status: "assigned" };
  return { events, select() { const query = { from() { return query; }, where() { return query; }, limit() { return Promise.resolve([order]); } }; return query; }, update() { return { set(value: any) { Object.assign(order, value); return { where() { return Promise.resolve(); } }; } }; }, insert() { return { values(value: any) { if (value.type) events.push({ ...value, occurredAt: new Date() }); return Promise.resolve(); } }; } };
}

describe("order event GPS timestamps", () => {
  it("persists pickup and delivery GPS values with server-created UTC timestamps", async () => {
    const db = fakeDb();
    const before = Date.now();
    await updateOrderStatusWithDb(db as never, 12, "picked_up", 22, "29.3375", "48.0281", "pickup");
    await updateOrderStatusWithDb(db as never, 12, "delivered", 22, "29.3400", "48.0300", "delivery");
    const after = Date.now();
    expect(db.events).toHaveLength(2);
    expect(db.events[0]).toMatchObject({ type: "picked_up", latitude: "29.3375", longitude: "48.0281" });
    expect(db.events[1]).toMatchObject({ type: "delivered", latitude: "29.3400", longitude: "48.0300" });
    for (const event of db.events) {
      expect(event.occurredAt).toBeInstanceOf(Date);
      expect(event.occurredAt.getTime()).toBeGreaterThanOrEqual(before);
      expect(event.occurredAt.getTime()).toBeLessThanOrEqual(after);
      expect(event.occurredAt.toISOString()).toMatch(/Z$/);
    }
  });
});
