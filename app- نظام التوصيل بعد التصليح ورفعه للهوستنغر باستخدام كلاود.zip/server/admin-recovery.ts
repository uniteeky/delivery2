import { createHash, timingSafeEqual } from "node:crypto";

export function isValidAdminRecoverySecret(provided: unknown, expected: string): boolean {
  if (typeof provided !== "string" || expected.length < 40) return false;
  const providedBytes = Buffer.from(provided, "utf8");
  const expectedBytes = Buffer.from(expected, "utf8");
  return providedBytes.length === expectedBytes.length && timingSafeEqual(providedBytes, expectedBytes);
}

/** Store only a non-reversible fingerprint in the audit action, never the secret itself. */
export function adminRecoveryAuditAction(secret: string): string {
  const digest = createHash("sha256").update(secret, "utf8").digest("hex");
  return `auth.admin_recovery_${digest}`;
}
