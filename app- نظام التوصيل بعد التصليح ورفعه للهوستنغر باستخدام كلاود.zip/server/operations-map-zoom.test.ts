import { describe, expect, it } from "vitest";
import { getOperationsMapMarkerPosition, scaleOperationsMapViewport } from "../client/src/lib/operationsMap";
import { readFileSync } from "node:fs";

describe("operations map controls", () => {
  it("uses a Mercator-aware marker position and shrinks the viewport when zooming in", () => {
    const viewport = { west: 47.8, east: 48.1, south: 29.1, north: 29.5 };
    const point = getOperationsMapMarkerPosition({ latitude: 29.3, longitude: 47.95 }, viewport);
    const zoomed = scaleOperationsMapViewport(viewport, 0.6);
    expect(point.left).toBeGreaterThan(0);
    expect(point.top).toBeGreaterThan(0);
    expect(zoomed.east - zoomed.west).toBeLessThan(viewport.east - viewport.west);
  });

  it("shows only recent locations for drivers with an open shift", () => {
    const db = readFileSync(new URL("./db.ts", import.meta.url), "utf8");
    expect(db).toContain("freshnessCutoff");
    expect(db).toContain("isNull(shifts.endedAt)");
  });
});
