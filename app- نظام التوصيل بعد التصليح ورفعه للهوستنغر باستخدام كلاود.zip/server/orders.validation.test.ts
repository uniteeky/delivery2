import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createContext(): TrpcContext {
  const now = new Date();
  const user: AuthenticatedUser = {
    id: 1,
    openId: "validation-user",
    email: "validation@example.com",
    name: "Validation User",
    loginMethod: "manus",
    role: "admin",
    roles: ["admin"],
    status: "active",
    approvalStatus: "approved",
    createdAt: now,
    updatedAt: now,
    lastSignedIn: now,
  };

  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("orders.create validation", () => {
  it("rejects supervisor orders without a pickup address", async () => {
    const caller = appRouter.createCaller(createContext());

    await expect(caller.orders.create({
      source: "supervisor",
      companyId: 1,
      driverId: 2,
      deliveryAddress: "عنوان التسليم صالح",
    } as never)).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("rejects supervisor orders without an assigned driver", async () => {
    const caller = appRouter.createCaller(createContext());

    await expect(caller.orders.create({
      source: "supervisor",
      companyId: 1,
      pickupAddress: "عنوان الاستلام صالح",
      deliveryAddress: "عنوان التسليم صالح",
    } as never)).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("rejects orders with a blank delivery address", async () => {
    const caller = appRouter.createCaller(createContext());

    await expect(caller.orders.create({
      source: "external",
      pickupAddress: "عنوان الاستلام صالح",
      deliveryAddress: "   ",
    } as never)).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });
});
