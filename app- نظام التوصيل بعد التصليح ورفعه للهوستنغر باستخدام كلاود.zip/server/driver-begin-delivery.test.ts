import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import * as db from "./db";
import type { TrpcContext } from "./_core/context";

function context(): TrpcContext {
  const now = new Date();
  return { user: { id: 33, openId: "driver-begin", name: "سائق", role: "driver", roles: ["driver"], status: "active", approvalStatus: "approved", createdAt: now, updatedAt: now, lastSignedIn: now }, req: { protocol: "https", headers: {} } as TrpcContext["req"], res: {} as TrpcContext["res"] };
}

describe("driver.beginDelivery", () => {
  it("moves only the driver's own order to the pickup-photo stage", async () => {
    const ownership = vi.spyOn(db, "driverOwnsOrder").mockResolvedValue(true);
    const update = vi.spyOn(db, "updateOrderStatus").mockResolvedValue({ orderId: 91, status: "picked_up" });
    try {
      await expect(appRouter.createCaller(context()).driver.beginDelivery({ orderId: 91, latitude: "29.3", longitude: "48.0" })).resolves.toMatchObject({ status: "picked_up" });
      expect(update).toHaveBeenCalledWith(91, "picked_up", 33, "29.3", "48.0", "بدأ التوصيل");
    } finally { ownership.mockRestore(); update.mockRestore(); }
  });
});
