import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const viteModulePath = fileURLToPath(new URL("./_core/vite.ts", import.meta.url));

describe("production Vite boundary", () => {
  it("loads Vite only from the development setup function", async () => {
    const source = await readFile(viteModulePath, "utf8");

    expect(source).not.toContain('from "vite"');
    expect(source).not.toContain('from "../../vite.config"');
    expect(source).toContain('const viteModuleId = "vite"');
    expect(source).toContain('const viteConfigModuleId = "../../vite.config"');
    expect(source).toContain("import(viteModuleId)");
    expect(source).toContain("import(viteConfigModuleId)");
  });
});
