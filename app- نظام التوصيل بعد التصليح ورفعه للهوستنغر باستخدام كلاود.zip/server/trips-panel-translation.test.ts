import { describe, expect, it } from "vitest";
import { supportedLanguages, translations } from "../client/src/i18n";

describe("trips panel translations", () => {
  const keys = [
    "tripManagement", "tripsDescription", "driverFileNumber", "optionalTripName", "creatingTrip", "createTrip",
    "loadDriverTripsError", "automaticGrouped", "manualTrip", "driverLabel", "orderCount", "automaticTripReason",
    "manualTripReason", "searchOrder", "selectOrder", "tripOrdersLoadError", "tripNoOrders", "closedTripMessage",
    "tripOpenStatus", "tripActiveStatus", "tripClosedStatus",
  ] as const;

  it("has every trip-panel key in all supported languages", () => {
    for (const language of Object.keys(supportedLanguages) as Array<keyof typeof translations>) {
      for (const key of keys) expect(translations[language][key]).toBeTruthy();
    }
  });
});
