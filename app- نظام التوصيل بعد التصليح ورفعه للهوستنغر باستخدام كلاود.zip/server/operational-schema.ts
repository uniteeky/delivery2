type SchemaDatabase = { execute: (statement: string) => Promise<unknown> };
type DatabaseErrorLike = Error & {
  code?: string;
  errno?: number;
  cause?: unknown;
};

const ensured = new WeakSet<object>();
const inFlight = new WeakMap<object, Promise<void>>();

const additiveColumns = [
  ["companyAddresses", "pickupContactName", "varchar(180) NULL"],
  ["companyAddresses", "locationUrl", "varchar(1000) NULL"],
  ["companyAddresses", "governorateId", "int NULL"],
  ["companyAddresses", "areaId", "int NULL"],
  [
    "drivers",
    "driverPayType",
    "enum('salary','salary_commission','contractor') NOT NULL DEFAULT 'salary'",
  ],
  [
    "drivers",
    "vehicleType",
    "enum('car','refrigerated_car','motorcycle','semi_truck','refrigerated_semi_truck','truck','refrigerated_truck') NOT NULL DEFAULT 'car'",
  ],
  ["drivers", "baseSalary", "decimal(10,3) NOT NULL DEFAULT 0.000"],
  ["drivers", "defaultCommission", "decimal(10,3) NOT NULL DEFAULT 0.000"],
  ["orders", "pickupGovernorateId", "int NULL"],
  ["orders", "pickupAreaId", "int NULL"],
  ["orders", "pickupLocationUrl", "varchar(1000) NULL"],
  [
    "orders",
    "requestedVehicleType",
    "enum('car','refrigerated_car','motorcycle','semi_truck','refrigerated_semi_truck','truck','refrigerated_truck') NULL",
  ],
  ["orders", "deliveryGovernorateId", "int NULL"],
  ["orders", "deliveryAreaId", "int NULL"],
  ["orders", "cashToCollectAmount", "decimal(12,3) NOT NULL DEFAULT 0.000"],
  ["orders", "cashCollectionNote", "text NULL"],
  ["orders", "cashCollectedAmount", "decimal(12,3) NOT NULL DEFAULT 0.000"],
  ["orders", "cashCollectionRecorded", "boolean NOT NULL DEFAULT false"],
  ["orders", "cashCollectedAt", "timestamp NULL"],
  ["orders", "cashCollectedByUserId", "int NULL"],
  ["orders", "cashCollectedShiftId", "bigint NULL"],
  ["orders", "deliveryFeeManual", "boolean NOT NULL DEFAULT false"],
  ["orders", "deliveryFeeChargeOnFailure", "boolean NOT NULL DEFAULT false"],
  ["orders", "driverCommission", "decimal(10,3) NOT NULL DEFAULT 0.000"],
  ["orders", "companyShare", "decimal(10,3) NOT NULL DEFAULT 0.000"],
  ["orders", "driverCommissionManual", "boolean NOT NULL DEFAULT false"],
  ["orders", "companyShareManual", "boolean NOT NULL DEFAULT false"],
  ["orders", "compensationInitialized", "boolean NOT NULL DEFAULT false"],
  ["orders", "returnedToCompany", "boolean NOT NULL DEFAULT false"],
] as const;

const createStatements = [
  `CREATE TABLE IF NOT EXISTS \`governorates\` (
    \`id\` int NOT NULL AUTO_INCREMENT,
    \`nameAr\` varchar(180) NOT NULL,
    \`nameEn\` varchar(180) NOT NULL,
    \`active\` boolean NOT NULL DEFAULT true,
    \`createdAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    \`updatedAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (\`id\`), UNIQUE KEY \`governorates_name_ar_unique\` (\`nameAr\`), KEY \`governorates_active_idx\` (\`active\`)
  )`,
  `CREATE TABLE IF NOT EXISTS \`deliveryAreas\` (
    \`id\` int NOT NULL AUTO_INCREMENT,
    \`governorateId\` int NOT NULL,
    \`nameAr\` varchar(180) NOT NULL,
    \`nameEn\` varchar(180) NOT NULL,
    \`active\` boolean NOT NULL DEFAULT true,
    \`createdAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    \`updatedAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (\`id\`), UNIQUE KEY \`delivery_areas_governorate_name_unique\` (\`governorateId\`, \`nameAr\`), KEY \`delivery_areas_governorate_active_idx\` (\`governorateId\`, \`active\`)
  )`,
  `CREATE TABLE IF NOT EXISTS \`companyAreaRates\` (
    \`id\` int NOT NULL AUTO_INCREMENT,
    \`companyId\` int NOT NULL,
    \`areaId\` int NOT NULL,
    \`amount\` decimal(10,3) NOT NULL DEFAULT 0.000,
    \`createdByUserId\` int NOT NULL,
    \`createdAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    \`updatedAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (\`id\`), UNIQUE KEY \`company_area_rates_company_area_unique\` (\`companyId\`, \`areaId\`), KEY \`company_area_rates_area_idx\` (\`areaId\`)
  )`,
  `CREATE TABLE IF NOT EXISTS \`companyGovernorateRates\` (
    \`id\` int NOT NULL AUTO_INCREMENT,
    \`companyId\` int NOT NULL,
    \`governorateId\` int NOT NULL,
    \`amount\` decimal(10,3) NOT NULL DEFAULT 0.000,
    \`createdByUserId\` int NOT NULL,
    \`createdAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    \`updatedAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (\`id\`), UNIQUE KEY \`company_governorate_rates_company_governorate_unique\` (\`companyId\`, \`governorateId\`), KEY \`company_governorate_rates_governorate_idx\` (\`governorateId\`)
  )`,
  `CREATE TABLE IF NOT EXISTS \`companyAddresses\` (
    \`id\` int NOT NULL AUTO_INCREMENT,
    \`companyId\` int NOT NULL,
    \`label\` varchar(180) NOT NULL,
    \`address\` text NOT NULL,
    \`phone\` varchar(40) NULL,
    \`pickupContactName\` varchar(180) NULL,
    \`locationUrl\` varchar(1000) NULL,
    \`governorateId\` int NULL,
    \`areaId\` int NULL,
    \`isDefault\` boolean NOT NULL DEFAULT false,
    \`active\` boolean NOT NULL DEFAULT true,
    \`createdAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    \`updatedAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (\`id\`), KEY \`company_addresses_company_default_idx\` (\`companyId\`, \`isDefault\`, \`active\`)
  )`,
  `CREATE TABLE IF NOT EXISTS \`driverCommissionRates\` (
    \`id\` int NOT NULL AUTO_INCREMENT,
    \`driverId\` int NOT NULL,
    \`companyId\` int NULL,
    \`areaId\` int NULL,
    \`amount\` decimal(10,3) NOT NULL DEFAULT 0.000,
    \`createdByUserId\` int NOT NULL,
    \`createdAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    \`updatedAt\` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (\`id\`), KEY \`driver_commission_rates_driver_idx\` (\`driverId\`), KEY \`driver_commission_rates_company_area_idx\` (\`companyId\`, \`areaId\`)
  )`,
] as const;

function details(error: unknown) {
  const outer = error as DatabaseErrorLike | null;
  const cause = outer?.cause as DatabaseErrorLike | undefined;
  return {
    code: cause?.code ?? outer?.code,
    errno: cause?.errno ?? outer?.errno,
    message: `${outer?.message ?? String(error)} ${cause?.message ?? ""}`,
  };
}

function isMissingColumn(error: unknown) {
  const value = details(error);
  return (
    value.code === "ER_BAD_FIELD_ERROR" ||
    value.errno === 1054 ||
    /unknown column|column .* does not exist/i.test(value.message)
  );
}

export async function ensureOperationalSchema(db: SchemaDatabase) {
  if (ensured.has(db)) return;
  const running = inFlight.get(db);
  if (running) return running;

  const task = (async () => {
    for (const statement of createStatements) await db.execute(statement);
    // Optional role migrations must never prevent the existing application from starting.
    // Some Hostinger plans reject ALTER TABLE for the runtime database user.
    try {
      await db.execute(
        "ALTER TABLE `users` MODIFY COLUMN `role` enum('admin','supervisor','accountant','driver','company','trader') NOT NULL DEFAULT 'driver'"
      );
    } catch {
      // The old roles remain usable; the admin can apply this additive migration later.
    }
    try {
      await db.execute(
        "ALTER TABLE `users` MODIFY COLUMN `requestedRole` enum('driver','supervisor','accountant','company','trader') NULL"
      );
    } catch {
      // Keep login available when ALTER TABLE is unavailable.
    }
    for (const [table, column, definition] of additiveColumns) {
      try {
        await db.execute(`SELECT \`${column}\` FROM \`${table}\` LIMIT 0`);
      } catch (error) {
        if (!isMissingColumn(error)) throw error;
        try {
          await db.execute(
            `ALTER TABLE \`${table}\` ADD COLUMN \`${column}\` ${definition}`
          );
        } catch {
          // A restricted Hostinger database user must not take down login.
        }
      }
    }
    await db.execute(
      "UPDATE `orders` SET `companyShare` = `deliveryFee`, `driverCommission` = 0.000, `compensationInitialized` = true WHERE `compensationInitialized` = false AND `returnedToCompany` = false"
    );
  })();

  inFlight.set(db, task);
  try {
    await task;
    ensured.add(db);
  } catch (error) {
    inFlight.delete(db);
    throw error;
  }
}
