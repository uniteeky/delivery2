import { describe, expect, it } from "vitest";
import { buildWhatsAppUrl, composeWhatsAppOrderMessage, type WhatsAppOrderLabels } from "../shared/whatsapp";

const labels: WhatsAppOrderLabels = {
  title: "Order",
  orderNumber: "Number",
  status: "Status",
  pickupAddress: "Pickup",
  deliveryAddress: "Delivery",
  customer: "Customer",
  phone: "Phone",
  area: "Area",
  notes: "Notes",
  completedAt: "Completed",
  media: "Media",
  driverIntro: "Driver order",
  completedIntro: "Completed order",
  summaryIntro: "Order summary",
};

const order = {
  orderNumber: "CC-100",
  status: "in_transit",
  pickupAddress: "Restaurant gate",
  deliveryAddress: "Customer building",
  customerName: "Customer",
  customerPhone: "+96550000000",
  area: "Kuwait City",
  notes: "Call on arrival",
  deliveryFee: "9.000",
  internalAudit: "must not be shared",
  media: [
    { kind: "order" as const, fileUrl: "https://files.test/order.jpg" },
    { kind: "delivery" as const, fileUrl: "https://files.test/delivery.jpg" },
  ],
};

describe("WhatsApp order export", () => {
  it("includes driver-operational fields but excludes internal fee and audit data", () => {
    const message = composeWhatsAppOrderMessage(order, "driver", labels);
    expect(message).toContain("Restaurant gate");
    expect(message).toContain("Customer building");
    expect(message).toContain("+96550000000");
    expect(message).toContain("Call on arrival");
    expect(message).not.toContain("9.000");
    expect(message).not.toContain("must not be shared");
    expect(message).not.toContain("delivery.jpg");
  });

  it("includes only delivery media for completed-order export", () => {
    const message = composeWhatsAppOrderMessage({ ...order, status: "delivered", deliveredAt: "2026-08-20T10:00:00Z" }, "completed", labels);
    expect(message).toContain("Completed order");
    expect(message).toContain("https://files.test/delivery.jpg");
    expect(message).not.toContain("https://files.test/order.jpg");
    expect(message).not.toContain("+96550000000");
    expect(message).not.toContain("9.000");
  });

  it("encodes the message in a WhatsApp URL", () => {
    expect(buildWhatsAppUrl("Order\nCC-100")).toBe("https://wa.me/?text=Order%0ACC-100");
  });
});
