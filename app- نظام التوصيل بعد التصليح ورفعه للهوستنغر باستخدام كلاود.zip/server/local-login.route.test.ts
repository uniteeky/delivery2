import express from "express";
import type { AddressInfo } from "node:net";
import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";
import * as db from "./db";
import { ENV } from "./_core/env";
import { registerOAuthRoutes } from "./_core/oauth";
import { appRouter } from "./routers";
import { sdk } from "./_core/sdk";
import { COOKIE_NAME } from "@shared/const";

const approvedUser = { id: 21, name: "Local Driver", role: "driver", approvalStatus: "approved", status: "active" } as never;
const originalCookieSecret = ENV.cookieSecret;

async function withServer(run: (baseUrl: string) => Promise<void>) {
  const app = express();
  app.use(express.json());
  registerOAuthRoutes(app);
  const server = app.listen(0);
  try {
    const address = server.address() as AddressInfo;
    await run(`http://127.0.0.1:${address.port}`);
  } finally {
    await new Promise<void>((resolve) => server.close(() => resolve()));
  }
}

describe("local login HTTP route", () => {
  beforeAll(() => {
    ENV.cookieSecret = "local-login-test-secret";
  });

  afterAll(() => {
    ENV.cookieSecret = originalCookieSecret;
  });

  it("sets a signed session cookie and the cookie authenticates the local user", async () => {
    const verifier = vi.spyOn(db, "verifyLocalCredentials").mockResolvedValue(approvedUser);
    const userLookup = vi.spyOn(db, "getUserById").mockResolvedValue(approvedUser);
    try {
      await withServer(async (baseUrl) => {
        const response = await fetch(`${baseUrl}/api/auth/local-login`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ civilId: "123456789012", password: "CorrectPass123" }) });
        expect(response.status).toBe(200);
        expect(response.headers.get("location")).toBeNull();
        const setCookie = response.headers.get("set-cookie") ?? "";
        expect(setCookie).toContain(`${COOKIE_NAME}=`);
        const sessionUser = await sdk.authenticateRequest({ headers: { cookie: setCookie.split(";")[0] } } as never);
        expect(sessionUser.id).toBe(21);
        expect(sessionUser.role).toBe("driver");
        const driverLookup = vi.spyOn(db, "getDriverForUser").mockResolvedValue({ id: 31, userId: 21 } as never);
        const protectedResult = await appRouter.createCaller({ user: sessionUser, req: {} as never, res: {} as never }).driver.me();
        expect(protectedResult?.userId).toBe(21);
        expect(sessionUser.role).toBe("driver");
        driverLookup.mockRestore();
      });
    } finally {
      verifier.mockRestore();
      userLookup.mockRestore();
    }
  });

  it("accepts a business email address as the local login identifier", async () => {
    const verifier = vi.spyOn(db, "verifyLocalCredentials").mockResolvedValue(approvedUser);
    try {
      await withServer(async (baseUrl) => {
        const response = await fetch(`${baseUrl}/api/auth/local-login`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ username: "merchant@example.com", password: "CorrectPass123" }),
        });
        expect(response.status).toBe(200);
        expect(verifier).toHaveBeenCalledWith("merchant@example.com", "CorrectPass123");
      });
    } finally {
      verifier.mockRestore();
    }
  });

  it("normalizes Arabic civil-ID digits before local login", async () => {
    const verifier = vi.spyOn(db, "verifyLocalCredentials").mockResolvedValue(approvedUser);
    try {
      await withServer(async (baseUrl) => {
        const response = await fetch(`${baseUrl}/api/auth/local-login`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ civilId: "١٢٣٤٥٦٧٨٩٠١٢", password: "CorrectPass123" }),
        });
        expect(response.status).toBe(200);
        expect(verifier).toHaveBeenCalledWith("123456789012", "CorrectPass123");
      });
    } finally {
      verifier.mockRestore();
    }
  });

  it("returns a JSON 500 instead of crashing when the database rejects login", async () => {
    const verifier = vi.spyOn(db, "verifyLocalCredentials").mockRejectedValue(new Error("connect ECONNREFUSED"));
    try {
      await withServer(async (baseUrl) => {
        const response = await fetch(`${baseUrl}/api/auth/local-login`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ civilId: "123456789012", password: "CorrectPass123" }) });
        expect(response.status).toBe(500);
        expect(response.headers.get("content-type")).toContain("application/json");
        await expect(response.json()).resolves.toMatchObject({ error: expect.stringContaining("قاعدة البيانات") });
      });
    } finally { verifier.mockRestore(); }
  });

  it("rejects an incorrect password", async () => {
    const verifier = vi.spyOn(db, "verifyLocalCredentials").mockResolvedValue(undefined);
    try {
      await withServer(async (baseUrl) => {
        const response = await fetch(`${baseUrl}/api/auth/local-login`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ civilId: "123456789012", password: "WrongPass123" }) });
        expect(response.status).toBe(401);
      });
    } finally { verifier.mockRestore(); }
  });

  it("rejects a pending account", async () => {
    const verifier = vi.spyOn(db, "verifyLocalCredentials").mockResolvedValue(undefined);
    try {
      await withServer(async (baseUrl) => {
        const response = await fetch(`${baseUrl}/api/auth/local-login`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ civilId: "123456789013", password: "CorrectPass123" }) });
        expect(response.status).toBe(401);
      });
    } finally { verifier.mockRestore(); }
  });

  it("rejects an inactive account", async () => {
    const verifier = vi.spyOn(db, "verifyLocalCredentials").mockResolvedValue(undefined);
    try {
      await withServer(async (baseUrl) => {
        const response = await fetch(`${baseUrl}/api/auth/local-login`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ civilId: "123456789014", password: "CorrectPass123" }) });
        expect(response.status).toBe(401);
      });
    } finally { verifier.mockRestore(); }
  });
});
