import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import { publicDriverAccountDefaults } from "./db";

const admin = { id: 1, role: "admin" as const, status: "active" as const, approvalStatus: "approved" as const, name: "Admin" };

describe("registration validation", () => {
  it("rejects malformed Civil ID and weak driver password before DB access", async () => {
    const caller = appRouter.createCaller({ user: null, req: {} as never, res: {} as never });
    await expect(caller.auth.registerDriver({ civilId: "123", password: "short", name: "سائق", phone: "50000000", preferredLanguage: "ar" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("keeps public driver registration pending and inactive until manager approval", () => {
    expect(publicDriverAccountDefaults()).toEqual({
      role: "driver",
      approvalStatus: "pending",
      status: "inactive",
      loginMethod: "local-civil-id",
      mustChangePassword: false,
    });
  });

  it("rejects malformed staff input before manager DB mutation", async () => {
    const caller = appRouter.createCaller({ user: admin, req: {} as never, res: {} as never });
    await expect(caller.users.createStaffAccount({ civilId: "123", password: "short", name: "", phone: "1", role: "accountant" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });
});

  it("accepts a requested supervisor or accountant role in the public registration contract", async () => {
    const caller = appRouter.createCaller({ user: null, req: {} as never, res: {} as never });
    await expect(caller.auth.registerDriver({ civilId: "123", password: "short", name: "مشرف", phone: "50000000", preferredLanguage: "ar", requestedRole: "supervisor" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(caller.auth.registerDriver({ civilId: "123", password: "short", name: "محاسب", phone: "50000000", preferredLanguage: "ar", requestedRole: "accountant" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });
