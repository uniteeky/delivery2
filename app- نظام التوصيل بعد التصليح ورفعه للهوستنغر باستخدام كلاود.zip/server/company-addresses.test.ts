import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const schema = readFileSync(new URL("../drizzle/schema.ts", import.meta.url), "utf8");
const db = readFileSync(new URL("./db.ts", import.meta.url), "utf8");
const router = readFileSync(new URL("./routers.ts", import.meta.url), "utf8");
const supervisorForm = readFileSync(new URL("../client/src/pages/NewOrder.tsx", import.meta.url), "utf8");
const driverForm = readFileSync(new URL("../client/src/pages/DriverNewOrder.tsx", import.meta.url), "utf8");

describe("company addresses", () => {
  it("stores a named address and phone separately from the company record", () => {
    expect(schema).toContain('companyAddresses = mysqlTable("companyAddresses"');
    expect(schema).toContain('label: varchar("label"');
    expect(schema).toContain('phone: varchar("phone"');
    expect(db).toContain("export async function createCompanyAddress");
    expect(db).toContain("export async function updateCompanyAddress");
    expect(db).toContain("company.address_created");
  });

  it("protects address management and allows address lookup for authorized order creation", () => {
    expect(router).toContain("createAddress: protectedProcedure");
    expect(router).toContain("updateAddress: protectedProcedure");
    expect(router).toContain("await requireCapability(ctx.user, \"companies_view\")");
    expect(router).toContain("companyAddresses: protectedProcedure");
  });

  it("shows branch selection and fills the selected branch address and phone in both order forms", () => {
    for (const source of [supervisorForm, driverForm]) {
      expect(source).toContain("companyAddressId");
      expect(source).toContain("selectCompanyAddress");
      expect(source).toContain("pickupAddress: selected.address");
      expect(source).toContain("pickupPhone: selected.phone");
    }
  });
});
