import { describe, expect, it } from "vitest";
import { setUserRoleWithDb } from "./db";
import { canAccessDashboardPath, getEffectiveRoles, hasRole } from "../shared/operations";

function makeQuery(value: unknown) {
  const query: any = {
    from() { return query; },
    where() { return query; },
    limit() { return Promise.resolve(value); },
    then(resolve: (value: unknown) => unknown, reject?: (reason: unknown) => unknown) { return Promise.resolve(value).then(resolve, reject); },
  };
  return query;
}

describe("multi-role account access", () => {
  it("combines the primary role with granted roles for navigation", () => {
    const user = { role: "accountant" as const, roles: ["accountant", "supervisor"] as const };
    expect(getEffectiveRoles(user)).toEqual(["accountant", "supervisor"]);
    expect(hasRole(user, "supervisor")).toBe(true);
    expect(canAccessDashboardPath(user.roles, "/operations-room", ["dashboard_view"])).toBe(true);
  });

  it("records a granted secondary role and returns the effective role set", async () => {
    const auditRows: unknown[] = [];
    let selectCount = 0;
    const db = {
      select() {
        const count = selectCount++;
        if (count === 0) return makeQuery([{ id: 7, role: "accountant" }]);
        if (count === 1) return makeQuery([{ role: "accountant" }]);
        return makeQuery([{ role: "supervisor" }]);
      },
      insert() {
        const chain: any = { values(value: unknown) { auditRows.push(value); return chain; }, onDuplicateKeyUpdate() { return Promise.resolve(); } };
        return chain;
      },
    };
    const result = await setUserRoleWithDb(db as never, 7, "supervisor", true, 1);
    expect(result.roles).toEqual(["accountant", "supervisor"]);
    expect(auditRows[1]).toMatchObject({ action: "user.role_granted", entityId: "7:supervisor" });
  });

  it("protects the admin account from secondary role changes", async () => {
    const db = { select() { return makeQuery([{ id: 1, role: "admin" }]); } };
    await expect(setUserRoleWithDb(db as never, 1, "supervisor", true, 2)).rejects.toThrow("حساب المدير المحمي");
  });
});

describe("common effective-role combinations", () => {
  it.each([
    ["supervisor+accountant", ["accountant", "supervisor"], "/finance", true],
    ["supervisor+driver", ["driver", "supervisor"], "/operations-room", true],
    ["company+accountant", ["company", "accountant"], "/finance", true],
  ])("supports %s without losing the primary boundary", (_label, roles, path, expected) => {
    expect(hasRole({ role: roles[0] as any, roles }, roles[1] as any)).toBe(true);
    expect(canAccessDashboardPath(roles as any, path, ["dashboard_view", "finance_view"])).toBe(expected);
  });
});
