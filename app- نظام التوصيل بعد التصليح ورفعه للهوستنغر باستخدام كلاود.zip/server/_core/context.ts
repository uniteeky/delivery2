import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import { sdk } from "./sdk";
import { getUserRoles } from "../db";
import type { PlatformRole } from "../../shared/operations";

export type AuthenticatedUser = User & { roles: PlatformRole[] };

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: AuthenticatedUser | null;
};

export async function createContext(
  opts: CreateExpressContextOptions
): Promise<TrpcContext> {
  let user: AuthenticatedUser | null = null;

  try {
    const authenticated = await sdk.authenticateRequest(opts.req);
    user = { ...authenticated, roles: (await getUserRoles(authenticated.id)) as PlatformRole[] };
  } catch (error) {
    // Authentication is optional for public procedures.
    user = null;
  }

  return {
    req: opts.req,
    res: opts.res,
    user,
  };
}
