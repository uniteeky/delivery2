import "dotenv/config";
import express from "express";
import { createServer } from "http";
import path from "node:path";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { runScheduledBackup } from "../scheduled";

async function startServer() {
  const app = express();
  // Hostinger terminates HTTPS before forwarding traffic to this Node process.
  // Trust the first proxy so req.protocol and secure session cookies remain correct.
  app.set("trust proxy", 1);
  const server = createServer(app);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  app.use("/media", express.static(path.resolve(process.env.LOCAL_MEDIA_DIR || path.join(process.cwd(), "media")), { maxAge: "30d" }));
  registerStorageProxy(app);
  registerOAuthRoutes(app);
  app.post("/api/scheduled/backup", runScheduledBackup);
  app.get("/api/build-version", (_req, res) => {
    res.json({ version: "cc-ops-2026-09-27-r13", release: "driver-cash-collection-reports", builtAt: "2026-09-27T20:57:00Z" });
  });
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const port = Number.parseInt(process.env.PORT || "3000", 10);
  if (!Number.isInteger(port) || port < 1 || port > 65535)
    throw new Error("PORT must be a valid TCP port");

  server.listen(port, "0.0.0.0", () => {
    console.log(`Server running on port ${port}`);
  });
}

startServer().catch(console.error);
