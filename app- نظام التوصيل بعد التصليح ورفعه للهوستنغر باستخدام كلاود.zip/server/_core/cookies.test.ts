import { afterEach, describe, expect, it } from "vitest";
import { getSessionCookieOptions } from "./cookies";

const initialNodeEnv = process.env.NODE_ENV;

afterEach(() => {
  process.env.NODE_ENV = initialNodeEnv;
});

describe("session cookie options", () => {
  it("keeps the production local-login cookie secure behind a TLS-terminating proxy", () => {
    process.env.NODE_ENV = "production";
    const options = getSessionCookieOptions({ protocol: "http", headers: {} } as never);
    expect(options).toMatchObject({ httpOnly: true, path: "/", sameSite: "none", secure: true });
  });

  it("uses a development-compatible cookie when the local request is not HTTPS", () => {
    process.env.NODE_ENV = "development";
    const options = getSessionCookieOptions({ protocol: "http", headers: {} } as never);
    expect(options).toMatchObject({ sameSite: "lax", secure: false });
  });
});
