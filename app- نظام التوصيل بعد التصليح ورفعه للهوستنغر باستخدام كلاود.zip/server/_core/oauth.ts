import { COOKIE_NAME, ONE_YEAR_MS, OAUTH_STATE_COOKIE, decodeOAuthState } from "@shared/const";
import { parse as parseCookieHeader } from "cookie";
import type { Express, Request, Response } from "express";
import * as db from "../db";
import { ENV } from "./env";
import { getSessionCookieOptions } from "./cookies";
import { sdk } from "./sdk";
import { isValidAdminRecoverySecret } from "../admin-recovery";

const recoveryAttempts = new Map<string, { count: number; windowStartedAt: number }>();
const RECOVERY_ATTEMPT_LIMIT = 5;
const RECOVERY_WINDOW_MS = 15 * 60 * 1000;
const LOCAL_USERNAME_PATTERN = /^[a-z0-9][a-z0-9_.-]{2,79}$/;
const LOCAL_EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function allowRecoveryAttempt(ip: string, now = Date.now()) {
  const current = recoveryAttempts.get(ip);
  if (!current || now - current.windowStartedAt >= RECOVERY_WINDOW_MS) {
    recoveryAttempts.set(ip, { count: 1, windowStartedAt: now });
    if (recoveryAttempts.size > 10_000) {
      recoveryAttempts.forEach((attempt, key) => { if (now - attempt.windowStartedAt >= RECOVERY_WINDOW_MS) recoveryAttempts.delete(key); });
    }
    return true;
  }
  if (current.count >= RECOVERY_ATTEMPT_LIMIT) return false;
  current.count += 1;
  return true;
}

function getQueryParam(req: Request, key: string): string | undefined {
  const value = req.query[key];
  return typeof value === "string" ? value : undefined;
}

export function registerOAuthRoutes(app: Express) {
  app.get("/api/auth/manager-bootstrap/status", async (_req: Request, res: Response) => {
    try {
      res.json({ available: await db.isFirstManagerBootstrapAvailable() });
    } catch {
      res.status(503).json({ available: false });
    }
  });

  app.post("/api/auth/manager-bootstrap", async (req: Request, res: Response) => {
    const civilId = typeof req.body?.civilId === "string" ? db.normalizeCivilId(req.body.civilId) : "";
    const password = typeof req.body?.password === "string" ? req.body.password : "";
    const email = typeof req.body?.email === "string" ? req.body.email : "";
    try {
      const user = await db.bootstrapFirstManager({ civilId, password, email });
      const sessionToken = await sdk.createSessionToken(`local_${user.id}`, { name: user.name });
      res.cookie(COOKIE_NAME, sessionToken, { ...getSessionCookieOptions(req), maxAge: ONE_YEAR_MS });
      res.status(201).json({ success: true, role: user.role, approvalStatus: user.approvalStatus });
    } catch (error) {
      const message = error instanceof Error ? error.message : "تعذر إعداد حساب المدير";
      const status = message.includes("بالفعل") || message.includes("مستخدم") ? 409 : 400;
      res.status(status).json({ error: message });
    }
  });

  app.post("/api/auth/local-login", async (req: Request, res: Response) => {
    const suppliedLogin =
      typeof req.body?.civilId === "string"
        ? req.body.civilId
        : typeof req.body?.username === "string"
          ? req.body.username
          : typeof req.body?.email === "string"
            ? req.body.email
            : "";
    const civilId = db.normalizeCivilId(suppliedLogin).toLowerCase();
    const password = typeof req.body?.password === "string" ? req.body.password : "";
    if (
      (!/^\d{12}$/.test(civilId) &&
        !LOCAL_USERNAME_PATTERN.test(civilId) &&
        !LOCAL_EMAIL_PATTERN.test(civilId)) ||
      password.length < 8
    ) {
      res.status(400).json({
        error: "الرقم المدني أو البريد الإلكتروني أو اسم المستخدم غير صحيح",
      });
      return;
    }
    try {
      const user = await db.verifyLocalCredentials(civilId, password);
      if (!user) {
        res.status(401).json({ error: "بيانات الدخول غير صحيحة أو الحساب غير معتمد" });
        return;
      }
      const sessionToken = await sdk.createSessionToken(`local_${user.id}`, { name: user.name || "" });
      res.cookie(COOKIE_NAME, sessionToken, { ...getSessionCookieOptions(req), maxAge: ONE_YEAR_MS });
      res.json({ success: true, role: user.role, approvalStatus: user.approvalStatus });
    } catch (error) {
      const databaseError = error && typeof error === "object" ? error as { cause?: unknown; code?: unknown } : null;
      const cause = databaseError?.cause;
      const nestedCause = cause && typeof cause === "object" ? cause as { code?: unknown } : null;
      console.error("[Auth] Local login database/session failure", {
        message: error instanceof Error ? error.message : String(error),
        name: error instanceof Error ? error.name : undefined,
        code: typeof databaseError?.code === "string" ? databaseError.code : undefined,
        causeMessage: cause instanceof Error ? cause.message : undefined,
        causeCode: typeof nestedCause?.code === "string" ? nestedCause.code : undefined,
      });
      res.status(500).json({ error: "تعذر الاتصال بقاعدة البيانات. تحقق من إعدادات MySQL ثم أعد المحاولة." });
    }
  });

  app.post("/api/auth/admin-recovery", async (req: Request, res: Response) => {
    res.setHeader("Cache-Control", "no-store");
    res.setHeader("Referrer-Policy", "no-referrer");
    const ip = req.ip || req.socket.remoteAddress || "unknown";
    if (!allowRecoveryAttempt(ip)) {
      res.status(429).json({ error: "تم تجاوز عدد المحاولات. انتظر 15 دقيقة ثم حاول مجددًا." });
      return;
    }
    const providedSecret = req.get("x-admin-recovery-secret") ?? "";
    if (!ENV.adminRecoverySecret || !isValidAdminRecoverySecret(providedSecret, ENV.adminRecoverySecret)) {
      res.status(401).json({ error: "رمز الاستعادة غير صحيح أو غير مفعّل." });
      return;
    }
    const login = typeof req.body?.login === "string" ? req.body.login : "";
    const newPassword = typeof req.body?.newPassword === "string" ? req.body.newPassword : "";
    try {
      await db.completeAdminPasswordRecovery({ login, newPassword, recoverySecret: providedSecret });
      res.json({ success: true });
    } catch (error) {
      const message = error instanceof Error ? error.message : "تعذر إتمام استعادة كلمة مرور المدير.";
      const status = message.includes("انتهت صلاحية") ? 409 : message.includes("12 و128") ? 400 : 400;
      res.status(status).json({ error: message.includes("Database unavailable") ? "تعذر الاتصال بقاعدة البيانات. حاول لاحقًا." : message });
    }
  });

  app.get("/api/oauth/callback", async (req: Request, res: Response) => {
    const code = getQueryParam(req, "code");
    const state = getQueryParam(req, "state");

    if (!code || !state) {
      res.status(400).json({ error: "code and state are required" });
      return;
    }

    // CSRF guard: the nonce in `state` must match the one-time cookie that
    // startLogin set in the browser that began this login. An attacker can
    // forge `state`, but cannot plant this cookie in the victim's browser.
    const { nonce } = decodeOAuthState(state);
    const expectedNonce = parseCookieHeader(req.headers.cookie ?? "")[OAUTH_STATE_COOKIE];
    if (!nonce || nonce !== expectedNonce) {
      res.status(403).json({ error: "invalid oauth state" });
      return;
    }
    res.clearCookie(OAUTH_STATE_COOKIE, { path: "/", secure: true, sameSite: "none" });

    try {
      const tokenResponse = await sdk.exchangeCodeForToken(code, state);
      const userInfo = await sdk.getUserInfo(tokenResponse.accessToken);

      if (!userInfo.openId) {
        res.status(400).json({ error: "openId missing from user info" });
        return;
      }

      await db.upsertUser({
        openId: userInfo.openId,
        name: userInfo.name || null,
        email: userInfo.email ?? null,
        loginMethod: userInfo.loginMethod ?? userInfo.platform ?? null,
        lastSignedIn: new Date(),
      });

      const sessionToken = await sdk.createSessionToken(userInfo.openId, {
        name: userInfo.name || "",
        expiresInMs: ONE_YEAR_MS,
      });

      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });

      res.redirect(302, "/");
    } catch (error) {
      console.error("[OAuth] Callback failed", error);
      res.status(500).json({ error: "OAuth callback failed" });
    }
  });
}
