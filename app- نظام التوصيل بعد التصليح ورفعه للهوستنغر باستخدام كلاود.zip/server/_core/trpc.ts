import { initTRPC, TRPCError } from "@trpc/server";
import superjson from "superjson";
import type { TrpcContext } from "./context";

const t = initTRPC.context<TrpcContext>().create({
  transformer: superjson,
});

export const router = t.router;
export const publicProcedure = t.procedure;

export function canUseProtectedAccount(user: { status?: string; approvalStatus?: string } | null | undefined) {
  if (!user) return false;
  return user.status !== "inactive" && user.approvalStatus !== "pending" && user.approvalStatus !== "rejected";
}

const requireUser = t.middleware(async opts => {
  const { ctx, next } = opts;

  if (!ctx.user) {
    throw new TRPCError({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
  }
  if (!canUseProtectedAccount(ctx.user)) {
    throw new TRPCError({ code: "FORBIDDEN", message: "الحساب بانتظار الاعتماد أو موقوف" });
  }

  return next({
    ctx: {
      ...ctx,
      user: ctx.user,
    },
  });
});

export const protectedProcedure = t.procedure.use(requireUser);

export const adminProcedure = t.procedure.use(
  t.middleware(async opts => {
    const { ctx, next } = opts;

    if (!ctx.user || ctx.user.role !== "admin") {
      throw new TRPCError({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
    }
    if (!canUseProtectedAccount(ctx.user)) {
      throw new TRPCError({ code: "FORBIDDEN", message: "الحساب بانتظار الاعتماد أو موقوف" });
    }

    return next({
      ctx: {
        ...ctx,
        user: ctx.user,
      },
    });
  }),
);

export const UNAUTHED_ERR_MSG = "يجب تسجيل الدخول للمتابعة";
export const NOT_ADMIN_ERR_MSG = "ليس لديك صلاحية المدير";
