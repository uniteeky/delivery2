import { describe, expect, it, vi } from "vitest";
import * as db from "./db";
import { appRouter } from "./routers";

const admin = { id: 1, role: "admin" as const, status: "active" as const, approvalStatus: "approved" as const, name: "Admin" };
const driver = { id: 7, role: "driver" as const, status: "active" as const, approvalStatus: "approved" as const, name: "Driver", civilId: "123456789012", loginMethod: "local-civil-id" as const };
const caller = (user: typeof admin | typeof driver) => appRouter.createCaller({ user, req: {} as never, res: {} as never });

describe("order transfer workflow", () => {
  it("transfers an order through the manager procedure and preserves the reason", async () => {
    const transfer = vi.spyOn(db, "transferOrder").mockResolvedValue({ orderId: 15, fromDriverId: 4, toDriverId: 9, reason: "تغيير منطقة التغطية" });
    try {
      await expect(caller(admin).orders.transfer({ orderId: 15, toDriverId: 9, reason: "تغيير منطقة التغطية" })).resolves.toMatchObject({ orderId: 15, toDriverId: 9 });
      expect(transfer).toHaveBeenCalledWith(15, 9, 1, "تغيير منطقة التغطية");
    } finally { transfer.mockRestore(); }
  });

  it("returns transfer history to an authorized manager and forwards the order id", async () => {
    const history = vi.spyOn(db, "listOrderTransfers").mockResolvedValue([{ id: 3, orderId: 15, fromDriverId: 4, toDriverId: 9, transferredByUserId: 1, reason: "تغيير منطقة التغطية", transferredAt: new Date("2026-08-20T08:00:00Z") }]);
    try {
      await expect(caller(admin).orders.transfers({ orderId: 15 })).resolves.toHaveLength(1);
      expect(history).toHaveBeenCalledWith(15);
    } finally { history.mockRestore(); }
  });

  it("does not allow a driver to use the transfer history procedure", async () => {
    const history = vi.spyOn(db, "listOrderTransfers");
    try {
      await expect(caller(driver).orders.transfers({ orderId: 15 })).rejects.toMatchObject({ code: "FORBIDDEN" });
      expect(history).not.toHaveBeenCalled();
    } finally { history.mockRestore(); }
  });

  it("does not allow a driver to use the manager transfer procedure", async () => {
    const transfer = vi.spyOn(db, "transferOrder");
    try {
      await expect(caller(driver).orders.transfer({ orderId: 15, toDriverId: 9 })).rejects.toMatchObject({ code: "FORBIDDEN" });
      expect(transfer).not.toHaveBeenCalled();
    } finally { transfer.mockRestore(); }
  });
});
