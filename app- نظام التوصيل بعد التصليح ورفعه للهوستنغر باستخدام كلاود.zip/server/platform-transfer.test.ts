import { describe, expect, it } from "vitest";
import { isPlatformTransferAllowed } from "./platform-transfer";

const enabled = { mode: "active", allowDriverTransfer: true, allowSupervisorTransfer: true, allowManagerTransfer: true };

describe("platform transfer settings", () => {
  it("allows each role when its setting is enabled", () => {
    expect(isPlatformTransferAllowed({ role: "driver" }, enabled)).toBe(true);
    expect(isPlatformTransferAllowed({ role: "supervisor" }, enabled)).toBe(true);
    expect(isPlatformTransferAllowed({ role: "admin" }, enabled)).toBe(true);
  });

  it("blocks drivers and supervisors independently when admin turns their switches off", () => {
    expect(isPlatformTransferAllowed({ role: "driver" }, { ...enabled, allowDriverTransfer: false })).toBe(false);
    expect(isPlatformTransferAllowed({ role: "supervisor" }, { ...enabled, allowSupervisorTransfer: false })).toBe(false);
    expect(isPlatformTransferAllowed({ role: "admin" }, { ...enabled, allowDriverTransfer: false, allowSupervisorTransfer: false })).toBe(true);
  });

  it("blocks transfers when the platform is not active", () => {
    expect(isPlatformTransferAllowed({ role: "driver" }, { ...enabled, mode: "read_only" })).toBe(false);
  });

  it("uses the most privileged effective role when accounts have multiple roles", () => {
    expect(isPlatformTransferAllowed({ role: "driver", roles: ["supervisor"] }, { ...enabled, allowDriverTransfer: false, allowSupervisorTransfer: true })).toBe(false);
    expect(isPlatformTransferAllowed({ role: "admin", roles: ["driver"] }, { ...enabled, allowManagerTransfer: true, allowDriverTransfer: false })).toBe(true);
  });
});
