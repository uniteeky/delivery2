import { describe, expect, it } from "vitest";
import { independentOrderShares, initialOrderShares, resolveDriverCommission } from "../shared/driver-compensation";

describe("resolveDriverCommission", () => {
  it("gives salary-only drivers no per-delivery commission", () => {
    expect(resolveDriverCommission({ payType: "salary", defaultCommission: 5, companyId: 1, areaId: 2, rates: [{ companyId: 1, areaId: 2, amount: 7 }] })).toBe(0);
  });
  it("uses the default commission for salary-plus-commission and contractors", () => {
    for (const payType of ["salary_commission", "contractor"] as const) {
      expect(resolveDriverCommission({ payType, defaultCommission: "2.500", companyId: 1, areaId: 2, rates: [] })).toBe(2.5);
    }
  });
  it("prefers exact company-and-area, then company, then area rates", () => {
    const rates = [
      { companyId: null, areaId: 2, amount: "1.000" },
      { companyId: 1, areaId: null, amount: "2.000" },
      { companyId: 1, areaId: 2, amount: "3.000" },
    ];
    expect(resolveDriverCommission({ payType: "contractor", defaultCommission: 9, companyId: 1, areaId: 2, rates })).toBe(3);
    expect(resolveDriverCommission({ payType: "contractor", defaultCommission: 9, companyId: 1, areaId: 8, rates })).toBe(2);
    expect(resolveDriverCommission({ payType: "contractor", defaultCommission: 9, companyId: 8, areaId: 2, rates })).toBe(1);
  });
  it("starts company share at fee minus commission but permits an independent manual split", () => {
    expect(initialOrderShares({ deliveryFee: "5.000", driverCommission: "2.000" })).toEqual({ driverCommission: "2.000", companyShare: "3.000" });
    expect(independentOrderShares({ deliveryFee: "5", driverCommission: "2", companyShare: "0" })).toEqual({ deliveryFee: "5.000", driverCommission: "2.000", companyShare: "0.000" });
    expect(initialOrderShares({ deliveryFee: "5", driverCommission: "2", returnedToCompany: true })).toEqual({ driverCommission: "0.000", companyShare: "0.000" });
  });
});
