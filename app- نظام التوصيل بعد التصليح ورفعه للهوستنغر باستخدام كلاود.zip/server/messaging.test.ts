import { readFileSync } from "node:fs";
import { beforeEach, describe, expect, it, vi } from "vitest";
import * as db from "./db";
import { appRouter } from "./routers";

const user = { id: 42, role: "supervisor" as const, status: "active" as const, approvalStatus: "approved" as const, name: "مشرف اختبار" };
const driver = { id: 77, role: "driver" as const, status: "active" as const, approvalStatus: "approved" as const, name: "سائق اختبار" };
const caller = (actor = user) => appRouter.createCaller({ user: actor, req: {} as never, res: {} as never });

describe("messaging authorization and persistence contract", () => {
  beforeEach(() => vi.restoreAllMocks());

  it("creates a thread with the authenticated creator and selected members", async () => {
    const create = vi.spyOn(db, "createMessageThread").mockResolvedValue({ threadId: 701 });
    await expect(caller().messaging.createThread({ type: "direct", memberIds: [9] })).resolves.toEqual({ threadId: 701 });
    expect(create).toHaveBeenCalledWith({ type: "direct", memberIds: [9] }, 42);
  });

  it("allows a supervisor to create a group but rejects a driver attempting the same action", async () => {
    const create = vi.spyOn(db, "createMessageThread").mockResolvedValue({ threadId: 702 });
    await expect(caller().messaging.createThread({ type: "group", title: "فريق المساء", memberIds: [9, 10] })).resolves.toEqual({ threadId: 702 });
    await expect(caller(driver).messaging.createThread({ type: "group", title: "غير مسموح", memberIds: [9, 10] })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller().messaging.createThread({ type: "direct", memberIds: [9, 10] })).rejects.toThrow("المحادثة الفردية");
  });

  it("lists only the authenticated user's threads through the scoped db helper", async () => {
    const list = vi.spyOn(db, "listMessageThreads").mockResolvedValue([{ id: 701, type: "direct", title: "تشغيل", orderId: null, companyId: null, createdByUserId: 42, createdAt: new Date() }] as never);
    await expect(caller().messaging.listThreads()).resolves.toHaveLength(1);
    expect(list).toHaveBeenCalledWith(42);
  });

  it("passes the authenticated user to message reads and sends for non-member rejection", async () => {
    const listMessages = vi.spyOn(db, "listThreadMessages").mockRejectedValue(new Error("لا يمكنك الوصول إلى هذه المحادثة"));
    const send = vi.spyOn(db, "sendThreadMessage").mockRejectedValue(new Error("لا يمكنك الوصول إلى هذه المحادثة"));
    await expect(caller().messaging.listMessages({ threadId: 701, limit: 50 })).rejects.toThrow("لا يمكنك الوصول");
    await expect(caller().messaging.send({ threadId: 701, body: "رسالة" })).rejects.toThrow("لا يمكنك الوصول");
    expect(listMessages).toHaveBeenCalledWith(701, 42, 50);
    expect(send).toHaveBeenCalledWith(701, 42, "رسالة", []);
  });

  it("exposes protected image and audio attachment handling in the messaging contract", () => {
    const routerSource = readFileSync(new URL("./routers.ts", import.meta.url), "utf8");
    const dbSource = readFileSync(new URL("./db.ts", import.meta.url), "utf8");
    expect(routerSource).toContain('type: z.enum(["image", "audio"])');
    expect(routerSource).toContain("storagePut(`messages/");
    expect(routerSource).toContain("إنشاء القروبات متاح للمدير أو المشرف فقط");
    expect(dbSource).toContain("messageAttachments");
    expect(dbSource).toContain("attachments: attachmentsByMessage.get(message.id)");
  });
});
