import { describe, expect, it } from "vitest";
import { canWriteDuringSubscription, getSubscriptionMode, getSubscriptionReminderDays } from "../shared/platform";

const now = new Date("2026-09-19T12:00:00.000Z");

describe("independent platform subscription rules", () => {
  it("keeps an unset subscription active for initial setup", () => {
    expect(getSubscriptionMode({}, now)).toBe("active");
    expect(canWriteDuringSubscription("active")).toBe(true);
  });

  it("blocks writes after the end date and before a future start date", () => {
    expect(getSubscriptionMode({ endsAt: "2026-09-19T11:59:59.000Z" }, now)).toBe("read_only");
    expect(getSubscriptionMode({ startsAt: "2026-09-20T00:00:00.000Z" }, now)).toBe("not_started");
    expect(canWriteDuringSubscription("read_only")).toBe(false);
    expect(canWriteDuringSubscription("not_started")).toBe(false);
  });

  it("returns reminders only for three, two, and one days remaining", () => {
    expect(getSubscriptionReminderDays("2026-09-22T12:00:00.000Z", now)).toBe(3);
    expect(getSubscriptionReminderDays("2026-09-21T12:00:00.000Z", now)).toBe(2);
    expect(getSubscriptionReminderDays("2026-09-20T12:00:00.000Z", now)).toBe(1);
    expect(getSubscriptionReminderDays("2026-09-25T12:00:00.000Z", now)).toBeNull();
  });
});
