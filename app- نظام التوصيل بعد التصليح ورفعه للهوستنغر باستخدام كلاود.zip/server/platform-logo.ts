import { Buffer } from "node:buffer";

export const PLATFORM_LOGO_MIME_TYPES = ["image/png", "image/jpeg", "image/webp"] as const;
export type PlatformLogoMimeType = (typeof PLATFORM_LOGO_MIME_TYPES)[number];
export const MAX_PLATFORM_LOGO_BYTES = 8 * 1024 * 1024;
export const MAX_PLATFORM_LOGO_BASE64_LENGTH = Math.ceil(MAX_PLATFORM_LOGO_BYTES / 3) * 4;

const BASE64_PATTERN = /^[A-Za-z0-9+/]*={0,2}$/;

export function platformLogoExtension(mimeType: PlatformLogoMimeType) {
  if (mimeType === "image/png") return "png";
  if (mimeType === "image/webp") return "webp";
  return "jpg";
}

export function decodePlatformLogo(dataBase64: string, mimeType: PlatformLogoMimeType) {
  if (!dataBase64 || dataBase64.length > MAX_PLATFORM_LOGO_BASE64_LENGTH || dataBase64.length % 4 !== 0 || !BASE64_PATTERN.test(dataBase64)) {
    throw new Error("ملف الشعار غير صالح أو يتجاوز الحد الأقصى (8 ميجابايت)");
  }

  const bytes = Buffer.from(dataBase64, "base64");
  if (!bytes.length || bytes.length > MAX_PLATFORM_LOGO_BYTES) {
    throw new Error("حجم الشعار غير صالح أو يتجاوز الحد الأقصى (8 ميجابايت)");
  }
  if (bytes.toString("base64") !== dataBase64) {
    throw new Error("ملف الشعار غير صالح");
  }

  const isPng = mimeType === "image/png"
    && bytes.length >= 8
    && bytes.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
  const isJpeg = mimeType === "image/jpeg"
    && bytes.length >= 3
    && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
  const isWebp = mimeType === "image/webp"
    && bytes.length >= 12
    && bytes.toString("ascii", 0, 4) === "RIFF"
    && bytes.toString("ascii", 8, 12) === "WEBP";

  if (!isPng && !isJpeg && !isWebp) {
    throw new Error("محتوى الملف لا يطابق نوع صورة الشعار المسموح");
  }

  return bytes;
}
