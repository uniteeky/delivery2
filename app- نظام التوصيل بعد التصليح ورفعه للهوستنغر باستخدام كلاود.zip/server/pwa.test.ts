import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const publicDir = resolve(process.cwd(), "client/public");

describe("PWA installation and notification fallback", () => {
  it("defines an Arabic-first standalone manifest with driver start URL", () => {
    const manifest = JSON.parse(readFileSync(resolve(publicDir, "manifest.webmanifest"), "utf8")) as Record<string, unknown>;
    expect(manifest.lang).toBe("ar");
    expect(manifest.dir).toBe("rtl");
    expect(manifest.display).toBe("standalone");
    expect(manifest.start_url).toBe("/driver");
    expect(manifest.scope).toBe("/");
    expect(manifest.icons).toEqual(expect.arrayContaining([
      expect.objectContaining({ sizes: "192x192", type: "image/png" }),
      expect.objectContaining({ sizes: "512x512", type: "image/png" }),
    ]));
  });

  it("caches the shell, falls back offline, and opens the driver after notification clicks", () => {
    const serviceWorker = readFileSync(resolve(publicDir, "sw.js"), "utf8");
    expect(serviceWorker).toContain('"/driver"');
    expect(serviceWorker).toContain("caches.open(CACHE_NAME)");
    expect(serviceWorker).toContain("fetch(event.request).catch");
    expect(serviceWorker).toContain('caches.match("/")');
    expect(serviceWorker).toContain('self.clients.openWindow("/driver")');
  });
});
