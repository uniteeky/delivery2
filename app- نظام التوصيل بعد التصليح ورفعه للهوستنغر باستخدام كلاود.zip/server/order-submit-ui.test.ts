import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const read = (path: string) => readFileSync(resolve(process.cwd(), path), "utf8");

describe("order submission UI contract", () => {
  it("keeps supervisor order creation linked to a selected company and driver", () => {
    const source = read("client/src/pages/NewOrder.tsx");
    expect(source).toContain("trpc.companies.list.useQuery");
    expect(source).toContain("trpc.drivers.list.useQuery");
    expect(source).toContain("driverId: Number(form.driverId)");
    expect(source).toContain('source: form.companyId ? "supervisor" : "external"');
  });

  it("selects a branch and fills pickup name, phone, and address", () => {
    const source = read("client/src/pages/NewOrder.tsx");
    expect(source).toContain("companyAddressId");
    expect(source).toContain("trpc.companies.addresses.useQuery");
    expect(source).toContain("selectCompanyAddress");
    expect(source).toContain("pickupAddress: selected.address");
    expect(source).toContain("pickupPhone: selected.phone");
  });

  it("keeps the pickup and recipient contact fields editable after a branch fills them", () => {
    const source = read("client/src/pages/NewOrder.tsx");
    expect(source).toContain('id="pickupPhone"');
    expect(source).toContain('id="pickupAddress"');
    expect(source).toContain('id="recipientPhone"');
    expect(source).toContain('onChange={(event) => set("pickupPhone", event.target.value)}');
    expect(source).toContain('onChange={(event) => set("pickupAddress", event.target.value)}');
  });

  it("provides the same branch selector to the driver order form", () => {
    const source = read("client/src/pages/DriverNewOrder.tsx");
    expect(source).toContain("trpc.driver.companyAddresses.useQuery");
    expect(source).toContain("companyAddressId");
    expect(source).toContain("selectCompanyAddress");
    expect(source).toContain("pickupAddress: selected.address");
    expect(source).toContain("pickupPhone: selected.phone");
  });

  it("continues to render address and phone data safely in driver order cards", () => {
    const source = read("client/src/pages/DriverHome.tsx");
    expect(source).toContain("OrderContacts");
    expect(source).toContain("pickupPhone");
    expect(source).toContain("customerPhone");
  });
});
