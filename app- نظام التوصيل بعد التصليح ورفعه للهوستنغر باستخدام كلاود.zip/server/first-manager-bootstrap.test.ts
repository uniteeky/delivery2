import { describe, expect, it } from "vitest";
import { validateFirstManagerInput } from "./db";

describe("first local manager bootstrap input", () => {
  it("normalizes Arabic Civil-ID digits and email before creating the first manager", () => {
    expect(validateFirstManagerInput({ civilId: "١٢٣٤٥٦٧٨٩٠١٢", email: " MANAGER@EXAMPLE.COM ", password: "SecurePass123" })).toEqual({
      civilId: "123456789012",
      email: "manager@example.com",
    });
  });

  it("rejects malformed Civil IDs, weak passwords, and invalid email addresses", () => {
    expect(() => validateFirstManagerInput({ civilId: "123", email: "manager@example.com", password: "SecurePass123" })).toThrow("الرقم المدني");
    expect(() => validateFirstManagerInput({ civilId: "123456789012", email: "manager@example.com", password: "short" })).toThrow("كلمة المرور");
    expect(() => validateFirstManagerInput({ civilId: "123456789012", email: "not-an-email", password: "SecurePass123" })).toThrow("البريد الإلكتروني");
  });
});
