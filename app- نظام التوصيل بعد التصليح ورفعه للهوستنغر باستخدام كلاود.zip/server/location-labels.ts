export type LocationLabelInput = {
  governorateId?: number | null;
  areaId?: number | null;
};

export type LocationLabel = {
  governorateName: string | null;
  areaName: string | null;
};

export function locationLabelKey(input: LocationLabelInput) {
  return `${input.governorateId ?? 0}:${input.areaId ?? 0}`;
}

export function buildLocationLabelMaps(
  inputs: LocationLabelInput[],
  governorates: Array<{ id: number; nameAr: string }>,
  areas: Array<{ id: number; governorateId: number; nameAr: string }>,
) {
  const governorateNames = new Map(governorates.map((item) => [item.id, item.nameAr]));
  const areasById = new Map(areas.map((item) => [item.id, item]));
  return new Map(inputs.map((input) => {
    const area = input.areaId == null ? undefined : areasById.get(input.areaId);
    const governorateId = input.governorateId ?? area?.governorateId;
    return [locationLabelKey(input), {
      governorateName: governorateId == null ? null : governorateNames.get(governorateId) ?? null,
      areaName: area?.nameAr ?? null,
    } satisfies LocationLabel] as const;
  }));
}
