import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import * as db from "./db";

const activeUser = (role: "admin" | "supervisor" | "accountant" | "driver" | "company") => ({ id: 1, role, status: "active", approvalStatus: "approved", name: role });
const callerFor = (role: "admin" | "supervisor" | "accountant" | "driver" | "company") => appRouter.createCaller({ user: activeUser(role), req: {} as never, res: {} as never });

describe("manager API boundaries", () => {
  it("allows the manager to approve an account and grant a permission through the router", async () => {
    const access = vi.spyOn(db, "updateUserAccess").mockResolvedValue({ id: 8, role: "supervisor", status: "active", approvalStatus: "approved" } as never);
    const permission = vi.spyOn(db, "setUserPermission").mockResolvedValue({ userId: 8, permissionKey: "finance_view", granted: true });
    try {
      const caller = callerFor("admin");
      for (const role of ["driver", "supervisor", "accountant"] as const) {
        await caller.users.updateAccess({ userId: 8, role, approvalStatus: "approved", status: "active" });
      }
      await caller.users.setPermission({ userId: 8, permissionKey: "finance_view", granted: true });
      expect(access).toHaveBeenCalledTimes(3);
      expect(access).toHaveBeenNthCalledWith(1, 8, { role: "driver", status: "active", approvalStatus: "approved" }, 1);
      expect(access).toHaveBeenNthCalledWith(2, 8, { role: "supervisor", status: "active", approvalStatus: "approved" }, 1);
      expect(access).toHaveBeenNthCalledWith(3, 8, { role: "accountant", status: "active", approvalStatus: "approved" }, 1);
      expect(permission).toHaveBeenCalledWith(8, "finance_view", true, 1);
    } finally { access.mockRestore(); permission.mockRestore(); }
  });

  it("allows only an existing manager to create an immediately approved local manager", async () => {
    const createManager = vi.spyOn(db, "createManagerAccount").mockResolvedValue({ userId: 12, role: "admin", approvalStatus: "approved", status: "active" });
    try {
      await expect(callerFor("admin").users.createManagerAccount({ civilId: "123456789012", email: "manager@example.com", password: "SecurePass123" })).resolves.toMatchObject({ userId: 12, role: "admin", approvalStatus: "approved" });
      expect(createManager).toHaveBeenCalledWith({ civilId: "123456789012", email: "manager@example.com", password: "SecurePass123" }, 1);
      for (const role of ["supervisor", "accountant", "driver", "company"] as const) {
        await expect(callerFor(role).users.createManagerAccount({ civilId: "123456789012", email: "manager@example.com", password: "SecurePass123" })).rejects.toMatchObject({ code: "FORBIDDEN" });
      }
    } finally { createManager.mockRestore(); }
  });

  it("rejects incomplete driver profile data at the router boundary", async () => {
    const createDriver = vi.spyOn(db, "createDriverProfile");
    try {
      const caller = callerFor("admin");
      await expect(caller.users.createDriver({ userId: 8, vehicleLabel: " ", licenseNumber: "12" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
      expect(createDriver).not.toHaveBeenCalled();
    } finally { createDriver.mockRestore(); }
  });

  it("blocks every non-manager from suspension and reactivation", async () => {
    for (const role of ["supervisor", "accountant", "driver", "company"] as const) {
      const caller = callerFor(role);
      await expect(caller.users.updateAccess({ userId: 8, status: "inactive" })).rejects.toMatchObject({ code: "FORBIDDEN" });
      await expect(caller.users.updateAccess({ userId: 8, status: "active" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    }
  });

  it("routes multi-company trip additions and propagates closed-trip rejection", async () => {
    const createTrip = vi.spyOn(db, "createTrip").mockResolvedValue({ tripId: 501, driverId: 22, label: "مسار صباحي", status: "open" });
    const addOrder = vi.spyOn(db, "addOrderToTrip").mockImplementation(async (orderId) => {
      if (orderId === 903) throw new Error("لا يمكن إضافة الطلب إلى هذه الرحلة في حالته الحالية");
      return { orderId, tripId: 501, driverId: 22 };
    });
    try {
      const caller = callerFor("admin");
      await expect(caller.trips.create({ driverId: 22, label: "مسار صباحي" })).resolves.toMatchObject({ tripId: 501 });
      await expect(caller.trips.addOrder({ tripId: 501, orderId: 901 })).resolves.toMatchObject({ orderId: 901, tripId: 501 });
      await expect(caller.trips.addOrder({ tripId: 501, orderId: 902 })).resolves.toMatchObject({ orderId: 902, tripId: 501 });
      await expect(caller.trips.addOrder({ tripId: 501, orderId: 903 })).rejects.toThrow("لا يمكن إضافة الطلب");
      expect(createTrip).toHaveBeenCalledWith(22, "مسار صباحي", 1);
      expect(addOrder).toHaveBeenNthCalledWith(1, 901, 501, 1);
      expect(addOrder).toHaveBeenNthCalledWith(2, 902, 501, 1);
    } finally { createTrip.mockRestore(); addOrder.mockRestore(); }
  });

  it("allows manager-created driver/company accounts and order assignment through the router", async () => {
    const account = vi.spyOn(db, "registerStaffAccount").mockResolvedValue({ userId: 77, role: "driver", approvalStatus: "pending" });
    const createOrder = vi.spyOn(db, "createOrder").mockResolvedValue({ id: 88, orderNumber: "CC-TEST" });
    try {
      const caller = callerFor("admin");
      await caller.users.createStaffAccount({ civilId: "123456789012", password: "temporary-pass", name: "سائق اختبار", phone: "50000000", role: "driver" });
      await caller.users.createStaffAccount({ civilId: "123456789013", password: "temporary-pass", name: "حساب شركة", phone: "50000001", role: "company", companyId: 9 });
      await caller.orders.create({ source: "supervisor", companyId: 9, driverId: 22, pickupContactName: "المطعم", pickupAddress: "عنوان استلام واضح", pickupPhone: "50000000", deliveryAddress: "عنوان اختبار واضح", customerName: "عميل", customerPhone: "50000001" });
      expect(account).toHaveBeenNthCalledWith(1, expect.objectContaining({ role: "driver" }), 1);
      expect(account).toHaveBeenNthCalledWith(2, expect.objectContaining({ role: "company", companyId: 9 }), 1);
      expect(createOrder).toHaveBeenCalledWith(expect.objectContaining({ driverId: 22, companyId: 9 }), 1);
    } finally { account.mockRestore(); createOrder.mockRestore(); }
  });

  it("requires a pickup address for external orders and forwards both addresses", async () => {
    const createOrder = vi.spyOn(db, "createOrder").mockResolvedValue({ id: 100, orderNumber: "CC-EXTERNAL" } as never);
    try {
      const caller = callerFor("admin");
      await expect(caller.orders.create({ source: "external", deliveryAddress: "عنوان التسليم الواضح" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
      await expect(caller.orders.create({ source: "external", pickupContactName: "جهة الاستلام", pickupAddress: "عنوان الاستلام الواضح", pickupPhone: "50000000", deliveryAddress: "عنوان التسليم الواضح", customerName: "عميل", customerPhone: "50000001" })).resolves.toMatchObject({ id: 100 });
      expect(createOrder).toHaveBeenCalledWith(expect.objectContaining({ source: "external", pickupContactName: "جهة الاستلام", pickupAddress: "عنوان الاستلام الواضح", pickupPhone: "50000000", deliveryAddress: "عنوان التسليم الواضح" }), 1);
    } finally { createOrder.mockRestore(); }
  });

  it("returns approved active drivers and persists driver assignment during order creation", async () => {
    const drivers = vi.spyOn(db, "listActiveDrivers").mockResolvedValue([{ id: 22, userId: 77, name: "سائق معتمد", civilId: "123456789012", phone: "50000000", vehicleLabel: "سيارة" }] as never);
    const createOrder = vi.spyOn(db, "createOrder").mockResolvedValue({ id: 99, orderNumber: "CC-ASSIGNED" } as never);
    try {
      const caller = callerFor("admin");
      await expect(caller.drivers.list()).resolves.toMatchObject([{ id: 22, name: "سائق معتمد" }]);
      await expect(caller.orders.create({ source: "supervisor", companyId: 9, driverId: 22, pickupContactName: "المطعم", pickupAddress: "عنوان استلام صالح للاختبار", pickupPhone: "50000000", deliveryAddress: "عنوان تسليم صالح للاختبار", customerName: "عميل", customerPhone: "50000001" })).resolves.toMatchObject({ id: 99 });
      expect(createOrder).toHaveBeenCalledWith(expect.objectContaining({ driverId: 22, companyId: 9 }), 1);
    } finally { drivers.mockRestore(); createOrder.mockRestore(); }
  });

  it("returns both external-order addresses through the orders.get API path", async () => {
    const getDetails = vi.spyOn(db, "getOrderDetails").mockResolvedValue({ id: 501, orderNumber: "CC-EXTERNAL-501", source: "external", pickupAddress: "عنوان الاستلام", deliveryAddress: "عنوان التسليم", status: "pending", media: [] } as never);
    try {
      await expect(callerFor("admin").orders.get({ orderId: 501 })).resolves.toMatchObject({ source: "external", pickupAddress: "عنوان الاستلام", deliveryAddress: "عنوان التسليم" });
      expect(getDetails).toHaveBeenCalledWith(501);
    } finally { getDetails.mockRestore(); }
  });

  it("blocks every non-manager from company management and backup scheduling", async () => {
    for (const role of ["supervisor", "accountant", "driver", "company"] as const) {
      const caller = callerFor(role);
      await expect(caller.companies.create({ name: "شركة اختبار", code: "TEST-1", defaultDeliveryFee: "1.000" })).rejects.toMatchObject({ code: "FORBIDDEN" });
      await expect(caller.companies.update({ companyId: 1, status: "inactive" })).rejects.toMatchObject({ code: "FORBIDDEN" });
      await expect(caller.backups.getSchedule()).rejects.toMatchObject({ code: "FORBIDDEN" });
      await expect(caller.backups.list()).rejects.toMatchObject({ code: "FORBIDDEN" });
      await expect(caller.backups.create()).rejects.toMatchObject({ code: "FORBIDDEN" });
      await expect(caller.backups.updateSchedule({ frequency: "daily", destinationLabel: "external", enabled: false })).rejects.toMatchObject({ code: "FORBIDDEN" });
    }
  });

  it("blocks every non-manager from granting or revoking permissions", async () => {
    for (const role of ["supervisor", "accountant", "driver", "company"] as const) {
      const caller = callerFor(role);
      await expect(caller.users.setPermission({ userId: 8, permissionKey: "finance_view", granted: true })).rejects.toMatchObject({ code: "FORBIDDEN" });
      await expect(caller.users.setPermission({ userId: 8, permissionKey: "finance_view", granted: false })).rejects.toMatchObject({ code: "FORBIDDEN" });
    }
  });
});
