import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import * as db from "./db";

const localDriver = () => ({ id: 42, role: "driver" as const, status: "active" as const, approvalStatus: "approved" as const, name: "Driver", civilId: "123456789012", loginMethod: "local-civil-id" });
const callerFor = (user: ReturnType<typeof localDriver>) => appRouter.createCaller({ user, req: {} as never, res: {} as never });
const admin = () => ({ id: 1, role: "admin" as const, status: "active" as const, approvalStatus: "approved" as const, name: "Admin" });

describe("local password change", () => {
  it("changes the password through the protected local-account route", async () => {
    const change = vi.spyOn(db, "changeLocalPassword").mockResolvedValue({ success: true });
    try {
      await expect(callerFor(localDriver()).auth.changeLocalPassword({ currentPassword: "old-pass", newPassword: "new-pass", confirmPassword: "new-pass" })).resolves.toEqual({ success: true });
      expect(change).toHaveBeenCalledWith(42, "old-pass", "new-pass");
    } finally { change.mockRestore(); }
  });

  it("rejects mismatched confirmation before reaching the database", async () => {
    const change = vi.spyOn(db, "changeLocalPassword");
    try {
      await expect(callerFor(localDriver()).auth.changeLocalPassword({ currentPassword: "old-pass", newPassword: "new-pass", confirmPassword: "different" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
      expect(change).not.toHaveBeenCalled();
    } finally { change.mockRestore(); }
  });

  it("allows an admin to reset another local account and requires matching confirmation", async () => {
    const reset = vi.spyOn(db, "resetLocalPassword").mockResolvedValue({ success: true, userId: 42, mustChangePassword: true });
    try {
      await expect(callerFor(admin()).users.resetPassword({ userId: 42, temporaryPassword: "temporary-123", confirmPassword: "temporary-123" })).resolves.toMatchObject({ success: true, mustChangePassword: true });
      expect(reset).toHaveBeenCalledWith(42, "temporary-123", 1);
      await expect(callerFor(admin()).users.resetPassword({ userId: 42, temporaryPassword: "temporary-123", confirmPassword: "different-123" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    } finally { reset.mockRestore(); }
  });

  it("rejects non-admin users from resetting passwords", async () => {
    const reset = vi.spyOn(db, "resetLocalPassword");
    try {
      await expect(callerFor(localDriver()).users.resetPassword({ userId: 7, temporaryPassword: "temporary-123", confirmPassword: "temporary-123" })).rejects.toMatchObject({ code: "FORBIDDEN" });
      expect(reset).not.toHaveBeenCalled();
    } finally { reset.mockRestore(); }
  });

  it("rejects OAuth-style users from the local password route", async () => {
    const change = vi.spyOn(db, "changeLocalPassword");
    try {
      await expect(callerFor({ ...localDriver(), civilId: null, loginMethod: "manus" }).auth.changeLocalPassword({ currentPassword: "old-pass", newPassword: "new-pass", confirmPassword: "new-pass" })).rejects.toMatchObject({ code: "FORBIDDEN" });
      expect(change).not.toHaveBeenCalled();
    } finally { change.mockRestore(); }
  });
});
