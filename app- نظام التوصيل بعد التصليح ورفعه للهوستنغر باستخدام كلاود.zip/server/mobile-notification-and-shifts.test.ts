import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

describe("Mobile notifications, open shifts, and offline visibility", () => {
  it("uses service-worker notifications rather than the unsupported notification constructor", () => {
    const driverAlerts = readFileSync(new URL("../client/src/components/DriverAlerts.tsx", import.meta.url), "utf8");
    const bell = readFileSync(new URL("../client/src/components/NotificationBell.tsx", import.meta.url), "utf8");
    expect(driverAlerts).toContain("showBrowserNotification");
    expect(bell).toContain("showBrowserNotification");
    expect(driverAlerts).not.toContain("new Notification");
    expect(bell).not.toContain("new Notification");
  });

  it("returns shift start time and renders a live counter with collapse control and offline banner", () => {
    const db = readFileSync(new URL("../server/db.ts", import.meta.url), "utf8");
    const shifts = readFileSync(new URL("../client/src/components/OpenShiftDriversBanner.tsx", import.meta.url), "utf8");
    const network = readFileSync(new URL("../client/src/components/NetworkStatusBanner.tsx", import.meta.url), "utf8");
    expect(db).toContain("shiftStartedAt: shifts.startedAt");
    expect(shifts).toContain("formatShiftDuration");
    expect(shifts).toContain("تصغير");
    expect(network).toContain('window.addEventListener("offline"');
    expect(network).toContain("لا يوجد اتصال بالإنترنت");
  });
});
