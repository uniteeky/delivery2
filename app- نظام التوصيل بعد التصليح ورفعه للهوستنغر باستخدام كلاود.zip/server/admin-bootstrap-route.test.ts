import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const appPath = fileURLToPath(new URL("../client/src/App.tsx", import.meta.url));
const oauthPath = fileURLToPath(new URL("./_core/oauth.ts", import.meta.url));

describe("manager sign-in and admin recovery routes", () => {
  it("wires the login and recovery pages without the legacy ad-hoc setup page", async () => {
    const source = await readFile(appPath, "utf8");
    expect(source).toContain('<Route path={"/local-login"} component={LocalLogin} />');
    expect(source).toContain('<Route path={"/admin-recovery"} component={AdminRecovery} />');
    expect(source).not.toContain("q8dragen");
  });

  it("keeps local login and a protected recovery API, removing the old first-admin shortcut", async () => {
    const source = await readFile(oauthPath, "utf8");
    expect(source).toContain('app.post("/api/auth/local-login"');
    expect(source).toContain('app.post("/api/auth/admin-recovery"');
    expect(source).toContain("isValidAdminRecoverySecret");
    expect(source).not.toContain("/api/auth/q8dragen-admin");
  });
});
