import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

describe("Driver GPS fallback", () => {
  it("starts and ends a shift with optional coordinates when the device location is unavailable", () => {
    const source = readFileSync(new URL("../client/src/pages/DriverHome.tsx", import.meta.url), "utf8");
    const router = readFileSync(new URL("../server/routers.ts", import.meta.url), "utf8");
    expect(source).toContain("setGpsUnavailableAtStart(!location)");
    expect(source).toContain("startShift.mutate({ driverId: driver.data.id, ...(location ?? {}) })");
    expect(source).toContain("endShift.mutate({ shiftId: activeShift.data.id, ...(location ?? {}) })");
    expect(source).toContain("تم بدء الوردية بدون GPS");
    expect(router).toContain("latitude: z.string().optional()");
    expect(router).toContain("longitude: z.string().optional()");
  });
});
