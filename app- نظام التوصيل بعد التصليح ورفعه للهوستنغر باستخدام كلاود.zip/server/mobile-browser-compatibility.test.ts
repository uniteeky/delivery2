import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

describe("Mobile browser compatibility", () => {
  it("targets Safari and Android-compatible browser output and ships the referenced web manifest", () => {
    const viteConfig = readFileSync(new URL("../vite.config.ts", import.meta.url), "utf8");
    const html = readFileSync(new URL("../client/index.html", import.meta.url), "utf8");
    const manifest = readFileSync(new URL("../client/public/manifest.webmanifest", import.meta.url), "utf8");
    expect(viteConfig).toContain('target: ["es2018", "safari12", "chrome80"]');
    expect(viteConfig).toContain('cssTarget: ["safari12", "chrome80"]');
    expect(html).toContain('name="viewport"');
    expect(html).toContain('rel="manifest" href="/manifest.webmanifest"');
    expect(manifest).toContain('"display": "standalone"');
  });
});
