import { describe, expect, it } from "vitest";
import { createDriverProfile, ensureApprovedDriverProfilesWithDb, listActiveDriversWithDb, setUserPermissionWithDb, updateUserAccessWithDb } from "./db";

function makeAccessDb(targetStatus: "active" | "inactive" = "inactive") {
  const before = { id: 7, role: "driver", status: targetStatus === "active" ? "inactive" : "active", approvalStatus: "approved", name: "سائق اختبار" };
  const after = { ...before, status: targetStatus };
  const auditRows: unknown[] = [];
  let selectCount = 0;
  const db = {
    select() {
      const query = {
        from() { return query; },
        where() { return query; },
        limit() { return Promise.resolve(selectCount++ === 0 ? [before] : [after]); },
      };
      return query;
    },
    update() {
      return { set() { return { where() { return Promise.resolve(); } }; } };
    },
    insert() {
      return { values(value: unknown) { auditRows.push(value); return Promise.resolve(); } };
    },
  };
  return { db, auditRows };
}

function makePermissionDb() {
  const auditRows: unknown[] = [];
  const db = {
    select() {
      const query = { from() { return query; }, where() { return query; }, limit() { return Promise.resolve([{ id: 8, role: "supervisor" }]); } };
      return query;
    },
    insert() {
      const chain = { values(value: unknown) { auditRows.push(value); return chain; }, onDuplicateKeyUpdate() { return Promise.resolve(); } };
      return chain;
    },
  };
  return { db, auditRows };
}

describe("manager account access audit", () => {
  it("rejects incomplete vehicle or license data before database access", async () => {
    await expect(createDriverProfile(7, { vehicleLabel: " ", licenseNumber: "12" }, 1)).rejects.toThrow("Vehicle label is required");
    await expect(createDriverProfile(7, { vehicleLabel: "تويوتا 1234", licenseNumber: " " }, 1)).rejects.toThrow("License number is required");
  });
  it("does not create a driver profile when an approved legacy driver lacks vehicle/license data", async () => {
    const inserts: unknown[] = [];
    let selectCount = 0;
    const db = {
      select() {
        const query = { from() { return query; }, where() { return query; }, limit() { return Promise.resolve([]); } };
        if (selectCount++ === 0) query.where = () => Promise.resolve([{ id: 7 }]) as never;
        return query;
      },
      insert() { return { values(value: unknown) { inserts.push(value); return Promise.resolve(); } }; },
      update() { return { set() { return { where() { return Promise.resolve(); } }; } }; },
    };
    await ensureApprovedDriverProfilesWithDb(db as never);
    expect(inserts).toEqual([]);
  });

  it("self-heals a legacy approved driver and returns it for NewOrder selection", async () => {
    const inserts: unknown[] = [];
    let selectCount = 0;
    const db = {
      select() {
        const count = selectCount++;
        if (count === 0) return { from() { return this; }, where() { return Promise.resolve([{ id: 7 }]); } };
        if (count === 1) return { from() { return this; }, where() { return this; }, limit() { return Promise.resolve([{ id: 41, vehicleLabel: "تويوتا 1234", licenseNumber: "LIC-7" }]); } };
        return { from() { return this; }, innerJoin() { return this; }, where() { return this; }, orderBy() { return Promise.resolve([{ id: 41, userId: 7, name: "سائق قديم", civilId: "123456789012", active: true, vehicleLabel: "تويوتا 1234", licenseNumber: "LIC-7" }]); } };
      },
      insert() { return { values(value: unknown) { inserts.push(value); return Promise.resolve(); } }; },
      update() { return { set() { return { where() { return Promise.resolve(); } }; } }; },
    };
    const result = await listActiveDriversWithDb(db as never);
    expect(inserts).toEqual([]);
    expect(result).toMatchObject([{ id: 41, userId: 7, name: "سائق قديم", vehicleLabel: "تويوتا 1234", licenseNumber: "LIC-7" }]);
  });

  it("records a non-deletable audit entry when suspending a user", async () => {
    const { db, auditRows } = makeAccessDb();
    const result = await updateUserAccessWithDb(db as never, 7, { status: "inactive" }, 1);
    expect(result.status).toBe("inactive");
    expect(auditRows).toHaveLength(1);
    expect(auditRows[0]).toMatchObject({ actorUserId: 1, action: "user.access_updated", entityType: "user", entityId: "7" });
  });

  it("records approval changes for driver, supervisor, and accountant accounts", async () => {
    for (const role of ["driver", "supervisor", "accountant"] as const) {
      const { db, auditRows } = makeAccessDb("active");
      await updateUserAccessWithDb(db as never, 7, { role, approvalStatus: "approved", status: "active" }, 1);
      expect(auditRows[0]).toMatchObject({ action: "user.access_updated", entityId: "7" });
    }
  });

  it("approving a driver does not create an incomplete profile", async () => {
    const before = { id: 7, role: "driver", status: "inactive", approvalStatus: "pending", name: "سائق جديد" };
    const after = { ...before, status: "active", approvalStatus: "approved" };
    const inserts: unknown[] = [];
    let selectCount = 0;
    const db = {
      select() {
        const query = { from() { return query; }, where() { return query; }, limit() { const value = selectCount++ === 0 ? [before] : selectCount === 2 ? [] : [after]; return Promise.resolve(value); } };
        return query;
      },
      update() { return { set() { return { where() { return Promise.resolve(); } }; } }; },
      insert() { return { values(value: unknown) { inserts.push(value); return Promise.resolve(); } }; },
    };
    await updateUserAccessWithDb(db as never, 7, { role: "driver", approvalStatus: "approved", status: "active" }, 1);
    expect(inserts).toHaveLength(1);
    expect(inserts[0]).toMatchObject({ action: "user.access_updated", entityId: "7" });
  });

  it("records approval changes with before and after audit snapshots", async () => {
    const { db, auditRows } = makeAccessDb("active");
    const result = await updateUserAccessWithDb(db as never, 7, { approvalStatus: "approved", status: "active" }, 1);
    expect(result.status).toBe("active");
    expect(auditRows[0]).toMatchObject({ action: "user.access_updated", entityId: "7" });
  });

  it("records a second immutable audit entry when reactivating a user", async () => {
    const { db, auditRows } = makeAccessDb("active");
    const result = await updateUserAccessWithDb(db as never, 7, { status: "active" }, 1);
    expect(result.status).toBe("active");
    expect(auditRows[0]).toMatchObject({ action: "user.access_updated", entityId: "7" });
    expect(JSON.parse(String((auditRows[0] as { beforeJson: string }).beforeJson)).status).toBe("inactive");
    expect(JSON.parse(String((auditRows[0] as { afterJson: string }).afterJson)).status).toBe("active");
  });

  it("records grant and revoke actions for manager-controlled permissions", async () => {
    const granted = makePermissionDb();
    await setUserPermissionWithDb(granted.db as never, 8, "finance_view", true, 1);
    expect(granted.auditRows[1]).toMatchObject({ action: "user.permission_granted", entityId: "8:finance_view" });
    const revoked = makePermissionDb();
    await setUserPermissionWithDb(revoked.db as never, 8, "finance_view", false, 1);
    expect(revoked.auditRows[1]).toMatchObject({ action: "user.permission_revoked", entityId: "8:finance_view" });
  });
});

  it("promotes a driver account and deactivates its driver profile with an audit snapshot", async () => {
    const before = { id: 7, role: "driver", status: "active", approvalStatus: "approved", name: "سائق اختبار" };
    const after = { ...before, role: "admin" as const };
    const auditRows: unknown[] = [];
    const updates: unknown[] = [];
    let selectCount = 0;
    const db = {
      select() {
        const query = {
          from() { return query; },
          where() { return query; },
          limit() {
            const value = selectCount++ === 0 ? [before] : selectCount === 2 ? [{ id: 41, active: true }] : selectCount === 3 ? [] : [after];
            return Promise.resolve(value);
          },
        };
        return query;
      },
      update() { return { set(value: unknown) { updates.push(value); return { where() { return Promise.resolve(); } }; } }; },
      insert() { return { values(value: unknown) { auditRows.push(value); return Promise.resolve(); } }; },
    };
    const result = await updateUserAccessWithDb(db as never, 7, { role: "admin" }, 1);
    expect(result.role).toBe("admin");
    expect(updates).toContainEqual({ active: false });
    expect(auditRows[0]).toMatchObject({ action: "user.access_updated", entityId: "7" });
    expect(JSON.parse(String((auditRows[0] as { afterJson: string }).afterJson)).driverProfileActive).toBe(false);
  });

  it("blocks removing the driver role while an active shift exists", async () => {
    const before = { id: 7, role: "driver", status: "active", approvalStatus: "approved", name: "سائق اختبار" };
    let selectCount = 0;
    let updated = false;
    const db = {
      select() {
        const query = {
          from() { return query; },
          where() { return query; },
          limit() {
            const value = selectCount++ === 0 ? [before] : selectCount === 2 ? [{ id: 41, active: true }] : [{ id: 99 }];
            return Promise.resolve(value);
          },
        };
        return query;
      },
      update() { return { set() { updated = true; return { where() { return Promise.resolve(); } }; } }; },
      insert() { return { values() { return Promise.resolve(); } }; },
    };
    await expect(updateUserAccessWithDb(db as never, 7, { role: "admin" }, 1)).rejects.toThrow("أنه الوردية النشطة");
    expect(updated).toBe(false);
  });
