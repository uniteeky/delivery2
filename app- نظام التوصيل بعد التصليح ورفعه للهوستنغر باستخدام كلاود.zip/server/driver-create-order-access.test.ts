import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

describe("Driver create-order access", () => {
  it("allows the protected driver new-order route and requires a recipient phone for direct calling", () => {
    const operations = readFileSync(new URL("../shared/operations.ts", import.meta.url), "utf8");
    const page = readFileSync(new URL("../client/src/pages/DriverNewOrder.tsx", import.meta.url), "utf8");
    const home = readFileSync(new URL("../client/src/pages/DriverHome.tsx", import.meta.url), "utf8");
    expect(operations).toContain('path === "/driver/new-order"');
    expect(page).toContain('required type="tel"');
    expect(page).toContain('inputMode="tel"');
    expect(home).toContain('href={`tel:${order.customerPhone}`}');
  });
});
