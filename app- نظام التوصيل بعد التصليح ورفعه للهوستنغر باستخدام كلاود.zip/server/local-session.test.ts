import { describe, expect, it } from "vitest";
import { sdk } from "./_core/sdk";

describe("local session authentication", () => {
  it("uses a stable local app identifier when Hostinger has no OAuth app ID", () => {
    expect(sdk.getSessionAppId("")).toBe("city-center-local");
    expect(sdk.getSessionAppId("configured-app")).toBe("configured-app");
  });

  it("accepts a local-user session when a migrated account has no saved name", async () => {
    const token = await sdk.createSessionToken("local_19", { name: "" });

    await expect(sdk.verifySession(token)).resolves.toEqual({
      openId: "local_19",
      appId: expect.any(String),
      name: "",
    });
  });
});
