import { describe, expect, it } from "vitest";
import { resolveCompanyDeliveryRate } from "../shared/company-delivery-rate";

describe("company delivery rate priority", () => {
  it("uses an area override ahead of the governorate-wide rate", () => {
    expect(resolveCompanyDeliveryRate("2.500", "3.000", "4.000")).toBe("2.500");
  });

  it("uses the governorate-wide rate when no area override exists", () => {
    expect(resolveCompanyDeliveryRate(null, "3.000", "4.000")).toBe("3.000");
  });

  it("keeps a zero area override instead of inheriting a positive governorate rate", () => {
    expect(resolveCompanyDeliveryRate("0.000", "3.000", "4.000")).toBe("0.000");
  });

  it("falls back to the company default when no location rate is set", () => {
    expect(resolveCompanyDeliveryRate(null, null, "4.000")).toBe("4.000");
  });
});
