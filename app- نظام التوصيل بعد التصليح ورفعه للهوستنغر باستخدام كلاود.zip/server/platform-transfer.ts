type TransferUser = { role: string; roles?: readonly string[] };
type TransferAccessSettings = {
  mode: string;
  allowDriverTransfer: boolean;
  allowSupervisorTransfer: boolean;
  allowManagerTransfer: boolean;
};

export function isPlatformTransferAllowed(user: TransferUser, settings: TransferAccessSettings) {
  if (settings.mode !== "active") return false;
  const roles = new Set([user.role, ...(user.roles ?? [])]);
  if (roles.has("admin")) return settings.allowManagerTransfer;
  if (roles.has("driver")) return settings.allowDriverTransfer;
  if (roles.has("supervisor")) return settings.allowSupervisorTransfer;
  return settings.allowManagerTransfer;
}
