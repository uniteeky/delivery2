import { describe, expect, it } from "vitest";
import { adminRecoveryAuditAction, isValidAdminRecoverySecret } from "./admin-recovery";

describe("admin recovery secret", () => {
  const secret = "one-time-admin-recovery-code-0123456789abcdef0123456789abcdef";

  it("accepts only an exact secret when the configured secret is sufficiently long", () => {
    expect(isValidAdminRecoverySecret(secret, secret)).toBe(true);
    expect(isValidAdminRecoverySecret(`${secret}x`, secret)).toBe(false);
    expect(isValidAdminRecoverySecret("wrong-secret", secret)).toBe(false);
    expect(isValidAdminRecoverySecret(secret, "short-secret")).toBe(false);
    expect(isValidAdminRecoverySecret(undefined, secret)).toBe(false);
  });

  it("derives a stable audit fingerprint without storing the secret in the action", () => {
    const action = adminRecoveryAuditAction(secret);
    expect(action).toBe(adminRecoveryAuditAction(secret));
    expect(action).not.toContain(secret);
    expect(action).toMatch(/^auth\.admin_recovery_[a-f0-9]{64}$/);
    expect(adminRecoveryAuditAction(`${secret}x`)).not.toBe(action);
  });
});
