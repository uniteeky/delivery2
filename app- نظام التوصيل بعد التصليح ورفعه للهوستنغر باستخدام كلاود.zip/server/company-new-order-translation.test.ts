import { describe, expect, it } from "vitest";
import { supportedLanguages, translations } from "../client/src/i18n";

describe("CompanyPortal and NewOrder translation coverage", () => {
  it("contains status and optional-field labels in every supported language", () => {
    const keys = [
      "optional",
      "optionalPickupTime",
      "optionalDeliveryTime",
      "statusNew",
      "statusAssigned",
      "statusPickedUp",
      "statusInTransit",
      "statusDelivered",
      "statusFailed",
      "notAdded",
      "noNotes",
      "newOrderLoginRequired",
      "newOrderLoginHint",
      "newOrderLoginAction",
      "newOrderBack",
      "newOrderHint",
      "newOrderCurrentAccount",
      "newOrderPermissions",
      "newOrderCompany",
      "newOrderChooseCompany",
      "newOrderDriverLoading",
      "newOrderDriverError",
      "newOrderNoDriverAssignment",
      "newOrderNoApprovedDriver",
      "newOrderDriverPermissionHint",
      "newOrderDriverApprovalHint",
      "newOrderDriverAssignHint",
      "newOrderNotesPlaceholder",
      "newOrderCreatedSuccess",
      "newOrderDriverUploadsHint",
      "newOrderCreateError",
      "companiesUpdateError",
      "companyFeeDelivery",
    ] as const;

    for (const language of Object.keys(supportedLanguages) as Array<keyof typeof translations>) {
      for (const key of keys) {
        expect(translations[language][key], `${language}.${key}`).toBeTruthy();
      }
    }
  });
});
