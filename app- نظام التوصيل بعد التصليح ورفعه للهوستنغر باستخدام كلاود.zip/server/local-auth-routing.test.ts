import { describe, expect, it } from "vitest";
import { LOCAL_LOGIN_PATH, requiresExternalAccountSetup, shouldStayOnLocalAccessPage } from "../client/src/lib/local-auth-routing";

describe("City Center local-auth boundaries", () => {
  it("keeps local Civil-ID sessions out of the legacy Manus setup flow", () => {
    expect(requiresExternalAccountSetup({ loginMethod: "local-civil-id", mustChangePassword: true })).toBe(false);
  });

  it("uses the local login page after a local-session boundary", () => {
    expect(LOCAL_LOGIN_PATH).toBe("/local-login");
    expect(shouldStayOnLocalAccessPage("/local-login")).toBe(true);
    expect(shouldStayOnLocalAccessPage("/account")).toBe(false);
  });
});
