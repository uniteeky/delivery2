import { Buffer } from "node:buffer";
import { describe, expect, it } from "vitest";
import { decodePlatformLogo, MAX_PLATFORM_LOGO_BYTES, platformLogoExtension } from "./platform-logo";

const asBase64 = (bytes: Buffer) => bytes.toString("base64");

const png = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x01]);
const jpeg = Buffer.from([0xff, 0xd8, 0xff, 0x01]);
const webp = Buffer.from("RIFF\x04\x00\x00\x00WEBPVP8 ", "binary");

describe("platform logo upload validation", () => {
  it.each([
    ["image/png", png, "png"],
    ["image/jpeg", jpeg, "jpg"],
    ["image/webp", webp, "webp"],
  ] as const)("accepts verified %s images", (mimeType, bytes, extension) => {
    expect(decodePlatformLogo(asBase64(bytes), mimeType)).toEqual(bytes);
    expect(platformLogoExtension(mimeType)).toBe(extension);
  });

  it("rejects a mismatched content type", () => {
    expect(() => decodePlatformLogo(asBase64(png), "image/jpeg")).toThrow(/محتوى الملف/);
  });

  it("rejects non-base64 data and oversized uploads", () => {
    expect(() => decodePlatformLogo("not an image", "image/png")).toThrow(/غير صالح/);
    const oversized = Buffer.alloc(MAX_PLATFORM_LOGO_BYTES + 1, 1);
    expect(() => decodePlatformLogo(asBase64(oversized), "image/png")).toThrow(/8 ميجابايت/);
  });
});
