import { describe, expect, it, vi } from "vitest";
import { ensurePlatformSettingsSchema } from "./platform-settings-schema";

describe("ensurePlatformSettingsSchema", () => {
  it("creates a complete settings table and safely leaves existing columns intact", async () => {
    const execute = vi.fn(async (statement: string) => {
      if (statement.startsWith("SELECT ")) {
        const column = statement.match(/^SELECT `([^`]+)`/)?.[1];
        if (column === "nextOrderNumber") {
          const cause = Object.assign(new Error("Unknown column 'nextOrderNumber'"), { code: "ER_BAD_FIELD_ERROR", errno: 1054 });
          throw Object.assign(new Error("Failed query"), { cause });
        }
      }
      return undefined;
    });
    const db = { execute };

    await ensurePlatformSettingsSchema(db);

    expect(execute.mock.calls[0]?.[0]).toContain("CREATE TABLE IF NOT EXISTS `platformSettings`");
    expect(execute).toHaveBeenCalledWith("ALTER TABLE `platformSettings` ADD COLUMN `nextOrderNumber` int NOT NULL DEFAULT 1");
    expect(execute.mock.calls.some(([statement]) => statement.includes("ADD COLUMN `brandName`"))).toBe(false);
  });

  it("does not repeat initialization for the same database instance", async () => {
    const execute = vi.fn(async () => undefined);
    const db = { execute };

    await ensurePlatformSettingsSchema(db);
    const callsAfterFirstEnsure = execute.mock.calls.length;
    await ensurePlatformSettingsSchema(db);

    expect(execute).toHaveBeenCalledTimes(callsAfterFirstEnsure);
  });

  it("shares one initialization while concurrent requests arrive", async () => {
    let release!: () => void;
    const gate = new Promise<void>((resolve) => { release = resolve; });
    const execute = vi.fn(async () => { await gate; return undefined; });
    const db = { execute };

    const first = ensurePlatformSettingsSchema(db);
    const second = ensurePlatformSettingsSchema(db);
    await Promise.resolve();
    expect(execute).toHaveBeenCalledTimes(1);
    release();
    await Promise.all([first, second]);
    expect(execute).toHaveBeenCalledTimes(15);
  });
});
