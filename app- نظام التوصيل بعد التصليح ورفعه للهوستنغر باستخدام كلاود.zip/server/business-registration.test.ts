import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
const router = readFileSync(new URL("./routers.ts", import.meta.url), "utf8");
const db = readFileSync(new URL("./db.ts", import.meta.url), "utf8");
const page = readFileSync(new URL("../client/src/pages/BusinessRegistration.tsx", import.meta.url), "utf8");
describe("business registration", () => {
  it("supports direct company/trader registration without civil ID and keeps it pending", () => { expect(router).toContain('requestedRole: z'); expect(router).toContain('"company", "trader"'); expect(db).toContain('approvalStatus: "pending"'); expect(db).toContain('companyUsers'); });
  it("exposes the public business registration form without a civil ID field", () => { expect(page).toContain("registerDriver"); expect(page).toContain("companyName"); expect(page).toContain("trader"); expect(page).not.toContain("civilId"); });
});
