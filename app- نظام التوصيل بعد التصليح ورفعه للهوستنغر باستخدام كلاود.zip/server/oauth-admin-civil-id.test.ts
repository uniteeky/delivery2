import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("OAuth admin civil-ID setup", () => {
  it("exposes the civil-ID setup only through a protected procedure", () => {
    const source = readFileSync(resolve(process.cwd(), "server/routers.ts"), "utf8");
    expect(source).toContain("setOwnCivilId: protectedProcedure");
    expect(source).not.toContain("adminRecovery: publicProcedure");
  });

  it("keeps the public recovery endpoint secret-protected while account settings provides OAuth entry", () => {
    const oauthSource = readFileSync(resolve(process.cwd(), "server/_core/oauth.ts"), "utf8");
    const accountSource = readFileSync(resolve(process.cwd(), "client/src/pages/AccountSettings.tsx"), "utf8");
    expect(oauthSource).toContain("matchesRecoverySecret");
    expect(accountSource).toContain("startLogin");
    expect(accountSource).toContain("setOwnCivilId");
  });
});
