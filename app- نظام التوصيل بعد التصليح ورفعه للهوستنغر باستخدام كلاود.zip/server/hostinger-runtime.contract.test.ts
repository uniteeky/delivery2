import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const serverEntry = readFileSync(
  new URL("./_core/index.ts", import.meta.url),
  "utf8"
);
const packageManifest = JSON.parse(
  readFileSync(new URL("../package.json", import.meta.url), "utf8")
);

describe("Hostinger production runtime contract", () => {
  it("listens on Hostinger's assigned port and public interface", () => {
    expect(serverEntry).toContain('Number.parseInt(process.env.PORT || "3000", 10)');
    expect(serverEntry).toContain('server.listen(port, "0.0.0.0"');
    expect(serverEntry).not.toContain("findAvailablePort");
  });

  it("provides explicit migration and account-schema verification commands", () => {
    expect(packageManifest.scripts["db:migrate"]).toBe("drizzle-kit migrate");
    expect(packageManifest.scripts["db:check-accounts"]).toBe(
      "node scripts/verify-account-schema.mjs"
    );
  });
});
