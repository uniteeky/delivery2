import { describe, expect, it } from "vitest";
import { assignOrderWithDb, sendThreadMessageWithDb, transferOrderWithDb } from "./db";

function query(value: unknown) {
  const chain: any = {
    from() { return chain; },
    innerJoin() { return chain; },
    leftJoin() { return chain; },
    where() { return chain; },
    orderBy() { return chain; },
    limit() { return Promise.resolve(value); },
    then(resolve: (value: unknown) => unknown, reject?: (reason: unknown) => unknown) { return Promise.resolve(value).then(resolve, reject); },
  };
  return chain;
}

function fakeDb(selectValues: unknown[]) {
  const inserted: unknown[] = [];
  const db: any = {
    select() { return query(selectValues.shift() ?? []); },
      update() { return { set() { return { where: () => Promise.resolve() }; } }; },
    insert() { const chain: any = { values(value: unknown) { inserted.push(value); return Promise.resolve([{ insertId: 500 }]); } }; return chain; },
  };
  return { db, inserted };
}

describe("operational notification events", () => {
  it("creates a notification for the assigned driver's user", async () => {
    const { db, inserted } = fakeDb([[{ id: 10, orderNumber: "CC-10", assignedDriverId: null }], [{ userId: 900 }]]);
    await assignOrderWithDb(db, 10, 77, 1, 12);
    expect(inserted.some((value: any) => value.userId === 900 && value.title === "طلب جديد مسند إليك")).toBe(true);
  });

  it("creates a notification for the receiving driver after transfer", async () => {
    const { db, inserted } = fakeDb([[{ id: 10, orderNumber: "CC-10", assignedDriverId: 55 }], [], [{ id: 55, name: "السائق السابق" }, { id: 78, name: "السائق الجديد" }], [{ userId: 901 }]]);
    await transferOrderWithDb(db, 10, 78, 1, "تغيير المنطقة");
    expect(inserted.some((value: any) => value.userId === 901 && value.title === "تم تحويل طلب إليك")).toBe(true);
  });

  it("creates notifications for every other thread member and excludes the sender", async () => {
    const { db, inserted } = fakeDb([[{ id: 1 }], [{ userId: 42 }, { userId: 902 }, { userId: 903 }]]);
    await sendThreadMessageWithDb(db, 33, 42, "وصلت الرسالة");
    const notificationBatch: any[] = inserted.find((value: any) => Array.isArray(value) && value[0]?.title === "رسالة داخلية جديدة") as any[];
    expect(notificationBatch.map((item) => item.userId)).toEqual([902, 903]);
  });

  it("stores image or audio attachments on the saved message before notifying members", async () => {
    const { db, inserted } = fakeDb([[{ id: 1 }], [{ userId: 42 }, { userId: 902 }]]);
    await sendThreadMessageWithDb(db, 33, 42, "", [{ type: "audio", fileKey: "messages/33/voice.webm", fileUrl: "/media/messages/33/voice.webm", fileName: "voice.webm", mimeType: "audio/webm", sizeBytes: 1200 }]);
    const attachments = inserted.find((value: any) => Array.isArray(value) && value[0]?.fileKey === "messages/33/voice.webm") as any[];
    expect(attachments).toEqual([expect.objectContaining({ messageId: 500, type: "audio", sizeBytes: 1200 })]);
    expect(inserted.some((value: any) => Array.isArray(value) && value[0]?.title === "رسالة داخلية جديدة" && value[0]?.body === "أرسل تسجيلاً صوتياً")).toBe(true);
  });
});
