import { existsSync, readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";

const projectRoot = join(process.cwd());
const distRoot = join(projectRoot, "dist");

function collectFiles(directory: string): string[] {
  if (!existsSync(directory)) return [];
  return readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const path = join(directory, entry.name);
    return entry.isDirectory() ? collectFiles(path) : [path];
  });
}

describe("post-build authentication safety", () => {
  it("contains no known bypass flags or shared test credentials in generated artifacts", () => {
    const files = [join(distRoot, "index.js"), ...collectFiles(join(distRoot, "public"))].filter(existsSync);
    expect(files.length).toBeGreaterThan(0);
    const built = files.map((file) => readFileSync(file, "utf8")).join("\n");
    expect(built).not.toMatch(/TEST_BYPASS|AUTH_BYPASS|skipAuth|test[-_ ]account/i);
    expect(built).not.toMatch(/123456789000|qW1234567890@@/);
  });
});
