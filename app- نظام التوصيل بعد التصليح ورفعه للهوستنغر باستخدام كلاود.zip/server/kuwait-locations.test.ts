import { describe, expect, it } from "vitest";
import { KUWAIT_GOVERNORATES } from "../shared/kuwait-locations";

describe("Kuwait location seed", () => {
  it("provides six governorates with areas in both Arabic and English", () => {
    expect(KUWAIT_GOVERNORATES).toHaveLength(6);
    for (const governorate of KUWAIT_GOVERNORATES) {
      expect(governorate.nameAr.trim()).not.toBe("");
      expect(governorate.nameEn.trim()).not.toBe("");
      expect(governorate.areas.length).toBeGreaterThan(0);
      for (const area of governorate.areas) {
        expect(area.nameAr.trim()).not.toBe("");
        expect(area.nameEn.trim()).not.toBe("");
        expect(area.nameAr).not.toMatch(/[()]/);
        expect(area.nameEn).not.toMatch(/[()]/);
      }
      expect(governorate.nameAr).not.toMatch(/[()]/);
      expect(governorate.nameEn).not.toMatch(/[()]/);
      expect(new Set(governorate.areas.map((area) => area.nameAr)).size).toBe(governorate.areas.length);
    }
  });
});
