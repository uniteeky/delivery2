import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { parse as parseCookie } from "cookie";
import { createHeartbeatJob, updateHeartbeatJob } from "./_core/heartbeat";
import { storageGetSignedUrl, storagePut } from "./storage";
import {
  decodePlatformLogo,
  MAX_PLATFORM_LOGO_BASE64_LENGTH,
  PLATFORM_LOGO_MIME_TYPES,
  platformLogoExtension,
} from "./platform-logo";
import { isPlatformTransferAllowed } from "./platform-transfer";
import {
  assignOrder,
  attachOrderMedia,
  createCompany,
  createCompanyAddress,
  createCompanyPortalOrder,
  bulkCreateCompanyPortalOrders,
  createDriverProfile,
  createManagerAccount,
  createBusinessAccount,
  createMessageThread,
  createNotification,
  createOrder,
  createGovernorate,
  createDeliveryArea,
  listLocationDirectory,
  listAllLocations,
  setLocationActive,
  listCompanyAreaRates,
  setCompanyAreaRate,
  listCompanyGovernorateRates,
  setCompanyGovernorateRate,
  listDriverCompensation,
  updateDriverCompensation,
  listDriverCommissionRates,
  setDriverCommissionRate,
  driverOwnsOrder,
  driverOwnsShift,
  endDriverShift,
  getActiveDriverShift,
  getBackupSchedule,
  getDashboardSummary,
  getDriverForUser,
  listActiveDrivers,
  listActiveShiftDrivers,
  listActiveCompanies,
  listCompanyAddresses,
  getFinancialReport,
  getFinancialSummary,
  getAccountingReport,
  createFinancialEntry,
  updateFinancialEntry,
  listFinanceFilterOptions,
  getSupervisorOperationalReport,
  getOrderDetails,
  listAuditLogs,
  listCompanies,
  listCompanyOrdersForPortal,
  listCompanyPortalDrivers,
  listDriverOrders,
  listDriverTrips,
  createTrip,
  updateTripStatus,
  addOrderToTrip,
  listLatestDriverLocations,
  recordDriverLocation,
  listNotifications,
  getBackupScheduleByTaskUid,
  listBackupSnapshots,
  createBackupSnapshot,
  createBackupSnapshotRecord,
  restoreBackupSnapshot,
  listRecentOrders,
  listOrderTransfers,
  listOrderEvents,
  listMessageRecipients,
  listMessageThreads,
  listThreadMessages,
  listUserPermissions,
  listUsers,
  listUserRoles,
  markNotificationRead,
  normalizeCivilId,
  registerDriver,
  registerStaffAccount,
  resetLocalPassword,
  setOwnCivilId,
  updateUserProfile,
  changeLocalPassword,
  sendThreadMessage,
  setUserPermission,
  setUserRole,
  startDriverShift,
  transferOrder,
  transferDriverOrder,
  updateBackupSchedule,
  updateCompany,
  updateCompanyAddress,
  updateOrderAddresses,
  updateOrderFee,
  updateOrderCompensation,
  updateOrderStatus,
  returnOrderToCompany,
  updateUserAccess,
} from "./db";
import {
  getPlatformAccessState,
  getPlatformSettings,
  updatePlatformSettings,
} from "./db";

const managerRoles = ["admin"] as const;
const operationsRoles = ["admin", "supervisor"] as const;
const civilIdSchema = z
  .string()
  .trim()
  .transform(value => normalizeCivilId(value))
  .refine(value => /^\d{12}$/.test(value), {
    message: "الرقم المدني يجب أن يتكون من 12 رقماً",
  });
const LOCAL_USERNAME_PATTERN = /^[a-z0-9][a-z0-9_.-]{2,79}$/;
const LOCAL_EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function isValidBusinessLogin(value: string) {
  const normalized = value.trim().toLowerCase();
  return (
    LOCAL_USERNAME_PATTERN.test(normalized) ||
    LOCAL_EMAIL_PATTERN.test(normalized)
  );
}

export function hasEffectiveRole(
  user: { role: string; roles?: readonly string[] } | null | undefined,
  role: string
) {
  return Boolean(user && (user.role === role || user.roles?.includes(role)));
}

export function isDriverOnly(
  user: { role: string; roles?: readonly string[] } | null | undefined
) {
  return (
    hasEffectiveRole(user, "driver") &&
    !["admin", "supervisor", "accountant", "company", "trader"].some(role =>
      hasEffectiveRole(user, role)
    )
  );
}

export function canViewOrderPricing(
  user: { role: string; roles?: readonly string[] } | null | undefined
) {
  return (
    hasEffectiveRole(user, "admin") ||
    hasEffectiveRole(user, "accountant") ||
    hasEffectiveRole(user, "supervisor")
  );
}

export function canManageCompensation(
  user: { role: string; roles?: readonly string[] } | null | undefined
) {
  return canViewOrderPricing(user);
}

function hideOrderPricing<
  T extends {
    deliveryFee?: unknown;
    driverCommission?: unknown;
    companyShare?: unknown;
    deliveryFeeManual?: unknown;
    deliveryFeeChargeOnFailure?: unknown;
    driverCommissionManual?: unknown;
    companyShareManual?: unknown;
    compensationInitialized?: unknown;
    returnedToCompany?: unknown;
  },
>(
  order: T,
  options: {
    includeDeliveryFee?: boolean;
    includeDriverCommission?: boolean;
  } = {}
) {
  const {
    deliveryFee,
    driverCommission,
    companyShare: _hiddenCompanyShare,
    deliveryFeeManual: _hiddenDeliveryFeePolicy,
    deliveryFeeChargeOnFailure: _hiddenFailedFeePolicy,
    driverCommissionManual: _hiddenCommissionPolicy,
    companyShareManual: _hiddenSharePolicy,
    compensationInitialized: _hiddenInitialized,
    returnedToCompany: _hiddenReturnMarker,
    ...operationalOrder
  } = order;
  return {
    ...operationalOrder,
    ...(options.includeDeliveryFee ? { deliveryFee } : {}),
    ...(options.includeDriverCommission ? { driverCommission } : {}),
  };
}

export function requireRole(
  user:
    | {
        role: string;
        roles?: readonly string[];
        status?: string;
        approvalStatus?: string;
      }
    | null
    | undefined,
  roles: readonly string[]
) {
  const effectiveRoles = user ? [user.role, ...(user.roles ?? [])] : [];
  if (!user || !roles.some(role => effectiveRoles.includes(role)))
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "ليس لديك صلاحية لتنفيذ هذا الإجراء",
    });
  if (
    user.status === "inactive" ||
    user.approvalStatus === "pending" ||
    user.approvalStatus === "rejected"
  )
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "الحساب غير معتمد أو موقوف",
    });
}

export function hasGrantedPermission(
  permissions: Array<{ permissionKey: string; granted: boolean }>,
  permissionKey: string
) {
  return permissions.some(
    item => item.permissionKey === permissionKey && item.granted
  );
}

async function requireBackupCapability(
  user: {
    id: number;
    role: string;
    roles?: readonly string[];
    status?: string;
    approvalStatus?: string;
  },
  permissionKey: string
) {
  requireRole(user, ["admin", "supervisor"]);
  if (user.role === "admin" || user.roles?.includes("admin")) return;
  const permissions = await listUserPermissions(user.id);
  if (!hasGrantedPermission(permissions, permissionKey))
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "تحتاج إلى صلاحية النسخ الاحتياطي من المدير",
    });
}

export async function requireCapability(
  user: {
    id: number;
    role: string;
    roles?: readonly string[];
    status?: string;
    approvalStatus?: string;
  },
  permissionKey: string
) {
  requireRole(user, ["admin", "supervisor", "accountant"]);
  if (user.role === "admin" || user.roles?.includes("admin")) return;
  const permissions = await listUserPermissions(user.id);
  if (!hasGrantedPermission(permissions, permissionKey)) {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "تحتاج إلى صلاحية إضافية من المدير",
    });
  }
}

async function requireTransferEnabled(user: {
  id: number;
  role: string;
  roles?: readonly string[];
  status?: string;
  approvalStatus?: string;
}) {
  if (process.env.NODE_ENV === "test") return;
  const access = await getPlatformAccessState();
  if (!isPlatformTransferAllowed(user, access)) {
    const message =
      access.mode !== "active"
        ? "الاشتراك منتهٍ والموقع في وضع القراءة فقط"
        : "تحويل الطلبات غير مفعّل لهذا الدور";
    throw new TRPCError({ code: "FORBIDDEN", message });
  }
}

export const appRouter = router({
  system: systemRouter,
  platform: router({
    branding: publicProcedure.query(async () => {
      const settings = await getPlatformSettings();
      return {
        brandName: settings.brandName,
        logoUrl: settings.logoUrl,
        primaryColor: settings.primaryColor,
        accentColor: settings.accentColor,
      };
    }),
    canTransfer: protectedProcedure.query(async ({ ctx }) => {
      const settings = await getPlatformAccessState();
      return { allowed: isPlatformTransferAllowed(ctx.user!, settings) };
    }),
    settings: protectedProcedure.query(async ({ ctx }) => {
      requireRole(ctx.user, managerRoles);
      return getPlatformAccessState();
    }),
    uploadLogo: protectedProcedure
      .input(
        z.object({
          mimeType: z.enum(PLATFORM_LOGO_MIME_TYPES),
          dataBase64: z.string().min(1).max(MAX_PLATFORM_LOGO_BASE64_LENGTH),
        })
      )
      .mutation(async ({ ctx, input }) => {
        requireRole(ctx.user, managerRoles);
        let bytes: Buffer;
        try {
          bytes = decodePlatformLogo(input.dataBase64, input.mimeType);
        } catch (error) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message:
              error instanceof Error ? error.message : "ملف الشعار غير صالح",
          });
        }
        const extension = platformLogoExtension(input.mimeType);
        const stored = await storagePut(
          `platform/branding/logo-${Date.now()}.${extension}`,
          bytes,
          input.mimeType
        );
        return { logoUrl: stored.url };
      }),
    updateSettings: protectedProcedure
      .input(
        z.object({
          brandName: z.string().trim().min(2).max(180),
          logoUrl: z.string().trim().max(512).nullable(),
          primaryColor: z.string().regex(/^#[0-9a-fA-F]{6}$/),
          accentColor: z.string().regex(/^#[0-9a-fA-F]{6}$/),
          subscriptionStartsAt: z.string().datetime().nullable(),
          subscriptionEndsAt: z.string().datetime().nullable(),
          allowDriverTransfer: z.boolean(),
          allowSupervisorTransfer: z.boolean(),
          allowManagerTransfer: z.boolean(),
          hideDriverDeliveryFee: z.boolean(),
          orderNumberFormat: z.enum(["numeric", "alphabetic"]),
          nextOrderNumber: z.number().int().min(1).max(2147483647),
        })
      )
      .mutation(async ({ ctx, input }) => {
        requireRole(ctx.user, managerRoles);
        return updatePlatformSettings(
          {
            ...input,
            subscriptionStartsAt: input.subscriptionStartsAt
              ? new Date(input.subscriptionStartsAt)
              : null,
            subscriptionEndsAt: input.subscriptionEndsAt
              ? new Date(input.subscriptionEndsAt)
              : null,
          },
          ctx.user!.id
        );
      }),
  }),
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    permissions: protectedProcedure.query(({ ctx }) =>
      listUserPermissions(ctx.user!.id)
    ),
    roles: protectedProcedure.query(({ ctx }) => listUserRoles(ctx.user!.id)),
    registerDriver: publicProcedure
      .input(
        z
          .object({
            civilId: civilIdSchema.optional(),
            loginName: z.string().trim().min(3).max(320).optional(),
            password: z.string().min(8, "كلمة المرور يجب ألا تقل عن 8 أحرف"),
            name: z.string().trim().min(2).max(160),
            phone: z.string().trim().min(8).max(40),
            email: z.string().email().max(320).optional(),
            businessName: z.string().trim().min(2).max(180).optional(),
            businessCode: z.string().trim().min(2).max(40).optional(),
            businessPhone: z.string().trim().max(40).optional(),
            businessAddress: z.string().trim().max(1000).optional(),
            preferredLanguage: z.enum(["ar", "en", "bn", "hi"]).default("ar"),
            requestedRole: z
              .enum(["driver", "supervisor", "accountant", "company", "trader"])
              .default("driver"),
          })
          .superRefine((value, ctx) => {
            const business =
              value.requestedRole === "company" ||
              value.requestedRole === "trader";
            if (business && !isValidBusinessLogin(value.loginName ?? ""))
              ctx.addIssue({
                code: z.ZodIssueCode.custom,
                path: ["loginName"],
                message:
                  "أدخل بريداً إلكترونياً صحيحاً أو اسم مستخدم إنجليزياً من 3 أحرف على الأقل",
              });
            if (!business && !value.civilId)
              ctx.addIssue({
                code: z.ZodIssueCode.custom,
                path: ["civilId"],
                message: "الرقم المدني يجب أن يتكون من 12 رقماً",
              });
          })
      )
      .mutation(({ input }) => registerDriver(input)),
    setOwnCivilId: protectedProcedure
      .input(
        z.object({
          civilId: civilIdSchema,
        })
      )
      .mutation(({ ctx, input }) => setOwnCivilId(ctx.user!.id, input.civilId)),
    changeLocalPassword: protectedProcedure
      .input(
        z.object({
          currentPassword: z.string().min(8),
          newPassword: z.string().min(8),
          confirmPassword: z.string().min(8),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!ctx.user?.civilId || ctx.user.loginMethod !== "local-civil-id")
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "تغيير كلمة المرور متاح للحساب المحلي فقط",
          });
        if (input.newPassword !== input.confirmPassword)
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "كلمتا المرور الجديدتان غير متطابقتين",
          });
        return changeLocalPassword(
          ctx.user.id,
          input.currentPassword,
          input.newPassword
        );
      }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  companyPortal: router({
    createOrder: protectedProcedure
      .input(
        z.object({
          customerName: z.string().trim().max(180).optional(),
          customerPhone: z.string().max(40).optional(),
          pickupAddress: z.string().trim().min(5),
          pickupGovernorateId: z.number().int().positive().optional(),
          pickupAreaId: z.number().int().positive().optional(),
          pickupScheduledAt: z.string().datetime().optional(),
          deliveryAddress: z.string().trim().min(5),
          deliveryGovernorateId: z.number().int().positive().optional(),
          deliveryAreaId: z.number().int().positive().optional(),
          deliveryScheduledAt: z.string().datetime().optional(),
          area: z.string().max(120).optional(),
          notes: z.string().max(2000).optional(),
          cashToCollectAmount: z
            .string()
            .regex(/^\d{1,9}(\.\d{1,3})?$/)
            .optional(),
          cashCollectionNote: z.string().max(1000).optional(),
          requestedVehicleType: z
            .enum([
              "car",
              "refrigerated_car",
              "motorcycle",
              "semi_truck",
              "refrigerated_semi_truck",
              "truck",
              "refrigerated_truck",
            ])
            .optional(),
          assignedDriverId: z.number().int().positive().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        requireRole(ctx.user, ["company", "trader"]);
        return createCompanyPortalOrder(ctx.user!.id, input);
      }),
    myOrders: protectedProcedure.query(async ({ ctx }) => {
      requireRole(ctx.user, ["company", "trader"]);
      const permissions = await listUserPermissions(ctx.user!.id);
      return listCompanyOrdersForPortal(
        ctx.user!.id,
        permissions.filter(item => item.granted).map(item => item.permissionKey)
      );
    }),
    drivers: protectedProcedure.query(async ({ ctx }) => {
      requireRole(ctx.user, ["company", "trader"]);
      return listCompanyPortalDrivers(ctx.user!.id);
    }),
    bulkCreate: protectedProcedure
      .input(
        z.object({
          orders: z
            .array(
              z.object({
                customerName: z.string().max(180).optional(),
                customerPhone: z.string().max(40).optional(),
                pickupAddress: z.string().min(5),
                deliveryAddress: z.string().min(5),
                cashToCollectAmount: z.string().optional(),
                cashCollectionNote: z.string().max(1000).optional(),
                requestedVehicleType: z
                  .enum([
                    "car",
                    "refrigerated_car",
                    "motorcycle",
                    "semi_truck",
                    "refrigerated_semi_truck",
                    "truck",
                    "refrigerated_truck",
                  ])
                  .optional(),
              })
            )
            .max(500),
        })
      )
      .mutation(async ({ ctx, input }) => {
        requireRole(ctx.user, ["company", "trader"]);
        return bulkCreateCompanyPortalOrders(ctx.user!.id, input.orders);
      }),
  }),
  driver: router({
    me: protectedProcedure.query(async ({ ctx }) => {
      requireRole(ctx.user, ["driver"]);
      return (await getDriverForUser(ctx.user!.id)) ?? null;
    }),
    trips: protectedProcedure.query(async ({ ctx }) => {
      requireRole(ctx.user, ["driver"]);
      const driver = await getDriverForUser(ctx.user!.id);
      return driver ? listDriverTrips(driver.id) : [];
    }),
    setTripStatus: protectedProcedure
      .input(
        z.object({
          tripId: z.number().int().positive(),
          status: z.enum(["active", "closed"]),
        })
      )
      .mutation(async ({ ctx, input }) => {
        requireRole(ctx.user, ["driver"]);
        const driver = await getDriverForUser(ctx.user!.id);
        const trips = driver ? await listDriverTrips(driver.id) : [];
        if (!trips.some(trip => trip.id === input.tripId))
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "الرحلة لا تخص حسابك",
          });
        return updateTripStatus(input.tripId, input.status, ctx.user!.id);
      }),
    myOrders: protectedProcedure.query(async ({ ctx }) => {
      requireRole(ctx.user, ["driver"]);
      const driver = await getDriverForUser(ctx.user!.id);
      const settings = await getPlatformSettings();
      return driver
        ? listDriverOrders(driver.id, !settings.hideDriverDeliveryFee)
        : [];
    }),
    activeShiftDrivers: protectedProcedure.query(async ({ ctx }) => {
      requireRole(ctx.user, ["driver"]);
      return listActiveShiftDrivers();
    }),
    companies: protectedProcedure.query(async ({ ctx }) => {
      requireRole(ctx.user, ["driver"]);
      return listActiveCompanies();
    }),
    companyAddresses: protectedProcedure
      .input(z.object({ companyId: z.number().int().positive() }))
      .query(async ({ ctx, input }) => {
        requireRole(ctx.user, ["driver"]);
        return listCompanyAddresses(input.companyId, true);
      }),
    beginDelivery: protectedProcedure
      .input(
        z.object({
          orderId: z.number().int().positive(),
          latitude: z.string().optional(),
          longitude: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        requireRole(ctx.user, ["driver"]);
        if (!(await driverOwnsOrder(ctx.user!.id, input.orderId)))
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "الطلب غير مسند إلى حسابك",
          });
        return updateOrderStatus(
          input.orderId,
          "picked_up",
          ctx.user!.id,
          undefined,
          input.latitude,
          input.longitude,
          "بدأ التوصيل"
        );
      }),
    completeDelivery: protectedProcedure
      .input(
        z.object({
          orderId: z.number().int().positive(),
          cashCollectedAmount: z.string().regex(/^\d{1,9}(\.\d{1,3})?$/),
          latitude: z.string().optional(),
          longitude: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        requireRole(ctx.user, ["driver"]);
        if (!(await driverOwnsOrder(ctx.user!.id, input.orderId)))
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "الطلب غير مسند إلى حسابك",
          });
        return updateOrderStatus(
          input.orderId,
          "delivered",
          ctx.user!.id,
          undefined,
          input.latitude,
          input.longitude,
          "تم التسليم وتسجيل المبلغ المحصل",
          input.cashCollectedAmount
        );
      }),
    returnOrder: protectedProcedure
      .input(
        z.object({
          orderId: z.number().int().positive(),
          note: z.string().max(1000).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        requireRole(ctx.user, ["driver"]);
        if (!(await driverOwnsOrder(ctx.user!.id, input.orderId)))
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "الطلب غير مسند إلى حسابك",
          });
        return returnOrderToCompany(input.orderId, ctx.user!.id, input.note);
      }),
    transferOrder: protectedProcedure
      .input(
        z.object({
          orderId: z.number().int().positive(),
          toDriverId: z.number().int().positive(),
          reason: z.string().max(1000).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        requireRole(ctx.user, ["driver"]);
        await requireTransferEnabled(ctx.user!);
        const driver = await getDriverForUser(ctx.user!.id);
        if (!driver)
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "لا يوجد ملف سائق مرتبط بالحساب",
          });
        return transferDriverOrder(
          input.orderId,
          driver.id,
          input.toDriverId,
          ctx.user!.id,
          input.reason
        );
      }),
    createOrder: protectedProcedure
      .input(
        z.object({
          companyId: z.number().int().positive().optional(),
          pickupContactName: z.string().trim().min(2).max(180),
          customerName: z.string().trim().max(180).optional(),
          customerPhone: z.string().trim().min(5).max(40),
          pickupAddress: z.string().trim().min(5),
          pickupPhone: z.string().trim().min(5).max(40),
          pickupLocationUrl: z.string().url().max(1000).optional(),
          pickupGovernorateId: z.number().int().positive().optional(),
          pickupAreaId: z.number().int().positive().optional(),
          deliveryAddress: z.string().trim().min(5),
          deliveryGovernorateId: z.number().int().positive().optional(),
          deliveryAreaId: z.number().int().positive().optional(),
          area: z.string().max(120).optional(),
          notes: z.string().max(2000).optional(),
          cashToCollectAmount: z
            .string()
            .regex(/^\d{1,9}(\.\d{1,3})?$/)
            .optional(),
          cashCollectionNote: z.string().max(1000).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        requireRole(ctx.user, ["driver"]);
        const driver = await getDriverForUser(ctx.user!.id);
        if (!driver)
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "لا يوجد ملف سائق مرتبط بالحساب",
          });
        return createOrder(
          {
            ...input,
            source: input.companyId ? "supervisor" : "external",
            driverId: driver.id,
          },
          ctx.user!.id
        );
      }),
    activeShift: protectedProcedure.query(async ({ ctx }) => {
      requireRole(ctx.user, ["driver"]);
      const driver = await getDriverForUser(ctx.user!.id);
      return driver ? ((await getActiveDriverShift(driver.id)) ?? null) : null;
    }),
    updateLocation: protectedProcedure
      .input(
        z.object({
          latitude: z.string().regex(/^-?\d+(\.\d+)?$/),
          longitude: z.string().regex(/^-?\d+(\.\d+)?$/),
        })
      )
      .mutation(async ({ ctx, input }) => {
        requireRole(ctx.user, ["driver"]);
        const driver = await getDriverForUser(ctx.user!.id);
        if (!driver)
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "لا يوجد ملف سائق مرتبط بالحساب",
          });
        return recordDriverLocation(driver.id, input.latitude, input.longitude);
      }),
  }),
  trips: router({
    create: protectedProcedure
      .input(
        z.object({
          driverId: z.number().int().positive(),
          label: z.string().trim().max(120).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        await requireCapability(ctx.user, "orders_manage");
        return createTrip(input.driverId, input.label, ctx.user!.id);
      }),
    listForDriver: protectedProcedure
      .input(z.object({ driverId: z.number().int().positive() }))
      .query(async ({ ctx, input }) => {
        await requireCapability(ctx.user, "orders_view");
        return listDriverTrips(input.driverId);
      }),
    addOrder: protectedProcedure
      .input(
        z.object({
          tripId: z.number().int().positive(),
          orderId: z.number().int().positive(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        await requireCapability(ctx.user, "orders_manage");
        return addOrderToTrip(input.orderId, input.tripId, ctx.user!.id);
      }),
    setStatus: protectedProcedure
      .input(
        z.object({
          tripId: z.number().int().positive(),
          status: z.enum(["active", "closed"]),
        })
      )
      .mutation(async ({ ctx, input }) => {
        await requireCapability(ctx.user, "orders_manage");
        return updateTripStatus(input.tripId, input.status, ctx.user!.id);
      }),
  }),
  drivers: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      await requireCapability(ctx.user, "orders_manage");
      return listActiveDrivers();
    }),
    openShifts: protectedProcedure.query(async ({ ctx }) => {
      requireRole(ctx.user, operationsRoles);
      return listActiveShiftDrivers();
    }),
    compensationList: protectedProcedure.query(async ({ ctx }) => {
      if (!canViewOrderPricing(ctx.user))
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "بيانات أجور السائقين متاحة للإدارة والمحاسبة فقط",
        });
      await requireCapability(ctx.user, "finance_view");
      return listDriverCompensation();
    }),
    updateCompensation: protectedProcedure
      .input(
        z.object({
          driverId: z.number().int().positive(),
          payType: z.enum(["salary", "salary_commission", "contractor"]),
          baseSalary: z.string().regex(/^\d+(\.\d{1,3})?$/),
          defaultCommission: z.string().regex(/^\d+(\.\d{1,3})?$/),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!canManageCompensation(ctx.user))
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "تعديل أجور السائقين متاح للإدارة والمحاسبة",
          });
        await requireCapability(ctx.user, "finance_edit");
        return updateDriverCompensation(input, ctx.user!.id);
      }),
    commissionRates: protectedProcedure
      .input(z.object({ driverId: z.number().int().positive() }))
      .query(async ({ ctx, input }) => {
        if (!canViewOrderPricing(ctx.user))
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "بيانات أجور السائقين متاحة للإدارة والمحاسبة فقط",
          });
        await requireCapability(ctx.user, "finance_view");
        return listDriverCommissionRates(input.driverId);
      }),
    setCommissionRate: protectedProcedure
      .input(
        z.object({
          driverId: z.number().int().positive(),
          companyId: z.number().int().positive().optional(),
          areaId: z.number().int().positive().optional(),
          amount: z.string().regex(/^\d+(\.\d{1,3})?$/),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!canManageCompensation(ctx.user))
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "تعديل عمولات السائقين متاح للإدارة والمحاسبة",
          });
        await requireCapability(ctx.user, "finance_edit");
        return setDriverCommissionRate(input, ctx.user!.id);
      }),
  }),
  orders: router({
    get: protectedProcedure
      .input(z.object({ orderId: z.number().int().positive() }))
      .query(async ({ ctx, input }) => {
        if (isDriverOnly(ctx.user)) {
          if (!(await driverOwnsOrder(ctx.user!.id, input.orderId)))
            throw new TRPCError({
              code: "FORBIDDEN",
              message: "الطلب غير مسند إلى حسابك",
            });
        } else {
          await requireCapability(ctx.user, "orders_view");
        }
        const result = await getOrderDetails(input.orderId);
        if (!result)
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "الطلب غير موجود",
          });
        if (canViewOrderPricing(ctx.user)) return result;
        if (isDriverOnly(ctx.user)) {
          const settings = await getPlatformAccessState();
          return hideOrderPricing(result, {
            includeDriverCommission: true,
            includeDeliveryFee: !settings.hideDriverDeliveryFee,
          });
        }
        return hideOrderPricing(result);
      }),
    create: protectedProcedure
      .input(
        z
          .object({
            companyId: z.number().int().positive().optional(),
            driverId: z.number().int().positive().optional(),
            source: z
              .enum(["supervisor", "company", "external"])
              .default("supervisor"),
            pickupContactName: z.string().trim().min(2).max(180),
            customerName: z.string().trim().max(180).optional(),
            customerPhone: z.string().trim().min(5).max(40),
            pickupAddress: z.string().trim().min(5),
            pickupPhone: z.string().trim().min(5).max(40),
            pickupLocationUrl: z.string().url().max(1000).optional(),
            pickupGovernorateId: z.number().int().positive().optional(),
            pickupAreaId: z.number().int().positive().optional(),
            pickupScheduledAt: z.string().datetime().optional(),
            deliveryAddress: z.string().trim().min(5),
            deliveryGovernorateId: z.number().int().positive().optional(),
            deliveryAreaId: z.number().int().positive().optional(),
            deliveryScheduledAt: z.string().datetime().optional(),
            area: z.string().max(120).optional(),
            notes: z.string().max(2000).optional(),
            cashToCollectAmount: z
              .string()
              .regex(/^\d{1,9}(\.\d{1,3})?$/)
              .optional(),
            cashCollectionNote: z.string().max(1000).optional(),
            deliveryFee: z
              .string()
              .regex(/^\d+(\.\d{1,3})?$/)
              .optional(),
            driverCommission: z
              .string()
              .regex(/^\d+(\.\d{1,3})?$/)
              .optional(),
            companyShare: z
              .string()
              .regex(/^\d+(\.\d{1,3})?$/)
              .optional(),
            deliveryFeeChargeOnFailure: z.boolean().optional(),
          })
          .superRefine((value, ctx) => {
            if (value.source === "supervisor" && !value.companyId)
              ctx.addIssue({
                code: "custom",
                path: ["companyId"],
                message: "اختر الشركة التابعة للطلب",
              });
            if (value.source === "external" && value.companyId)
              ctx.addIssue({
                code: "custom",
                path: ["companyId"],
                message: "الطلب الخارجي لا يرتبط بشركة",
              });
            if (value.source === "external" && !value.pickupAddress)
              ctx.addIssue({
                code: "custom",
                path: ["pickupAddress"],
                message: "أدخل عنوان الاستلام للطلب الخارجي",
              });
          })
      )
      .mutation(async ({ ctx, input }) => {
        await requireCapability(ctx.user, "orders_manage");
        if (
          (input.deliveryFee !== undefined ||
            input.driverCommission !== undefined ||
            input.companyShare !== undefined ||
            input.deliveryFeeChargeOnFailure !== undefined) &&
          !canManageCompensation(ctx.user)
        )
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "الرسوم والعمولات تعدلها الإدارة أو المحاسبة",
          });
        return createOrder(input, ctx.user!.id);
      }),
    assign: protectedProcedure
      .input(
        z.object({
          orderId: z.number().int().positive(),
          driverId: z.number().int().positive(),
          tripId: z.number().int().positive().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        await requireCapability(ctx.user, "orders_manage");
        return assignOrder(
          input.orderId,
          input.driverId,
          ctx.user!.id,
          input.tripId
        );
      }),
    transfer: protectedProcedure
      .input(
        z.object({
          orderId: z.number().int().positive(),
          toDriverId: z.number().int().positive(),
          reason: z.string().max(1000).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        await requireCapability(ctx.user, "orders_manage");
        await requireTransferEnabled(ctx.user!);
        return transferOrder(
          input.orderId,
          input.toDriverId,
          ctx.user!.id,
          input.reason
        );
      }),
    transfers: protectedProcedure
      .input(z.object({ orderId: z.number().int().positive() }))
      .query(async ({ ctx, input }) => {
        await requireCapability(ctx.user, "orders_view");
        return listOrderTransfers(input.orderId);
      }),
    events: protectedProcedure
      .input(z.object({ orderId: z.number().int().positive() }))
      .query(async ({ ctx, input }) => {
        await requireCapability(ctx.user, "orders_view");
        return listOrderEvents(input.orderId);
      }),
    updateAddresses: protectedProcedure
      .input(
        z.object({
          orderId: z.number().int().positive(),
          pickupAddress: z.string().trim().min(5).optional(),
          pickupGovernorateId: z
            .number()
            .int()
            .positive()
            .nullable()
            .optional(),
          pickupAreaId: z.number().int().positive().nullable().optional(),
          deliveryAddress: z.string().trim().min(5),
          deliveryGovernorateId: z
            .number()
            .int()
            .positive()
            .nullable()
            .optional(),
          deliveryAreaId: z.number().int().positive().nullable().optional(),
          reason: z.string().max(1000).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        await requireCapability(ctx.user, "orders_manage");
        return updateOrderAddresses(input.orderId, input, ctx.user!.id);
      }),
    updateStatus: protectedProcedure
      .input(
        z.object({
          orderId: z.number().int().positive(),
          status: z.enum([
            "assigned",
            "picked_up",
            "in_transit",
            "delivered",
            "failed",
          ]),
          latitude: z.string().optional(),
          longitude: z.string().optional(),
          note: z.string().max(1000).optional(),
          failureReason: z
            .enum([
              "no_answer",
              "not_present",
              "wrong_address",
              "postponed",
              "refused",
              "address_changed",
              "other",
            ])
            .optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!hasEffectiveRole(ctx.user, "driver") || !isDriverOnly(ctx.user))
          await requireCapability(ctx.user, "orders_manage");
        if (isDriverOnly(ctx.user) && input.status === "delivered")
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "أدخل المبلغ المستلم عند إتمام التسليم من شاشة السائق",
          });
        if (
          isDriverOnly(ctx.user) &&
          !(await driverOwnsOrder(ctx.user!.id, input.orderId))
        )
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "الطلب غير مسند إلى حسابك",
          });
        return updateOrderStatus(
          input.orderId,
          input.status,
          ctx.user!.id,
          input.failureReason,
          input.latitude,
          input.longitude,
          input.note
        );
      }),
    attachMedia: protectedProcedure
      .input(
        z.object({
          orderId: z.number().int().positive(),
          kind: z.enum(["order", "invoice", "delivery"]),
          fileName: z.string().max(180),
          mimeType: z.string().regex(/^image\//),
          dataBase64: z.string().min(20).max(12_000_000),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!hasEffectiveRole(ctx.user, "driver") || !isDriverOnly(ctx.user))
          await requireCapability(ctx.user, "orders_manage");
        if (
          isDriverOnly(ctx.user) &&
          !(await driverOwnsOrder(ctx.user!.id, input.orderId))
        )
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "الطلب غير مسند إلى حسابك",
          });
        const buffer = Buffer.from(input.dataBase64, "base64");
        if (buffer.length > 8 * 1024 * 1024)
          throw new TRPCError({
            code: "PAYLOAD_TOO_LARGE",
            message: "الحد الأقصى للصورة 8 ميجابايت",
          });
        const stored = await storagePut(
          `orders/${input.orderId}/${Date.now()}-${input.fileName.replace(/[^a-zA-Z0-9._-]/g, "_")}`,
          buffer,
          input.mimeType
        );
        await attachOrderMedia(
          {
            orderId: input.orderId,
            kind: input.kind,
            fileKey: stored.key,
            fileUrl: stored.url,
          },
          ctx.user!.id
        );
        return { url: stored.url };
      }),
  }),
  notifications: router({
    list: protectedProcedure.query(({ ctx }) =>
      listNotifications(ctx.user!.id)
    ),
    markRead: protectedProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(({ ctx, input }) =>
        markNotificationRead(input.id, ctx.user!.id)
      ),
    createForUser: protectedProcedure
      .input(
        z.object({
          userId: z.number().int().positive(),
          title: z.string().max(180),
          body: z.string().max(2000),
        })
      )
      .mutation(async ({ ctx, input }) => {
        await requireCapability(ctx.user, "orders_manage");
        return createNotification(input);
      }),
  }),
  messaging: router({
    recipients: protectedProcedure.query(({ ctx }) =>
      listMessageRecipients(ctx.user!.id)
    ),
    listThreads: protectedProcedure.query(({ ctx }) =>
      listMessageThreads(ctx.user!.id)
    ),
    createThread: protectedProcedure
      .input(
        z
          .object({
            type: z.enum(["direct", "group", "order", "company"]),
            title: z.string().trim().max(180).optional(),
            orderId: z.number().int().positive().optional(),
            companyId: z.number().int().positive().optional(),
            memberIds: z.array(z.number().int().positive()).max(100),
          })
          .superRefine((value, issueCtx) => {
            if (value.type === "direct" && value.memberIds.length !== 1)
              issueCtx.addIssue({
                code: "custom",
                path: ["memberIds"],
                message: "المحادثة الفردية تحتاج مستلماً واحداً",
              });
            if (value.type === "group" && value.memberIds.length < 2)
              issueCtx.addIssue({
                code: "custom",
                path: ["memberIds"],
                message: "اختر عضوين على الأقل لإنشاء القروب",
              });
          })
      )
      .mutation(({ ctx, input }) => {
        if (
          input.type === "group" &&
          !hasEffectiveRole(ctx.user, "admin") &&
          !hasEffectiveRole(ctx.user, "supervisor")
        )
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "إنشاء القروبات متاح للمدير أو المشرف فقط",
          });
        return createMessageThread(input, ctx.user!.id);
      }),
    listMessages: protectedProcedure
      .input(
        z.object({
          threadId: z.number().int().positive(),
          limit: z.number().int().min(1).max(100).default(50),
        })
      )
      .query(({ ctx, input }) =>
        listThreadMessages(input.threadId, ctx.user!.id, input.limit)
      ),
    send: protectedProcedure
      .input(
        z
          .object({
            threadId: z.number().int().positive(),
            body: z.string().trim().max(4000).default(""),
            attachments: z
              .array(
                z.object({
                  type: z.enum(["image", "audio"]),
                  fileName: z.string().trim().min(1).max(180),
                  mimeType: z
                    .string()
                    .regex(
                      /^(image\/(jpeg|png|webp|gif)|audio\/(webm|ogg|mpeg|mp4|wav|x-m4a|aac))$/
                    ),
                  dataBase64: z.string().min(20).max(16_000_000),
                })
              )
              .max(4)
              .default([]),
          })
          .superRefine((value, issueCtx) => {
            if (!value.body && !value.attachments.length)
              issueCtx.addIssue({
                code: "custom",
                path: ["body"],
                message: "أدخل رسالة أو أرفق ملفاً",
              });
          })
      )
      .mutation(async ({ ctx, input }) => {
        const uploaded = [] as Array<{
          type: "image" | "audio";
          fileKey: string;
          fileUrl: string;
          fileName: string;
          mimeType: string;
          sizeBytes: number;
        }>;
        for (const attachment of input.attachments) {
          const buffer = Buffer.from(attachment.dataBase64, "base64");
          if (buffer.length > 10 * 1024 * 1024)
            throw new TRPCError({
              code: "PAYLOAD_TOO_LARGE",
              message: "الحد الأقصى لكل صورة أو تسجيل صوتي هو 10 ميجابايت",
            });
          const safeName = attachment.fileName.replace(/[^a-zA-Z0-9._-]/g, "_");
          const stored = await storagePut(
            `messages/${input.threadId}/${Date.now()}-${safeName}`,
            buffer,
            attachment.mimeType
          );
          uploaded.push({
            type: attachment.type,
            fileKey: stored.key,
            fileUrl: stored.url,
            fileName: attachment.fileName,
            mimeType: attachment.mimeType,
            sizeBytes: buffer.length,
          });
        }
        return sendThreadMessage(
          input.threadId,
          ctx.user!.id,
          input.body,
          uploaded
        );
      }),
  }),
  finance: router({
    summary: protectedProcedure.query(async ({ ctx }) => {
      if (!canViewOrderPricing(ctx.user))
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "بيانات الأسعار متاحة للمدير والمحاسب فقط",
        });
      await requireCapability(ctx.user, "finance_view");
      return getFinancialSummary();
    }),
    report: protectedProcedure
      .input(
        z
          .object({
            area: z.string().optional(),
            status: z
              .enum([
                "assigned",
                "picked_up",
                "in_transit",
                "delivered",
                "failed",
              ])
              .optional(),
            fromDate: z.string().optional(),
            toDate: z.string().optional(),
          })
          .optional()
      )
      .query(async ({ ctx, input }) => {
        if (!canViewOrderPricing(ctx.user))
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "بيانات الأسعار متاحة للمدير والمحاسب فقط",
          });
        await requireCapability(ctx.user, "finance_view");
        return getFinancialReport(input ?? {});
      }),
    updateFee: protectedProcedure
      .input(
        z.object({
          orderId: z.number().int().positive(),
          deliveryFee: z.string().regex(/^\d+(\.\d{1,3})?$/),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!canManageCompensation(ctx.user))
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "تعديل رسوم الطلب متاح للإدارة والمحاسبة",
          });
        await requireCapability(ctx.user, "finance_edit");
        return updateOrderFee(input.orderId, input.deliveryFee, ctx.user!.id);
      }),
    updateCompensation: protectedProcedure
      .input(
        z
          .object({
            orderId: z.number().int().positive(),
            deliveryFee: z
              .string()
              .regex(/^\d+(\.\d{1,3})?$/)
              .optional(),
            driverCommission: z
              .string()
              .regex(/^\d+(\.\d{1,3})?$/)
              .optional(),
            companyShare: z
              .string()
              .regex(/^\d+(\.\d{1,3})?$/)
              .optional(),
            deliveryFeeChargeOnFailure: z.boolean().optional(),
          })
          .refine(
            value =>
              value.deliveryFee !== undefined ||
              value.driverCommission !== undefined ||
              value.companyShare !== undefined ||
              value.deliveryFeeChargeOnFailure !== undefined
          )
      )
      .mutation(async ({ ctx, input }) => {
        if (!canManageCompensation(ctx.user))
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "تعديل الرسوم والعمولات متاح للإدارة والمحاسبة",
          });
        await requireCapability(ctx.user, "finance_edit");
        return updateOrderCompensation(input, ctx.user!.id);
      }),
    filterOptions: protectedProcedure.query(async ({ ctx }) => {
      if (!canViewOrderPricing(ctx.user))
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "بيانات الأسعار متاحة للمدير والمحاسب فقط",
        });
      await requireCapability(ctx.user, "finance_view");
      return listFinanceFilterOptions();
    }),
    accountingReport: protectedProcedure
      .input(
        z
          .object({
            fromDate: z.string().optional(),
            toDate: z.string().optional(),
            companyId: z.number().int().positive().optional(),
            driverId: z.number().int().positive().optional(),
            governorateId: z.number().int().positive().optional(),
            areaId: z.number().int().positive().optional(),
            status: z
              .enum([
                "pending",
                "assigned",
                "picked_up",
                "in_transit",
                "delivered",
                "failed",
              ])
              .optional(),
            scope: z.enum(["all", "company", "external"]).optional(),
          })
          .optional()
      )
      .query(async ({ ctx, input }) => {
        if (!canViewOrderPricing(ctx.user))
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "بيانات الأسعار متاحة للمدير والمحاسب فقط",
          });
        await requireCapability(ctx.user, "finance_view");
        return getAccountingReport(input ?? {});
      }),
    createEntry: protectedProcedure
      .input(
        z.object({
          type: z.enum(["income", "expense"]),
          category: z.enum([
            "company_payment",
            "delivery_revenue",
            "salary",
            "rent",
            "installment",
            "utilities",
            "insurance",
            "fuel",
            "marketing",
            "maintenance",
            "purchase",
            "sale",
            "other",
          ]),
          companyId: z.number().int().positive().optional(),
          orderId: z.number().int().positive().optional(),
          amount: z.string().regex(/^\d+(\.\d{1,3})?$/),
          description: z.string().trim().min(2).max(500),
          reference: z.string().max(160).optional(),
          transactionDate: z.string().datetime(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!canViewOrderPricing(ctx.user))
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "القيود المالية متاحة للمحاسب أو المدير فقط",
          });
        await requireCapability(ctx.user, "finance_edit");
        return createFinancialEntry(input, ctx.user!.id);
      }),
    updateEntry: protectedProcedure
      .input(
        z.object({
          id: z.number().int().positive(),
          type: z.enum(["income", "expense"]),
          category: z.enum([
            "company_payment",
            "delivery_revenue",
            "salary",
            "rent",
            "installment",
            "utilities",
            "insurance",
            "fuel",
            "marketing",
            "maintenance",
            "purchase",
            "sale",
            "other",
          ]),
          companyId: z.number().int().positive().optional(),
          amount: z.string().regex(/^\d+(\.\d{1,3})?$/),
          description: z.string().trim().min(2).max(500),
          reference: z.string().max(160).optional(),
          transactionDate: z.string().datetime(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!canViewOrderPricing(ctx.user))
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "القيود المالية متاحة للمحاسب أو المدير فقط",
          });
        await requireCapability(ctx.user, "finance_edit");
        return updateFinancialEntry(input, ctx.user!.id);
      }),
  }),
  backups: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      await requireBackupCapability(ctx.user, "backup_view");
      return listBackupSnapshots();
    }),
    create: protectedProcedure.mutation(async ({ ctx }) => {
      await requireBackupCapability(ctx.user, "backup_create");
      const snapshot = await createBackupSnapshot();
      const payload = JSON.stringify({
        ...snapshot,
        coverage: {
          databaseTables: Object.keys(snapshot.tables),
          mediaFilesIncludedAsReferences: snapshot.tables.orderMedia.length,
        },
      });
      const stored = await storagePut(
        `backups/manual/${snapshot.generatedAt}.json`,
        payload,
        "application/json"
      );
      const record = await createBackupSnapshotRecord({
        storageKey: stored.key,
        downloadUrl: stored.url,
        generatedAt: new Date(snapshot.generatedAt),
        sizeBytes: Buffer.byteLength(payload),
        createdByUserId: ctx.user!.id,
      });
      return { ...record, downloadUrl: await storageGetSignedUrl(stored.key) };
    }),
    getDownloadUrl: protectedProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .query(async ({ ctx, input }) => {
        await requireBackupCapability(ctx.user, "backup_download");
        const snapshots = await listBackupSnapshots();
        const snapshot = snapshots.find(item => item.id === input.id);
        if (!snapshot)
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "النسخة غير موجودة",
          });
        return {
          url: await storageGetSignedUrl(snapshot.storageKey),
          fileName: snapshot.storageKey.split("/").pop() ?? "backup.json",
        };
      }),
    upload: protectedProcedure
      .input(
        z.object({
          fileName: z.string().max(180),
          dataBase64: z.string().min(100).max(35_000_000),
        })
      )
      .mutation(async ({ ctx, input }) => {
        requireRole(ctx.user, managerRoles);
        const payload = Buffer.from(input.dataBase64, "base64").toString(
          "utf8"
        );
        const parsed = JSON.parse(payload) as {
          format?: string;
          version?: number;
          generatedAt?: string;
          secureUsers?: string;
          tables?: Record<string, unknown[]>;
        };
        if (
          parsed.format !== "city-center-delivery-backup" ||
          parsed.version !== 2 ||
          !parsed.secureUsers ||
          !parsed.tables
        )
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "صيغة النسخة غير مدعومة أو ناقصة",
          });
        const stored = await storagePut(
          `backups/uploaded/${input.fileName.replace(/[^a-zA-Z0-9._-]/g, "_")}`,
          payload,
          "application/json"
        );
        const record = await createBackupSnapshotRecord({
          storageKey: stored.key,
          downloadUrl: stored.url,
          generatedAt: new Date(parsed.generatedAt ?? Date.now()),
          sizeBytes: Buffer.byteLength(payload),
          createdByUserId: ctx.user!.id,
        });
        return { ...record, validated: true };
      }),
    restore: protectedProcedure
      .input(
        z.object({
          dataBase64: z.string().min(100).max(35_000_000),
          confirmation: z.literal("RESTORE_CITY_CENTER"),
        })
      )
      .mutation(async ({ ctx, input }) => {
        requireRole(ctx.user, managerRoles);
        const payload = Buffer.from(input.dataBase64, "base64").toString(
          "utf8"
        );
        try {
          return await restoreBackupSnapshot(payload, ctx.user!.id);
        } catch (error) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message:
              error instanceof Error ? error.message : "تعذر استعادة النسخة",
          });
        }
      }),
    getSchedule: protectedProcedure.query(({ ctx }) => {
      requireRole(ctx.user, managerRoles);
      return getBackupSchedule();
    }),
    updateSchedule: protectedProcedure
      .input(
        z.object({
          frequency: z.enum(["hourly", "every_6_hours", "daily", "weekly"]),
          destinationLabel: z.string().trim().min(2).max(180),
          enabled: z.boolean(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        requireRole(ctx.user, managerRoles);
        const current = await getBackupSchedule();
        const sessionToken =
          parseCookie(ctx.req.headers.cookie ?? "")[COOKIE_NAME] ?? "";
        const cronByFrequency = {
          hourly: "0 0 * * * *",
          every_6_hours: "0 0 */6 * * *",
          daily: "0 0 2 * * *",
          weekly: "0 0 2 * * 0",
        } as const;
        let cronTaskUid = current?.cronTaskUid ?? null;
        if (input.enabled) {
          if (cronTaskUid)
            await updateHeartbeatJob(
              cronTaskUid,
              {
                cron: cronByFrequency[input.frequency],
                path: "/api/scheduled/backup",
                enable: true,
                description: "City Center off-server backup",
              },
              sessionToken
            );
          else {
            const job = await createHeartbeatJob(
              {
                name: "city-center-backup",
                cron: cronByFrequency[input.frequency],
                path: "/api/scheduled/backup",
                description: "City Center off-server backup",
              },
              sessionToken
            );
            cronTaskUid = job.taskUid;
          }
        } else if (cronTaskUid) {
          await updateHeartbeatJob(
            cronTaskUid,
            { enable: false },
            sessionToken
          );
        }
        return updateBackupSchedule({ ...input, cronTaskUid }, ctx.user!.id);
      }),
  }),
  audit: router({
    list: protectedProcedure
      .input(
        z.object({
          page: z.number().int().min(1).default(1),
          pageSize: z.number().int().min(1).max(100).default(50),
        })
      )
      .query(async ({ ctx, input }) => {
        await requireCapability(ctx.user, "audit_view");
        return listAuditLogs(input.page, input.pageSize);
      }),
  }),
  shifts: router({
    start: protectedProcedure
      .input(
        z.object({
          driverId: z.number().int().positive(),
          latitude: z.string().optional(),
          longitude: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!hasEffectiveRole(ctx.user, "driver") || !isDriverOnly(ctx.user))
          await requireCapability(ctx.user, "orders_manage");
        if (hasEffectiveRole(ctx.user, "driver") && isDriverOnly(ctx.user)) {
          const driver = await getDriverForUser(ctx.user.id);
          if (!driver || driver.id !== input.driverId)
            throw new TRPCError({
              code: "FORBIDDEN",
              message: "لا يمكنك بدء وردية لسائق آخر",
            });
        }
        return startDriverShift(
          input.driverId,
          input.latitude,
          input.longitude
        );
      }),
    end: protectedProcedure
      .input(
        z.object({
          shiftId: z.number().int().positive(),
          latitude: z.string().optional(),
          longitude: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!hasEffectiveRole(ctx.user, "driver") || !isDriverOnly(ctx.user))
          await requireCapability(ctx.user, "orders_manage");
        if (
          isDriverOnly(ctx.user) &&
          !(await driverOwnsShift(ctx.user!.id, input.shiftId))
        )
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "الوردية لا تخص حسابك",
          });
        return endDriverShift(input.shiftId, input.latitude, input.longitude);
      }),
  }),
  dashboard: router({
    summary: protectedProcedure.query(async ({ ctx }) => {
      await requireCapability(ctx.user, "dashboard_view");
      return getDashboardSummary();
    }),
    recentOrders: protectedProcedure.query(async ({ ctx }) => {
      await requireCapability(ctx.user, "dashboard_view");
      const orders = await listRecentOrders(10);
      return canViewOrderPricing(ctx.user)
        ? orders
        : orders.map(order => hideOrderPricing(order));
    }),
    driverLocations: protectedProcedure.query(async ({ ctx }) => {
      await requireCapability(ctx.user, "dashboard_view");
      return listLatestDriverLocations();
    }),
  }),
  supervisorReports: router({
    get: protectedProcedure
      .input(
        z
          .object({
            fromDate: z.string().optional(),
            toDate: z.string().optional(),
            companyId: z.number().int().positive().optional(),
            driverId: z.number().int().positive().optional(),
            vehicleType: z
              .enum([
                "car",
                "refrigerated_car",
                "motorcycle",
                "semi_truck",
                "refrigerated_semi_truck",
                "truck",
                "refrigerated_truck",
              ])
              .optional(),
            unassigned: z.boolean().optional(),
            governorateId: z.number().int().positive().optional(),
            areaId: z.number().int().positive().optional(),
            status: z
              .enum([
                "pending",
                "assigned",
                "picked_up",
                "in_transit",
                "delivered",
                "failed",
              ])
              .optional(),
            paymentMethod: z.enum(["paid", "cash_on_delivery"]).optional(),
            paymentCollection: z
              .enum(["collected", "not_collected"])
              .optional(),
            search: z.string().trim().max(120).optional(),
            source: z.enum(["supervisor", "company", "external"]).optional(),
          })
          .optional()
      )
      .query(async ({ ctx, input }) => {
        await requireCapability(ctx.user, "dashboard_view");
        return getSupervisorOperationalReport(input ?? {});
      }),
  }),
  users: router({
    list: protectedProcedure
      .input(
        z.object({
          page: z.number().int().min(1).default(1),
          pageSize: z.number().int().min(1).max(100).default(25),
        })
      )
      .query(({ ctx, input }) => {
        requireRole(ctx.user, managerRoles);
        return listUsers(input.page, input.pageSize);
      }),
    createManagerAccount: protectedProcedure
      .input(
        z.object({
          civilId: civilIdSchema,
          password: z.string().min(8).max(200),
          email: z.string().trim().email().max(320),
        })
      )
      .mutation(({ ctx, input }) => {
        requireRole(ctx.user, managerRoles);
        return createManagerAccount(input, ctx.user!.id);
      }),
    createBusinessAccount: protectedProcedure
      .input(
        z.object({
          companyId: z.number().int().positive().optional(),
          companyName: z.string().trim().min(2).max(180).optional(),
          companyPhone: z.string().trim().max(40).optional(),
          companyAddress: z.string().trim().max(1000).optional(),
          username: z.string().trim().min(3).max(120).optional(),
          password: z.string().min(8).max(200).optional(),
          role: z.enum(["company", "trader"]),
        }).superRefine((value, ctx) => {
          if (!value.companyId && !value.companyName)
            ctx.addIssue({ code: z.ZodIssueCode.custom, path: ["companyName"], message: "أدخل اسم الشركة أو التاجر" });
          if (Boolean(value.username) !== Boolean(value.password))
            ctx.addIssue({ code: z.ZodIssueCode.custom, path: ["username"], message: "أدخل اسم المستخدم وكلمة المرور معاً" });
        })
      )
      .mutation(({ ctx, input }) => {
        requireRole(ctx.user, managerRoles);
        return createBusinessAccount(input, ctx.user!.id);
      }),
    createStaffAccount: protectedProcedure
      .input(
        z.object({
          civilId: civilIdSchema,
          password: z.string().min(8).max(200),
          name: z.string().trim().min(2).max(160),
          phone: z.string().trim().min(5).max(40),
          email: z.string().email().optional(),
          role: z.enum([
            "supervisor",
            "accountant",
            "driver",
            "company",
            "trader",
          ]),
          companyId: z.number().int().positive().optional(),
        })
      )
      .mutation(({ ctx, input }) => {
        requireRole(ctx.user, managerRoles);
        return registerStaffAccount(input, ctx.user!.id);
      }),
    createDriver: protectedProcedure
      .input(
        z.object({
          userId: z.number().int().positive(),
          vehicleLabel: z.string().trim().min(2).max(120),
          licenseNumber: z.string().trim().max(80).optional(),
          vehicleType: z.enum([
            "car",
            "refrigerated_car",
            "motorcycle",
            "semi_truck",
            "refrigerated_semi_truck",
            "truck",
            "refrigerated_truck",
          ]),
        })
      )
      .mutation(({ ctx, input }) => {
        requireRole(ctx.user, managerRoles);
        return createDriverProfile(input.userId, input, ctx.user!.id);
      }),
    updateAccess: protectedProcedure
      .input(
        z.object({
          userId: z.number().int().positive(),
          role: z
            .enum(["admin", "supervisor", "accountant", "driver", "company", "trader"])
            .optional(),
          status: z.enum(["active", "inactive"]).optional(),
          approvalStatus: z
            .enum(["pending", "approved", "rejected"])
            .optional(),
        })
      )
      .mutation(({ ctx, input }) => {
        requireRole(ctx.user, managerRoles);
        return updateUserAccess(
          input.userId,
          {
            role: input.role,
            status: input.status,
            approvalStatus: input.approvalStatus,
          },
          ctx.user!.id
        );
      }),
    updateProfile: protectedProcedure
      .input(
        z.object({
          userId: z.number().int().positive(),
          name: z.string().trim().min(2).max(160),
          phone: z.string().trim().min(5).max(40),
          email: z.string().email().max(320).optional(),
          companyId: z.number().int().positive().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        requireRole(ctx.user, managerRoles);
        return updateUserProfile(input.userId, input, ctx.user!.id);
      }),
    resetPassword: protectedProcedure
      .input(
        z.object({
          userId: z.number().int().positive(),
          temporaryPassword: z.string().min(8).max(200),
          confirmPassword: z.string().min(8).max(200),
        })
      )
      .mutation(async ({ ctx, input }) => {
        requireRole(ctx.user, managerRoles);
        if (input.temporaryPassword !== input.confirmPassword)
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "كلمتا المرور غير متطابقتين",
          });
        if (input.userId === ctx.user!.id)
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "استخدم إعدادات حسابك لتغيير كلمة مرورك",
          });
        return resetLocalPassword(
          input.userId,
          input.temporaryPassword,
          ctx.user!.id
        );
      }),
    permissions: protectedProcedure
      .input(z.object({ userId: z.number().int().positive() }))
      .query(({ ctx, input }) => {
        requireRole(ctx.user, managerRoles);
        return listUserPermissions(input.userId);
      }),
    setPermission: protectedProcedure
      .input(
        z.object({
          userId: z.number().int().positive(),
          permissionKey: z.string().trim().min(2).max(80),
          granted: z.boolean(),
        })
      )
      .mutation(({ ctx, input }) => {
        requireRole(ctx.user, managerRoles);
        return setUserPermission(
          input.userId,
          input.permissionKey,
          input.granted,
          ctx.user!.id
        );
      }),
    setRole: protectedProcedure
      .input(
        z.object({
          userId: z.number().int().positive(),
          role: z.enum([
            "supervisor",
            "accountant",
            "driver",
            "company",
            "trader",
          ]),
          granted: z.boolean(),
        })
      )
      .mutation(({ ctx, input }) => {
        requireRole(ctx.user, managerRoles);
        return setUserRole(
          input.userId,
          input.role,
          input.granted,
          ctx.user!.id
        );
      }),
  }),
  companies: router({
    list: protectedProcedure
      .input(
        z.object({
          page: z.number().int().min(1).default(1),
          pageSize: z.number().int().min(1).max(100).default(20),
        })
      )
      .query(async ({ ctx, input }) => {
        await requireCapability(ctx.user, "companies_view");
        const result = await listCompanies(input.page, input.pageSize);
        if (canViewOrderPricing(ctx.user)) return result;
        return {
          ...result,
          items: result.items.map(company => ({
            ...company,
            defaultDeliveryFee: undefined,
          })),
        };
      }),
    create: protectedProcedure
      .input(
        z.object({
          name: z.string().trim().min(2).max(180),
          defaultDeliveryFee: z
            .string()
            .regex(/^\d+(\.\d{1,3})?$/)
            .optional(),
          phone: z.string().max(40).optional(),
          whatsapp: z.string().max(40).optional(),
          address: z.string().max(1000).optional(),
          locationUrl: z.string().url().max(1000).optional(),
          pickupContactName: z.string().trim().max(180).optional(),
          governorateId: z.number().int().positive().optional(),
          areaId: z.number().int().positive().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        requireRole(ctx.user, managerRoles);
        const id = await createCompany(input, ctx.user!.id);
        return { id };
      }),
    update: protectedProcedure
      .input(
        z.object({
          companyId: z.number().int().positive(),
          name: z.string().trim().min(2).max(180).optional(),
          phone: z.string().max(40).optional(),
          whatsapp: z.string().max(40).optional(),
          address: z.string().max(1000).optional(),
          locationUrl: z.string().url().max(1000).optional(),
          defaultDeliveryFee: z
            .string()
            .regex(/^\d+(\.\d{1,3})?$/)
            .optional(),
          status: z.enum(["active", "inactive"]).optional(),
          portalEnabled: z.boolean().optional(),
        })
      )
      .mutation(({ ctx, input }) => {
        requireRole(ctx.user, managerRoles);
        const { companyId, ...changes } = input;
        return updateCompany(companyId, changes, ctx.user!.id);
      }),
    addresses: protectedProcedure
      .input(z.object({ companyId: z.number().int().positive() }))
      .query(async ({ ctx, input }) => {
        await requireCapability(ctx.user, "companies_view");
        return listCompanyAddresses(input.companyId);
      }),
    createAddress: protectedProcedure
      .input(
        z.object({
          companyId: z.number().int().positive(),
          label: z.string().trim().min(2).max(180),
          address: z.string().trim().min(5).max(1000),
          locationUrl: z.string().url().max(1000).optional(),
          phone: z.string().trim().min(5).max(40).optional(),
          pickupContactName: z.string().trim().max(180).optional(),
          governorateId: z.number().int().positive().optional(),
          areaId: z.number().int().positive().optional(),
          isDefault: z.boolean().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        requireRole(ctx.user, managerRoles);
        return { id: await createCompanyAddress(input, ctx.user!.id) };
      }),
    updateAddress: protectedProcedure
      .input(
        z.object({
          addressId: z.number().int().positive(),
          label: z.string().trim().min(2).max(180).optional(),
          address: z.string().trim().min(5).max(1000).optional(),
          phone: z.string().trim().min(5).max(40).optional(),
          pickupContactName: z.string().trim().max(180).nullable().optional(),
          locationUrl: z.string().url().max(1000).nullable().optional(),
          governorateId: z.number().int().positive().nullable().optional(),
          areaId: z.number().int().positive().nullable().optional(),
          isDefault: z.boolean().optional(),
          active: z.boolean().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        requireRole(ctx.user, managerRoles);
        const { addressId, ...changes } = input;
        return updateCompanyAddress(addressId, changes, ctx.user!.id);
      }),
    areaRates: protectedProcedure
      .input(z.object({ companyId: z.number().int().positive() }))
      .query(async ({ ctx, input }) => {
        if (!canViewOrderPricing(ctx.user))
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "تعرفات الشركات متاحة للإدارة والمحاسبة فقط",
          });
        await requireCapability(ctx.user, "finance_view");
        return listCompanyAreaRates(input.companyId);
      }),
    setAreaRate: protectedProcedure
      .input(
        z.object({
          companyId: z.number().int().positive(),
          areaId: z.number().int().positive(),
          amount: z.string().regex(/^\d+(\.\d{1,3})?$/),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!canManageCompensation(ctx.user))
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "تعديل تعرفة الشركة متاح للإدارة والمحاسبة",
          });
        await requireCapability(ctx.user, "finance_edit");
        return setCompanyAreaRate(input, ctx.user!.id);
      }),
    governorateRates: protectedProcedure
      .input(z.object({ companyId: z.number().int().positive() }))
      .query(async ({ ctx, input }) => {
        if (!canViewOrderPricing(ctx.user))
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "تعرفات الشركات متاحة للإدارة والمحاسبة فقط",
          });
        await requireCapability(ctx.user, "finance_view");
        return listCompanyGovernorateRates(input.companyId);
      }),
    setGovernorateRate: protectedProcedure
      .input(
        z.object({
          companyId: z.number().int().positive(),
          governorateId: z.number().int().positive(),
          amount: z.string().regex(/^\d+(\.\d{1,3})?$/),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (!canManageCompensation(ctx.user))
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "تعديل تعرفة الشركة متاح للإدارة والمحاسبة",
          });
        await requireCapability(ctx.user, "finance_edit");
        return setCompanyGovernorateRate(input, ctx.user!.id);
      }),
  }),
  locations: router({
    directory: protectedProcedure.query(() => listLocationDirectory()),
    manageList: protectedProcedure.query(async ({ ctx }) => {
      requireRole(ctx.user, operationsRoles);
      return listAllLocations();
    }),
    createGovernorate: protectedProcedure
      .input(
        z.object({
          nameAr: z.string().trim().min(2).max(180),
          nameEn: z.string().trim().max(180).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        requireRole(ctx.user, operationsRoles);
        return createGovernorate(input, ctx.user!.id);
      }),
    createArea: protectedProcedure
      .input(
        z.object({
          governorateId: z.number().int().positive(),
          nameAr: z.string().trim().min(2).max(180),
          nameEn: z.string().trim().max(180).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        requireRole(ctx.user, operationsRoles);
        return createDeliveryArea(input, ctx.user!.id);
      }),
    setActive: protectedProcedure
      .input(
        z.object({
          kind: z.enum(["governorate", "area"]),
          id: z.number().int().positive(),
          active: z.boolean(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        requireRole(ctx.user, operationsRoles);
        return setLocationActive(input, ctx.user!.id);
      }),
  }),
});

export type AppRouter = typeof appRouter;
