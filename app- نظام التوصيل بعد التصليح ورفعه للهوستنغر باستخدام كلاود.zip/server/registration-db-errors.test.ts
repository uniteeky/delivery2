import { describe, expect, it } from "vitest";
import { registrationDatabaseMessage, unwrapDatabaseError } from "./db";

const wrap = (inner: Record<string, unknown>) =>
  Object.assign(new Error("Failed query: insert into `users` ... params: null,secret-hash"), {
    cause: Object.assign(new Error(String(inner.sqlMessage ?? "")), inner),
  });

describe("registration database errors", () => {
  it("finds the real MySQL error behind Drizzle's generic Failed query message", () => {
    const err = wrap({ errno: 1265, code: "WARN_DATA_TRUNCATED", sqlMessage: "Data truncated for column 'role' at row 1" });
    expect(unwrapDatabaseError(err).errno).toBe(1265);
    expect(registrationDatabaseMessage(err)).toContain("بنية المستخدمين في MySQL قديمة");
  });
  it("maps duplicate and missing-column errors to clear Arabic messages without SQL text", () => {
    expect(registrationDatabaseMessage(wrap({ errno: 1062, code: "ER_DUP_ENTRY", sqlMessage: "Duplicate entry" }))).toContain("مسجل مسبقاً");
    const missing = registrationDatabaseMessage(wrap({ errno: 1054, code: "ER_BAD_FIELD_ERROR", sqlMessage: "Unknown column 'x'" }));
    expect(missing).toContain("db:migrate");
    expect(missing).not.toMatch(/Failed query|params/);
  });
  it("returns null for unknown errors so a generic safe message is used", () => {
    expect(registrationDatabaseMessage(new Error("boom"))).toBeNull();
  });
});
