import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const source = (file: string) => readFileSync(resolve(process.cwd(), file), "utf8");

describe("cash collection display coverage", () => {
  it("shows customer cash due and recorded collections in driver active and delivered lists", () => {
    const driver = source("client/src/pages/DriverHome.tsx");
    expect(driver).toContain("order.cashToCollectAmount");
    expect(driver).toContain("cashCollectedDrafts[order.id]");
    expect(driver).toContain("order.cashCollectionRecorded");
    expect(driver).toContain("order.cashCollectedAmount");
    expect(driver).toContain("order.cashCollectionNote");
    expect(driver).toContain("activeShift.data.cashCollectedTotal");
    expect(driver).toContain("receipt.cashCollectedTotal");
  });

  it("shows collection details in dashboard, trip order picker, and live operations order cards", () => {
    for (const file of ["client/src/pages/Home.tsx", "client/src/components/TripsPanel.tsx", "client/src/pages/OperationsRoom.tsx"]) {
      const view = source(file);
      expect(view, file).toContain("cashToCollectAmount");
      expect(view, file).toContain("cashCollectedAmount");
      expect(view, file).toContain("cashCollectionNote");
    }
  });

  it("shows due, received and notes in printable order details and accounting/operations reports", () => {
    for (const file of ["client/src/pages/OrderDetails.tsx", "client/src/pages/Finance.tsx", "client/src/pages/OperationsRoom.tsx", "client/src/pages/CompanyPortal.tsx"]) {
      const view = source(file);
      expect(view, file).toContain("cashToCollectAmount");
      expect(view, file).toContain("cashCollectedAmount");
      expect(view, file).toContain("cashCollectionNote");
    }
  });
});
