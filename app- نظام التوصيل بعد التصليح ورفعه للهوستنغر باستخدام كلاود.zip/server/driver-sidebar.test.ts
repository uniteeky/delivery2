import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const source = readFileSync(new URL("../client/src/pages/DriverHome.tsx", import.meta.url), "utf8");

describe("driver mobile sidebar", () => {
  it("uses an opaque system background for the shared sidebar shell", () => {
    const sidebarSource = readFileSync(new URL("../client/src/components/ui/sidebar.tsx", import.meta.url), "utf8");
    expect(sidebarSource).toContain("bg-background text-foreground");
    expect(sidebarSource).not.toContain('className="bg-sidebar text-sidebar-foreground');
  });

  it("uses a solid white mobile panel and a separate dimmed backdrop", () => {
    const sidebarSource = readFileSync(new URL("../client/src/components/ui/sidebar.tsx", import.meta.url), "utf8");
    const sheetSource = readFileSync(new URL("../client/src/components/ui/sheet.tsx", import.meta.url), "utf8");
    expect(sidebarSource).toContain("bg-white text-slate-900");
    expect(sheetSource).toContain("bg-white text-slate-900");
    expect(sheetSource).toContain("z-[55] bg-black/65");
    expect(sheetSource).toContain("z-[60]");
  });

  it("keeps the menu trigger, close behavior, account route, logout, and language switcher wired", () => {
    expect(source).toContain("setMenuOpen(true)");
    expect(source).toContain("onOpenChange={setMenuOpen}");
    expect(source).toContain('navigate(\"/driver/account\")');
    expect(source).toContain("LanguageSwitcher");
    expect(source).toContain("void logout()");
  });

  it("keeps a dedicated mobile trigger connected directly to the mobile sidebar state", () => {
    const layoutSource = readFileSync(new URL("../client/src/components/DashboardLayout.tsx", import.meta.url), "utf8");
    expect(layoutSource).toContain("data-sidebar-mobile-trigger");
    expect(layoutSource).toContain("setOpenMobile(!openMobile)");
    expect(layoutSource).toContain("if (isMobile) setOpenMobile(false)");
  });
});
