import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("first-admin bootstrap copy", () => {
  const source = readFileSync(resolve(process.cwd(), "client/src/i18n.tsx"), "utf8");

  it("labels the Arabic portal as first-admin creation", () => {
    expect(source).toContain('recoveryTitle: "إنشاء حساب المدير الأول"');
    expect(source).toContain('recoveryDescription: "أنشئ حساب المدير الأول باستخدام السر الخاص.');
    expect(source).toContain('recoverySubmit: "إنشاء حساب المدير"');
    expect(source).toContain('recoveryError: "تعذر إنشاء حساب المدير"');
  });

  it("keeps the English bootstrap wording explicit", () => {
    expect(source).toContain('recoveryTitle: "Create the first admin account"');
    expect(source).toContain('recoveryDescription: "Create the first admin account with the private setup secret.');
    expect(source).toContain('recoverySubmit: "Create admin account"');
  });
});
