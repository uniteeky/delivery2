import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  authenticateRequest: vi.fn(),
  getSchedule: vi.fn(),
  snapshot: vi.fn(),
  put: vi.fn(),
  getSignedUrl: vi.fn(),
  mark: vi.fn(),
}));

vi.mock("./_core/sdk", () => ({ sdk: { authenticateRequest: mocks.authenticateRequest } }));
vi.mock("./db", () => ({ getBackupScheduleByTaskUid: mocks.getSchedule, createBackupSnapshot: mocks.snapshot, markBackupRun: mocks.mark }));
vi.mock("./storage", () => ({ storagePut: mocks.put, storageGetSignedUrl: mocks.getSignedUrl }));

import { runScheduledBackup } from "./scheduled";

describe("scheduled backup callback", () => {
  beforeEach(() => vi.clearAllMocks());

  it("returns 403 for non-cron callers", async () => {
    mocks.authenticateRequest.mockResolvedValue({ isCron: false });
    const res = { status: vi.fn().mockReturnThis(), json: vi.fn() };
    await runScheduledBackup({ originalUrl: "/api/scheduled/backup" } as never, res as never);
    expect(res.status).toHaveBeenCalledWith(403);
    expect(res.json).toHaveBeenCalledWith({ error: "cron-only" });
  });

  it("copies media files, uploads a manifest, and marks the schedule after success", async () => {
    mocks.authenticateRequest.mockResolvedValue({ isCron: true, taskUid: "cron-task-2" });
    mocks.getSchedule.mockResolvedValue({ id: 9, enabled: true });
    mocks.snapshot.mockResolvedValue({ generatedAt: "2026-08-19T10:00:00.000Z", tables: { orderMedia: [{ id: 4, kind: "delivery", fileKey: "media/delivery.jpg" }], users: [] } });
    mocks.getSignedUrl.mockResolvedValue("https://signed.example/media.jpg");
    mocks.put.mockImplementation(async (key: string) => ({ key, url: `/manus-storage/${key}` }));
    const originalFetch = globalThis.fetch;
    globalThis.fetch = vi.fn().mockResolvedValue(new Response(new Uint8Array([1, 2, 3]), { status: 200 }));
    const res = { status: vi.fn().mockReturnThis(), json: vi.fn() };
    try { await runScheduledBackup({ originalUrl: "/api/scheduled/backup" } as never, res as never); } finally { globalThis.fetch = originalFetch; }
    expect(mocks.getSignedUrl).toHaveBeenCalledWith("media/delivery.jpg");
    expect(mocks.put).toHaveBeenCalledTimes(2);
    expect(mocks.put).toHaveBeenLastCalledWith(expect.stringContaining("manifest.json"), expect.stringContaining("mediaFilesCopied"), "application/json");
    expect(mocks.mark).toHaveBeenCalledWith(9);
    expect(res.json).toHaveBeenCalledWith(expect.objectContaining({ ok: true }));
  });

  it("skips orphan task UIDs without creating or uploading a snapshot", async () => {
    mocks.authenticateRequest.mockResolvedValue({ isCron: true, taskUid: "cron-task-1" });
    mocks.getSchedule.mockResolvedValue(undefined);
    const res = { status: vi.fn().mockReturnThis(), json: vi.fn() };
    await runScheduledBackup({ originalUrl: "/api/scheduled/backup" } as never, res as never);
    expect(res.json).toHaveBeenCalledWith({ ok: true, skipped: "orphan-or-disabled" });
    expect(mocks.snapshot).not.toHaveBeenCalled();
    expect(mocks.put).not.toHaveBeenCalled();
  });
});
