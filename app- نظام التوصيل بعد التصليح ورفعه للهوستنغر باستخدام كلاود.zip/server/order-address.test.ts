import { describe, expect, it, vi } from "vitest";
import * as db from "./db";
import { updateOrderAddressesWithDb } from "./db";
import { appRouter } from "./routers";

const admin = { id: 1, role: "admin" as const, status: "active" as const, approvalStatus: "approved" as const, name: "Admin" };
const driver = { id: 7, role: "driver" as const, status: "active" as const, approvalStatus: "approved" as const, name: "Driver", civilId: "123456789012", loginMethod: "local-civil-id" as const };
const caller = (user: typeof admin | typeof driver) => appRouter.createCaller({ user, req: {} as never, res: {} as never });

function makeAddressDb() {
  const events: unknown[] = [];
  const audits: unknown[] = [];
  const updates: unknown[] = [];
  const source = { id: 15, pickupAddress: "عنوان الاستلام القديم", deliveryAddress: "عنوان التسليم القديم" };
  const mock = {
    select() { const query = { from() { return query; }, where() { return query; }, limit() { return Promise.resolve([source]); } }; return query; },
    update() { return { set(value: unknown) { updates.push(value); return { where() { return Promise.resolve(); } }; } }; },
    insert(table: unknown) { return { values(value: unknown) { if (table) { events.push(value); } return Promise.resolve(); } }; },
  };
  return { mock, events, audits, updates };
}

describe("supervisor address editing", () => {
  it("preserves an unchanged pickup address and records before/after JSON", async () => {
    const { mock, updates } = makeAddressDb();
    const result = await updateOrderAddressesWithDb(mock as never, 15, { deliveryAddress: "عنوان التسليم الجديد", reason: "تصحيح الموقع" }, 1);
    expect(result.pickupAddress).toBe("عنوان الاستلام القديم");
    expect(updates[0]).toMatchObject({ pickupAddress: "عنوان الاستلام القديم", deliveryAddress: "عنوان التسليم الجديد" });
  });

  it("updates both addresses through the manager procedure with an audit reason", async () => {
    const update = vi.spyOn(db, "updateOrderAddresses").mockResolvedValue({ orderId: 15, pickupAddress: "السالمية", deliveryAddress: "منطقة حولي" });
    try {
      await expect(caller(admin).orders.updateAddresses({ orderId: 15, pickupAddress: "السالمية", deliveryAddress: "منطقة حولي", reason: "تصحيح الموقع" })).resolves.toMatchObject({ orderId: 15, deliveryAddress: "منطقة حولي" });
      expect(update).toHaveBeenCalledWith(15, { orderId: 15, pickupAddress: "السالمية", deliveryAddress: "منطقة حولي", reason: "تصحيح الموقع" }, 1);
    } finally { update.mockRestore(); }
  });

  it("rejects address editing from a driver account", async () => {
    const update = vi.spyOn(db, "updateOrderAddresses");
    try {
      await expect(caller(driver).orders.updateAddresses({ orderId: 15, deliveryAddress: "عنوان حولي واضح" })).rejects.toMatchObject({ code: "FORBIDDEN" });
      expect(update).not.toHaveBeenCalled();
    } finally { update.mockRestore(); }
  });
});
