import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const bell = readFileSync(new URL("../client/src/components/NotificationBell.tsx", import.meta.url), "utf8");
const messages = readFileSync(new URL("../client/src/components/MessagingAlertListener.tsx", import.meta.url), "utf8");
const driverAlerts = readFileSync(new URL("../client/src/components/DriverAlerts.tsx", import.meta.url), "utf8");

describe("foreground notification acknowledgement", () => {
  it("persists seen notification IDs and marks displayed operational alerts as read", () => {
    expect(bell).toContain("city-center-seen-notification-alerts-v1");
    expect(bell).toContain("deliveryItems.forEach");
    expect(bell).toContain("markRead.mutate({ id: item.id })");
  });

  it("persists and acknowledges a new message when its foreground alert is shown", () => {
    expect(messages).toContain("city-center-seen-message-alerts-v1");
    expect(messages).toContain("seen.add(newest.id)");
    expect(messages).toContain("markRead.mutate({ id: newest.id })");
  });

  it("persists a driver order ID at first alert display rather than waiting for delivery completion", () => {
    expect(driverAlerts).toContain("newOrders.forEach((order) => acknowledgedIdsRef.current.add(order.id))");
    expect(driverAlerts).toContain("saveAcknowledgedOrderIds(acknowledgedIdsRef.current)");
  });
});
