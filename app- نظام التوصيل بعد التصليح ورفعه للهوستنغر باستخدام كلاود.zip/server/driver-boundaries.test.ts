import { describe, expect, it, vi } from "vitest";
import * as db from "./db";
import { appRouter } from "./routers";

const driverUser = { id: 22, role: "driver" as const, status: "active" as const, approvalStatus: "approved" as const, name: "Driver" };
const caller = () => appRouter.createCaller({ user: driverUser, req: {} as never, res: {} as never });

describe("driver ownership boundaries", () => {
  it("blocks status updates and media uploads for another driver's order", async () => {
    const ownership = vi.spyOn(db, "driverOwnsOrder").mockResolvedValue(false);
    try {
      await expect(caller().orders.updateStatus({ orderId: 900, status: "picked_up" })).rejects.toMatchObject({ code: "FORBIDDEN" });
      await expect(caller().orders.attachMedia({ orderId: 900, kind: "delivery", fileName: "proof.jpg", mimeType: "image/jpeg", dataBase64: "data:image/jpeg;base64," + "a".repeat(40) })).rejects.toMatchObject({ code: "FORBIDDEN" });
    } finally { ownership.mockRestore(); }
  });

  it("scopes trip listing and status changes to the authenticated driver", async () => {
    const driverLookup = vi.spyOn(db, "getDriverForUser").mockResolvedValue({ id: 22, userId: 22 } as never);
    const trips = vi.spyOn(db, "listDriverTrips").mockResolvedValue([{ id: 301, driverId: 22, status: "open", orders: [] }] as never);
    const status = vi.spyOn(db, "updateTripStatus").mockResolvedValue({ tripId: 301, status: "active" });
    try {
      const scoped = await caller().driver.trips();
      expect(scoped).toHaveLength(1);
      expect(scoped[0].driverId).toBe(22);
      await expect(caller().driver.setTripStatus({ tripId: 999, status: "active" })).rejects.toMatchObject({ code: "FORBIDDEN" });
      await caller().driver.setTripStatus({ tripId: 301, status: "active" });
      expect(status).toHaveBeenCalledWith(301, "active", 22);
    } finally { driverLookup.mockRestore(); trips.mockRestore(); status.mockRestore(); }
  });

  it("requires a driver profile before accepting live location updates", async () => {
    const driverLookup = vi.spyOn(db, "getDriverForUser").mockResolvedValue(undefined);
    try {
      await expect(caller().driver.updateLocation({ latitude: "29.3759", longitude: "47.9774" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    } finally { driverLookup.mockRestore(); }
  });

  it("blocks starting another driver's shift and ending another driver's shift", async () => {
    const driverLookup = vi.spyOn(db, "getDriverForUser").mockResolvedValue({ id: 22, userId: 22 } as never);
    const shiftOwnership = vi.spyOn(db, "driverOwnsShift").mockResolvedValue(false);
    try {
      await expect(caller().shifts.start({ driverId: 99 })).rejects.toMatchObject({ code: "FORBIDDEN" });
      await expect(caller().shifts.end({ shiftId: 901 })).rejects.toMatchObject({ code: "FORBIDDEN" });
    } finally { driverLookup.mockRestore(); shiftOwnership.mockRestore(); }
  });
});
