import { describe, expect, it } from "vitest";
import { canUseProtectedAccount } from "./_core/trpc";

describe("protected account access", () => {
  it("blocks pending and inactive accounts globally", () => {
    expect(canUseProtectedAccount(null)).toBe(false);
    expect(canUseProtectedAccount({ status: "inactive", approvalStatus: "approved" })).toBe(false);
    expect(canUseProtectedAccount({ status: "active", approvalStatus: "pending" })).toBe(false);
    expect(canUseProtectedAccount({ status: "active", approvalStatus: "rejected" })).toBe(false);
  });

  it("allows an active approved account to reach protected procedures", () => {
    expect(canUseProtectedAccount({ status: "active", approvalStatus: "approved" })).toBe(true);
  });
});
