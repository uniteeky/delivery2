import { describe, expect, it } from "vitest";
import { attachOrderMediaWithDb, getOrderDetailsWithDb } from "./db";

function fakeDb() {
  const media: any[] = [];
  const order = { id: 12, orderNumber: "CC-12", status: "delivered", pickupAddress: "عنوان الاستلام الاختبار", deliveryAddress: "عنوان التسليم الاختبار" };
  return {
    select() { const query = { from() { return query; }, where() { return query; }, limit() { return Promise.resolve([order]); }, orderBy() { return Promise.resolve(media); }, then(resolve: (value: unknown) => unknown, reject?: (reason: unknown) => unknown) { return Promise.resolve(media).then(resolve, reject); } }; return query; },
    insert() { return { values(value: any) { if (value.orderId) media.push({ id: media.length + 1, ...value, createdAt: new Date() }); return Promise.resolve(); } }; },
  };
}

describe("order details media persistence", () => {
  it("returns media attached through the upload data path after reload", async () => {
    const db = fakeDb();
    await attachOrderMediaWithDb(db as never, { orderId: 12, kind: "delivery", fileKey: "orders/12/delivery.jpg", fileUrl: "/media/delivery.jpg" }, 22);
    const result = await getOrderDetailsWithDb(db as never, 12);
    expect(result?.orderNumber).toBe("CC-12");
    expect(result?.pickupAddress).toBe("عنوان الاستلام الاختبار");
    expect(result?.deliveryAddress).toBe("عنوان التسليم الاختبار");
    expect(result?.media).toEqual([expect.objectContaining({ kind: "delivery", fileUrl: "/media/delivery.jpg" })]);
  });
});
