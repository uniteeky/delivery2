import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const router = readFileSync(new URL("./routers.ts", import.meta.url), "utf8");
const database = readFileSync(new URL("./db.ts", import.meta.url), "utf8");
const usersPage = readFileSync(
  new URL("../client/src/pages/Users.tsx", import.meta.url),
  "utf8"
);

describe("account-role registration contract", () => {
  it("normalizes civil IDs and validates all public account roles", () => {
    expect(router).toContain("civilId: civilIdSchema.optional()");
    expect(router).toContain('"driver", "supervisor", "accountant", "company", "trader"');
    expect(router).toContain('"admin", "supervisor", "accountant", "driver", "company", "trader"');
  });

  it("does not silently downgrade a trader to a company on an outdated MySQL enum", () => {
    expect(database).toContain("بنية المستخدمين في MySQL قديمة");
    expect(database).not.toContain("...userValues,\n      role: \"company\",");
  });

  it("keeps trader available in the administrator role controls", () => {
    expect(usersPage).toContain('"company" | "trader"');
    expect(usersPage).toContain('"trader",\n                                ] as const');
  });
});
