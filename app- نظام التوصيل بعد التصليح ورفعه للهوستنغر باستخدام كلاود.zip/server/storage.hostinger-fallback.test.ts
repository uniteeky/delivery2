import { afterEach, describe, expect, it } from "vitest";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { ENV } from "./_core/env";
import { storagePut } from "./storage";

describe("Hostinger local media fallback", () => {
  const original = { forgeApiUrl: ENV.forgeApiUrl, forgeApiKey: ENV.forgeApiKey, localMediaDir: process.env.LOCAL_MEDIA_DIR };
  let temporaryDirectory = "";

  afterEach(async () => {
    ENV.forgeApiUrl = original.forgeApiUrl;
    ENV.forgeApiKey = original.forgeApiKey;
    if (original.localMediaDir === undefined) delete process.env.LOCAL_MEDIA_DIR;
    else process.env.LOCAL_MEDIA_DIR = original.localMediaDir;
    if (temporaryDirectory) await rm(temporaryDirectory, { recursive: true, force: true });
  });

  it("writes order media locally and returns a served URL when Forge credentials are unavailable", async () => {
    temporaryDirectory = await mkdtemp(path.join(os.tmpdir(), "ccd-media-"));
    process.env.LOCAL_MEDIA_DIR = temporaryDirectory;
    ENV.forgeApiUrl = "";
    ENV.forgeApiKey = "";

    const stored = await storagePut("orders/23/proof.jpg", Buffer.from("proof-image"), "image/jpeg");

    expect(stored.url).toMatch(/^\/media\/orders\/23\/proof_[a-f0-9]{8}\.jpg$/);
    expect(await readFile(path.join(temporaryDirectory, stored.key), "utf8")).toBe("proof-image");
  });
});
