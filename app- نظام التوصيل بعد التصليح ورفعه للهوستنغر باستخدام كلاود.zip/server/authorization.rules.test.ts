import { describe, expect, it } from "vitest";
import { hasEffectiveRole, hasGrantedPermission, isDriverOnly, requireCapability, requireRole } from "./routers";

const active = (role: string) => ({ role, status: "active", approvalStatus: "approved" });

describe("router authorization boundaries", () => {
  it("allows only managers to use manager-only procedures", () => {
    expect(() => requireRole(active("admin"), ["admin"])).not.toThrow();
    expect(() => requireRole(active("supervisor"), ["admin"])).toThrowError();
    expect(() => requireRole(active("accountant"), ["admin"])).toThrowError();
    expect(() => requireRole(active("driver"), ["admin"])).toThrowError();
    expect(() => requireRole(active("company"), ["admin"])).toThrowError();
  });

  it("keeps role-specific procedures isolated", () => {
    expect(() => requireRole(active("company"), ["company"])).not.toThrow();
    expect(() => requireRole(active("company"), ["accountant"])).toThrowError();
    expect(() => requireRole(active("accountant"), ["accountant"])).not.toThrow();
    expect(() => requireRole(active("accountant"), ["driver"])).toThrowError();
    expect(() => requireRole(active("driver"), ["driver"])).not.toThrow();
    expect(() => requireRole(active("driver"), ["supervisor"])).toThrowError();
  });

  it("requires an explicit permission key for supervisor and accountant operations", () => {
    expect(hasGrantedPermission([{ permissionKey: "orders_manage", granted: false }], "orders_manage")).toBe(false);
    expect(hasGrantedPermission([{ permissionKey: "finance_view", granted: true }], "finance_edit")).toBe(false);
    expect(hasGrantedPermission([{ permissionKey: "orders_manage", granted: true }], "orders_manage")).toBe(true);
  });

  it("recognizes combined roles for real router boundary decisions", () => {
    const supervisorAccountant = { role: "accountant", roles: ["accountant", "supervisor"], status: "active", approvalStatus: "approved" };
    const supervisorDriver = { role: "driver", roles: ["driver", "supervisor"], status: "active", approvalStatus: "approved" };
    expect(hasEffectiveRole(supervisorAccountant, "supervisor")).toBe(true);
    expect(() => requireRole(supervisorAccountant, ["supervisor"])).not.toThrow();
    expect(isDriverOnly(supervisorDriver)).toBe(false);
    expect(() => requireRole(supervisorDriver, ["supervisor"])).not.toThrow();
    expect(isDriverOnly({ role: "driver", roles: ["driver"], status: "active", approvalStatus: "approved" })).toBe(true);
  });

  it("blocks inactive and pending users even when their role matches", () => {
    expect(() => requireRole({ role: "admin", status: "inactive", approvalStatus: "approved" }, ["admin"])).toThrowError();
    expect(() => requireRole({ role: "driver", status: "active", approvalStatus: "pending" }, ["driver"])).toThrowError();
  });
});
