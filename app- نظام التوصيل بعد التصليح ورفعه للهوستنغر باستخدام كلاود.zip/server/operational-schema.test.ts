import { describe, expect, it, vi } from "vitest";
import { ensureOperationalSchema } from "./operational-schema";

describe("ensureOperationalSchema", () => {
  it("creates location/rate tables, checks added fields and backfills legacy fee-only orders", async () => {
    const execute = vi.fn(async (_statement: string) => undefined);
    await ensureOperationalSchema({ execute });
    const statements = execute.mock.calls.map(([statement]) => statement);
    expect(statements.some((statement) => statement.includes("CREATE TABLE IF NOT EXISTS `governorates`"))).toBe(true);
    expect(statements.some((statement) => statement.includes("CREATE TABLE IF NOT EXISTS `deliveryAreas`"))).toBe(true);
    expect(statements.some((statement) => statement.includes("CREATE TABLE IF NOT EXISTS `companyAreaRates`"))).toBe(true);
    expect(statements.some((statement) => statement.includes("CREATE TABLE IF NOT EXISTS `companyGovernorateRates`"))).toBe(true);
    expect(statements.some((statement) => statement.includes("CREATE TABLE IF NOT EXISTS `driverCommissionRates`"))).toBe(true);
    expect(statements.some((statement) => statement.includes("SELECT `driverPayType` FROM `drivers` LIMIT 0"))).toBe(true);
    expect(statements.some((statement) => statement.includes("SELECT `driverCommission` FROM `orders` LIMIT 0"))).toBe(true);
    expect(statements.some((statement) => statement.includes("SELECT `deliveryFeeManual` FROM `orders` LIMIT 0"))).toBe(true);
    expect(statements.some((statement) => statement.includes("SELECT `deliveryFeeChargeOnFailure` FROM `orders` LIMIT 0"))).toBe(true);
    expect(statements.some((statement) => statement.includes("SELECT `pickupContactName` FROM `companyAddresses` LIMIT 0"))).toBe(true);
    expect(statements.some((statement) => statement.includes("SELECT `cashCollectedShiftId` FROM `orders` LIMIT 0"))).toBe(true);
    expect(statements.at(-1)).toContain("UPDATE `orders` SET `companyShare` = `deliveryFee`");
  });
  it("adds explicit failed-order fee columns when upgrading an existing Hostinger schema", async () => {
    const execute = vi.fn(async (statement: string) => {
      if (statement.includes("SELECT `deliveryFeeManual` FROM `orders`") || statement.includes("SELECT `deliveryFeeChargeOnFailure` FROM `orders`")) {
        throw Object.assign(new Error("Unknown column"), { code: "ER_BAD_FIELD_ERROR" });
      }
      return undefined;
    });
    await ensureOperationalSchema({ execute });
    expect(execute.mock.calls.some(([statement]) => statement.includes("ALTER TABLE `orders` ADD COLUMN `deliveryFeeManual`"))).toBe(true);
    expect(execute.mock.calls.some(([statement]) => statement.includes("ALTER TABLE `orders` ADD COLUMN `deliveryFeeChargeOnFailure`"))).toBe(true);
  });
  it("is idempotent for an initialized database object", async () => {
    const execute = vi.fn(async (_statement: string) => undefined);
    const db = { execute };
    await ensureOperationalSchema(db);
    const count = execute.mock.calls.length;
    await ensureOperationalSchema(db);
    expect(execute).toHaveBeenCalledTimes(count);
  });
  it("shares a single in-flight initialization among concurrent requests", async () => {
    let release!: () => void;
    const gate = new Promise<void>((resolve) => { release = resolve; });
    const execute = vi.fn(async (_statement: string) => { await gate; return undefined; });
    const db = { execute };
    const first = ensureOperationalSchema(db);
    const second = ensureOperationalSchema(db);
    await Promise.resolve();
    expect(execute).toHaveBeenCalledTimes(1);
    release();
    await Promise.all([first, second]);
    expect(execute.mock.calls.at(-1)?.[0]).toContain("UPDATE `orders`");
  });
});
