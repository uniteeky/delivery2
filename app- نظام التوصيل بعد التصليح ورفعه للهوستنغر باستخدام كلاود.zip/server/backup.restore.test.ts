import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import { decryptBackupData, encryptBackupData } from "./db";

const callerFor = (role: "admin" | "supervisor") => appRouter.createCaller({ user: { id: 1, role, status: "active", approvalStatus: "approved", name: role }, req: {} as never, res: {} as never });

describe("backup restore safety", () => {
  it("round-trips encrypted restore secrets without exposing plaintext", () => {
    const plain = JSON.stringify({ passwordHash: "sensitive-hash", role: "admin" });
    const encrypted = encryptBackupData(plain);
    expect(encrypted).not.toContain("sensitive-hash");
    expect(decryptBackupData(encrypted)).toBe(plain);
  });

  it("rejects supervisor access to upload and restore routes", async () => {
    const caller = callerFor("supervisor");
    await expect(caller.backups.upload({ fileName: "backup.json", dataBase64: Buffer.from("x".repeat(120)).toString("base64") })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.backups.restore({ dataBase64: Buffer.from("x".repeat(120)).toString("base64"), confirmation: "RESTORE_CITY_CENTER" })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("requires the exact restore confirmation token", async () => {
    const caller = callerFor("admin");
    await expect(caller.backups.restore({ dataBase64: Buffer.from("x".repeat(120)).toString("base64"), confirmation: "WRONG" as "RESTORE_CITY_CENTER" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });
});
