import { describe, expect, it, vi } from "vitest";
import * as db from "./db";
import * as storage from "./storage";
import { appRouter } from "./routers";

const admin = { id: 1, role: "admin" as const, status: "active" as const, approvalStatus: "approved" as const, name: "Admin" };

describe("order media router flow", () => {
  it("returns an upload failure that the UI can retry", async () => {
    const put = vi.spyOn(storage, "storagePut").mockRejectedValue(new Error("storage unavailable"));
    try {
      const caller = appRouter.createCaller({ user: admin, req: {} as never, res: {} as never });
      await expect(caller.orders.attachMedia({ orderId: 12, kind: "invoice", fileName: "invoice.jpg", mimeType: "image/jpeg", dataBase64: "a".repeat(40) })).rejects.toThrow("storage unavailable");
    } finally { put.mockRestore(); }
  });

  it("uploads through orders.attachMedia and reloads through orders.get", async () => {
    const put = vi.spyOn(storage, "storagePut").mockResolvedValue({ key: "orders/12/delivery.jpg", url: "/media/delivery.jpg" });
    const attach = vi.spyOn(db, "attachOrderMedia").mockResolvedValue(undefined);
    const getDetails = vi.spyOn(db, "getOrderDetails").mockResolvedValue({ id: 12, orderNumber: "CC-12", status: "delivered", deliveryAddress: "عنوان", media: [{ id: 2, kind: "delivery", fileUrl: "/media/delivery.jpg", uploadedByUserId: 1, createdAt: new Date() }] } as never);
    try {
      const caller = appRouter.createCaller({ user: admin, req: {} as never, res: {} as never });
      await caller.orders.attachMedia({ orderId: 12, kind: "delivery", fileName: "delivery.jpg", mimeType: "image/jpeg", dataBase64: "a".repeat(40) });
      const result = await caller.orders.get({ orderId: 12 });
      expect(attach).toHaveBeenCalledWith({ orderId: 12, kind: "delivery", fileKey: "orders/12/delivery.jpg", fileUrl: "/media/delivery.jpg" }, 1);
      expect(result.media[0]).toMatchObject({ kind: "delivery", fileUrl: "/media/delivery.jpg" });
    } finally { put.mockRestore(); attach.mockRestore(); getDetails.mockRestore(); }
  });
});
