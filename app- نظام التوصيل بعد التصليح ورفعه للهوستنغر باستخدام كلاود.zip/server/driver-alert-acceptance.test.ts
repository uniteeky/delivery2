import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

describe("Driver assigned-order acceptance and open-shift visibility", () => {
  it("plays the confirmed order-alert asset and provides an acknowledgement path that stops audio and vibration", () => {
    const audio = readFileSync(new URL("../client/src/lib/driverAudio.ts", import.meta.url), "utf8");
    const alerts = readFileSync(new URL("../client/src/components/DriverAlerts.tsx", import.meta.url), "utf8");
    expect(audio).toContain("city-center-driver-order-alert_201c275b.m4a");
    expect(alerts).toContain("استقبل الطلب");
    expect(alerts).toContain("navigator.vibrate(0)");
    expect(alerts).toContain("stopRepeatingDriverAlert();");
    expect(alerts).toContain("city-center-acknowledged-order-alerts-v2");
    expect(alerts).toContain("window.localStorage.setItem");
    expect(alerts).toContain("newOrders.forEach((order) => acknowledgedIdsRef.current.add(order.id))");
  });

  it("exposes open-shift drivers only to operations roles and renders their list in orders and operations views", () => {
    const router = readFileSync(new URL("../server/routers.ts", import.meta.url), "utf8");
    const layout = readFileSync(new URL("../client/src/components/DashboardLayout.tsx", import.meta.url), "utf8");
    expect(router).toContain("openShifts: protectedProcedure");
    expect(router).toContain("requireRole(ctx.user, operationsRoles)");
    expect(layout).toContain('location === "/orders/new" || location === "/operations-room"');
  });
});
