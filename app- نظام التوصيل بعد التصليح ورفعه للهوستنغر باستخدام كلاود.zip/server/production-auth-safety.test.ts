import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const authSources = [
  readFileSync(new URL("../client/src/App.tsx", import.meta.url), "utf8"),
  readFileSync(new URL("../server/routers.ts", import.meta.url), "utf8"),
  readFileSync(new URL("../server/_core/context.ts", import.meta.url), "utf8"),
].join("\n");

describe("production authentication safety", () => {
  it("does not ship an authentication bypass or embedded test credentials", () => {
    expect(authSources).not.toMatch(/TEST_BYPASS|AUTH_BYPASS|skipAuth|test[-_ ]account/i);
    expect(authSources).not.toMatch(/123456789000|qW1234567890@@/);
  });
});
