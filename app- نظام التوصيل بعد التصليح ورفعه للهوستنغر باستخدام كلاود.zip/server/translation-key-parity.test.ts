import { describe, expect, it } from "vitest";
import { supportedLanguages, translations } from "../client/src/i18n";

describe("translation key parity", () => {
  it("keeps all supported languages aligned with the Arabic key set", () => {
    const baseKeys = Object.keys(translations.ar).sort();
    for (const language of Object.keys(supportedLanguages) as Array<keyof typeof translations>) {
      expect(Object.keys(translations[language]).sort(), language).toEqual(baseKeys);
    }
  });
});
