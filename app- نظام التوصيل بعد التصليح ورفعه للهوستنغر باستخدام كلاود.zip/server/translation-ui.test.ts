import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

const root = resolve(import.meta.dirname, "..");
const read = (path: string) => readFileSync(resolve(root, path), "utf8");

describe("واجهة الترجمة", () => {
  it("تضم قاموساً كاملاً للنصوص الجديدة في المحاسبة والمراسلات والطلبات", () => {
    const text = read("client/src/lib/uiText.ts");
    for (const key of ["النظام المالي والمحاسبي", "تواصل الفريق", "دفتر الطلبات والفواتير وإثباتات التوصيل", "عنوان أو فرع الشركة", "بدء العمل"]) {
      expect(text).toContain(`"${key}":`);
    }
    expect(text).toContain('en: "Financial & accounting system"');
    expect(text).toContain('bn: "টিম যোগাযোগ"');
    expect(text).toContain('hi: "कंपनी का पता या शाखा"');
  });

  it("تستدعي الصفحات ذات النصوص الجديدة مترجم الواجهة بدلاً من النص العربي الثابت", () => {
    const finance = read("client/src/pages/Finance.tsx");
    const messaging = read("client/src/pages/Messaging.tsx");
    const newOrder = read("client/src/pages/NewOrder.tsx");
    const driver = read("client/src/pages/DriverHome.tsx");
    for (const source of [finance, messaging, newOrder, driver]) expect(source).toContain("useUiText");
    expect(finance).toContain('tr("دفتر الطلبات والفواتير وإثباتات التوصيل")');
    expect(messaging).toContain('tr("تواصل الفريق")');
    expect(newOrder).toContain('tr("عنوان أو فرع الشركة")');
    expect(driver).toContain('tr("قائمة السائق")');
  });
});
