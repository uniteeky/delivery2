CREATE TABLE `companyAreaRates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`companyId` int NOT NULL,
	`areaId` int NOT NULL,
	`amount` decimal(10,3) NOT NULL DEFAULT '0.000',
	`createdByUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `companyAreaRates_id` PRIMARY KEY(`id`),
	CONSTRAINT `company_area_rates_company_area_unique` UNIQUE(`companyId`,`areaId`)
);
--> statement-breakpoint
CREATE TABLE `deliveryAreas` (
	`id` int AUTO_INCREMENT NOT NULL,
	`governorateId` int NOT NULL,
	`nameAr` varchar(180) NOT NULL,
	`nameEn` varchar(180) NOT NULL,
	`active` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `deliveryAreas_id` PRIMARY KEY(`id`),
	CONSTRAINT `delivery_areas_governorate_name_unique` UNIQUE(`governorateId`,`nameAr`)
);
--> statement-breakpoint
CREATE TABLE `driverCommissionRates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`driverId` int NOT NULL,
	`companyId` int,
	`areaId` int,
	`amount` decimal(10,3) NOT NULL DEFAULT '0.000',
	`createdByUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `driverCommissionRates_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `governorates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`nameAr` varchar(180) NOT NULL,
	`nameEn` varchar(180) NOT NULL,
	`active` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `governorates_id` PRIMARY KEY(`id`),
	CONSTRAINT `governorates_name_ar_unique` UNIQUE(`nameAr`)
);
--> statement-breakpoint
ALTER TABLE `companyAddresses` ADD `governorateId` int;--> statement-breakpoint
ALTER TABLE `companyAddresses` ADD `areaId` int;--> statement-breakpoint
ALTER TABLE `drivers` ADD `driverPayType` enum('salary','salary_commission','contractor') DEFAULT 'salary' NOT NULL;--> statement-breakpoint
ALTER TABLE `drivers` ADD `baseSalary` decimal(10,3) DEFAULT '0.000' NOT NULL;--> statement-breakpoint
ALTER TABLE `drivers` ADD `defaultCommission` decimal(10,3) DEFAULT '0.000' NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `pickupGovernorateId` int;--> statement-breakpoint
ALTER TABLE `orders` ADD `pickupAreaId` int;--> statement-breakpoint
ALTER TABLE `orders` ADD `deliveryGovernorateId` int;--> statement-breakpoint
ALTER TABLE `orders` ADD `deliveryAreaId` int;--> statement-breakpoint
ALTER TABLE `orders` ADD `deliveryFeeManual` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `deliveryFeeChargeOnFailure` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `driverCommission` decimal(10,3) DEFAULT '0.000' NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `companyShare` decimal(10,3) DEFAULT '0.000' NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `driverCommissionManual` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `companyShareManual` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `compensationInitialized` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `returnedToCompany` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `platformSettings` ADD `hideDriverDeliveryFee` boolean DEFAULT true NOT NULL;--> statement-breakpoint
UPDATE `orders` SET `companyShare` = `deliveryFee`, `driverCommission` = 0.000, `compensationInitialized` = true WHERE `compensationInitialized` = false AND `returnedToCompany` = false;--> statement-breakpoint
ALTER TABLE `orders` MODIFY `compensationInitialized` boolean NOT NULL DEFAULT true;--> statement-breakpoint
CREATE INDEX `company_area_rates_area_idx` ON `companyAreaRates` (`areaId`);--> statement-breakpoint
CREATE INDEX `delivery_areas_governorate_active_idx` ON `deliveryAreas` (`governorateId`,`active`);--> statement-breakpoint
CREATE INDEX `driver_commission_rates_driver_idx` ON `driverCommissionRates` (`driverId`);--> statement-breakpoint
CREATE INDEX `driver_commission_rates_company_area_idx` ON `driverCommissionRates` (`companyId`,`areaId`);--> statement-breakpoint
CREATE INDEX `governorates_active_idx` ON `governorates` (`active`);
