CREATE TABLE `companyGovernorateRates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`companyId` int NOT NULL,
	`governorateId` int NOT NULL,
	`amount` decimal(10,3) NOT NULL DEFAULT '0.000',
	`createdByUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `companyGovernorateRates_id` PRIMARY KEY(`id`),
	CONSTRAINT `company_governorate_rates_company_governorate_unique` UNIQUE(`companyId`,`governorateId`)
);
--> statement-breakpoint
CREATE INDEX `company_governorate_rates_governorate_idx` ON `companyGovernorateRates` (`governorateId`);