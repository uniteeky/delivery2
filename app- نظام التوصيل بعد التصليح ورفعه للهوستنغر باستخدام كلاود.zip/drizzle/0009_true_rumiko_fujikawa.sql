CREATE TABLE `financialEntries` (
	`id` bigint AUTO_INCREMENT NOT NULL,
	`financialEntryType` enum('income','expense') NOT NULL,
	`financialCategory` enum('company_payment','delivery_revenue','salary','maintenance','purchase','sale','other') NOT NULL DEFAULT 'other',
	`companyId` int,
	`orderId` int,
	`amount` decimal(12,3) NOT NULL,
	`description` varchar(500) NOT NULL,
	`reference` varchar(160),
	`transactionDate` timestamp NOT NULL,
	`createdByUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `financialEntries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `registrationRole` enum('driver','supervisor','accountant');--> statement-breakpoint
CREATE INDEX `financial_entries_date_idx` ON `financialEntries` (`transactionDate`);--> statement-breakpoint
CREATE INDEX `financial_entries_company_date_idx` ON `financialEntries` (`companyId`,`transactionDate`);--> statement-breakpoint
CREATE INDEX `financial_entries_category_idx` ON `financialEntries` (`financialCategory`);