import {
  bigint,
  boolean,
  decimal,
  index,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

export const userRoleEnum = mysqlEnum("role", [
  "admin",
  "supervisor",
  "accountant",
  "driver",
  "company",
  "trader",
]);
export const accountStatusEnum = mysqlEnum("accountStatus", [
  "active",
  "inactive",
]);
export const approvalStatusEnum = mysqlEnum("approvalStatus", [
  "pending",
  "approved",
  "rejected",
]);
export const orderSourceEnum = mysqlEnum("orderSource", [
  "supervisor",
  "company",
  "external",
]);
export const orderStatusEnum = mysqlEnum("orderStatus", [
  "pending",
  "assigned",
  "picked_up",
  "in_transit",
  "delivered",
  "failed",
]);
export const eventTypeEnum = mysqlEnum("eventType", [
  "created",
  "assigned",
  "picked_up",
  "in_transit",
  "delivered",
  "failed",
  "transferred",
  "address_updated",
  "fee_updated",
]);
export const failureReasonEnum = mysqlEnum("failureReason", [
  "no_answer",
  "not_present",
  "wrong_address",
  "postponed",
  "refused",
  "address_changed",
  "other",
]);
export const messageThreadTypeEnum = mysqlEnum("messageThreadType", [
  "direct",
  "group",
  "order",
  "company",
]);
export const messageAttachmentTypeEnum = mysqlEnum("messageAttachmentType", [
  "image",
  "audio",
]);
export const registrationRoleEnum = mysqlEnum("registrationRole", [
  "driver",
  "supervisor",
  "accountant",
  "company",
  "trader",
]);
export const financialEntryTypeEnum = mysqlEnum("financialEntryType", [
  "income",
  "expense",
]);
export const financialCategoryEnum = mysqlEnum("financialCategory", [
  "company_payment",
  "delivery_revenue",
  "salary",
  "rent",
  "installment",
  "utilities",
  "insurance",
  "fuel",
  "marketing",
  "maintenance",
  "purchase",
  "sale",
  "other",
]);
export const vehicleTypeEnum = mysqlEnum("vehicleType", [
  "car",
  "refrigerated_car",
  "motorcycle",
  "semi_truck",
  "refrigerated_semi_truck",
  "truck",
  "refrigerated_truck",
]);

export const users = mysqlTable(
  "users",
  {
    id: int("id").autoincrement().primaryKey(),
    openId: varchar("openId", { length: 64 }).unique(),
    civilId: varchar("civilId", { length: 32 }).unique(),
    passwordHash: text("passwordHash"),
    approvalStatus: approvalStatusEnum.notNull().default("approved"),
    requestedRole: registrationRoleEnum,
    name: varchar("name", { length: 160 }),
    email: varchar("email", { length: 320 }),
    phone: varchar("phone", { length: 40 }),
    loginMethod: varchar("loginMethod", { length: 64 }),
    role: userRoleEnum.notNull().default("driver"),
    status: accountStatusEnum.notNull().default("active"),
    mustChangePassword: boolean("mustChangePassword").notNull().default(false),
    preferredLanguage: varchar("preferredLanguage", { length: 12 })
      .notNull()
      .default("ar"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
    lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
  },
  table => ({
    roleStatusIdx: index("users_role_status_idx").on(table.role, table.status),
  })
);

export const platformSettings = mysqlTable("platformSettings", {
  id: int("id").primaryKey().default(1),
  brandName: varchar("brandName", { length: 180 })
    .notNull()
    .default("City Center"),
  logoUrl: text("logoUrl"),
  primaryColor: varchar("primaryColor", { length: 16 })
    .notNull()
    .default("#f97316"),
  accentColor: varchar("accentColor", { length: 16 })
    .notNull()
    .default("#0f172a"),
  subscriptionStartsAt: timestamp("subscriptionStartsAt"),
  subscriptionEndsAt: timestamp("subscriptionEndsAt"),
  allowDriverTransfer: boolean("allowDriverTransfer").notNull().default(true),
  allowSupervisorTransfer: boolean("allowSupervisorTransfer")
    .notNull()
    .default(true),
  allowManagerTransfer: boolean("allowManagerTransfer").notNull().default(true),
  hideDriverDeliveryFee: boolean("hideDriverDeliveryFee")
    .notNull()
    .default(true),
  orderNumberFormat: mysqlEnum("orderNumberFormat", ["numeric", "alphabetic"])
    .notNull()
    .default("numeric"),
  nextOrderNumber: int("nextOrderNumber").notNull().default(1),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const userRoles = mysqlTable(
  "userRoles",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    role: userRoleEnum.notNull(),
    grantedByUserId: int("grantedByUserId").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    userRoleIdx: uniqueIndex("user_roles_user_role_unique").on(
      table.userId,
      table.role
    ),
    userIdx: index("user_roles_user_idx").on(table.userId),
  })
);

export const userPermissions = mysqlTable(
  "userPermissions",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    permissionKey: varchar("permissionKey", { length: 80 }).notNull(),
    granted: boolean("granted").notNull().default(true),
    grantedByUserId: int("grantedByUserId").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    userPermissionIdx: uniqueIndex("user_permission_unique").on(
      table.userId,
      table.permissionKey
    ),
    userIdx: index("user_permissions_user_idx").on(table.userId),
  })
);

export const companies = mysqlTable(
  "companies",
  {
    id: int("id").autoincrement().primaryKey(),
    name: varchar("name", { length: 180 }).notNull(),
    code: varchar("code", { length: 40 }).notNull(),
    phone: varchar("phone", { length: 40 }),
    whatsapp: varchar("whatsapp", { length: 40 }),
    address: text("address"),
    defaultDeliveryFee: decimal("defaultDeliveryFee", {
      precision: 10,
      scale: 3,
    })
      .notNull()
      .default("0.000"),
    status: mysqlEnum("accountStatus", ["active", "inactive"])
      .notNull()
      .default("active"),
    portalEnabled: boolean("portalEnabled").notNull().default(false),
    notes: text("notes"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    codeIdx: uniqueIndex("companies_code_idx").on(table.code),
    statusIdx: index("companies_status_idx").on(table.status),
  })
);

export const governorates = mysqlTable(
  "governorates",
  {
    id: int("id").autoincrement().primaryKey(),
    nameAr: varchar("nameAr", { length: 180 }).notNull(),
    nameEn: varchar("nameEn", { length: 180 }).notNull(),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    nameArIdx: uniqueIndex("governorates_name_ar_unique").on(table.nameAr),
    activeIdx: index("governorates_active_idx").on(table.active),
  })
);

export const deliveryAreas = mysqlTable(
  "deliveryAreas",
  {
    id: int("id").autoincrement().primaryKey(),
    governorateId: int("governorateId").notNull(),
    nameAr: varchar("nameAr", { length: 180 }).notNull(),
    nameEn: varchar("nameEn", { length: 180 }).notNull(),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    governorateNameIdx: uniqueIndex(
      "delivery_areas_governorate_name_unique"
    ).on(table.governorateId, table.nameAr),
    governorateActiveIdx: index("delivery_areas_governorate_active_idx").on(
      table.governorateId,
      table.active
    ),
  })
);

export const companyAreaRates = mysqlTable(
  "companyAreaRates",
  {
    id: int("id").autoincrement().primaryKey(),
    companyId: int("companyId").notNull(),
    areaId: int("areaId").notNull(),
    amount: decimal("amount", { precision: 10, scale: 3 })
      .notNull()
      .default("0.000"),
    createdByUserId: int("createdByUserId").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    companyAreaIdx: uniqueIndex("company_area_rates_company_area_unique").on(
      table.companyId,
      table.areaId
    ),
    areaIdx: index("company_area_rates_area_idx").on(table.areaId),
  })
);

export const companyGovernorateRates = mysqlTable(
  "companyGovernorateRates",
  {
    id: int("id").autoincrement().primaryKey(),
    companyId: int("companyId").notNull(),
    governorateId: int("governorateId").notNull(),
    amount: decimal("amount", { precision: 10, scale: 3 })
      .notNull()
      .default("0.000"),
    createdByUserId: int("createdByUserId").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    companyGovernorateIdx: uniqueIndex(
      "company_governorate_rates_company_governorate_unique"
    ).on(table.companyId, table.governorateId),
    governorateIdx: index("company_governorate_rates_governorate_idx").on(
      table.governorateId
    ),
  })
);

// companyAddresses = mysqlTable("companyAddresses"
export const companyAddresses = mysqlTable(
  "companyAddresses",
  {
    id: int("id").autoincrement().primaryKey(),
    companyId: int("companyId").notNull(),
    label: varchar("label", { length: 180 }).notNull(),
    address: text("address").notNull(),
    phone: varchar("phone", { length: 40 }),
    pickupContactName: varchar("pickupContactName", { length: 180 }),
    locationUrl: varchar("locationUrl", { length: 1000 }),
    governorateId: int("governorateId"),
    areaId: int("areaId"),
    isDefault: boolean("isDefault").notNull().default(false),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    companyDefaultIdx: index("company_addresses_company_default_idx").on(
      table.companyId,
      table.isDefault,
      table.active
    ),
  })
);

export const companyUsers = mysqlTable(
  "companyUsers",
  {
    id: int("id").autoincrement().primaryKey(),
    companyId: int("companyId").notNull(),
    userId: int("userId").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({
    companyUserIdx: uniqueIndex("company_users_company_user_idx").on(
      table.companyId,
      table.userId
    ),
  })
);

export const companyDriverAssignments = mysqlTable(
  "companyDriverAssignments",
  {
    id: int("id").autoincrement().primaryKey(),
    companyId: int("companyId").notNull(),
    driverId: int("driverId").notNull(),
    createdByUserId: int("createdByUserId").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({
    uniqueAssignment: uniqueIndex("company_driver_assignment_unique").on(
      table.companyId,
      table.driverId
    ),
  })
);

export const drivers = mysqlTable("drivers", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  vehicleLabel: varchar("vehicleLabel", { length: 120 }),
  licenseNumber: varchar("licenseNumber", { length: 80 }),
  vehicleType: vehicleTypeEnum.notNull().default("car"),
  payType: mysqlEnum("driverPayType", [
    "salary",
    "salary_commission",
    "contractor",
  ])
    .notNull()
    .default("salary"),
  baseSalary: decimal("baseSalary", { precision: 10, scale: 3 })
    .notNull()
    .default("0.000"),
  defaultCommission: decimal("defaultCommission", { precision: 10, scale: 3 })
    .notNull()
    .default("0.000"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const driverCommissionRates = mysqlTable(
  "driverCommissionRates",
  {
    id: int("id").autoincrement().primaryKey(),
    driverId: int("driverId").notNull(),
    companyId: int("companyId"),
    areaId: int("areaId"),
    amount: decimal("amount", { precision: 10, scale: 3 })
      .notNull()
      .default("0.000"),
    createdByUserId: int("createdByUserId").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    driverIdx: index("driver_commission_rates_driver_idx").on(table.driverId),
    companyAreaIdx: index("driver_commission_rates_company_area_idx").on(
      table.companyId,
      table.areaId
    ),
  })
);

export const trips = mysqlTable(
  "trips",
  {
    id: int("id").autoincrement().primaryKey(),
    driverId: int("driverId").notNull(),
    label: varchar("label", { length: 120 }),
    status: mysqlEnum("tripStatus", ["open", "active", "closed"])
      .notNull()
      .default("open"),
    startedAt: timestamp("startedAt"),
    endedAt: timestamp("endedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({
    driverStatusIdx: index("trips_driver_status_idx").on(
      table.driverId,
      table.status
    ),
  })
);

export const orders = mysqlTable(
  "orders",
  {
    id: int("id").autoincrement().primaryKey(),
    orderNumber: varchar("orderNumber", { length: 48 }).notNull(),
    companyId: int("companyId"),
    source: orderSourceEnum.notNull().default("supervisor"),
    status: orderStatusEnum.notNull().default("pending"),
    assignedDriverId: int("assignedDriverId"),
    requestedVehicleType: vehicleTypeEnum,
    tripId: int("tripId"),
    customerName: varchar("customerName", { length: 180 }),
    customerPhone: varchar("customerPhone", { length: 40 }),
    pickupContactName: varchar("pickupContactName", { length: 180 }),
    pickupAddress: text("pickupAddress"),
    pickupPhone: varchar("pickupPhone", { length: 40 }),
    pickupLocationUrl: varchar("pickupLocationUrl", { length: 1000 }),
    pickupGovernorateId: int("pickupGovernorateId"),
    pickupAreaId: int("pickupAreaId"),
    pickupScheduledAt: timestamp("pickupScheduledAt"),
    deliveryAddress: text("deliveryAddress").notNull(),
    deliveryScheduledAt: timestamp("deliveryScheduledAt"),
    deliveryGovernorateId: int("deliveryGovernorateId"),
    deliveryAreaId: int("deliveryAreaId"),
    area: varchar("area", { length: 120 }),
    notes: text("notes"),
    cashToCollectAmount: decimal("cashToCollectAmount", {
      precision: 12,
      scale: 3,
    })
      .notNull()
      .default("0.000"),
    cashCollectionNote: text("cashCollectionNote"),
    cashCollectedAmount: decimal("cashCollectedAmount", {
      precision: 12,
      scale: 3,
    })
      .notNull()
      .default("0.000"),
    cashCollectionRecorded: boolean("cashCollectionRecorded")
      .notNull()
      .default(false),
    cashCollectedAt: timestamp("cashCollectedAt"),
    cashCollectedByUserId: int("cashCollectedByUserId"),
    cashCollectedShiftId: bigint("cashCollectedShiftId", { mode: "number" }),
    deliveryFee: decimal("deliveryFee", { precision: 10, scale: 3 })
      .notNull()
      .default("0.000"),
    deliveryFeeManual: boolean("deliveryFeeManual").notNull().default(false),
    deliveryFeeChargeOnFailure: boolean("deliveryFeeChargeOnFailure")
      .notNull()
      .default(false),
    driverCommission: decimal("driverCommission", { precision: 10, scale: 3 })
      .notNull()
      .default("0.000"),
    companyShare: decimal("companyShare", { precision: 10, scale: 3 })
      .notNull()
      .default("0.000"),
    driverCommissionManual: boolean("driverCommissionManual")
      .notNull()
      .default(false),
    companyShareManual: boolean("companyShareManual").notNull().default(false),
    compensationInitialized: boolean("compensationInitialized")
      .notNull()
      .default(true),
    returnedToCompany: boolean("returnedToCompany").notNull().default(false),
    failureReason: failureReasonEnum,
    failureNote: text("failureNote"),
    createdByUserId: int("createdByUserId").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    numberIdx: uniqueIndex("orders_number_idx").on(table.orderNumber),
    statusIdx: index("orders_status_idx").on(table.status),
    companyIdx: index("orders_company_idx").on(table.companyId),
    driverIdx: index("orders_driver_idx").on(table.assignedDriverId),
    cashShiftIdx: index("orders_cash_shift_idx").on(table.cashCollectedShiftId),
    areaIdx: index("orders_area_idx").on(table.area),
  })
);

export const financialEntries = mysqlTable(
  "financialEntries",
  {
    id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
    type: financialEntryTypeEnum.notNull(),
    category: financialCategoryEnum.notNull().default("other"),
    companyId: int("companyId"),
    orderId: int("orderId"),
    amount: decimal("amount", { precision: 12, scale: 3 }).notNull(),
    description: varchar("description", { length: 500 }).notNull(),
    reference: varchar("reference", { length: 160 }),
    transactionDate: timestamp("transactionDate").notNull(),
    createdByUserId: int("createdByUserId").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    dateIdx: index("financial_entries_date_idx").on(table.transactionDate),
    companyDateIdx: index("financial_entries_company_date_idx").on(
      table.companyId,
      table.transactionDate
    ),
    categoryIdx: index("financial_entries_category_idx").on(table.category),
  })
);

export const orderEvents = mysqlTable(
  "orderEvents",
  {
    id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
    orderId: int("orderId").notNull(),
    type: eventTypeEnum.notNull(),
    actorUserId: int("actorUserId").notNull(),
    latitude: decimal("latitude", { precision: 10, scale: 7 }),
    longitude: decimal("longitude", { precision: 10, scale: 7 }),
    addressBefore: text("addressBefore"),
    addressAfter: text("addressAfter"),
    feeBefore: decimal("feeBefore", { precision: 10, scale: 3 }),
    feeAfter: decimal("feeAfter", { precision: 10, scale: 3 }),
    note: text("note"),
    occurredAt: timestamp("occurredAt").defaultNow().notNull(),
  },
  table => ({
    orderTimeIdx: index("order_events_order_time_idx").on(
      table.orderId,
      table.occurredAt
    ),
  })
);

export const orderTransfers = mysqlTable(
  "orderTransfers",
  {
    id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
    orderId: int("orderId").notNull(),
    fromDriverId: int("fromDriverId"),
    toDriverId: int("toDriverId").notNull(),
    transferredByUserId: int("transferredByUserId").notNull(),
    reason: text("reason"),
    transferredAt: timestamp("transferredAt").defaultNow().notNull(),
  },
  table => ({
    orderTimeIdx: index("order_transfers_order_time_idx").on(
      table.orderId,
      table.transferredAt
    ),
  })
);

export const orderMedia = mysqlTable(
  "orderMedia",
  {
    id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
    orderId: int("orderId").notNull(),
    kind: mysqlEnum("mediaKind", ["order", "invoice", "delivery"]).notNull(),
    fileKey: varchar("fileKey", { length: 512 }).notNull(),
    fileUrl: text("fileUrl").notNull(),
    uploadedByUserId: int("uploadedByUserId").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({
    orderKindIdx: index("order_media_order_kind_idx").on(
      table.orderId,
      table.kind
    ),
  })
);

export const shifts = mysqlTable(
  "shifts",
  {
    id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
    driverId: int("driverId").notNull(),
    startedAt: timestamp("startedAt").notNull(),
    startLatitude: decimal("startLatitude", { precision: 10, scale: 7 }),
    startLongitude: decimal("startLongitude", { precision: 10, scale: 7 }),
    endedAt: timestamp("endedAt"),
    endLatitude: decimal("endLatitude", { precision: 10, scale: 7 }),
    endLongitude: decimal("endLongitude", { precision: 10, scale: 7 }),
  },
  table => ({
    driverStartedIdx: index("shifts_driver_started_idx").on(
      table.driverId,
      table.startedAt
    ),
  })
);

export const driverLocations = mysqlTable(
  "driverLocations",
  {
    id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
    driverId: int("driverId").notNull(),
    latitude: decimal("latitude", { precision: 10, scale: 7 }).notNull(),
    longitude: decimal("longitude", { precision: 10, scale: 7 }).notNull(),
    recordedAt: timestamp("recordedAt").defaultNow().notNull(),
  },
  table => ({
    driverTimeIdx: index("driver_locations_driver_time_idx").on(
      table.driverId,
      table.recordedAt
    ),
  })
);

export const auditLogs = mysqlTable(
  "auditLogs",
  {
    id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
    actorUserId: int("actorUserId").notNull(),
    action: varchar("action", { length: 100 }).notNull(),
    entityType: varchar("entityType", { length: 80 }).notNull(),
    entityId: varchar("entityId", { length: 80 }),
    beforeJson: text("beforeJson"),
    afterJson: text("afterJson"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({
    entityTimeIdx: index("audit_logs_entity_time_idx").on(
      table.entityType,
      table.entityId,
      table.createdAt
    ),
  })
);

export const messageThreads = mysqlTable("messageThreads", {
  id: int("id").autoincrement().primaryKey(),
  type: messageThreadTypeEnum.notNull().default("direct"),
  title: varchar("title", { length: 180 }),
  orderId: int("orderId"),
  companyId: int("companyId"),
  createdByUserId: int("createdByUserId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const threadMembers = mysqlTable(
  "threadMembers",
  {
    id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
    threadId: int("threadId").notNull(),
    userId: int("userId").notNull(),
    joinedAt: timestamp("joinedAt").defaultNow().notNull(),
  },
  table => ({
    threadUserIdx: uniqueIndex("thread_members_thread_user_idx").on(
      table.threadId,
      table.userId
    ),
  })
);

export const messages = mysqlTable(
  "messages",
  {
    id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
    threadId: int("threadId").notNull(),
    senderUserId: int("senderUserId").notNull(),
    body: text("body").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({
    threadTimeIdx: index("messages_thread_time_idx").on(
      table.threadId,
      table.createdAt
    ),
  })
);

export const messageAttachments = mysqlTable(
  "messageAttachments",
  {
    id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
    messageId: bigint("messageId", { mode: "number" }).notNull(),
    type: messageAttachmentTypeEnum.notNull(),
    fileKey: varchar("fileKey", { length: 512 }).notNull(),
    fileUrl: text("fileUrl").notNull(),
    fileName: varchar("fileName", { length: 180 }).notNull(),
    mimeType: varchar("mimeType", { length: 120 }).notNull(),
    sizeBytes: int("sizeBytes").notNull().default(0),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({
    messageIdx: index("message_attachments_message_idx").on(
      table.messageId,
      table.createdAt
    ),
  })
);

export const backupSchedules = mysqlTable(
  "backupSchedules",
  {
    id: int("id").autoincrement().primaryKey(),
    frequency: varchar("frequency", { length: 40 }).notNull().default("daily"),
    cronTaskUid: varchar("cronTaskUid", { length: 65 }),
    destinationLabel: varchar("destinationLabel", { length: 180 })
      .notNull()
      .default("Off-server storage"),
    enabled: boolean("enabled").notNull().default(false),
    lastRunAt: timestamp("lastRunAt"),
    lastStatus: varchar("lastStatus", { length: 40 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    taskUidIdx: uniqueIndex("backup_schedules_task_uid_idx").on(
      table.cronTaskUid
    ),
  })
);

export const backupSnapshots = mysqlTable(
  "backupSnapshots",
  {
    id: int("id").autoincrement().primaryKey(),
    scheduleId: int("scheduleId"),
    storageKey: varchar("storageKey", { length: 255 }).notNull(),
    downloadUrl: text("downloadUrl").notNull(),
    generatedAt: timestamp("generatedAt").notNull(),
    sizeBytes: int("sizeBytes").notNull().default(0),
    status: varchar("status", { length: 32 }).notNull().default("ready"),
    createdByUserId: int("createdByUserId").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({
    snapshotTimeIdx: index("backup_snapshots_created_at_idx").on(
      table.createdAt
    ),
    storageKeyIdx: uniqueIndex("backup_snapshots_storage_key_idx").on(
      table.storageKey
    ),
  })
);

export const notifications = mysqlTable(
  "notifications",
  {
    id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
    userId: int("userId").notNull(),
    title: varchar("title", { length: 180 }).notNull(),
    body: text("body").notNull(),
    link: varchar("link", { length: 512 }),
    readAt: timestamp("readAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({
    userReadTimeIdx: index("notifications_user_read_time_idx").on(
      table.userId,
      table.readAt,
      table.createdAt
    ),
  })
);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Company = typeof companies.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type FinancialEntry = typeof financialEntries.$inferSelect;
