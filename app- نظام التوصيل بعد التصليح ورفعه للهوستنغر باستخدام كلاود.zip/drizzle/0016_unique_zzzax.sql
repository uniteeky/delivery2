CREATE TABLE `platformSettings` (
	`id` int NOT NULL DEFAULT 1,
	`brandName` varchar(180) NOT NULL DEFAULT 'City Center',
	`logoUrl` text,
	`primaryColor` varchar(16) NOT NULL DEFAULT '#f97316',
	`accentColor` varchar(16) NOT NULL DEFAULT '#0f172a',
	`subscriptionStartsAt` timestamp,
	`subscriptionEndsAt` timestamp,
	`allowDriverTransfer` boolean NOT NULL DEFAULT true,
	`allowSupervisorTransfer` boolean NOT NULL DEFAULT true,
	`allowManagerTransfer` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `platformSettings_id` PRIMARY KEY(`id`)
);
