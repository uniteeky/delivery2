CREATE TABLE `auditLogs` (
	`id` bigint AUTO_INCREMENT NOT NULL,
	`actorUserId` int NOT NULL,
	`action` varchar(100) NOT NULL,
	`entityType` varchar(80) NOT NULL,
	`entityId` varchar(80),
	`beforeJson` text,
	`afterJson` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `auditLogs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `companies` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(180) NOT NULL,
	`code` varchar(40) NOT NULL,
	`phone` varchar(40),
	`whatsapp` varchar(40),
	`defaultDeliveryFee` decimal(10,3) NOT NULL DEFAULT '0.000',
	`accountStatus` enum('active','inactive') NOT NULL DEFAULT 'active',
	`portalEnabled` boolean NOT NULL DEFAULT false,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `companies_id` PRIMARY KEY(`id`),
	CONSTRAINT `companies_code_idx` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `companyUsers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`companyId` int NOT NULL,
	`userId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `companyUsers_id` PRIMARY KEY(`id`),
	CONSTRAINT `company_users_company_user_idx` UNIQUE(`companyId`,`userId`)
);
--> statement-breakpoint
CREATE TABLE `driverLocations` (
	`id` bigint AUTO_INCREMENT NOT NULL,
	`driverId` int NOT NULL,
	`latitude` decimal(10,7) NOT NULL,
	`longitude` decimal(10,7) NOT NULL,
	`recordedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `driverLocations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `drivers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`vehicleLabel` varchar(120),
	`licenseNumber` varchar(80),
	`active` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `drivers_id` PRIMARY KEY(`id`),
	CONSTRAINT `drivers_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `messageThreads` (
	`id` int AUTO_INCREMENT NOT NULL,
	`messageThreadType` enum('direct','group','order','company') NOT NULL DEFAULT 'direct',
	`title` varchar(180),
	`orderId` int,
	`companyId` int,
	`createdByUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `messageThreads_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `messages` (
	`id` bigint AUTO_INCREMENT NOT NULL,
	`threadId` int NOT NULL,
	`senderUserId` int NOT NULL,
	`body` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` bigint AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`body` text NOT NULL,
	`link` varchar(512),
	`readAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `orderEvents` (
	`id` bigint AUTO_INCREMENT NOT NULL,
	`orderId` int NOT NULL,
	`eventType` enum('created','assigned','picked_up','delivered','failed','transferred','address_updated','fee_updated') NOT NULL,
	`actorUserId` int NOT NULL,
	`latitude` decimal(10,7),
	`longitude` decimal(10,7),
	`addressBefore` text,
	`addressAfter` text,
	`feeBefore` decimal(10,3),
	`feeAfter` decimal(10,3),
	`note` text,
	`occurredAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `orderEvents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `orderMedia` (
	`id` bigint AUTO_INCREMENT NOT NULL,
	`orderId` int NOT NULL,
	`mediaKind` enum('order','invoice','delivery') NOT NULL,
	`fileKey` varchar(512) NOT NULL,
	`fileUrl` text NOT NULL,
	`uploadedByUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `orderMedia_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `orderTransfers` (
	`id` bigint AUTO_INCREMENT NOT NULL,
	`orderId` int NOT NULL,
	`fromDriverId` int,
	`toDriverId` int NOT NULL,
	`transferredByUserId` int NOT NULL,
	`reason` text,
	`transferredAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `orderTransfers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `orders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orderNumber` varchar(48) NOT NULL,
	`companyId` int,
	`orderSource` enum('supervisor','company','external') NOT NULL DEFAULT 'supervisor',
	`orderStatus` enum('pending','assigned','picked_up','in_transit','delivered','failed') NOT NULL DEFAULT 'pending',
	`assignedDriverId` int,
	`tripId` int,
	`customerName` varchar(180),
	`customerPhone` varchar(40),
	`deliveryAddress` text NOT NULL,
	`area` varchar(120),
	`notes` text,
	`deliveryFee` decimal(10,3) NOT NULL DEFAULT '0.000',
	`failureReason` enum('no_answer','not_present','wrong_address','postponed','refused','address_changed','other'),
	`failureNote` text,
	`createdByUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `orders_id` PRIMARY KEY(`id`),
	CONSTRAINT `orders_number_idx` UNIQUE(`orderNumber`)
);
--> statement-breakpoint
CREATE TABLE `shifts` (
	`id` bigint AUTO_INCREMENT NOT NULL,
	`driverId` int NOT NULL,
	`startedAt` timestamp NOT NULL,
	`startLatitude` decimal(10,7),
	`startLongitude` decimal(10,7),
	`endedAt` timestamp,
	`endLatitude` decimal(10,7),
	`endLongitude` decimal(10,7),
	CONSTRAINT `shifts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `threadMembers` (
	`id` bigint AUTO_INCREMENT NOT NULL,
	`threadId` int NOT NULL,
	`userId` int NOT NULL,
	`joinedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `threadMembers_id` PRIMARY KEY(`id`),
	CONSTRAINT `thread_members_thread_user_idx` UNIQUE(`threadId`,`userId`)
);
--> statement-breakpoint
CREATE TABLE `trips` (
	`id` int AUTO_INCREMENT NOT NULL,
	`driverId` int NOT NULL,
	`label` varchar(120),
	`tripStatus` enum('open','active','closed') NOT NULL DEFAULT 'open',
	`startedAt` timestamp,
	`endedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `trips_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `name` varchar(160);--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('admin','supervisor','accountant','driver','company') NOT NULL DEFAULT 'driver';--> statement-breakpoint
ALTER TABLE `users` ADD `phone` varchar(40);--> statement-breakpoint
ALTER TABLE `users` ADD `accountStatus` enum('active','inactive') DEFAULT 'active' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `mustChangePassword` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `preferredLanguage` varchar(12) DEFAULT 'ar' NOT NULL;--> statement-breakpoint
CREATE INDEX `audit_logs_entity_time_idx` ON `auditLogs` (`entityType`,`entityId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `companies_status_idx` ON `companies` (`accountStatus`);--> statement-breakpoint
CREATE INDEX `driver_locations_driver_time_idx` ON `driverLocations` (`driverId`,`recordedAt`);--> statement-breakpoint
CREATE INDEX `messages_thread_time_idx` ON `messages` (`threadId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `notifications_user_read_time_idx` ON `notifications` (`userId`,`readAt`,`createdAt`);--> statement-breakpoint
CREATE INDEX `order_events_order_time_idx` ON `orderEvents` (`orderId`,`occurredAt`);--> statement-breakpoint
CREATE INDEX `order_media_order_kind_idx` ON `orderMedia` (`orderId`,`mediaKind`);--> statement-breakpoint
CREATE INDEX `order_transfers_order_time_idx` ON `orderTransfers` (`orderId`,`transferredAt`);--> statement-breakpoint
CREATE INDEX `orders_status_idx` ON `orders` (`orderStatus`);--> statement-breakpoint
CREATE INDEX `orders_company_idx` ON `orders` (`companyId`);--> statement-breakpoint
CREATE INDEX `orders_driver_idx` ON `orders` (`assignedDriverId`);--> statement-breakpoint
CREATE INDEX `orders_area_idx` ON `orders` (`area`);--> statement-breakpoint
CREATE INDEX `shifts_driver_started_idx` ON `shifts` (`driverId`,`startedAt`);--> statement-breakpoint
CREATE INDEX `trips_driver_status_idx` ON `trips` (`driverId`,`tripStatus`);--> statement-breakpoint
CREATE INDEX `users_role_status_idx` ON `users` (`role`,`accountStatus`);