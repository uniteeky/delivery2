ALTER TABLE `users` MODIFY COLUMN `role` enum('admin','supervisor','accountant','driver','company','trader') NOT NULL DEFAULT 'driver';--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `registrationRole` enum('driver','supervisor','accountant','company','trader');--> statement-breakpoint
ALTER TABLE `userRoles` MODIFY COLUMN `role` enum('admin','supervisor','accountant','driver','company','trader') NOT NULL DEFAULT 'driver';
