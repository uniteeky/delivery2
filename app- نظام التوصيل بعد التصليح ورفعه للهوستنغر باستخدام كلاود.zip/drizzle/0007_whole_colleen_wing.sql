ALTER TABLE `orders` ADD `pickupScheduledAt` timestamp;--> statement-breakpoint
ALTER TABLE `orders` ADD `deliveryScheduledAt` timestamp;