CREATE TABLE `userPermissions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`permissionKey` varchar(80) NOT NULL,
	`granted` boolean NOT NULL DEFAULT true,
	`grantedByUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `userPermissions_id` PRIMARY KEY(`id`),
	CONSTRAINT `user_permission_unique` UNIQUE(`userId`,`permissionKey`)
);
--> statement-breakpoint
CREATE INDEX `user_permissions_user_idx` ON `userPermissions` (`userId`);