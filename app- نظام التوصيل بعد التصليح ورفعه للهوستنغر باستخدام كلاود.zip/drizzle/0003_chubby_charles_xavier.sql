CREATE TABLE `backupSchedules` (
	`id` int AUTO_INCREMENT NOT NULL,
	`frequency` varchar(40) NOT NULL DEFAULT 'daily',
	`cronTaskUid` varchar(65),
	`destinationLabel` varchar(180) NOT NULL DEFAULT 'Off-server storage',
	`enabled` boolean NOT NULL DEFAULT false,
	`lastRunAt` timestamp,
	`lastStatus` varchar(40),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `backupSchedules_id` PRIMARY KEY(`id`),
	CONSTRAINT `backup_schedules_task_uid_idx` UNIQUE(`cronTaskUid`)
);
