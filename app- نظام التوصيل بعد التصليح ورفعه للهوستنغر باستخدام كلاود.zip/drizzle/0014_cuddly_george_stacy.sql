CREATE TABLE `messageAttachments` (
	`id` bigint AUTO_INCREMENT NOT NULL,
	`messageId` bigint NOT NULL,
	`messageAttachmentType` enum('image','audio') NOT NULL,
	`fileKey` varchar(512) NOT NULL,
	`fileUrl` text NOT NULL,
	`fileName` varchar(180) NOT NULL,
	`mimeType` varchar(120) NOT NULL,
	`sizeBytes` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `messageAttachments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `message_attachments_message_idx` ON `messageAttachments` (`messageId`,`createdAt`);