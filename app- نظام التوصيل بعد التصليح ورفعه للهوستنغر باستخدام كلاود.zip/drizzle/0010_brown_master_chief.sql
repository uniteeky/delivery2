CREATE TABLE `backupSnapshots` (
	`id` int AUTO_INCREMENT NOT NULL,
	`scheduleId` int,
	`storageKey` varchar(255) NOT NULL,
	`downloadUrl` text NOT NULL,
	`generatedAt` timestamp NOT NULL,
	`sizeBytes` int NOT NULL DEFAULT 0,
	`status` varchar(32) NOT NULL DEFAULT 'ready',
	`createdByUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `backupSnapshots_id` PRIMARY KEY(`id`),
	CONSTRAINT `backup_snapshots_storage_key_idx` UNIQUE(`storageKey`)
);
--> statement-breakpoint
CREATE INDEX `backup_snapshots_created_at_idx` ON `backupSnapshots` (`createdAt`);