ALTER TABLE `companyAddresses` ADD `pickupContactName` varchar(180);--> statement-breakpoint
ALTER TABLE `orders` ADD `cashToCollectAmount` decimal(12,3) DEFAULT '0.000' NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `cashCollectionNote` text;--> statement-breakpoint
ALTER TABLE `orders` ADD `cashCollectedAmount` decimal(12,3) DEFAULT '0.000' NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `cashCollectionRecorded` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `cashCollectedAt` timestamp;--> statement-breakpoint
ALTER TABLE `orders` ADD `cashCollectedByUserId` int;--> statement-breakpoint
ALTER TABLE `orders` ADD `cashCollectedShiftId` bigint;--> statement-breakpoint
CREATE INDEX `orders_cash_shift_idx` ON `orders` (`cashCollectedShiftId`);