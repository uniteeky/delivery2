import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { useUiText } from "@/lib/uiText";
import type { DriverPayType } from "@shared/driver-compensation";
import { friendlyError } from "@/lib/errorMessage";

export default function DriverCompensationPanel({ canEdit }: { canEdit: boolean }) {
  const tr = useUiText();
  const utils = trpc.useUtils();
  const drivers = trpc.drivers.compensationList.useQuery();
  const financeOptions = trpc.finance.filterOptions.useQuery();
  const locations = trpc.locations.directory.useQuery(undefined, { staleTime: 300_000 });
  const [driverId, setDriverId] = useState("");
  const [profile, setProfile] = useState({ payType: "contractor" as DriverPayType, baseSalary: "0.000", defaultCommission: "0.000" });
  const [rate, setRate] = useState({ companyId: "", governorateId: "", areaId: "", amount: "0.000" });
  const [notice, setNotice] = useState("");
  const driver = drivers.data?.find((item) => String(item.id) === driverId);
  const areas = useMemo(() => locations.data?.find((item) => String(item.id) === rate.governorateId)?.areas ?? [], [locations.data, rate.governorateId]);
  const commissionRates = trpc.drivers.commissionRates.useQuery({ driverId: Number(driverId) }, { enabled: Boolean(driverId) });
  const saveProfile = trpc.drivers.updateCompensation.useMutation({
    onSuccess: async () => { setNotice(tr("تم حفظ طريقة أجر السائق.")); await utils.drivers.compensationList.invalidate(); },
    onError: (error) => setNotice(error.message),
  });
  const saveRate = trpc.drivers.setCommissionRate.useMutation({
    onSuccess: async () => { setNotice(tr("تم حفظ تعرفة عمولة السائق.")); await commissionRates.refetch(); },
    onError: (error) => setNotice(error.message),
  });

  useEffect(() => {
    if (!driverId && drivers.data?.length) setDriverId(String(drivers.data[0].id));
  }, [driverId, drivers.data]);
  useEffect(() => {
    if (driver) setProfile({ payType: driver.payType, baseSalary: String(driver.baseSalary ?? "0.000"), defaultCommission: String(driver.defaultCommission ?? "0.000") });
  }, [driver]);

  const submitProfile = () => {
    if (!driver) return;
    saveProfile.mutate({ driverId: driver.id, ...profile });
  };
  const submitRate = () => {
    if (!driverId || !rate.amount) return;
    saveRate.mutate({ driverId: Number(driverId), companyId: rate.companyId ? Number(rate.companyId) : undefined, areaId: rate.areaId ? Number(rate.areaId) : undefined, amount: rate.amount });
  };

  return <Card className="border-violet-200 shadow-sm">
    <CardHeader><CardTitle>{tr("أجور السائقين وعمولاتهم")}</CardTitle><CardDescription>{tr("حدد السائق براتب فقط أو راتب مع عمولة أو سائق تعاقد بالطلب، ثم أضف تعرفة مختلفة حسب الشركة والمنطقة عند الحاجة.")}</CardDescription></CardHeader>
    <CardContent className="space-y-5">
      {drivers.isLoading ? <p className="text-sm text-slate-500">{tr("جارٍ تحميل السائقين…")}</p> : drivers.error ? <p role="alert" className="text-sm text-red-700">{friendlyError(drivers.error)}</p> : !drivers.data?.length ? <p className="rounded-xl bg-slate-50 p-4 text-sm text-slate-500">{tr("لا توجد ملفات سائقين لإعداد أجورها.")}</p> : <>
        <label className="block space-y-1.5 text-sm font-semibold">{tr("السائق")}<select value={driverId} onChange={(event) => setDriverId(event.target.value)} className="h-11 w-full rounded-xl border border-slate-200 bg-white px-3">{(drivers.data ?? []).map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
        {driver ? <section className="grid gap-3 rounded-2xl border border-slate-200 bg-slate-50 p-4 sm:grid-cols-3">
          <label className="space-y-1.5 text-sm font-semibold">{tr("طريقة الأجر")}<select disabled={!canEdit} value={profile.payType} onChange={(event) => setProfile((current) => ({ ...current, payType: event.target.value as DriverPayType }))} className="h-11 w-full rounded-xl border border-slate-200 bg-white px-3"><option value="salary">{tr("راتب فقط")}</option><option value="salary_commission">{tr("راتب مع عمولة توصيل")}</option><option value="contractor">{tr("سائق تعاقد — بالطلب")}</option></select></label>
          <label className="space-y-1.5 text-sm font-semibold">{tr("الراتب الأساسي الشهري")}<Input disabled={!canEdit} type="number" min="0" step="0.001" value={profile.baseSalary} onChange={(event) => setProfile((current) => ({ ...current, baseSalary: event.target.value }))} className="h-11 bg-white" dir="ltr" /></label>
          <label className="space-y-1.5 text-sm font-semibold">{tr("العمولة الافتراضية لكل توصيل ناجح")}<Input disabled={!canEdit || profile.payType === "salary"} type="number" min="0" step="0.001" value={profile.defaultCommission} onChange={(event) => setProfile((current) => ({ ...current, defaultCommission: event.target.value }))} className="h-11 bg-white" dir="ltr" /></label>
          {canEdit ? <Button type="button" disabled={saveProfile.isPending} onClick={submitProfile} className="rounded-xl bg-violet-700 text-white hover:bg-violet-800 sm:col-span-3">{saveProfile.isPending ? tr("جارٍ الحفظ…") : tr("حفظ طريقة الأجر")}</Button> : null}
        </section> : null}
        <div className="space-y-3 rounded-2xl border border-emerald-100 bg-emerald-50/40 p-4">
          <div><h3 className="font-black text-slate-900">{tr("عمولة حسب الشركة والمنطقة")}</h3><p className="mt-1 text-xs leading-6 text-slate-600">{tr("يمكنك اختيار شركة ومنطقة معاً، أو أحدهما فقط، أو تركهما لتحديد تعرفة عامة لهذا السائق. قيمة صفر مسموحة.")}</p></div>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <select disabled={!canEdit} aria-label={tr("الشركة")} value={rate.companyId} onChange={(event) => setRate((current) => ({ ...current, companyId: event.target.value }))} className="h-11 rounded-xl border border-slate-200 bg-white px-3"><option value="">{tr("كل الشركات")}</option>{(financeOptions.data?.companies ?? []).map((company) => <option key={company.id} value={company.id}>{company.name}</option>)}</select>
            <select disabled={!canEdit} aria-label={tr("المحافظة")} value={rate.governorateId} onChange={(event) => setRate((current) => ({ ...current, governorateId: event.target.value, areaId: "" }))} className="h-11 rounded-xl border border-slate-200 bg-white px-3"><option value="">{tr("كل المحافظات")}</option>{(locations.data ?? []).map((item) => <option key={item.id} value={item.id}>{item.nameAr}</option>)}</select>
            <select disabled={!canEdit || !rate.governorateId} aria-label={tr("المنطقة")} value={rate.areaId} onChange={(event) => setRate((current) => ({ ...current, areaId: event.target.value }))} className="h-11 rounded-xl border border-slate-200 bg-white px-3"><option value="">{tr("كل المناطق")}</option>{areas.map((item) => <option key={item.id} value={item.id}>{item.nameAr}</option>)}</select>
            <Input disabled={!canEdit} type="number" min="0" step="0.001" aria-label={tr("عمولة السائق")} value={rate.amount} onChange={(event) => setRate((current) => ({ ...current, amount: event.target.value }))} className="h-11 bg-white" dir="ltr" />
          </div>
          {canEdit ? <Button type="button" disabled={!driverId || saveRate.isPending} onClick={submitRate} className="rounded-xl bg-emerald-700 text-white hover:bg-emerald-800">{saveRate.isPending ? tr("جارٍ الحفظ…") : tr("حفظ أو تحديث التعرفة")}</Button> : null}
          {commissionRates.error ? <p role="alert" className="text-sm text-red-700">{friendlyError(commissionRates.error)}</p> : null}
          <div className="space-y-2">{(commissionRates.data ?? []).length ? commissionRates.data!.map((item) => <button key={item.id} type="button" disabled={!canEdit} onClick={() => setRate({ companyId: item.companyId ? String(item.companyId) : "", governorateId: item.governorateId ? String(item.governorateId) : "", areaId: item.areaId ? String(item.areaId) : "", amount: String(item.amount) })} className="flex w-full flex-wrap items-center justify-between gap-2 rounded-xl border border-white bg-white px-3 py-2 text-right text-sm"><span>{item.companyName ?? tr("كل الشركات")} · {item.areaName ?? tr("كل المناطق")}</span><b dir="ltr">{Number(item.amount).toFixed(3)} {tr("د.ك")}</b></button>) : <p className="text-xs text-slate-500">{tr("لا توجد تعرفة مخصصة؛ يستخدم النظام العمولة الافتراضية للسائق.")}</p>}</div>
        </div>
      </>}
      {notice ? <p role="status" className="rounded-xl border border-slate-200 bg-white p-3 text-sm text-slate-700">{notice}</p> : null}
      {!canEdit ? <p className="text-xs text-amber-700">{tr("للتعديل يلزم منح هذا الحساب صلاحية finance_edit من صفحة الحسابات والصلاحيات.")}</p> : null}
    </CardContent>
  </Card>;
}
