import { supportedLanguages, useLanguage } from "@/i18n";
import { Languages } from "lucide-react";

export default function LanguageSwitcher() {
  const { language, setLanguage, t } = useLanguage();
  return <label className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-bold text-slate-700"><Languages className="h-4 w-4 text-orange-500" /><span className="sr-only">{t("language")}</span><select aria-label={t("language")} value={language} onChange={(event) => setLanguage(event.target.value as keyof typeof supportedLanguages)} className="bg-transparent outline-none"><option value="ar">العربية</option><option value="en">English</option><option value="bn">বাংলা</option><option value="hi">हिन्दी</option></select></label>;
}
