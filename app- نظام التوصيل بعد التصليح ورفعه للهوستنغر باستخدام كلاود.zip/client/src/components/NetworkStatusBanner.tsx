import { CloudOff, Wifi } from "lucide-react";
import { useEffect, useState } from "react";
import { useUiText } from "@/lib/uiText";

export default function NetworkStatusBanner() {
  const tr = useUiText();
  const [online, setOnline] = useState(() => typeof navigator === "undefined" ? true : navigator.onLine);
  const [restored, setRestored] = useState(false);

  useEffect(() => {
    const markOffline = () => { setOnline(false); setRestored(false); };
    const markOnline = () => { setOnline(true); setRestored(true); window.setTimeout(() => setRestored(false), 4_000); };
    window.addEventListener("offline", markOffline);
    window.addEventListener("online", markOnline);
    return () => { window.removeEventListener("offline", markOffline); window.removeEventListener("online", markOnline); };
  }, []);

  if (online && !restored) return null;
  return <div role="status" aria-live="polite" className={`fixed inset-x-3 bottom-3 z-[100] mx-auto flex w-auto max-w-md items-center gap-3 rounded-2xl px-4 py-3 text-sm font-bold shadow-2xl ${online ? "bg-emerald-600 text-white" : "bg-rose-600 text-white"}`}><span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-white/15">{online ? <Wifi className="h-5 w-5" /> : <CloudOff className="h-5 w-5" />}</span><span>{online ? tr("تمت استعادة اتصال الإنترنت.") : tr("لا يوجد اتصال بالإنترنت. قد لا تصل التحديثات الجديدة حتى يعود الاتصال.")}</span></div>;
}
