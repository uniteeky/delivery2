import { Minus, Plus } from "lucide-react";
import { useMemo, useState } from "react";
import { useLanguage } from "@/i18n";
import { createOpenStreetMapEmbedUrl, getOperationsMapMarkerPosition, getOperationsMapViewport, scaleOperationsMapViewport } from "@/lib/operationsMap";

type DriverLocation = { driverId: number; latitude: string; longitude: string; driverName: string | null; recordedAt: Date | string };

function formatRecordedAt(value: Date | string, locale: string, unavailable: string) {
  const date = value instanceof Date ? value : new Date(value);
  return Number.isNaN(date.getTime()) ? unavailable : date.toLocaleString(locale, { dateStyle: "short", timeStyle: "short" });
}

export default function DriverMap({ locations }: { locations: DriverLocation[] }) {
  const { t, language } = useLanguage();
  const validLocations = locations.filter((location) => { const latitude = Number(location.latitude); const longitude = Number(location.longitude); return Number.isFinite(latitude) && Number.isFinite(longitude) && latitude >= 28.5 && latitude <= 30.2 && longitude >= 46.5 && longitude <= 49.5; });
  const locale = language === "ar" ? "ar-KW" : language === "bn" ? "bn-BD" : language === "hi" ? "hi-IN" : "en-KW";
  const signature = validLocations.map((location) => `${location.latitude}:${location.longitude}`).join("|");
  const [zoomStep, setZoomStep] = useState(0);
  const baseViewport = useMemo(() => getOperationsMapViewport(validLocations), [signature]);
  const viewport = useMemo(() => scaleOperationsMapViewport(baseViewport, Math.pow(1.65, -zoomStep)), [baseViewport, zoomStep]);
  const mapUrl = useMemo(() => createOpenStreetMapEmbedUrl(viewport), [viewport]);

  return <div dir={language === "ar" ? "rtl" : "ltr"} className="relative overflow-hidden rounded-2xl border border-slate-200 bg-white">
    <iframe title={t("liveDriverMapTitle")} src={mapUrl} className="h-[360px] w-full border-0" loading="lazy" referrerPolicy="no-referrer" />
    <div className="absolute left-3 top-3 z-20 flex flex-col overflow-hidden rounded-xl border border-slate-300 bg-white shadow"><button type="button" onClick={() => setZoomStep((value) => Math.min(5, value + 1))} className="flex h-10 w-10 items-center justify-center text-slate-800 hover:bg-slate-100" aria-label="تكبير الخريطة"><Plus className="h-5 w-5" /></button><button type="button" onClick={() => setZoomStep((value) => Math.max(-3, value - 1))} className="flex h-10 w-10 items-center justify-center border-t border-slate-200 text-slate-800 hover:bg-slate-100" aria-label="تصغير الخريطة"><Minus className="h-5 w-5" /></button></div>
    {validLocations.map((location) => {
      const position = getOperationsMapMarkerPosition(location, viewport);
      const name = location.driverName?.trim() || `${t("driverNameFallback")} ${location.driverId}`;
      const recordedAt = formatRecordedAt(location.recordedAt, locale, t("timeUnavailable"));
      return <div key={`${location.driverId}:${location.recordedAt}`} className="pointer-events-none absolute z-10 -translate-x-1/2 -translate-y-full" style={{ left: `${position.left}%`, top: `${position.top}%` }} title={`${name} · ${t("lastUpdated")}: ${recordedAt}`}><span className="block whitespace-nowrap rounded-full border-2 border-orange-400 bg-slate-950 px-2 py-1 text-[11px] font-bold text-white shadow-lg">{name}</span><span className="mx-auto block h-3 w-3 rotate-45 border-b-2 border-r-2 border-orange-400 bg-slate-950" /></div>;
    })}
    {!validLocations.length ? <div className="absolute inset-0 flex items-center justify-center bg-white/90 p-6 text-center text-sm text-slate-600">{t("noDriverLocations")}</div> : null}
    {validLocations.length ? <div className="absolute bottom-3 right-3 z-10 max-w-[calc(100%-1.5rem)] rounded-xl border border-slate-200 bg-white/95 px-3 py-2 text-xs text-slate-700 shadow"><strong>{validLocations.length} {t("driversOnMap")}</strong><div className="mt-1 space-y-1">{validLocations.slice(0, 4).map((location) => <div key={location.driverId}>{location.driverName || `${t("driverNameFallback")} ${location.driverId}`} · {t("lastUpdated")}: {formatRecordedAt(location.recordedAt, locale, t("timeUnavailable"))}</div>)}</div></div> : null}
  </div>;
}
