import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { playDriverAlert } from "@/lib/driverAudio";
import { showBrowserNotification } from "@/lib/browserNotifications";
import { BellRing, MessageCircleMore, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { useLanguage } from "@/i18n";
import { useUiText } from "@/lib/uiText";

type MessageNotice = { id: number; title: string; body: string };

export default function MessagingAlertListener() {
  const { language } = useLanguage();
  const tr = useUiText();
  const notifications = trpc.notifications.list.useQuery(undefined, { refetchInterval: 8_000, refetchIntervalInBackground: true });
  const markRead = trpc.notifications.markRead.useMutation({ onSuccess: () => void notifications.refetch() });
  const previousNewestId = useRef<number | null>(null);
  const seenMessageIds = useRef<Set<number> | null>(null);
  if (!seenMessageIds.current) {
    try { seenMessageIds.current = typeof window === "undefined" ? new Set<number>() : new Set<number>(JSON.parse(window.localStorage.getItem("city-center-seen-message-alerts-v1") ?? "[]")); } catch { seenMessageIds.current = new Set<number>(); }
  }
  const timeoutRef = useRef<number | null>(null);
  const [notice, setNotice] = useState<MessageNotice | null>(null);

  useEffect(() => () => { if (timeoutRef.current) window.clearTimeout(timeoutRef.current); }, []);
  useEffect(() => {
    const seen = seenMessageIds.current ?? new Set<number>();
    const newest = (notifications.data ?? []).find((item) => !item.readAt && item.title === "رسالة داخلية جديدة" && !seen.has(item.id));
    if (!newest) return;
    if (previousNewestId.current === null) {
      previousNewestId.current = newest.id;
      return;
    }
    if (newest.id === previousNewestId.current) return;
    previousNewestId.current = newest.id;
    seen.add(newest.id);
    try { window.localStorage.setItem("city-center-seen-message-alerts-v1", JSON.stringify(Array.from(seen).slice(-400))); } catch { /* storage is optional */ }
    markRead.mutate({ id: newest.id });
    setNotice({ id: newest.id, title: newest.title, body: newest.body });
    void playDriverAlert();
    try { if ("vibrate" in navigator) navigator.vibrate([160, 70, 160]); } catch { /* vibration is optional */ }
    if (document.hidden && "Notification" in window && window.Notification.permission === "granted") void showBrowserNotification(newest.title, newest.body, `city-center-message-${newest.id}`);
    if (timeoutRef.current) window.clearTimeout(timeoutRef.current);
    timeoutRef.current = window.setTimeout(() => setNotice(null), 12_000);
  }, [notifications.data]);

  if (!notice) return null;
  const openMessage = () => {
    markRead.mutate({ id: notice.id });
    window.location.assign("/messaging");
  };
  return <div dir={language === "ar" ? "rtl" : "ltr"} role="status" className="fixed inset-x-3 top-3 z-[100] mx-auto max-w-md rounded-2xl border border-blue-200 bg-white p-3 shadow-2xl shadow-blue-950/15 sm:inset-x-auto sm:left-5 sm:top-5"><div className="flex items-start gap-3"><span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-blue-700 text-white"><BellRing className="h-5 w-5" /></span><button type="button" onClick={openMessage} className="min-w-0 flex-1 text-right"><p className="font-black text-slate-950">{notice.title === "رسالة داخلية جديدة" ? tr("رسالة داخلية جديدة") : notice.title}</p><p className="mt-1 line-clamp-2 text-sm leading-5 text-slate-600">{notice.body}</p></button><Button type="button" variant="ghost" size="icon" onClick={() => setNotice(null)} className="h-8 w-8 shrink-0"><X className="h-4 w-4" /></Button></div><Button type="button" onClick={openMessage} className="mt-3 h-9 w-full rounded-xl bg-blue-700 text-white hover:bg-blue-800"><MessageCircleMore className="ml-2 h-4 w-4" />{tr("فتح المراسلات")}</Button></div>;
}
