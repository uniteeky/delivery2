import { useMemo, useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { friendlyError } from "@/lib/errorMessage";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/i18n";
import { useUiText } from "@/lib/uiText";
import {
  ArrowDownUp,
  Edit3,
  Plus,
  RefreshCw,
  Search,
  Send,
  XCircle,
} from "lucide-react";

type Props = { onAdd?: () => void; title?: string };
type Status =
  | "pending"
  | "assigned"
  | "picked_up"
  | "in_transit"
  | "delivered"
  | "failed";
type FailureReason =
  | "no_answer"
  | "not_present"
  | "wrong_address"
  | "postponed"
  | "refused"
  | "address_changed"
  | "other";
type VehicleType =
  | "car"
  | "refrigerated_car"
  | "motorcycle"
  | "semi_truck"
  | "refrigerated_semi_truck"
  | "truck"
  | "refrigerated_truck";
const vehicleTypeLabels: Record<VehicleType, string> = {
  car: "سيارة",
  refrigerated_car: "سيارة تبريد",
  motorcycle: "دراجة نارية",
  semi_truck: "نصف شاحنة",
  refrigerated_semi_truck: "نصف شاحنة تبريد",
  truck: "شاحنة",
  refrigerated_truck: "شاحنة تبريد",
};

const isOpenStatus = (status: string) =>
  !["delivered", "failed"].includes(status);

export default function OrderManagementPanel({ onAdd, title }: Props) {
  const { language, t } = useLanguage();
  const tr = useUiText();
  const [, navigate] = useLocation();
  const companies = trpc.companies.list.useQuery({ page: 1, pageSize: 100 });
  const drivers = trpc.drivers.list.useQuery();
  const locations = trpc.locations.directory.useQuery(undefined, {
    staleTime: 300_000,
  });
  const [search, setSearch] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [companyId, setCompanyId] = useState("all");
  const [driverId, setDriverId] = useState("all");
  const [vehicleType, setVehicleType] = useState<VehicleType | "all">("all");
  const [governorateId, setGovernorateId] = useState("all");
  const [areaId, setAreaId] = useState("all");
  const [status, setStatus] = useState("all");
  const [paymentMethod, setPaymentMethod] = useState("all");
  const [paymentCollection, setPaymentCollection] = useState("all");
  const [source, setSource] = useState("all");
  const [activeAction, setActiveAction] = useState<{
    type: "transfer" | "price" | "failure";
    order: any;
  } | null>(null);
  const [transferDriver, setTransferDriver] = useState("");
  const [transferReason, setTransferReason] = useState("");
  const [price, setPrice] = useState({
    deliveryFee: "",
    driverCommission: "",
    companyShare: "",
  });
  const [failure, setFailure] = useState<{
    reason: FailureReason;
    note: string;
  }>({ reason: "refused", note: "" });
  const filters = useMemo(
    () => ({
      fromDate: fromDate || undefined,
      toDate: toDate || undefined,
      search: search.trim() || undefined,
      companyId: companyId === "all" ? undefined : Number(companyId),
      driverId: driverId === "all" ? undefined : Number(driverId),
      unassigned: driverId === "unassigned" ? true : undefined,
      vehicleType: vehicleType === "all" ? undefined : vehicleType,
      governorateId:
        governorateId === "all" ? undefined : Number(governorateId),
      areaId: areaId === "all" ? undefined : Number(areaId),
      status: status === "all" ? undefined : (status as Status),
      paymentMethod:
        paymentMethod === "all"
          ? undefined
          : (paymentMethod as "paid" | "cash_on_delivery"),
      paymentCollection:
        paymentCollection === "all"
          ? undefined
          : (paymentCollection as "collected" | "not_collected"),
      source:
        source === "all"
          ? undefined
          : (source as "supervisor" | "company" | "external"),
    }),
    [
      fromDate,
      toDate,
      search,
      companyId,
      driverId,
      vehicleType,
      governorateId,
      areaId,
      status,
      paymentMethod,
      paymentCollection,
      source,
    ]
  );
  const report = trpc.supervisorReports.get.useQuery(filters);
  const utils = trpc.useUtils();
  const transfer = trpc.orders.transfer.useMutation({
    onSuccess: async () => {
      setActiveAction(null);
      setTransferDriver("");
      setTransferReason("");
      await utils.supervisorReports.get.invalidate();
    },
  });
  const updatePrice = trpc.finance.updateCompensation.useMutation({
    onSuccess: async () => {
      setActiveAction(null);
      await utils.supervisorReports.get.invalidate();
    },
  });
  const updateStatus = trpc.orders.updateStatus.useMutation({
    onSuccess: async () => {
      setActiveAction(null);
      await utils.supervisorReports.get.invalidate();
    },
  });
  const statusLabels: Record<string, string> = {
    pending: t("statusNew"),
    assigned: t("statusAssigned"),
    picked_up: t("statusPickedUp"),
    in_transit: t("statusInTransit"),
    delivered: t("statusDelivered"),
    failed: t("statusFailed"),
  };
  const reasonLabels: Record<FailureReason, string> = {
    refused: "رفض العميل",
    no_answer: "لا يرد",
    not_present: "غير موجود",
    wrong_address: "عنوان خاطئ",
    postponed: "تأجيل",
    address_changed: "غيّر العنوان",
    other: "سبب آخر",
  };
  const orders = report.data?.orderRows ?? [];
  const reset = () => {
    setSearch("");
    setFromDate("");
    setToDate("");
    setCompanyId("all");
    setDriverId("all");
    setGovernorateId("all");
    setAreaId("all");
    setStatus("all");
    setPaymentMethod("all");
    setPaymentCollection("all");
    setSource("all");
    setVehicleType("all");
  };
  const openPrice = (order: any) => {
    setPrice({
      deliveryFee: String(order.deliveryFee ?? "0.000"),
      driverCommission: String(order.driverCommission ?? "0.000"),
      companyShare: String(order.companyShare ?? "0.000"),
    });
    setActiveAction({ type: "price", order });
  };
  const openTransfer = (order: any) => {
    setTransferDriver("");
    setTransferReason("");
    setActiveAction({ type: "transfer", order });
  };
  const openFailure = (order: any) => {
    setFailure({
      reason: (order.failureReason as FailureReason) || "refused",
      note: order.failureNote || "",
    });
    setActiveAction({ type: "failure", order });
  };
  return (
    <section className="mt-6" dir={language === "ar" ? "rtl" : "ltr"}>
      <Card className="rounded-3xl border-slate-100 bg-white shadow-sm">
        <CardHeader className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <CardTitle className="text-2xl font-black">
              {title || "إدارة الطلبات"}
            </CardTitle>
            <p className="mt-1 text-sm text-slate-500">
              الطلبات غير المسلّمة تظهر أولاً تلقائياً، ويمكن تنفيذ التحويل
              والتعديل من نفس الجدول.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button
              onClick={onAdd}
              className="rounded-xl bg-orange-500 text-white hover:bg-orange-600"
            >
              <Plus className="ml-2 h-4 w-4" /> إضافة طلب جديد
            </Button>
            <Button
              variant="outline"
              onClick={() => void report.refetch()}
              className="rounded-xl bg-white"
            >
              <RefreshCw className="ml-2 h-4 w-4" /> تحديث
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 rounded-2xl bg-slate-50 p-4 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-6">
            <label className="text-sm font-bold">
              بحث
              <Input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="رقم الطلب أو اسم العميل أو الهاتف"
                className="mt-1 bg-white"
              />
            </label>
            <label className="text-sm font-bold">
              من تاريخ
              <Input
                type="date"
                value={fromDate}
                onChange={e => setFromDate(e.target.value)}
                className="mt-1 bg-white"
              />
            </label>
            <label className="text-sm font-bold">
              إلى تاريخ
              <Input
                type="date"
                value={toDate}
                onChange={e => setToDate(e.target.value)}
                className="mt-1 bg-white"
              />
            </label>
            <label className="text-sm font-bold">
              الشركة
              <select
                value={companyId}
                onChange={e => setCompanyId(e.target.value)}
                className="mt-1 h-10 w-full rounded-md border bg-white px-3 text-sm"
              >
                <option value="all">الكل</option>
                {(companies.data?.items ?? []).map(c => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </label>
            <label className="text-sm font-bold">
              نوع المركبة
              <select
                value={vehicleType}
                onChange={e => {
                  setVehicleType(e.target.value as VehicleType | "all");
                  setDriverId("all");
                }}
                className="mt-1 h-10 w-full rounded-md border bg-white px-3 text-sm"
              >
                <option value="all">الكل</option>
                {Object.entries(vehicleTypeLabels).map(([key, label]) => (
                  <option key={key} value={key}>
                    {label}
                  </option>
                ))}
              </select>
            </label>
            <label className="text-sm font-bold">
              السائق
              <select
                value={driverId}
                onChange={e => setDriverId(e.target.value)}
                className="mt-1 h-10 w-full rounded-md border bg-white px-3 text-sm"
              >
                <option value="all">الكل</option>
                <option value="unassigned" className="font-bold text-red-600">
                  بدون سائق
                </option>
                {(drivers.data ?? [])
                  .filter(
                    d => vehicleType === "all" || d.vehicleType === vehicleType
                  )
                  .map(d => (
                    <option key={d.id} value={d.id}>
                      {d.name} ·{" "}
                      {vehicleTypeLabels[d.vehicleType as VehicleType] ||
                        "نوع غير محدد"}
                    </option>
                  ))}
              </select>
            </label>
            <label className="text-sm font-bold">
              المحافظة
              <select
                value={governorateId}
                onChange={e => {
                  setGovernorateId(e.target.value);
                  setAreaId("all");
                }}
                className="mt-1 h-10 w-full rounded-md border bg-white px-3 text-sm"
              >
                <option value="all">الكل</option>
                {(locations.data ?? []).map(g => (
                  <option key={g.id} value={g.id}>
                    {g.nameAr}
                  </option>
                ))}
              </select>
            </label>
            <label className="text-sm font-bold">
              المنطقة
              <select
                value={areaId}
                onChange={e => setAreaId(e.target.value)}
                className="mt-1 h-10 w-full rounded-md border bg-white px-3 text-sm"
              >
                <option value="all">الكل</option>
                {(locations.data ?? [])
                  .flatMap(g =>
                    governorateId === "all" || String(g.id) === governorateId
                      ? g.areas
                      : []
                  )
                  .map(a => (
                    <option key={a.id} value={a.id}>
                      {a.nameAr}
                      {governorateId === "all"
                        ? ` · ${(locations.data ?? []).find(g => g.id === a.governorateId)?.nameAr || ""}`
                        : ""}
                    </option>
                  ))}
              </select>
            </label>
            <label className="text-sm font-bold">
              الحالة
              <select
                value={status}
                onChange={e => setStatus(e.target.value)}
                className="mt-1 h-10 w-full rounded-md border bg-white px-3 text-sm"
              >
                <option value="all">الكل</option>
                {Object.entries(statusLabels).map(([key, label]) => (
                  <option key={key} value={key}>
                    {label}
                  </option>
                ))}
              </select>
            </label>
            <label className="text-sm font-bold">
              الدفع
              <select
                value={paymentMethod}
                onChange={e => setPaymentMethod(e.target.value)}
                className="mt-1 h-10 w-full rounded-md border bg-white px-3 text-sm"
              >
                <option value="all">الكل</option>
                <option value="paid">مدفوع مسبقاً</option>
                <option value="cash_on_delivery">الدفع عند الاستلام</option>
              </select>
            </label>
            <label className="text-sm font-bold">
              تحصيل الدفع
              <select
                value={paymentCollection}
                onChange={e => setPaymentCollection(e.target.value)}
                className="mt-1 h-10 w-full rounded-md border bg-white px-3 text-sm"
              >
                <option value="all">الكل</option>
                <option value="collected">تم التحصيل</option>
                <option value="not_collected">لم يتم التحصيل</option>
              </select>
            </label>
            <label className="text-sm font-bold">
              مصدر الطلب
              <select
                value={source}
                onChange={e => setSource(e.target.value)}
                className="mt-1 h-10 w-full rounded-md border bg-white px-3 text-sm"
              >
                <option value="all">الكل</option>
                <option value="supervisor">المشرف</option>
                <option value="company">الشركة</option>
                <option value="external">خارجي</option>
              </select>
            </label>
            <Button
              variant="outline"
              onClick={reset}
              className="mt-auto h-10 rounded-xl bg-white"
            >
              <XCircle className="ml-2 h-4 w-4" />
              مسح الفلاتر
            </Button>
          </div>
          <div className="mt-4 flex flex-wrap items-center gap-3 text-sm text-slate-500">
            <ArrowDownUp className="h-4 w-4 text-orange-500" /> ترتيب تلقائي:
            غير المسلّم أولاً · {orders.length} طلب
          </div>
          <div className="mt-3 overflow-x-auto rounded-2xl border border-slate-100">
            <table className="w-full min-w-[980px] text-[11px] sm:text-xs lg:text-sm">
              <thead className="bg-slate-50 text-right text-xs text-slate-500">
                <tr>
                  <th className="p-3">الطلب</th>
                  <th className="p-3">الشركة / العميل</th>
                  <th className="p-3">السائق</th>
                  <th className="p-3">الموقع</th>
                  <th className="p-3">الحالة / آخر حركة</th>
                  <th className="p-3">المبالغ</th>
                  <th className="p-3">الإجراءات</th>
                </tr>
              </thead>
              <tbody>
                {report.isLoading ? (
                  <tr>
                    <td colSpan={7} className="p-8 text-center">
                      جارٍ تحميل الطلبات…
                    </td>
                  </tr>
                ) : orders.length ? (
                  orders.map((order: any) => (
                    <tr
                      key={order.id}
                      className={`border-t border-slate-100 ${isOpenStatus(order.status) ? "bg-amber-50/30" : "bg-white"}`}
                    >
                      <td className="p-3 font-black">
                        <button
                          className="text-orange-700 underline"
                          onClick={() => navigate(`/orders/${order.id}`)}
                        >
                          {order.orderNumber}
                        </button>
                        <div className="mt-1 text-[11px] font-normal text-slate-500">
                          {new Date(order.updatedAt).toLocaleString(
                            language === "ar" ? "ar-KW" : "en-KW"
                          )}
                        </div>
                      </td>
                      <td className="p-3">
                        <b>
                          {order.companyName ||
                            (order.source === "external" ? "طلب خارجي" : "—")}
                        </b>
                        <div className="mt-1 text-xs text-slate-500">
                          {order.customerName || "بدون اسم"} ·{" "}
                          {order.customerPhone || "—"}
                        </div>
                      </td>
                      <td className="p-3">
                        {order.assignedDriverName ? (
                          <>
                            <span>{order.assignedDriverName}</span>
                            <div className="mt-1 text-[10px] text-slate-500">
                              {vehicleTypeLabels[
                                order.driverVehicleType as VehicleType
                              ] || ""}
                            </div>
                          </>
                        ) : (
                          <span className="font-black text-red-600">
                            بدون سائق
                          </span>
                        )}
                      </td>
                      <td className="p-3 text-xs">
                        {order.deliveryGovernorateName || "—"} ·{" "}
                        {order.deliveryAreaName || order.area || "—"}
                      </td>
                      <td className="p-3">
                        <span
                          className={`rounded-full px-2 py-1 text-xs font-bold ${order.status === "delivered" ? "bg-emerald-100 text-emerald-700" : order.status === "failed" ? "bg-rose-100 text-rose-700" : "bg-amber-100 text-amber-800"}`}
                        >
                          {statusLabels[order.status] || order.status}
                        </span>
                        {order.failureReason ? (
                          <div className="mt-2 text-xs text-rose-700">
                            {reasonLabels[order.failureReason as FailureReason]}
                            : {order.failureNote || "بدون ملاحظة"}
                          </div>
                        ) : null}
                      </td>
                      <td className="p-3 text-xs">
                        التوصيل:{" "}
                        <b>{Number(order.deliveryFee ?? 0).toFixed(3)}</b>
                        <br />
                        التحصيل:{" "}
                        <b>
                          {Number(order.cashToCollectAmount ?? 0).toFixed(3)}
                        </b>
                        {Number(order.cashToCollectAmount ?? 0) > 0 ? (
                          <span className="text-emerald-700">
                            {" "}
                            ·{" "}
                            {order.cashCollectionRecorded
                              ? "تم التحصيل"
                              : "غير محصل"}
                          </span>
                        ) : null}
                      </td>
                      <td className="p-3">
                        <div className="flex flex-wrap gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => openTransfer(order)}
                            className="rounded-lg bg-white"
                          >
                            <Send className="ml-1 h-3.5 w-3.5" />
                            تحويل
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => openPrice(order)}
                            className="rounded-lg bg-white"
                          >
                            <Edit3 className="ml-1 h-3.5 w-3.5" />
                            السعر
                          </Button>
                          {isOpenStatus(order.status) ? (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => openFailure(order)}
                              className="rounded-lg bg-white text-rose-700"
                            >
                              <XCircle className="ml-1 h-3.5 w-3.5" />
                              رفض / فشل
                            </Button>
                          ) : null}
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={7} className="p-8 text-center text-slate-500">
                      لا توجد طلبات بهذه الفلاتر
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
      <Dialog
        open={activeAction?.type === "transfer"}
        onOpenChange={open => !open && setActiveAction(null)}
      >
        <DialogContent className="w-[min(94vw,520px)] rounded-3xl bg-[#f8fafc]">
          <DialogHeader>
            <DialogTitle>
              تحويل الطلب {activeAction?.order?.orderNumber}
            </DialogTitle>
            <DialogDescription>
              اختر السائق الجديد وسيتم إرسال إشعار تلقائي له مع تسجيل التحويل.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <select
              value={transferDriver}
              onChange={e => setTransferDriver(e.target.value)}
              className="h-11 w-full rounded-xl border bg-white px-3"
            >
              <option value="">اختر السائق الجديد</option>
              {(drivers.data ?? [])
                .filter(d => d.id !== activeAction?.order?.assignedDriverId)
                .map(d => (
                  <option key={d.id} value={d.id}>
                    {d.name} · {d.vehicleLabel || "بدون مركبة"}
                  </option>
                ))}
            </select>
            <Input
              value={transferReason}
              onChange={e => setTransferReason(e.target.value)}
              placeholder="سبب التحويل (اختياري)"
            />
            <Button
              disabled={!transferDriver || transfer.isPending}
              onClick={() =>
                activeAction &&
                transfer.mutate({
                  orderId: activeAction.order.id,
                  toDriverId: Number(transferDriver),
                  reason: transferReason || undefined,
                })
              }
              className="w-full rounded-xl bg-orange-500 text-white"
            >
              {transfer.isPending ? "جارٍ التحويل…" : "تأكيد التحويل"}
            </Button>
            {transfer.error ? (
              <p className="text-sm text-rose-700">{friendlyError(transfer.error)}</p>
            ) : null}
          </div>
        </DialogContent>
      </Dialog>
      <Dialog
        open={activeAction?.type === "price"}
        onOpenChange={open => !open && setActiveAction(null)}
      >
        <DialogContent className="w-[min(94vw,560px)] rounded-3xl bg-[#f8fafc]">
          <DialogHeader>
            <DialogTitle>تعديل السعر والمحاسبة</DialogTitle>
            <DialogDescription>
              تعديل سعر التوصيل وعمولة السائق وحصة الشركة لهذا الطلب فقط.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-3 sm:grid-cols-3">
            <label className="text-sm font-bold">
              سعر التوصيل
              <Input
                value={price.deliveryFee}
                onChange={e =>
                  setPrice(p => ({ ...p, deliveryFee: e.target.value }))
                }
                type="number"
                min="0"
                step="0.001"
                dir="ltr"
              />
            </label>
            <label className="text-sm font-bold">
              عمولة السائق
              <Input
                value={price.driverCommission}
                onChange={e =>
                  setPrice(p => ({ ...p, driverCommission: e.target.value }))
                }
                type="number"
                min="0"
                step="0.001"
                dir="ltr"
              />
            </label>
            <label className="text-sm font-bold">
              حصة الشركة
              <Input
                value={price.companyShare}
                onChange={e =>
                  setPrice(p => ({ ...p, companyShare: e.target.value }))
                }
                type="number"
                min="0"
                step="0.001"
                dir="ltr"
              />
            </label>
          </div>
          <Button
            disabled={updatePrice.isPending}
            onClick={() =>
              activeAction &&
              updatePrice.mutate({
                orderId: activeAction.order.id,
                deliveryFee: price.deliveryFee,
                driverCommission: price.driverCommission,
                companyShare: price.companyShare,
              })
            }
            className="w-full rounded-xl bg-amber-600 text-white"
          >
            {updatePrice.isPending ? "جارٍ الحفظ…" : "حفظ التعديل"}
          </Button>
          {updatePrice.error ? (
            <p className="text-sm text-rose-700">{friendlyError(updatePrice.error)}</p>
          ) : null}
        </DialogContent>
      </Dialog>
      <Dialog
        open={activeAction?.type === "failure"}
        onOpenChange={open => !open && setActiveAction(null)}
      >
        <DialogContent className="w-[min(94vw,560px)] rounded-3xl bg-[#f8fafc]">
          <DialogHeader>
            <DialogTitle>رفض أو فشل تسليم الطلب</DialogTitle>
            <DialogDescription>
              اختر السبب وأضف ملاحظة السائق لتظهر في آخر حركة الطلب.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <select
              value={failure.reason}
              onChange={e =>
                setFailure(f => ({
                  ...f,
                  reason: e.target.value as FailureReason,
                }))
              }
              className="h-11 w-full rounded-xl border bg-white px-3"
            >
              {Object.entries(reasonLabels).map(([key, label]) => (
                <option key={key} value={key}>
                  {label}
                </option>
              ))}
            </select>
            <textarea
              value={failure.note}
              onChange={e => setFailure(f => ({ ...f, note: e.target.value }))}
              placeholder="ملاحظة السائق"
              className="min-h-28 w-full rounded-xl border bg-white p-3"
            />
            <Button
              disabled={updateStatus.isPending}
              onClick={() =>
                activeAction &&
                updateStatus.mutate({
                  orderId: activeAction.order.id,
                  status: "failed",
                  failureReason: failure.reason,
                  note: failure.note || undefined,
                })
              }
              className="w-full rounded-xl bg-rose-600 text-white"
            >
              {updateStatus.isPending ? "جارٍ الحفظ…" : "حفظ الحالة والملاحظة"}
            </Button>
            {updateStatus.error ? (
              <p className="text-sm text-rose-700">
                {friendlyError(updateStatus.error)}
              </p>
            ) : null}
          </div>
        </DialogContent>
      </Dialog>
    </section>
  );
}
