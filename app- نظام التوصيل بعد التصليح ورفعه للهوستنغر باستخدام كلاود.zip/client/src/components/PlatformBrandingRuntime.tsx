import { trpc } from "@/lib/trpc";
import { useEffect } from "react";

function mixColor(hex: string, amount: number) {
  const value = hex.replace("#", "");
  const red = Number.parseInt(value.slice(0, 2), 16);
  const green = Number.parseInt(value.slice(2, 4), 16);
  const blue = Number.parseInt(value.slice(4, 6), 16);
  const target = amount > 0 ? 255 : 0;
  const weight = Math.abs(amount);
  const channels = [red, green, blue].map((channel) => Math.round(channel + (target - channel) * weight));
  return `#${channels.map((channel) => channel.toString(16).padStart(2, "0")).join("")}`;
}

function contrastColor(hex: string) {
  const value = hex.replace("#", "");
  const channels = [0, 2, 4].map((offset) => Number.parseInt(value.slice(offset, offset + 2), 16) / 255).map((channel) => channel <= 0.04045 ? channel / 12.92 : ((channel + 0.055) / 1.055) ** 2.4);
  const luminance = 0.2126 * channels[0]! + 0.7152 * channels[1]! + 0.0722 * channels[2]!;
  return luminance > 0.42 ? "#111827" : "#ffffff";
}

export default function PlatformBrandingRuntime() {
  const branding = trpc.platform.branding.useQuery(undefined, { staleTime: 60_000 });

  useEffect(() => {
    if (!branding.data) return;
    document.title = branding.data.brandName;
    const root = document.documentElement;
    const themeColor = document.querySelector<HTMLMetaElement>('meta[name="theme-color"]');
    if (themeColor) themeColor.content = branding.data.primaryColor;
    let favicon = document.querySelector<HTMLLinkElement>('link[rel~="icon"]');
    if (!favicon) {
      favicon = document.createElement("link");
      favicon.rel = "icon";
      document.head.append(favicon);
    }
    if (branding.data.logoUrl) favicon.href = branding.data.logoUrl;
    root.style.setProperty("--platform-primary", branding.data.primaryColor);
    root.style.setProperty("--platform-accent", branding.data.accentColor);
    root.style.setProperty("--primary", branding.data.primaryColor);
    root.style.setProperty("--primary-foreground", contrastColor(branding.data.primaryColor));
    root.style.setProperty("--accent", branding.data.accentColor);
    root.style.setProperty("--accent-foreground", contrastColor(branding.data.accentColor));
    root.style.setProperty("--ring", branding.data.primaryColor);

    const orangeScale = [
      [50, 0.94], [100, 0.86], [200, 0.70], [300, 0.52], [400, 0.30],
      [500, 0], [600, -0.12], [700, -0.24], [800, -0.36], [900, -0.48],
    ] as const;
    for (const [shade, amount] of orangeScale) {
      root.style.setProperty(`--color-orange-${shade}`, mixColor(branding.data.primaryColor, amount));
    }
  }, [branding.data]);

  return null;
}
