import { useState } from "react";
import { ShieldCheck } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { friendlyError } from "@/lib/errorMessage";

export default function ManagerAccountSetup() {
  const utils = trpc.useUtils();
  const [form, setForm] = useState({ civilId: "", email: "", password: "" });
  const createManager = trpc.users.createManagerAccount.useMutation({
    onSuccess: () => {
      setForm({ civilId: "", email: "", password: "" });
      void utils.users.list.invalidate();
    },
  });

  return <Card className="mb-6 rounded-3xl border-emerald-100 bg-emerald-50/70 shadow-sm"><CardHeader><CardTitle className="flex items-center gap-2 text-xl font-black"><ShieldCheck className="h-5 w-5 text-emerald-600" />إنشاء حساب مدير</CardTitle><p className="text-sm leading-7 text-slate-600">هذا النموذج متاح للمدير فقط. الحساب الجديد يُعتمد فوراً ويأخذ الصلاحيات الإدارية الكاملة.</p></CardHeader><CardContent><form className="grid gap-3 sm:grid-cols-2" onSubmit={(event) => { event.preventDefault(); createManager.mutate(form); }}><Input required maxLength={12} inputMode="numeric" placeholder="الرقم المدني" value={form.civilId} onChange={(event) => setForm((current) => ({ ...current, civilId: event.target.value }))} /><Input required type="email" placeholder="البريد الإلكتروني" value={form.email} onChange={(event) => setForm((current) => ({ ...current, email: event.target.value }))} /><Input required minLength={8} type="password" placeholder="كلمة مرور المدير" value={form.password} onChange={(event) => setForm((current) => ({ ...current, password: event.target.value }))} /><Button type="submit" disabled={createManager.isPending} className="rounded-xl bg-emerald-600 text-white hover:bg-emerald-700">{createManager.isPending ? "جارٍ إنشاء المدير..." : "إنشاء مدير معتمد"}</Button>{createManager.error ? <p className="text-sm font-semibold text-red-700 sm:col-span-2">{friendlyError(createManager.error)}</p> : null}{createManager.isSuccess ? <p className="text-sm font-semibold text-emerald-700 sm:col-span-2">تم إنشاء حساب المدير واعتماده فوراً.</p> : null}</form></CardContent></Card>;
}
