import { Check, ChevronsUpDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Command, CommandEmpty, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { trpc } from "@/lib/trpc";
import { useUiText } from "@/lib/uiText";
import { useState } from "react";

type LocationKind = "pickup" | "delivery" | "branch";

function SearchableLocation({ label, value, options, placeholder, searchPlaceholder, disabled, onChange }: { label: string; value?: number | null; options: Array<{ id: number; nameAr: string; nameEn: string }>; placeholder: string; searchPlaceholder: string; disabled?: boolean; onChange: (id: number | undefined) => void }) {
  const [open, setOpen] = useState(false);
  const selected = options.find((option) => option.id === value);
  return <div className="space-y-1.5"><p className="text-sm font-semibold text-slate-700">{label}</p><Popover open={open} onOpenChange={setOpen}><PopoverTrigger asChild><Button type="button" variant="outline" role="combobox" aria-expanded={open} disabled={disabled} className="h-11 w-full justify-between rounded-xl bg-white px-3 font-normal">{selected?.nameAr ?? placeholder}<ChevronsUpDown className="h-4 w-4 shrink-0 opacity-50" /></Button></PopoverTrigger><PopoverContent align="start" className="z-[80] w-[--radix-popover-trigger-width] border border-slate-200 bg-white p-0 text-slate-900 shadow-xl dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"><Command className="bg-white text-slate-900 dark:bg-slate-900 dark:text-slate-100"><CommandInput placeholder={searchPlaceholder} className="bg-white dark:bg-slate-900" /><CommandList className="bg-white dark:bg-slate-900"><CommandEmpty className="bg-white text-slate-600 dark:bg-slate-900 dark:text-slate-300">لا توجد نتائج.</CommandEmpty>{options.map((option) => <CommandItem className="data-[selected=true]:bg-slate-100 dark:data-[selected=true]:bg-slate-800" key={option.id} value={`${option.nameAr} ${option.nameEn}`} onSelect={() => { onChange(selected?.id === option.id ? undefined : option.id); setOpen(false); }}><Check className={`h-4 w-4 ${selected?.id === option.id ? "opacity-100" : "opacity-0"}`} />{option.nameAr}<span className="mr-auto text-xs text-slate-400">{option.nameEn}</span></CommandItem>)}</CommandList></Command></PopoverContent></Popover></div>;
}

export default function LocationPicker({ kind, governorateId, areaId, onGovernorateChange, onAreaChange, compact = false }: { kind: LocationKind; governorateId?: number | null; areaId?: number | null; onGovernorateChange: (id: number | undefined) => void; onAreaChange: (id: number | undefined) => void; compact?: boolean }) {
  const tr = useUiText();
  const directory = trpc.locations.directory.useQuery(undefined, { staleTime: 300_000 });
  const governorates = directory.data ?? [];
  const areas = governorates.find((item) => item.id === governorateId)?.areas ?? [];
  const kindLabel = kind === "pickup" ? tr("الاستلام") : kind === "delivery" ? tr("التسليم") : tr("الفرع");
  const stackClass = compact ? "grid gap-3 sm:grid-cols-2" : "grid gap-3 sm:grid-cols-2";
  return <div className={stackClass}><SearchableLocation label={`${tr("المحافظة")} · ${kindLabel}`} value={governorateId} options={governorates} placeholder={tr("اختر المحافظة")} searchPlaceholder={tr("ابحث عن محافظة...")} onChange={(id) => { onGovernorateChange(id); onAreaChange(undefined); }} /><SearchableLocation label={`${tr("المنطقة")} · ${kindLabel}`} value={areaId} options={areas} placeholder={governorateId ? tr("اختر المنطقة") : tr("اختر المحافظة أولاً")} searchPlaceholder={tr("ابحث عن منطقة...")} disabled={!governorateId} onChange={onAreaChange} /></div>;
}
