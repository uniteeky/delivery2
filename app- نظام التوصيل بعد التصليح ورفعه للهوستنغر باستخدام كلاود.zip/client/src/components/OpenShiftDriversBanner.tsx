import {
  ChevronDown,
  ChevronUp,
  CircleDot,
  Clock3,
  Phone,
  Truck,
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useEffect, useState } from "react";

function formatShiftDuration(
  startedAt: Date | string | null | undefined,
  now: number
) {
  if (!startedAt) return "—";
  const elapsed = Math.max(0, now - new Date(startedAt).getTime());
  const hours = Math.floor(elapsed / 3_600_000);
  const minutes = Math.floor((elapsed % 3_600_000) / 60_000);
  const seconds = Math.floor((elapsed % 60_000) / 1_000);
  return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

function formatShiftStart(startedAt: Date | string | null | undefined) {
  if (!startedAt) return "غير متاح";
  return new Intl.DateTimeFormat("ar-KW", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  }).format(new Date(startedAt));
}

const vehicleTypeLabels: Record<string, string> = {
  car: "سيارة",
  refrigerated_car: "سيارة تبريد",
  motorcycle: "دراجة نارية",
  semi_truck: "نصف شاحنة",
  refrigerated_semi_truck: "نصف شاحنة تبريد",
  truck: "شاحنة",
  refrigerated_truck: "شاحنة تبريد",
};

export default function OpenShiftDriversBanner() {
  const activeShifts = trpc.drivers.openShifts.useQuery(undefined, {
    refetchInterval: 15_000,
    refetchIntervalInBackground: true,
  });
  const [collapsed, setCollapsed] = useState(false);
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 1_000);
    return () => window.clearInterval(timer);
  }, []);
  if (activeShifts.isLoading)
    return (
      <div className="mb-5 rounded-2xl border border-slate-100 bg-white p-4 text-sm text-slate-500">
        جارٍ تحديث السائقين في الوردية...
      </div>
    );
  if (activeShifts.error)
    return (
      <div className="mb-5 rounded-2xl border border-rose-100 bg-rose-50 p-4 text-sm text-rose-700">
        تعذر تحميل قائمة السائقين في الورديات المفتوحة.
      </div>
    );
  const drivers = activeShifts.data ?? [];
  return (
    <section className="mb-5 rounded-3xl border border-emerald-100 bg-white p-4 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-emerald-50 text-emerald-600">
            <Truck className="h-5 w-5" />
          </span>
          <div>
            <h2 className="font-black text-slate-900">
              السائقون في وردية مفتوحة (الشفت)
            </h2>
            <p className="text-xs text-slate-500">تحديث تلقائي كل 15 ثانية</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="rounded-full bg-emerald-50 px-3 py-1 text-sm font-black text-emerald-700">
            {drivers.length} متاح
          </span>
          <button
            type="button"
            onClick={() => setCollapsed(value => !value)}
            aria-expanded={!collapsed}
            className="inline-flex h-9 items-center gap-1 rounded-xl border border-slate-200 px-3 text-xs font-bold text-slate-700 hover:bg-slate-50"
          >
            {collapsed ? (
              <>
                <ChevronDown className="h-4 w-4" />
                توسيع
              </>
            ) : (
              <>
                <ChevronUp className="h-4 w-4" />
                تصغير
              </>
            )}
          </button>
        </div>
      </div>
      {collapsed ? (
        <p className="mt-3 text-sm text-slate-500">
          القسم مصغّر. اضغط «توسيع» لعرض السائقين وتوقيت وردياتهم.
        </p>
      ) : drivers.length ? (
        <div className="mt-4 grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
          {drivers.map(driver => (
            <div
              key={driver.id}
              className="rounded-2xl border border-slate-100 bg-slate-50 p-3"
            >
              <div className="flex items-center gap-2">
                <CircleDot className="h-4 w-4 shrink-0 text-emerald-500" />
                <strong className="min-w-0 break-words text-sm text-slate-900">
                  {driver.name || "سائق"}
                </strong>
              </div>
              <p className="mt-2 text-xs text-slate-600">
                {vehicleTypeLabels[driver.vehicleType] || "مركبة"} ·{" "}
                {driver.vehicleLabel || "بيانات غير مسجلة"}
              </p>
              <div className="mt-3 rounded-xl bg-white p-2 text-xs text-slate-600">
                <p>
                  بداية الوردية:{" "}
                  <strong className="text-slate-900">
                    {formatShiftStart(driver.shiftStartedAt)}
                  </strong>
                </p>
                <p className="mt-1 flex items-center gap-1 font-bold text-emerald-700">
                  <Clock3 className="h-3.5 w-3.5" />
                  المدة: {formatShiftDuration(driver.shiftStartedAt, now)}
                </p>
              </div>
              {driver.phone ? (
                <a
                  href={`tel:${driver.phone}`}
                  className="mt-2 inline-flex items-center gap-1 text-xs font-bold text-sky-700 hover:underline"
                >
                  <Phone className="h-3 w-3" />
                  {driver.phone}
                </a>
              ) : null}
            </div>
          ))}
        </div>
      ) : (
        <p className="mt-4 rounded-2xl bg-slate-50 p-4 text-sm text-slate-500">
          لا يوجد سائق لديه وردية مفتوحة الآن.
        </p>
      )}
    </section>
  );
}
