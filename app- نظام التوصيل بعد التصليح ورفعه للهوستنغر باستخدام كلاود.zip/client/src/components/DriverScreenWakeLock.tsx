import { useEffect, useRef } from "react";

type WakeLockSentinelLike = { release: () => Promise<void> };
type WakeLockNavigator = Navigator & { wakeLock?: { request: (type: "screen") => Promise<WakeLockSentinelLike> } };

export function useDriverScreenWakeLock(enabled: boolean) {
  const lockRef = useRef<WakeLockSentinelLike | null>(null);

  useEffect(() => {
    if (!enabled) return;
    const wakeLock = (navigator as WakeLockNavigator).wakeLock;
    if (!wakeLock) return;
    let disposed = false;
    const requestLock = async () => {
      try {
        const lock = await wakeLock.request("screen");
        if (disposed) { await lock.release(); return; }
        lockRef.current = lock;
      } catch {
        // The browser may require a different power-saving setting; the app remains usable.
      }
    };
    const onVisibilityChange = () => { if (document.visibilityState === "visible") void requestLock(); };
    void requestLock();
    document.addEventListener("visibilitychange", onVisibilityChange);
    return () => {
      disposed = true;
      document.removeEventListener("visibilitychange", onVisibilityChange);
      const lock = lockRef.current;
      lockRef.current = null;
      if (lock) void lock.release();
    };
  }, [enabled]);

  return null;
}

export default function DriverScreenWakeLock({ enabled }: { enabled: boolean }) {
  useDriverScreenWakeLock(enabled);
  return null;
}
