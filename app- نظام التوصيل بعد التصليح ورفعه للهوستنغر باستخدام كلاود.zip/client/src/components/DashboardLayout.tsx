import { useAuth } from "@/_core/hooks/useAuth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  useSidebar,
} from "@/components/ui/sidebar";
import { useLanguage } from "@/i18n";
import { LOCAL_LOGIN_PATH } from "@/lib/local-auth-routing";
import { trpc } from "@/lib/trpc";
import { canAccessDashboardPath } from "@shared/operations";
import { useIsMobile } from "@/hooks/useMobile";
import { Activity, Archive, BarChart3, Building2, ClipboardList, LayoutDashboard, LogOut, MapPinned, Menu, MessageSquare, PanelLeft, Settings, Truck, Users } from "lucide-react";
import { CSSProperties, useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";
import { DashboardLayoutSkeleton } from './DashboardLayoutSkeleton';
import MessagingAlertListener from "./MessagingAlertListener";
import { Button } from "./ui/button";
import LanguageSwitcher from "./LanguageSwitcher";

const logoUrl = "/manus-storage/city-center-logo-user_665f44b4.png";
import ManagerAccountSetup from "./ManagerAccountSetup";
import OpenShiftDriversBanner from "./OpenShiftDriversBanner";

const menuItems = [
  { icon: LayoutDashboard, key: "dashboard", path: "/" },
  { icon: ClipboardList, key: "orderManagement", path: "/orders/manage" },
  { icon: Activity, key: "operationsRoom", path: "/operations-room" },
  { icon: MessageSquare, key: "messaging", path: "/messaging" },
  { icon: Building2, key: "companies", path: "/companies" },
  { icon: MapPinned, key: "area", path: "/locations" },
  { icon: Users, key: "users", path: "/users" },
  { icon: BarChart3, key: "finance", path: "/finance" },
  { icon: Archive, key: "backupsTitle", path: "/backups" },
  { icon: Settings, key: "administration", path: "/platform-settings" },
  { icon: Truck, key: "driver", path: "/driver" },
  { icon: Building2, key: "companyPortal", path: "/company" },
] as const;

const SIDEBAR_WIDTH_KEY = "sidebar-width";
const DEFAULT_WIDTH = 280;
const MIN_WIDTH = 200;
const MAX_WIDTH = 480;
const BUILD_MARKER_FALLBACK = "release-pending";

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const [sidebarWidth, setSidebarWidth] = useState(() => {
    const saved = localStorage.getItem(SIDEBAR_WIDTH_KEY);
    return saved ? parseInt(saved, 10) : DEFAULT_WIDTH;
  });
  const { loading, user } = useAuth();
  const { language, t } = useLanguage();

  useEffect(() => {
    localStorage.setItem(SIDEBAR_WIDTH_KEY, sidebarWidth.toString());
  }, [sidebarWidth]);

  if (loading) {
    return <DashboardLayoutSkeleton />
  }

  if (!user) {
    return (
      <div dir={language === "ar" ? "rtl" : "ltr"} className="flex items-center justify-center min-h-screen">
        <div className="flex flex-col items-center gap-8 p-8 max-w-md w-full">
          <div className="flex flex-col items-center gap-6">
            <h1 className="text-2xl font-semibold tracking-tight text-center">
              {t("loginToContinue")}
            </h1>
            <p className="text-sm text-muted-foreground text-center max-w-sm">
              {t("dashboardLoginHint")}
            </p>
          </div>
          <Button
            onClick={() => window.location.assign(LOCAL_LOGIN_PATH)}
            size="lg"
            className="w-full shadow-lg hover:shadow-xl transition-all"
          >
            {t("loginAction")}
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div dir={language === "ar" ? "rtl" : "ltr"} className="min-h-screen">
    <SidebarProvider
      dir="ltr"
      style={
        {
          "--sidebar-width": `${sidebarWidth}px`,
        } as CSSProperties
      }
    >
      <MessagingAlertListener />
      <DashboardLayoutContent setSidebarWidth={setSidebarWidth}>
        {children}
      </DashboardLayoutContent>
    </SidebarProvider>
    </div>
  );
}

type DashboardLayoutContentProps = {
  children: React.ReactNode;
  setSidebarWidth: (width: number) => void;
};

function DashboardLayoutContent({
  children,
  setSidebarWidth,
}: DashboardLayoutContentProps) {
  const { user, logout } = useAuth();
  const permissionsQuery = trpc.auth.permissions.useQuery(undefined, { enabled: Boolean(user) });
  const brandingQuery = trpc.platform.branding.useQuery(undefined, { staleTime: 60_000 });
  const grantedPermissions = new Set((permissionsQuery.data ?? []).filter((item) => item.granted).map((item) => item.permissionKey));
  const { t, language } = useLanguage();
  const [location, setLocation] = useLocation();
  const { state, toggleSidebar, openMobile, setOpenMobile } = useSidebar();
  const isCollapsed = state === "collapsed";
  const [isResizing, setIsResizing] = useState(false);
  const [buildMarker, setBuildMarker] = useState(BUILD_MARKER_FALLBACK);
  const sidebarRef = useRef<HTMLDivElement>(null);
  const effectiveRoles = user ? [user.role, ...(user.roles ?? [])] : [];
  const canAccess = (path: string) => user ? canAccessDashboardPath(effectiveRoles, path, Array.from(grantedPermissions)) : false;
  const visibleMenuItems = menuItems.filter((item) => canAccess(item.path));
  const fallbackPath = effectiveRoles.includes("admin") || effectiveRoles.includes("supervisor") ? "/" : effectiveRoles.includes("accountant") ? "/finance" : effectiveRoles.includes("company") ? "/company" : "/driver";
  const activeMenuItem = menuItems.find(item => item.path === location);
  const isMobile = useIsMobile();
  const handleLocalLogout = async () => {
    await logout();
    window.location.assign(LOCAL_LOGIN_PATH);
  };

  useEffect(() => {
    if (user && !canAccess(location) && location !== "/404") setLocation(fallbackPath);
  }, [user?.role, user?.roles, location, permissionsQuery.data, fallbackPath]);

  useEffect(() => {
    if (isCollapsed) {
      setIsResizing(false);
    }
  }, [isCollapsed]);

  useEffect(() => {
    let active = true;
    fetch("/api/build-version", { cache: "no-store" })
      .then((response) => response.ok ? response.json() as Promise<{ version?: string }> : null)
      .then((metadata) => {
        if (active && metadata?.version) setBuildMarker(metadata.version);
      })
      .catch(() => undefined);
    return () => { active = false; };
  }, []);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isResizing) return;

      const sidebarLeft = sidebarRef.current?.getBoundingClientRect().left ?? 0;
      const newWidth = e.clientX - sidebarLeft;
      if (newWidth >= MIN_WIDTH && newWidth <= MAX_WIDTH) {
        setSidebarWidth(newWidth);
      }
    };

    const handleMouseUp = () => {
      setIsResizing(false);
    };

    if (isResizing) {
      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "col-resize";
      document.body.style.userSelect = "none";
    }

    return () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    };
  }, [isResizing, setSidebarWidth]);

  return (
    <>
      <div className="relative" ref={sidebarRef}>
        <Sidebar
          dir={language === "ar" ? "rtl" : "ltr"}
          collapsible="icon"
          className="border-r-0"
          disableTransition={isResizing}
        >
          <SidebarHeader className="h-16 justify-center">
            <div className="flex items-center gap-3 px-2 transition-all w-full">
              <LanguageSwitcher />
              <button
                onClick={toggleSidebar}
                className="h-8 w-8 flex items-center justify-center hover:bg-accent rounded-lg transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-ring shrink-0"
                  aria-label={t("menuToggle")}
              >
                <PanelLeft className="h-4 w-4 text-muted-foreground" />
              </button>
              {!isCollapsed ? (
                <div className="flex items-center gap-2 min-w-0">
                  <img src={brandingQuery.data?.logoUrl || logoUrl} alt="" className="h-8 w-8 shrink-0 rounded-lg object-contain" />
                  <span className="font-semibold tracking-tight truncate">
                    {brandingQuery.data?.brandName || t("brandName")}
                  </span>
                </div>
              ) : null}
            </div>
          </SidebarHeader>

          <SidebarContent className="gap-0">
            <SidebarMenu className="px-2 py-1">
              {visibleMenuItems.map(item => {
                const isActive = location === item.path;
                return (
                  <SidebarMenuItem key={item.path}>
                    <SidebarMenuButton
                      isActive={isActive}
                      onClick={() => { setLocation(item.path); if (isMobile) setOpenMobile(false); }}
                      tooltip={t(item.key)}
                      className={`h-10 transition-all font-normal`}
                    >
                      <item.icon
                        className={`h-4 w-4 ${isActive ? "text-primary" : ""}`}
                      />
                      <span>{t(item.key)}</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarContent>

          <SidebarFooter className="p-3">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-3 rounded-lg px-1 py-1 hover:bg-accent/50 transition-colors w-full text-left group-data-[collapsible=icon]:justify-center focus:outline-none focus-visible:ring-2 focus-visible:ring-ring">
                  <Avatar className="h-9 w-9 border shrink-0">
                    <AvatarFallback className="text-xs font-medium">
                      {user?.name?.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0 group-data-[collapsible=icon]:hidden">
                    <p className="text-sm font-medium truncate leading-none">
                      {user?.name || "-"}
                    </p>
                    <p className="text-xs text-muted-foreground truncate mt-1.5">
                      {user?.email || "-"}
                    </p>
                  </div>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem
                  onClick={() => { void handleLocalLogout(); }}
                  className="cursor-pointer text-destructive focus:text-destructive"
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>{t("logout")}</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <p className="mb-2 text-center text-[10px] text-muted-foreground group-data-[collapsible=icon]:hidden">{t("releaseMarker")} {buildMarker}</p>
          </SidebarFooter>
        </Sidebar>
        <div
          className={`absolute top-0 right-0 w-1 h-full cursor-col-resize hover:bg-primary/20 transition-colors ${isCollapsed ? "hidden" : ""}`}
          onMouseDown={() => {
            if (isCollapsed) return;
            setIsResizing(true);
          }}
          style={{ zIndex: 50 }}
        />
      </div>

      <SidebarInset dir={language === "ar" ? "rtl" : "ltr"}>
        {isMobile && (
          <div className="flex border-b h-14 items-center justify-between bg-background/95 px-2 backdrop-blur supports-[backdrop-filter]:backdrop-blur sticky top-0 z-40">
            <div className="flex items-center gap-2">
              <Button type="button" variant="outline" size="icon" data-sidebar-mobile-trigger aria-label={t("menuToggle")} aria-expanded={openMobile} onClick={() => setOpenMobile(!openMobile)} className="h-10 w-10 rounded-xl border-slate-200 bg-white shadow-sm">
                <Menu className="h-5 w-5" />
              </Button>
              <LanguageSwitcher />
              <div className="flex items-center gap-3">
                <div className="flex flex-col gap-1">
                  <span className="tracking-tight text-foreground">
                    {activeMenuItem ? t(activeMenuItem.key) : t("dashboard")}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}
          <main className="min-w-0 flex-1 p-4">{location === "/users" && effectiveRoles.includes("admin") ? <ManagerAccountSetup /> : null}{location === "/orders/new" || location === "/orders/manage" || location === "/operations-room" ? <OpenShiftDriversBanner /> : null}{children}</main>
      </SidebarInset>
    </>
  );
}
