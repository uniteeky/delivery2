import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/i18n";
import { useUiText } from "@/lib/uiText";
import { canSubmitManualOrderId, filterRecentOrderOptions, normalizeManualOrderId, recentOrdersPickerState } from "@shared/trips-panel";
import { Route } from "lucide-react";
import { friendlyError } from "@/lib/errorMessage";

export default function TripsPanel() {
  const { t, language } = useLanguage();
  const tr = useUiText();
  const [driverId, setDriverId] = useState("");
  const [label, setLabel] = useState("");
  const [orderId, setOrderId] = useState("");
  const [orderSearch, setOrderSearch] = useState("");
  const driverTrips = trpc.trips.listForDriver.useQuery({ driverId: Number(driverId) }, { enabled: Number(driverId) > 0 });
  const recentOrders = trpc.dashboard.recentOrders.useQuery();
  const selectableOrders = filterRecentOrderOptions(recentOrders.data, orderSearch);
  const pickerState = recentOrdersPickerState({ isLoading: recentOrders.isLoading, hasError: Boolean(recentOrders.error), optionCount: selectableOrders.length });
  const createTrip = trpc.trips.create.useMutation({ onSuccess: () => { setLabel(""); void driverTrips.refetch(); } });
  const addOrder = trpc.trips.addOrder.useMutation({ onSuccess: () => { setOrderId(""); setOrderSearch(""); void driverTrips.refetch(); } });
  const setStatus = trpc.trips.setStatus.useMutation({ onSuccess: () => void driverTrips.refetch() });
  const locale = language === "ar" ? "ar-KW" : language === "bn" ? "bn-BD" : language === "hi" ? "hi-IN" : "en-KW";
  const statusLabel = (status: string) => status === "open" ? t("tripOpenStatus") : status === "active" ? t("tripActiveStatus") : t("tripClosedStatus");

  return (
    <Card dir={language === "ar" ? "rtl" : "ltr"} className="mt-6 rounded-3xl border-sky-100 bg-sky-50/40 shadow-sm">
      <CardHeader><CardTitle className="flex items-center gap-2 text-xl font-black"><Route className="h-5 w-5 text-sky-600" />{t("tripManagement")}</CardTitle><p className="text-sm leading-7 text-slate-600">{t("tripsDescription")}</p></CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-3 sm:grid-cols-3">
          <Input inputMode="numeric" placeholder={t("driverFileNumber")} value={driverId} onChange={(event) => setDriverId(event.target.value.replace(/\D/g, ""))} />
          <Input placeholder={t("optionalTripName")} value={label} onChange={(event) => setLabel(event.target.value)} />
          <Button disabled={!Number(driverId) || createTrip.isPending} onClick={() => createTrip.mutate({ driverId: Number(driverId), label: label || undefined })} className="rounded-xl bg-sky-600 text-white hover:bg-sky-700">{createTrip.isPending ? t("creatingTrip") : t("createTrip")}</Button>
        </div>
        {createTrip.error ? <p className="text-sm text-red-700">{friendlyError(createTrip.error)}</p> : null}
        {driverTrips.error ? <p className="text-sm text-red-700">{t("loadDriverTripsError")} <Button size="sm" variant="outline" onClick={() => void driverTrips.refetch()} className="mr-2 rounded-lg">{t("retry")}</Button></p> : null}
        <div className="grid gap-3">
          {driverTrips.data?.map((trip) => {
            const isAutomatic = trip.label?.startsWith("رحلة تلقائية");
            return <div key={trip.id} className="rounded-2xl border border-white bg-white p-4"><div className="flex flex-wrap items-center justify-between gap-2"><div><div className="flex items-center gap-2"><p className="font-black">{trip.label || `${t("trips")} #${trip.id}`}</p>{isAutomatic ? <Badge className="rounded-full bg-emerald-100 text-emerald-700 hover:bg-emerald-100">{t("automaticGrouped")}</Badge> : <Badge className="rounded-full bg-violet-100 text-violet-700 hover:bg-violet-100">{t("manualTrip")}</Badge>}</div><p className="text-xs text-slate-500">{t("driverLabel")}: {trip.driverId} · {trip.orders.length} {t("orderCount")}</p>{isAutomatic ? <p className="mt-1 text-xs text-emerald-700">{t("automaticTripReason")}</p> : <p className="mt-1 text-xs text-violet-700">{t("manualTripReason")}</p>}</div><Badge className="rounded-full bg-slate-100 text-slate-700 hover:bg-slate-100">{statusLabel(trip.status)}</Badge></div><div className="mt-3 flex flex-wrap gap-2">{trip.status !== "closed" ? <><Input className="w-40" inputMode="numeric" placeholder={t("searchOrder")} value={orderSearch || orderId} onChange={(event) => { const value = event.target.value; setOrderSearch(value); setOrderId(normalizeManualOrderId(value)); }} /><select aria-label={t("selectOrder")} disabled={pickerState.disabled} className="h-9 max-w-[240px] rounded-xl border border-slate-200 bg-white px-2 text-xs" value="" onChange={(event) => { setOrderId(event.target.value); setOrderSearch(""); }}><option value="">{recentOrders.isLoading ? t("loading") : recentOrders.error ? t("tripOrdersLoadError") : selectableOrders.length === 0 ? t("tripNoOrders") : t("selectOrder")}</option>{selectableOrders.map((order) => <option key={order.id} value={order.id}>{order.orderNumber} · {order.status} · {tr("المطلوب")} {Number(order.cashToCollectAmount ?? 0).toFixed(3)} {tr("د.ك")}{order.cashCollectionRecorded ? ` · ${tr("المستلم")} ${Number(order.cashCollectedAmount ?? 0).toFixed(3)} ${tr("د.ك")}` : ""}{order.cashCollectionNote ? ` · ${tr("ملاحظة التحصيل")}: ${order.cashCollectionNote}` : ""}</option>)}</select>{recentOrders.error ? <><span className="text-xs text-rose-700">{t("tripOrdersLoadError")}</span><Button type="button" size="sm" variant="outline" onClick={() => void recentOrders.refetch()} className="rounded-xl">{t("retry")}</Button></> : !recentOrders.isLoading && selectableOrders.length === 0 ? <span className="text-xs text-slate-500">{t("tripNoOrders")}</span> : null}<Button size="sm" disabled={!canSubmitManualOrderId(orderId) || addOrder.isPending} onClick={() => addOrder.mutate({ tripId: trip.id, orderId: Number(orderId) })} className="rounded-xl bg-violet-600 text-white hover:bg-violet-700">{t("newOrder")}</Button>{trip.status === "open" ? <Button size="sm" variant="outline" onClick={() => setStatus.mutate({ tripId: trip.id, status: "active" })} className="rounded-xl">{t("start")}</Button> : <Button size="sm" variant="outline" onClick={() => setStatus.mutate({ tripId: trip.id, status: "closed" })} className="rounded-xl text-rose-700">{t("finish")}</Button>}</> : <span className="text-xs text-slate-500">{t("closedTripMessage")}</span>}</div>{addOrder.error ? <p className="mt-2 text-sm text-red-700">{friendlyError(addOrder.error)}</p> : null}</div>;
          })}
        </div>
      </CardContent>
    </Card>
  );
}
