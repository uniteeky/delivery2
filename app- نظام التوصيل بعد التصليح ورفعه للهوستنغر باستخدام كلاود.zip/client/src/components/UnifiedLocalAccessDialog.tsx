import { useState } from "react";
import { ArrowRight, LockKeyhole, ShieldCheck } from "lucide-react";
import { useLocation } from "wouter";
import { useLanguage } from "@/i18n";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function UnifiedLocalAccessDialog() {
  const { t, language } = useLanguage();
  const [, navigate] = useLocation();
  const [open, setOpen] = useState(false);
  const [civilId, setCivilId] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setPending(true);
    setError("");
    try {
      const response = await fetch("/api/auth/local-login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ civilId, password }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || t("loginErrorFallback"));
      setOpen(false);
      navigate(data.role === "driver" ? "/driver" : data.role === "company" ? "/company" : "/");
      window.location.reload();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : t("loginErrorFallback"));
    } finally {
      setPending(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="min-w-[12rem] rounded-full bg-slate-950 px-4 text-white shadow-lg shadow-slate-200 hover:bg-slate-800">
          {t("publicSystemLogin")} / {t("registerNew")} <ArrowRight className="mr-2 h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent dir={language === "ar" ? "rtl" : "ltr"} className="max-h-[92vh] overflow-y-auto rounded-[2rem] border-orange-100 bg-[#fffdf9] p-0 text-slate-900 shadow-2xl sm:max-w-md">
        <DialogHeader className="border-b border-orange-100 bg-gradient-to-br from-orange-50 via-white to-emerald-50 p-6 text-start sm:p-8">
          <div className="flex items-start gap-3">
            <div className="rounded-2xl bg-slate-950 p-3 text-orange-300"><LockKeyhole className="h-6 w-6" /></div>
            <div>
              <DialogTitle className="text-2xl font-black">{t("localLoginTitle")}</DialogTitle>
              <DialogDescription className="mt-2 text-sm leading-7 text-slate-600">{t("localLoginHint")}</DialogDescription>
            </div>
          </div>
        </DialogHeader>
        <div className="p-6 sm:p-8">
          <form onSubmit={submit} className="space-y-5">
            <div className="space-y-2"><Label htmlFor="unified-civil-id">{t("civilId")}</Label><Input id="unified-civil-id" inputMode="numeric" maxLength={12} required value={civilId} onChange={(event) => setCivilId(event.target.value)} placeholder={t("civilIdPlaceholder")} className="h-12 rounded-xl border-slate-200 bg-white" /></div>
            <div className="space-y-2"><Label htmlFor="unified-password">{t("password")}</Label><Input id="unified-password" type="password" minLength={8} required value={password} onChange={(event) => setPassword(event.target.value)} placeholder={t("passwordPlaceholder")} className="h-12 rounded-xl border-slate-200 bg-white" /></div>
            {error ? <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700">{error}</p> : null}
            <div className="rounded-2xl bg-slate-100 p-4 text-sm leading-7 text-slate-600"><ShieldCheck className="mb-1 inline h-4 w-4 text-emerald-600" /> {t("secureNote")}</div>
            <Button type="submit" disabled={pending} className="h-12 w-full rounded-xl bg-orange-500 font-bold text-white hover:bg-orange-600">{pending ? t("signingIn") : t("loginSafe")}</Button>
          </form>
          <div className="my-6 flex items-center gap-3 text-xs font-bold text-slate-400"><span className="h-px flex-1 bg-slate-200" /><span>{t("or")}</span><span className="h-px flex-1 bg-slate-200" /></div>
          <Button type="button" variant="outline" onClick={() => { setOpen(false); navigate("/register-driver"); }} className="h-12 w-full rounded-xl border-orange-200 bg-white font-bold text-orange-700 hover:bg-orange-50">{t("registerNew")}</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
