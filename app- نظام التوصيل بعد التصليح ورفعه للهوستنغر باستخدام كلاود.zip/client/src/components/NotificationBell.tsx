import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/i18n";
import { Bell, Volume2 } from "lucide-react";
import { playDriverAlert, unlockDriverAudio } from "@/lib/driverAudio";
import { showBrowserNotification } from "@/lib/browserNotifications";
import { useEffect, useRef, useState } from "react";

export default function NotificationBell() {
  const { t } = useLanguage();
  const [open, setOpen] = useState(false);
  const notifications = trpc.notifications.list.useQuery(undefined, { refetchInterval: 10_000, refetchIntervalInBackground: true });
  const markRead = trpc.notifications.markRead.useMutation({ onSuccess: () => notifications.refetch() });
  const unread = (notifications.data ?? []).filter((item) => !item.readAt);
  const previousUnreadIds = useRef<Set<number> | null>(null);
  const seenIds = useRef<Set<number> | null>(null);
  if (!seenIds.current) {
    try { seenIds.current = typeof window === "undefined" ? new Set<number>() : new Set<number>(JSON.parse(window.localStorage.getItem("city-center-seen-notification-alerts-v1") ?? "[]")); } catch { seenIds.current = new Set<number>(); }
  }
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission | "unsupported">("default");
  useEffect(() => { if (typeof window !== "undefined" && "Notification" in window) setNotificationPermission(window.Notification.permission); }, []);
  useEffect(() => {
    if (notifications.data === undefined || typeof window === "undefined") return;
    const seen = seenIds.current ?? new Set<number>();
    const unreadIds = new Set(unread.map((item) => item.id));
    const newItems = unread.filter((item) => !seen.has(item.id));
    if (previousUnreadIds.current === null) {
      const acknowledgedBeforeReload = unread.filter((item) => seen.has(item.id));
      acknowledgedBeforeReload.forEach((item) => markRead.mutate({ id: item.id }));
      unread.forEach((item) => seen.add(item.id));
      try { window.localStorage.setItem("city-center-seen-notification-alerts-v1", JSON.stringify(Array.from(seen).slice(-400))); } catch { /* storage is optional */ }
      previousUnreadIds.current = unreadIds;
      return;
    }
    const deliveryItems = newItems.filter((item) => item.title !== "رسالة داخلية جديدة");
    if (deliveryItems.length) {
      const newest = deliveryItems[deliveryItems.length - 1]!;
      void playDriverAlert();
      try { if ("vibrate" in navigator) navigator.vibrate([180, 80, 180]); } catch { /* vibration is optional */ }
      if (document.hidden && notificationPermission === "granted") void showBrowserNotification(newest.title || t("notificationFallbackTitle"), newest.body || t("notificationFallbackBody"), `city-center-notification-${newest.id}`);
      deliveryItems.forEach((item) => { seen.add(item.id); markRead.mutate({ id: item.id }); });
      try { window.localStorage.setItem("city-center-seen-notification-alerts-v1", JSON.stringify(Array.from(seen).slice(-400))); } catch { /* storage is optional */ }
    }
    previousUnreadIds.current = unreadIds;
  }, [notifications.data, unread, notificationPermission]);
  const enableNotifications = async () => { const unlocked = await unlockDriverAudio(); if (typeof window === "undefined" || !("Notification" in window)) { setNotificationPermission("unsupported"); return; } const permission = await window.Notification.requestPermission(); setNotificationPermission(permission); if (!unlocked) notifications.refetch(); };
  return <div className="relative"><Button type="button" variant="outline" onClick={() => setOpen((value) => !value)} className="relative h-11 rounded-xl bg-white"><Bell className="ml-2 h-4 w-4" /> {t("notifications")}{unread.length > 0 && <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-orange-500 px-1 text-[10px] font-black text-white">{unread.length}</span>}</Button>{open && <div className="absolute left-0 top-14 z-50 w-80 max-w-[calc(100vw-2rem)] rounded-2xl border border-slate-100 bg-white p-3 text-right shadow-xl"><div className="mb-2 flex items-center justify-between"><p className="font-black">{t("notifications")}</p><div className="flex items-center gap-2"><Volume2 className="h-4 w-4 text-orange-500" />{notificationPermission === "default" && <button type="button" onClick={enableNotifications} className="text-[11px] font-bold text-orange-600 hover:underline">{t("notificationsEnableDevice")}</button>}</div></div>{unread.length === 0 ? <p className="p-5 text-center text-sm text-slate-500">{t("notificationsNone")}</p> : <div className="space-y-2">{unread.slice(0, 8).map((item) => <button key={item.id} onClick={() => markRead.mutate({ id: item.id })} className="w-full rounded-xl bg-orange-50 p-3 text-right hover:bg-orange-100"><p className="text-sm font-bold text-slate-900">{item.title}</p><p className="mt-1 text-xs leading-5 text-slate-600">{item.body}</p></button>)}</div>}</div>}</div>;
}
