import { Bell, CheckCircle2, Download, MapPin, Package, Volume2 } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { useLanguage } from "@/i18n";
import { DRIVER_AUDIO_READY_EVENT, startRepeatingDriverAlert, stopRepeatingDriverAlert, unlockDriverAudio } from "@/lib/driverAudio";
import { showBrowserNotification } from "@/lib/browserNotifications";

type InstallPromptEvent = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: "accepted" | "dismissed" }> };

type DriverAlertOrder = {
  id: number;
  orderNumber: string;
  customerName?: string | null;
  pickupContactName?: string | null;
  cashToCollectAmount?: string | number | null;
  cashCollectionNote?: string | null;
  area?: string | null;
  pickupAddress?: string | null;
  deliveryAddress?: string | null;
  transferredByName?: string | null;
};

type DriverAlertProps = { orders: DriverAlertOrder[] };

function readAcknowledgedOrderIds() {
  if (typeof window === "undefined") return new Set<number>();
  try {
    const stored = window.localStorage.getItem("city-center-acknowledged-order-alerts-v2") ?? window.sessionStorage.getItem("city-center-acknowledged-order-alerts") ?? "[]";
    return new Set<number>(JSON.parse(stored));
  } catch { return new Set<number>(); }
}

function saveAcknowledgedOrderIds(ids: Set<number>) {
  if (typeof window !== "undefined") window.localStorage.setItem("city-center-acknowledged-order-alerts-v2", JSON.stringify(Array.from(ids)));
}

export default function DriverAlerts({ orders }: DriverAlertProps) {
  const { t, language } = useLanguage();
  const [permission, setPermission] = useState<NotificationPermission | "unsupported">(() => typeof Notification === "undefined" ? "unsupported" : Notification.permission);
  const [installEvent, setInstallEvent] = useState<InstallPromptEvent | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [audioReady, setAudioReady] = useState(() => typeof window !== "undefined" && window.sessionStorage.getItem("city-center-driver-audio-ready") === "true");
  const [pendingOrders, setPendingOrders] = useState<DriverAlertOrder[]>([]);
  const knownIdsRef = useRef<number[]>([]);
  const acknowledgedIdsRef = useRef<Set<number>>(readAcknowledgedOrderIds());

  useEffect(() => {
    const handler = (event: Event) => { event.preventDefault(); setInstallEvent(event as InstallPromptEvent); };
    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  useEffect(() => {
    const handleAudioReady = () => setAudioReady(true);
    window.addEventListener(DRIVER_AUDIO_READY_EVENT, handleAudioReady);
    return () => window.removeEventListener(DRIVER_AUDIO_READY_EVENT, handleAudioReady);
  }, []);

  const orderSignature = orders.map((order) => order.id).join(",");
  useEffect(() => {
    const newOrders = orders.filter((order) => !knownIdsRef.current.includes(order.id) && !acknowledgedIdsRef.current.has(order.id));
    knownIdsRef.current = orders.map((order) => order.id);
    if (!newOrders.length) return;
    newOrders.forEach((order) => acknowledgedIdsRef.current.add(order.id));
    saveAcknowledgedOrderIds(acknowledgedIdsRef.current);
    const body = newOrders.length === 1 && newOrders[0]?.transferredByName ? `الطلب محول من ${newOrders[0].transferredByName}.` : `${t("addedOrdersAlert")} ${newOrders.length} ${t("ordersToAccount")}`;
    if (permission === "granted") void showBrowserNotification(t("newDeliveryAlert"), body, `city-center-orders-${newOrders.map((order) => order.id).join("-")}`);
    try { if ("vibrate" in navigator) navigator.vibrate([240, 100, 240, 100, 420]); } catch { /* vibration is browser/device dependent */ }
    setNotice(body);
    setPendingOrders((current) => [...current, ...newOrders.filter((candidate) => !current.some((order) => order.id === candidate.id))]);
  }, [orderSignature, permission, t]);

  const activeOrder = pendingOrders[0] ?? null;
  useEffect(() => {
    if (!activeOrder) { stopRepeatingDriverAlert(); return; }
    if (audioReady) startRepeatingDriverAlert();
    return () => stopRepeatingDriverAlert();
  }, [activeOrder?.id, audioReady]);

  useEffect(() => () => stopRepeatingDriverAlert(), []);

  const acknowledge = () => {
    if (!activeOrder) return;
    acknowledgedIdsRef.current.add(activeOrder.id);
    saveAcknowledgedOrderIds(acknowledgedIdsRef.current);
    try { if ("vibrate" in navigator) navigator.vibrate(0); } catch { /* optional device behavior */ }
    stopRepeatingDriverAlert();
    setPendingOrders((current) => current.filter((order) => order.id !== activeOrder.id));
    setNotice(null);
  };

  const requestPermission = async () => {
    const unlocked = await unlockDriverAudio();
    setAudioReady(unlocked);
    if (unlocked && activeOrder) startRepeatingDriverAlert();
    if (typeof Notification === "undefined") { setNotice(unlocked ? t("alertsEnabled") : t("notificationsUnsupported")); return; }
    const result = await Notification.requestPermission();
    setPermission(result);
    setNotice(result === "granted" ? t("alertsEnabled") : unlocked ? t("alertsEnabled") : t("alertsDeniedHint"));
  };

  const install = async () => {
    if (!installEvent) return;
    await installEvent.prompt();
    const result = await installEvent.userChoice;
    if (result.outcome === "accepted") setInstallEvent(null);
  };

  return <div className="space-y-2" aria-live="polite">
    {notice && !activeOrder ? <div role="alert" className="flex items-center gap-3 rounded-2xl border border-orange-300/30 bg-orange-500/15 p-3 text-sm text-orange-100"><Volume2 className="h-5 w-5 shrink-0" /><span>{notice}</span></div> : null}
    {activeOrder ? <div role="dialog" aria-modal="true" aria-label="طلب جديد" className="fixed inset-0 z-[70] flex items-center justify-center bg-slate-950/75 p-4 backdrop-blur-sm"><div dir={language === "ar" ? "rtl" : "ltr"} className="w-full max-w-md overflow-hidden rounded-[2rem] border border-orange-300/30 bg-white text-right shadow-2xl"><div className="bg-gradient-to-l from-orange-500 to-amber-400 px-6 py-5 text-white"><div className="flex items-center gap-3"><span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/20"><Package className="h-6 w-6" /></span><div><p className="text-sm font-bold text-orange-50">تنبيه طلب جديد</p><h2 className="text-xl font-black">وصل لك طلب توصيل</h2></div></div></div><div className="space-y-4 p-6"><div className="rounded-2xl bg-slate-50 p-4"><p className="text-xs font-bold text-slate-500">رقم الطلب</p><p className="mt-1 text-xl font-black text-slate-900">{activeOrder.orderNumber}</p>{activeOrder.transferredByName ? <p className="mt-2 rounded-xl bg-amber-100 px-3 py-2 text-sm font-black text-amber-900">هذا الطلب محول من: {activeOrder.transferredByName}</p> : null}{activeOrder.customerName ? <p className="mt-2 text-sm font-semibold text-slate-700">{t("recipientName")}: {activeOrder.customerName}</p> : null}<p className="mt-2 rounded-xl bg-emerald-100 px-3 py-2 text-sm font-black text-emerald-900">المبلغ المطلوب تحصيله: {Number(activeOrder.cashToCollectAmount ?? 0).toFixed(3)} د.ك</p>{activeOrder.cashCollectionNote ? <p className="mt-1 text-xs font-semibold text-amber-800">ملاحظة التحصيل: {activeOrder.cashCollectionNote}</p> : null}{activeOrder.pickupContactName ? <p className="mt-1 text-xs text-slate-600">مستلم الطلب: {activeOrder.pickupContactName}</p> : null}{activeOrder.area ? <p className="mt-1 text-sm text-slate-600">{t("area")}: {activeOrder.area}</p> : null}</div>{activeOrder.pickupAddress ? <div className="flex gap-3 rounded-2xl border border-sky-100 bg-sky-50 p-4 text-slate-800"><MapPin className="mt-0.5 h-5 w-5 shrink-0 text-sky-600" /><div><p className="text-xs font-bold text-sky-700">{t("pickupAddress")}</p><p className="mt-1 text-sm leading-6">{activeOrder.pickupAddress}</p></div></div> : null}{activeOrder.deliveryAddress ? <div className="flex gap-3 rounded-2xl border border-orange-100 bg-orange-50 p-4 text-slate-800"><MapPin className="mt-0.5 h-5 w-5 shrink-0 text-orange-600" /><div><p className="text-xs font-bold text-orange-700">{t("deliveryAddress")}</p><p className="mt-1 text-sm leading-6">{activeOrder.deliveryAddress}</p></div></div> : null}{!audioReady ? <button type="button" onClick={() => void requestPermission()} className="flex w-full items-center justify-center gap-2 rounded-2xl border border-orange-200 bg-orange-50 px-5 py-3 font-bold text-orange-800"><Volume2 className="h-5 w-5" />تفعيل صوت التنبيه</button> : null}<button type="button" autoFocus onClick={acknowledge} className="flex h-13 w-full items-center justify-center gap-2 rounded-2xl bg-emerald-600 px-5 py-3 font-black text-white shadow-lg shadow-emerald-600/20 transition hover:bg-emerald-700 active:scale-[0.98]"><CheckCircle2 className="h-5 w-5" />استقبل الطلب</button><p className="text-center text-xs text-slate-500">سيتم إيقاف الجرس والاهتزاز بعد الاستقبال.</p></div></div></div> : null}
    <div className="flex flex-wrap gap-2">
      {(!audioReady || (permission !== "granted" && permission !== "unsupported")) ? <button onClick={() => void requestPermission()} className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-xs text-slate-200 hover:bg-white/10"><Bell className="h-4 w-4 text-orange-300" /> {t("enableAlerts")}</button> : null}
      {installEvent ? <button onClick={() => void install()} className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-xs text-slate-200 hover:bg-white/10"><Download className="h-4 w-4 text-sky-300" /> {t("addToHome")}</button> : null}
    </div>
  </div>;
}
