import { describe, expect, it } from "vitest";
import { supportedLanguages, translations } from "./i18n";

describe("four-language translation coverage", () => {
  it("keeps every supported language aligned with the Arabic key set", () => {
    const keys = Object.keys(translations.ar).sort();
    for (const language of Object.keys(supportedLanguages) as Array<keyof typeof supportedLanguages>) {
      expect(Object.keys(translations[language]).sort()).toEqual(keys);
      for (const key of keys) expect(String(translations[language][key as keyof typeof translations.ar]).trim()).not.toBe("");
    }
  });
});
