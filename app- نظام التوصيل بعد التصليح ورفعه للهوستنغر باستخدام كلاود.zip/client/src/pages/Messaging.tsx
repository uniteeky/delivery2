import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/i18n";
import { useUiText } from "@/lib/uiText";
import { AudioLines, ImagePlus, Loader2, MessageCircleMore, Mic, Paperclip, Plus, RefreshCw, Send, Square, UsersRound, X } from "lucide-react";
import { useEffect, useMemo, useRef, useState, type ChangeEvent, type FormEvent } from "react";
import { friendlyError } from "@/lib/errorMessage";

const MAX_ATTACHMENT_SIZE = 10 * 1024 * 1024;
const MAX_ATTACHMENTS = 4;
type AttachmentType = "image" | "audio";
type PendingAttachment = { id: string; file: File; type: AttachmentType; previewUrl?: string };

function readFileAsBase64(file: File, tr: (arabic: string) => string): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(",")[1] ?? "");
    reader.onerror = () => reject(new Error(tr("تعذر قراءة الملف")));
    reader.readAsDataURL(file);
  });
}

function formatFileSize(size: number) {
  return size >= 1024 * 1024 ? `${(size / 1024 / 1024).toFixed(1)} MB` : `${Math.max(1, Math.round(size / 1024))} KB`;
}

export default function Messaging() {
  const { language } = useLanguage();
  const tr = useUiText();
  const { user } = useAuth();
  const locale = language === "ar" ? "ar-KW" : language === "bn" ? "bn-BD" : language === "hi" ? "hi-IN" : "en-KW";
  const canCreateGroups = user?.role === "admin" || user?.role === "supervisor" || user?.roles?.includes("admin") || user?.roles?.includes("supervisor");
  const [selectedThreadId, setSelectedThreadId] = useState<number | null>(null);
  const [selectedRecipientIds, setSelectedRecipientIds] = useState<number[]>([]);
  const [threadKind, setThreadKind] = useState<"direct" | "group">("direct");
  const [message, setMessage] = useState("");
  const [threadTitle, setThreadTitle] = useState("");
  const [attachments, setAttachments] = useState<PendingAttachment[]>([]);
  const [notice, setNotice] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const audioInputRef = useRef<HTMLInputElement>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const recorderStreamRef = useRef<MediaStream | null>(null);
  const messageEndRef = useRef<HTMLDivElement>(null);

  const me = trpc.auth.me.useQuery();
  const recipients = trpc.messaging.recipients.useQuery(undefined, { staleTime: 60_000 });
  const threads = trpc.messaging.listThreads.useQuery(undefined, { refetchInterval: 10_000, refetchIntervalInBackground: true });
  const messages = trpc.messaging.listMessages.useQuery(
    { threadId: selectedThreadId ?? 0, limit: 100 },
    { enabled: Boolean(selectedThreadId), refetchInterval: 5_000, refetchIntervalInBackground: true },
  );
  const utils = trpc.useUtils();
  const createThread = trpc.messaging.createThread.useMutation({
    onSuccess: async ({ threadId }) => {
      setSelectedThreadId(threadId);
      setThreadTitle("");
      setSelectedRecipientIds([]);
      await threads.refetch();
      setNotice(tr("تم إنشاء المحادثة."));
    },
    onError: (error) => setNotice(error.message),
  });
  const send = trpc.messaging.send.useMutation({
    onSuccess: async () => {
      setMessage("");
      attachments.forEach((attachment) => attachment.previewUrl && URL.revokeObjectURL(attachment.previewUrl));
      setAttachments([]);
      await Promise.all([messages.refetch(), utils.messaging.listThreads.invalidate(), utils.notifications.list.invalidate()]);
      setNotice(tr("تم إرسال الرسالة."));
    },
    onError: (error) => setNotice(error.message),
  });
  const peopleById = useMemo(
    () => new Map([...(recipients.data ?? []), ...(me.data ? [{ id: me.data.id, name: me.data.name, role: me.data.role }] : [])].map((person) => [person.id, person])),
    [recipients.data, me.data],
  );

  useEffect(() => {
    if (!selectedThreadId && threads.data?.[0]) setSelectedThreadId(threads.data[0].id);
  }, [selectedThreadId, threads.data]);
  useEffect(() => {
    messageEndRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages.data]);
  useEffect(() => () => {
    recorderRef.current?.stop();
    recorderStreamRef.current?.getTracks().forEach((track) => track.stop());
  }, []);

  const selected = threads.data?.find((thread) => thread.id === selectedThreadId);
  const toggleRecipient = (id: number) => {
    if (threadKind === "direct") {
      setSelectedRecipientIds([id]);
      return;
    }
    setSelectedRecipientIds((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  };
  const addFiles = (files: FileList | null, type: AttachmentType) => {
    if (!files?.length) return;
    const next = Array.from(files);
    const accepted = next.filter((file) => {
      const matchesType = type === "image" ? file.type.startsWith("image/") : file.type.startsWith("audio/");
      if (!matchesType || file.size > MAX_ATTACHMENT_SIZE) return false;
      return true;
    });
    if (accepted.length !== next.length) setNotice(tr("يُسمح بالصور أو التسجيلات الصوتية حتى 10 ميجابايت للملف."));
    setAttachments((current) => {
      const available = Math.max(0, MAX_ATTACHMENTS - current.length);
      if (accepted.length > available) setNotice(`${tr("يمكن إرفاق")} ${MAX_ATTACHMENTS} ${tr("ملفات كحد أقصى في الرسالة.")}`);
      return [...current, ...accepted.slice(0, available).map((file) => ({ id: crypto.randomUUID(), file, type, previewUrl: type === "image" ? URL.createObjectURL(file) : undefined }))];
    });
  };
  const handleImagePick = (event: ChangeEvent<HTMLInputElement>) => {
    addFiles(event.target.files, "image");
    event.target.value = "";
  };
  const handleAudioPick = (event: ChangeEvent<HTMLInputElement>) => {
    addFiles(event.target.files, "audio");
    event.target.value = "";
  };
  const removeAttachment = (id: string) => setAttachments((current) => {
    const target = current.find((attachment) => attachment.id === id);
    if (target?.previewUrl) URL.revokeObjectURL(target.previewUrl);
    return current.filter((attachment) => attachment.id !== id);
  });
  const startRecording = async () => {
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") {
      setNotice(tr("التسجيل الصوتي غير مدعوم في هذا المتصفح. يمكنك إرفاق ملف صوتي بدلاً من ذلك."));
      return;
    }
    if (attachments.length >= MAX_ATTACHMENTS) {
      setNotice(`${tr("يمكن إرفاق")} ${MAX_ATTACHMENTS} ${tr("ملفات كحد أقصى في الرسالة.")}`);
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      const chunks: BlobPart[] = [];
      recorder.ondataavailable = (event) => { if (event.data.size) chunks.push(event.data); };
      recorder.onstop = () => {
        const blob = new Blob(chunks, { type: recorder.mimeType || "audio/webm" });
        stream.getTracks().forEach((track) => track.stop());
        recorderStreamRef.current = null;
        if (blob.size > MAX_ATTACHMENT_SIZE) {
          setNotice(tr("التسجيل أطول من الحجم المسموح. سجّل رسالة أقصر من 10 ميجابايت."));
          return;
        }
        const extension = recorder.mimeType.includes("ogg") ? "ogg" : recorder.mimeType.includes("mp4") ? "m4a" : "webm";
        const file = new File([blob], `تسجيل-${new Date().toISOString()}.${extension}`, { type: recorder.mimeType || "audio/webm" });
        setAttachments((current) => current.length >= MAX_ATTACHMENTS ? current : [...current, { id: crypto.randomUUID(), file, type: "audio" }]);
      };
      recorderRef.current = recorder;
      recorderStreamRef.current = stream;
      recorder.start();
      setIsRecording(true);
      setNotice(tr("جارٍ تسجيل الرسالة الصوتية… اضغط إيقاف عند الانتهاء."));
    } catch {
      setNotice(tr("تعذر الوصول إلى الميكروفون. اسمح باستخدامه من إعدادات المتصفح أو أرفق ملفاً صوتياً."));
    }
  };
  const stopRecording = () => {
    recorderRef.current?.stop();
    recorderRef.current = null;
    setIsRecording(false);
  };
  const submitThread = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (threadKind === "direct" && selectedRecipientIds.length !== 1) return setNotice(tr("اختر شخصاً واحداً للمحادثة الفردية."));
    if (threadKind === "group" && selectedRecipientIds.length < 2) return setNotice(tr("اختر عضوين على الأقل لإنشاء القروب."));
    createThread.mutate({ type: threadKind, title: threadKind === "group" ? threadTitle.trim() || undefined : undefined, memberIds: selectedRecipientIds });
  };
  const submitMessage = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!selectedThreadId || (!message.trim() && !attachments.length)) return;
    try {
      const encodedAttachments = await Promise.all(attachments.map(async (attachment) => ({ type: attachment.type, fileName: attachment.file.name, mimeType: attachment.file.type || (attachment.type === "image" ? "image/png" : "audio/webm"), dataBase64: await readFileAsBase64(attachment.file, tr) })));
      send.mutate({ threadId: selectedThreadId, body: message.trim(), attachments: encodedAttachments });
    } catch (error) {
      setNotice(friendlyError(error, tr("تعذر تجهيز المرفق للإرسال.")));
    }
  };

  return (
    <DashboardLayout>
      <div dir={language === "ar" ? "rtl" : "ltr"} className="min-h-screen bg-slate-50 p-3 sm:p-5 lg:p-7">
        <div className="mx-auto w-full max-w-7xl">
          <header className="flex flex-col gap-3 border-b border-slate-200 pb-5 sm:flex-row sm:items-end sm:justify-between">
            <div><div className="flex items-center gap-2 text-sm font-bold text-blue-700"><MessageCircleMore className="h-4 w-4" /> {tr("المراسلات الداخلية")}</div><h1 className="mt-2 text-3xl font-black tracking-tight text-slate-950">{tr("تواصل الفريق")}</h1><p className="mt-2 text-sm leading-6 text-slate-500">{tr("رسائل فردية وقروبات تشغيلية مع صور وتسجيلات صوتية. التنبيه يظهر داخل الموقع على الهاتف واللابتوب.")}</p></div>
            <Button variant="outline" onClick={() => { void threads.refetch(); if (selectedThreadId) void messages.refetch(); }} className="rounded-xl bg-white"><RefreshCw className="ml-2 h-4 w-4" /> تحديث</Button>
          </header>
          {notice ? <p role="status" className="mt-4 rounded-xl border border-blue-200 bg-blue-50 px-4 py-3 text-sm font-semibold text-blue-900">{notice}</p> : null}

          <div className="mt-5 grid gap-5 lg:grid-cols-[330px_minmax(0,1fr)]">
            <Card className="border-slate-200 shadow-sm"><CardHeader><CardTitle className="text-lg">{tr("المحادثات")}</CardTitle><CardDescription>{tr("اختر محادثة أو ابدأ رسالة جديدة.")}</CardDescription></CardHeader><CardContent className="space-y-2">
              {threads.isLoading ? <p className="rounded-xl bg-slate-50 p-3 text-sm text-slate-500">{tr("جارٍ تحميل المحادثات…")}</p> : threads.error ? <p className="rounded-xl bg-rose-50 p-3 text-sm text-rose-700">{tr("تعذر تحميل المحادثات.")}</p> : (threads.data ?? []).length === 0 ? <p className="rounded-xl bg-slate-50 p-3 text-sm text-slate-500">{tr("لا توجد محادثات بعد.")}</p> : (threads.data ?? []).map((thread) => <Button key={thread.id} variant="outline" onClick={() => setSelectedThreadId(thread.id)} className={`min-h-16 w-full justify-between rounded-2xl text-right ${selectedThreadId === thread.id ? "border-blue-300 bg-blue-50" : "bg-white"}`}><span className="min-w-0"><strong className="block truncate">{thread.title || (thread.type === "group" ? tr("قروب تشغيلي") : tr("محادثة فردية"))}</strong><small className="mt-1 block text-slate-500">{thread.type === "group" ? tr("قروب") : tr("فردية")} · {new Date(thread.createdAt).toLocaleDateString(locale)}</small></span><Badge variant="outline" className="rounded-full">#{thread.id}</Badge></Button>)}

              <form onSubmit={submitThread} className="mt-4 space-y-3 border-t border-slate-100 pt-4">
                <div className="flex items-center justify-between"><p className="text-sm font-black text-slate-900">{tr("رسالة جديدة")}</p><div className="flex gap-1"><Button type="button" size="sm" variant={threadKind === "direct" ? "default" : "outline"} onClick={() => { setThreadKind("direct"); setSelectedRecipientIds([]); }} className="h-8 rounded-lg">{tr("فردية")}</Button>{canCreateGroups ? <Button type="button" size="sm" variant={threadKind === "group" ? "default" : "outline"} onClick={() => { setThreadKind("group"); setSelectedRecipientIds([]); }} className="h-8 rounded-lg"><UsersRound className="ml-1 h-3.5 w-3.5" />{tr("قروب")}</Button> : null}</div></div>
                {threadKind === "group" ? <Input value={threadTitle} onChange={(event) => setThreadTitle(event.target.value)} placeholder={tr("اسم القروب (اختياري)")} className="rounded-xl" /> : <p className="text-xs text-slate-500">{tr("اختر شخصاً واحداً لإرسال رسالة مباشرة.")}</p>}
                <div className="max-h-60 space-y-1.5 overflow-y-auto rounded-2xl bg-slate-50 p-2">{recipients.isLoading ? <p className="p-2 text-xs text-slate-500">{tr("جارٍ تحميل الأعضاء…")}</p> : recipients.error ? <p className="p-2 text-xs text-rose-700">{tr("تعذر تحميل الأعضاء.")}</p> : (recipients.data ?? []).map((person) => <button type="button" key={person.id} onClick={() => toggleRecipient(person.id)} className={`flex w-full items-center justify-between rounded-xl p-2.5 text-right text-sm transition-colors ${selectedRecipientIds.includes(person.id) ? "bg-blue-100 text-blue-950" : "bg-white text-slate-700 hover:bg-slate-100"}`}><span className="min-w-0"><strong className="block truncate">{person.name || tr("مستخدم")}</strong><small className="text-slate-500">{person.role}</small></span><span className="text-lg">{selectedRecipientIds.includes(person.id) ? "✓" : "＋"}</span></button>)}</div>
                <Button type="submit" disabled={createThread.isPending || !selectedRecipientIds.length} className="w-full rounded-xl bg-blue-700 text-white hover:bg-blue-800">{createThread.isPending ? tr("جارٍ الإنشاء…") : threadKind === "group" ? tr("إنشاء القروب") : tr("بدء المحادثة")}</Button>
              </form>
            </CardContent></Card>

            <Card className="flex min-h-[620px] min-w-0 flex-col border-slate-200 shadow-sm"><CardHeader className="border-b border-slate-100"><CardTitle>{selected?.title || tr("اختر محادثة")}</CardTitle><CardDescription>{selected ? (selected.type === "group" ? tr("قروب داخلي محفوظ") : tr("محادثة فردية محفوظة")) : tr("ابدأ محادثة فردية أو أنشئ قروباً من القائمة.")}</CardDescription></CardHeader><CardContent className="flex min-h-0 flex-1 flex-col p-3 sm:p-4">
              {!selectedThreadId ? <div className="grid flex-1 place-items-center rounded-2xl bg-slate-50 p-6 text-center text-sm text-slate-500">{tr("اختر محادثة من القائمة لعرض الرسائل والمرفقات.")}</div> : <>
                <div className="flex-1 space-y-3 overflow-y-auto rounded-2xl bg-slate-50 p-3 sm:p-4">{messages.isLoading ? <p className="text-sm text-slate-500">{tr("جارٍ تحميل الرسائل…")}</p> : messages.error ? <p className="text-sm text-rose-700">{tr("تعذر تحميل الرسائل.")}</p> : (messages.data ?? []).length === 0 ? <p className="text-sm text-slate-500">{tr("لا توجد رسائل بعد. ابدأ المحادثة من الأسفل.")}</p> : (messages.data ?? []).slice().reverse().map((item) => <div key={item.id} className={`max-w-[92%] rounded-2xl p-3 shadow-sm sm:max-w-[78%] ${item.senderUserId === me.data?.id ? "mr-auto bg-blue-700 text-white" : "ml-auto bg-white text-slate-900"}`}><p className="whitespace-pre-wrap text-sm leading-6">{item.body}</p>{item.attachments.length ? <div className="mt-3 grid gap-2">{item.attachments.map((attachment) => attachment.type === "image" ? <a key={attachment.id} href={attachment.fileUrl} target="_blank" rel="noreferrer" className="block overflow-hidden rounded-xl border border-white/20 bg-white/10"><img src={attachment.fileUrl} alt={attachment.fileName} className="max-h-60 w-full object-cover" /><span className="block truncate px-2 py-1.5 text-xs">{attachment.fileName}</span></a> : <div key={attachment.id} className="rounded-xl border border-white/20 bg-white/10 p-2"><div className="mb-1 flex items-center gap-1.5 text-xs font-bold"><AudioLines className="h-3.5 w-3.5" />{attachment.fileName}</div><audio controls preload="metadata" className="h-9 w-full"><source src={attachment.fileUrl} type={attachment.mimeType} />{tr("متصفحك لا يدعم تشغيل الصوت.")}</audio></div>)}</div> : null}<p className={`mt-2 text-[11px] ${item.senderUserId === me.data?.id ? "text-blue-100" : "text-slate-400"}`}>{peopleById.get(item.senderUserId)?.name || `${tr("مستخدم")} ${item.senderUserId}`} · {new Date(item.createdAt).toLocaleString(locale)}</p></div>)}<div ref={messageEndRef} /></div>
                <form onSubmit={submitMessage} className="mt-3 rounded-2xl border border-slate-200 bg-white p-2 sm:p-3"><input ref={imageInputRef} type="file" accept="image/jpeg,image/png,image/webp,image/gif" multiple hidden onChange={handleImagePick} /><input ref={audioInputRef} type="file" accept="audio/webm,audio/ogg,audio/mpeg,audio/mp4,audio/wav,audio/x-m4a,audio/aac" hidden onChange={handleAudioPick} />
                  {attachments.length ? <div className="mb-2 flex flex-wrap gap-2">{attachments.map((attachment) => <div key={attachment.id} className="flex max-w-full items-center gap-2 rounded-xl bg-slate-100 px-2 py-1.5 text-xs text-slate-700">{attachment.type === "image" ? <ImagePlus className="h-4 w-4 text-emerald-700" /> : <AudioLines className="h-4 w-4 text-violet-700" />}<span className="max-w-40 truncate">{attachment.file.name}</span><span className="text-slate-400">{formatFileSize(attachment.file.size)}</span><button type="button" onClick={() => removeAttachment(attachment.id)} aria-label={tr("إزالة المرفق")}><X className="h-4 w-4" /></button></div>)}</div> : null}
                  <div className="flex items-end gap-2"><div className="flex gap-1"><Button type="button" variant="outline" size="icon" onClick={() => imageInputRef.current?.click()} className="h-11 w-11 rounded-xl" title={tr("إرفاق صورة")}><ImagePlus className="h-4 w-4" /></Button><Button type="button" variant="outline" size="icon" onClick={() => audioInputRef.current?.click()} className="h-11 w-11 rounded-xl" title={tr("إرفاق تسجيل صوتي")}><Paperclip className="h-4 w-4" /></Button><Button type="button" variant={isRecording ? "destructive" : "outline"} size="icon" onClick={isRecording ? stopRecording : startRecording} className="h-11 w-11 rounded-xl" title={isRecording ? tr("إيقاف التسجيل") : tr("تسجيل صوتي")}>{isRecording ? <Square className="h-4 w-4" /> : <Mic className="h-4 w-4" />}</Button></div><Textarea value={message} onChange={(event) => setMessage(event.target.value)} placeholder={tr("اكتب رسالتك…")} className="min-h-11 flex-1 resize-none rounded-xl" rows={1} /><Button type="submit" disabled={send.isPending || (!message.trim() && !attachments.length)} className="h-11 rounded-xl bg-blue-700 px-4 text-white hover:bg-blue-800">{send.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}</Button></div>
                </form>{send.error ? <p className="mt-2 text-sm text-rose-700">{tr("تعذر إرسال الرسالة:")} {friendlyError(send.error)}</p> : null}
              </>}
            </CardContent></Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
