import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import DriverMap from "@/components/DriverMap";
import NotificationBell from "@/components/NotificationBell";
import LanguageSwitcher from "@/components/LanguageSwitcher";
import UnifiedLocalAccessDialog from "@/components/UnifiedLocalAccessDialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { LOCAL_LOGIN_PATH } from "@/lib/local-auth-routing";
import { trpc } from "@/lib/trpc";
import { useUiText } from "@/lib/uiText";
import { useLanguage } from "@/i18n";
import { getDashboardQuickActionPath } from "@shared/operations";
import { Link } from "wouter";
import {
  Activity,
  ArrowLeft,
  Bell,
  Building2,
  ChevronLeft,
  ClipboardList,
  Clock3,
  FileBarChart,
  Globe2,
  LayoutDashboard,
  MapPinned,
  MessageSquareText,
  PackageCheck,
  Search,
  ShieldCheck,
  Truck,
  UsersRound,
} from "lucide-react";

const logoUrl = "/manus-storage/city-center-logo-user_665f44b4.png";

const kpis = [
  { key: "ordersToday", value: "0", hintKey: "noData", icon: ClipboardList, tone: "orange" },
  { key: "inTransit", value: "0", hintKey: "setupStatus", icon: Truck, tone: "blue" },
  { key: "delivered", value: "0", hintKey: "noData", icon: PackageCheck, tone: "green" },
  { key: "activeDrivers", value: "0", hintKey: "users", icon: UsersRound, tone: "violet" },
] as const;

const quickActions = [
  { titleKey: "newOrder", detailKey: "deliveryData", icon: ClipboardList, accent: "bg-orange-50 text-orange-700" },
  { titleKey: "operationsRoom", detailKey: "dashboard", icon: MapPinned, accent: "bg-blue-50 text-blue-700" },
  { titleKey: "users", detailKey: "registeredAccounts", icon: UsersRound, accent: "bg-violet-50 text-violet-700" },
  { titleKey: "finance", detailKey: "financeSummary", icon: FileBarChart, accent: "bg-emerald-50 text-emerald-700" },
] as const;

function PublicHome() {
  const { t, language } = useLanguage();
  const brandingQuery = trpc.platform.branding.useQuery(undefined, { staleTime: 60_000 });
  const brandName = brandingQuery.data?.brandName || t("brandName");
  const brandLogo = brandingQuery.data?.logoUrl || logoUrl;
  return (
    <div dir={language === "ar" ? "rtl" : "ltr"} className="min-h-screen overflow-x-hidden bg-[#fffaf4] text-slate-900">
      <header className="mx-auto flex w-full max-w-7xl flex-col gap-4 px-4 py-5 sm:flex-row sm:items-center sm:justify-between sm:px-5 lg:px-8">
        <div className="flex w-full items-center justify-center gap-3 sm:w-auto sm:justify-start">
          <img src={brandLogo} alt={brandName} className="h-12 w-12 shrink-0 rounded-2xl object-contain shadow-sm" />
          <div>
            <p className="text-lg font-black tracking-tight">{brandName}</p>
            <p className="text-xs font-semibold text-slate-500">{t("publicTagline")}</p>
          </div>
        </div>
        <div className="flex w-full flex-wrap items-center justify-center gap-2 sm:w-auto sm:justify-end">
          <UnifiedLocalAccessDialog />
          <Link href="/register-business"><Button variant="outline" className="min-w-[8.5rem] rounded-full border-orange-200 bg-white px-4 text-orange-700">تسجيل شركة / تاجر</Button></Link>
          <Button onClick={() => window.location.assign(LOCAL_LOGIN_PATH)} style={{ backgroundColor: brandingQuery.data?.accentColor }} className="min-w-[8.5rem] rounded-full bg-slate-900 px-4 text-white hover:bg-slate-800">
            {t("publicSystemLogin")} <ArrowLeft className="mr-2 h-4 w-4" />
          </Button>
        </div>
      </header>

      <main>
        <section className="relative mx-auto grid max-w-7xl gap-12 px-5 pb-20 pt-12 lg:grid-cols-[1.05fr_.95fr] lg:items-center lg:px-8 lg:pb-28 lg:pt-20">
          <div className="relative z-10">
            <Badge className="mb-6 rounded-full border border-orange-200 bg-orange-50 px-4 py-2 text-orange-700 hover:bg-orange-50">
              {t("publicPlatformBadge")}
            </Badge>
            <h1 className="max-w-2xl text-4xl font-black leading-[1.12] tracking-tight text-slate-950 sm:text-5xl lg:text-7xl">
              {t("publicHeroTitle")} <span className="text-orange-500">{t("publicHeroHighlight")}</span>
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-9 text-slate-600">
              {t("publicHeroDescription")}
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Button onClick={() => window.location.assign(LOCAL_LOGIN_PATH)} size="lg" className="rounded-2xl bg-orange-500 px-7 text-white shadow-lg shadow-orange-200 hover:bg-orange-600">
                {t("publicDashboardLogin")} <ChevronLeft className="mr-2 h-5 w-5" />
              </Button>
              <Button size="lg" variant="outline" className="rounded-2xl border-slate-200 bg-white px-7" onClick={() => document.getElementById("capabilities")?.scrollIntoView({ behavior: "smooth" })}>
                {t("publicExplore")}
              </Button>
            </div>
            <div className="mt-10 flex flex-wrap gap-x-7 gap-y-3 text-sm font-semibold text-slate-500">
              <span className="flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-emerald-600" /> {t("publicPermissions")}</span>
              <span className="flex items-center gap-2"><Globe2 className="h-4 w-4 text-blue-600" /> {t("publicMultilingual")}</span>
              <span className="flex items-center gap-2"><Activity className="h-4 w-4 text-orange-500" /> {t("publicScalable")}</span>
            </div>
          </div>
          <div className="relative min-h-[430px]">
            <div className="absolute -left-8 top-10 h-64 w-64 rounded-full bg-orange-200/60 blur-3xl" />
            <div className="absolute -bottom-4 right-0 h-64 w-64 rounded-full bg-sky-200/70 blur-3xl" />
            <div className="relative mt-5 rounded-[2rem] border border-white/80 bg-white/80 p-4 shadow-2xl shadow-slate-200/70 backdrop-blur lg:rotate-2">
              <div className="rounded-[1.5rem] bg-slate-950 p-5 text-white" style={{ backgroundColor: brandingQuery.data?.accentColor }}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3"><img src={brandLogo} alt="" className="h-10 w-10 rounded-xl object-contain" /><div><p className="font-bold">{brandName}</p><p className="text-xs text-slate-400">{t("publicOverview")}</p></div></div>
                  <Bell className="h-5 w-5 text-orange-300" />
                </div>
                <div className="mt-8 grid grid-cols-2 gap-3">
                  {[t("ordersToday"), t("delivered"), t("inTransit"), t("activeDrivers")].map((label, index) => <div key={label} className="rounded-2xl bg-white/10 p-4"><p className="text-xs text-slate-400">{label}</p><p className="mt-2 text-2xl font-black">{index === 3 ? "0" : "0"}</p></div>)}
                </div>
                <div className="mt-4 rounded-2xl bg-white/10 p-4"><div className="flex items-center justify-between text-xs text-slate-400"><span>{t("publicOperationsStatus")}</span><span>{t("publicSystemSetup")}</span></div><div className="mt-4 h-2 rounded-full bg-white/10"><div className="h-2 w-[18%] rounded-full bg-orange-400" /></div></div>
              </div>
            </div>
          </div>
        </section>

        <section id="capabilities" className="border-y border-orange-100 bg-white px-5 py-20 lg:px-8">
          <div className="mx-auto max-w-7xl"><div className="max-w-2xl"><p className="font-bold text-orange-500">{t("publicDesignedFor")}</p><h2 className="mt-3 text-3xl font-black tracking-tight sm:text-4xl">{t("publicCapabilitiesTitle")}</h2><p className="mt-4 leading-8 text-slate-600">{t("publicCapabilitiesDescription")}</p></div><div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{[{ title: t("publicOrdersCapability"), text: t("publicOrdersCapabilityText"), icon: ClipboardList }, { title: t("publicDriverCapability"), text: t("publicDriverCapabilityText"), icon: Truck }, { title: t("publicOperationsCapability"), text: t("publicOperationsCapabilityText"), icon: MapPinned }, { title: t("publicFinanceCapability"), text: t("publicFinanceCapabilityText"), icon: FileBarChart }].map(({ title, text, icon: Icon }) => <Card key={title} className="rounded-3xl border-slate-100 shadow-none"><CardContent className="p-6"><div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-slate-950 text-orange-300"><Icon className="h-5 w-5" /></div><h3 className="mt-5 font-black">{title}</h3><p className="mt-2 text-sm leading-7 text-slate-500">{text}</p></CardContent></Card>)}</div></div>
        </section>
      </main>
      <footer className="mx-auto flex max-w-7xl flex-col gap-3 px-5 py-8 text-sm text-slate-500 sm:flex-row sm:items-center sm:justify-between lg:px-8"><span>© {brandName} {t("publicFooter")}</span><span>{t("publicRegion")}</span></footer>
    </div>
  );
}

function OperationsHome() {
  const { t, language } = useLanguage();
  const tr = useUiText();
  const summary = trpc.dashboard.summary.useQuery();
  const recentOrders = trpc.dashboard.recentOrders.useQuery();
  const driverLocations = trpc.dashboard.driverLocations.useQuery(undefined, { refetchInterval: 15000, refetchIntervalInBackground: true });
  const liveKpis = kpis.map((item, index) => ({ ...item, value: [summary.data?.ordersToday, summary.data?.inTransit, summary.data?.delivered, summary.data?.activeDrivers][index] ?? 0 }));
  return <DashboardLayout><div dir={language === "ar" ? "rtl" : "ltr"} className="min-h-screen bg-[#f8fafc] text-slate-900"><div className="mx-auto max-w-[1500px] p-4 sm:p-6 lg:p-8"><div className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between"><div><div className="flex items-center gap-2 text-sm font-semibold text-slate-500"><LayoutDashboard className="h-4 w-4 text-orange-500" /> {t("dashboard")}</div><h1 className="mt-2 text-3xl font-black tracking-tight sm:text-4xl">{t("dashboardGreeting")}</h1><p className="mt-2 text-sm text-slate-500">{t("dashboardIntro")}</p></div><div className="flex flex-wrap gap-2"><LanguageSwitcher /><Link href="/orders/new"><Button className="rounded-xl bg-orange-500 text-white hover:bg-orange-600"><ClipboardList className="ml-2 h-4 w-4" /> {t("newOrder")}</Button></Link><NotificationBell /></div></div>
      <div className="mt-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{liveKpis.map(({ key, value, hintKey, icon: Icon, tone }) => <Card key={key} className="rounded-3xl border-slate-100 shadow-sm"><CardContent className="p-5"><div className="flex items-start justify-between"><div><p className="text-sm font-semibold text-slate-500">{t(key)}</p><p className="mt-3 text-4xl font-black tracking-tight">{value}</p><p className="mt-2 text-xs text-slate-400">{t(hintKey)}</p></div><div className={`rounded-2xl p-3 ${tone === "orange" ? "bg-orange-50 text-orange-600" : tone === "blue" ? "bg-blue-50 text-blue-600" : tone === "green" ? "bg-emerald-50 text-emerald-600" : "bg-violet-50 text-violet-600"}`}><Icon className="h-5 w-5" /></div></div></CardContent></Card>)}</div>
      <div className="mt-8 grid gap-6 xl:grid-cols-[1.25fr_.75fr]"><Card className="rounded-3xl border-slate-100 shadow-sm"><CardHeader className="flex flex-row items-center justify-between space-y-0"><div><CardTitle className="text-xl font-black">{t("latestOrders")}</CardTitle><p className="mt-1 text-sm text-slate-500">{t("latestOrdersHint")}</p></div><Button variant="ghost" className="text-orange-600">{t("allOrders")} <ChevronLeft className="mr-1 h-4 w-4" /></Button></CardHeader><CardContent><div className="flex min-h-[245px] flex-col items-center justify-center rounded-2xl border border-dashed border-slate-200 bg-slate-50/70 p-6 text-center"><div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white text-slate-300 shadow-sm"><PackageCheck className="h-7 w-7" /></div>{recentOrders.data?.length ? <div className="w-full space-y-2 text-right">{recentOrders.data.slice(0, 5).map((order) => <div key={order.id} className="flex items-center justify-between rounded-xl bg-white p-3 text-sm"><span className="min-w-0"><b className="block">{order.orderNumber}</b><small className="mt-1 block text-[11px] font-semibold text-emerald-800">{tr("المطلوب")}: {Number(order.cashToCollectAmount ?? 0).toFixed(3)} {tr("د.ك")} · {tr("المستلم")}: {order.cashCollectionRecorded ? `${Number(order.cashCollectedAmount ?? 0).toFixed(3)} ${tr("د.ك")}` : tr("غير مسجل")}</small>{order.cashCollectionNote ? <small className="mt-0.5 block text-[10px] text-amber-800">{tr("ملاحظة التحصيل")}: {order.cashCollectionNote}</small> : null}</span><Badge className="bg-orange-50 text-orange-700">{order.status}</Badge></div>)}</div> : <><h3 className="mt-4 font-bold">{t("noOrders")}</h3><p className="mt-2 max-w-sm text-sm leading-6 text-slate-500">ابدأ بإضافة أول طلب شركة أو طلب خارجي، وستظهر لك حالته وسجل عملياته هنا.</p></>}<Link href="/orders/new"><Button variant="outline" className="mt-5 rounded-xl bg-white">{t("createFirstOrder")}</Button></Link></div></CardContent></Card><Card className="rounded-3xl border-slate-100 shadow-sm"><CardHeader><CardTitle className="text-xl font-black">{t("quickActions")}</CardTitle><p className="mt-1 text-sm text-slate-500">{t("quickActionsHint")}</p></CardHeader><CardContent className="space-y-3">{quickActions.map(({ titleKey, detailKey, icon: Icon, accent }) => <button key={titleKey} onClick={() => { const target = getDashboardQuickActionPath(titleKey); window.location.href = target; }} className="flex w-full items-center gap-3 rounded-2xl border border-slate-100 bg-white p-3 text-right transition hover:-translate-y-0.5 hover:border-orange-200 hover:shadow-sm"><span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${accent}`}><Icon className="h-5 w-5" /></span><span className="min-w-0"><span className="block font-bold">{t(titleKey)}</span><span className="mt-1 block truncate text-xs text-slate-500">{t(detailKey)}</span></span><ChevronLeft className="mr-auto h-4 w-4 text-slate-300" /></button>)}</CardContent></Card></div>
      <div className="mt-6 grid gap-6 lg:grid-cols-3"><Card className="rounded-3xl border-slate-100 shadow-sm lg:col-span-2"><CardHeader><div className="flex items-center justify-between"><div><CardTitle className="text-xl font-black">{t("liveOperationsTitle")}</CardTitle><p className="mt-1 text-sm text-slate-500">{t("liveOperationsHint")}</p></div><Badge className="rounded-full bg-emerald-50 text-emerald-700 hover:bg-emerald-50">{t("liveNow")}</Badge></div></CardHeader><CardContent><div className="grid gap-3 sm:grid-cols-3">{[{ label: t("databaseReady"), value: t("ready"), icon: ShieldCheck }, { label: t("identityReady"), value: t("ready"), icon: Activity }, { label: t("ordersReady"), value: t("ordersAvailable"), icon: ClipboardList }].map(({ label, value, icon: Icon }) => <div key={label} className="rounded-2xl bg-slate-50 p-4"><Icon className="h-5 w-5 text-orange-500" /><p className="mt-4 text-sm font-bold">{label}</p><p className="mt-1 text-xs text-slate-500">{value}</p></div>)}</div></CardContent></Card><Card className="rounded-3xl border-slate-100 shadow-sm"><CardHeader><CardTitle className="text-xl font-black">{t("quickSearch")}</CardTitle></CardHeader><CardContent><div className="relative"><Search className="absolute right-3 top-3 h-4 w-4 text-slate-400" /><Input className="h-11 rounded-xl border-slate-200 pr-9" placeholder={t("searchOrderHint")} /></div><Separator className="my-5" /><div className="flex items-center gap-3 text-sm text-slate-500"><Clock3 className="h-4 w-4 text-orange-500" /> {t("auditSavedHint")}</div><div className="mt-4 flex items-center gap-3 text-sm text-slate-500"><MessageSquareText className="h-4 w-4 text-blue-500" /> {t("messagingHint")}</div></CardContent></Card></div><Card className="mt-6 rounded-3xl border-slate-100 shadow-sm"><CardHeader><CardTitle className="flex items-center justify-between text-xl font-black"><span>{t("operationsRoom")}</span><Badge className="rounded-full bg-sky-50 text-sky-700 hover:bg-sky-50">{driverLocations.isLoading ? t("loading") : `${driverLocations.data?.length ?? 0} ${t("driversOnMap")}`}</Badge></CardTitle><p className="mt-1 text-sm text-slate-500">{t("driverMap")} · {t("liveDriverMapDescription")}</p></CardHeader><CardContent>{driverLocations.error ? <div className="rounded-2xl bg-red-50 p-4 text-sm text-red-700">{t("locationsError")} <Button size="sm" variant="outline" onClick={() => driverLocations.refetch()} className="mr-2 rounded-lg">{t("retry")}</Button></div> : <DriverMap locations={driverLocations.data ?? []} />}</CardContent></Card></div></div></DashboardLayout>;
  }

export default function Home() {
  const { isAuthenticated, loading } = useAuth();
  if (loading) return <div className="flex min-h-screen items-center justify-center bg-[#fffaf4] text-slate-500">جارٍ تجهيز المنصة...</div>;
  return isAuthenticated ? <OperationsHome /> : <PublicHome />;
}
