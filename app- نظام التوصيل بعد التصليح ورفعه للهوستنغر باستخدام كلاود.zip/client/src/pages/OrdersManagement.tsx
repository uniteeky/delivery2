import { useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import OrderManagementPanel from "@/components/OrderManagementPanel";
import NewOrder from "@/pages/NewOrder";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { useLanguage } from "@/i18n";

export default function OrdersManagement() {
  const { language } = useLanguage();
  const [addOpen, setAddOpen] = useState(false);
  return (
    <DashboardLayout>
      <main
        dir={language === "ar" ? "rtl" : "ltr"}
        className="min-h-screen bg-[#f8fafc] p-4 sm:p-6 lg:p-8"
      >
        <div className="mx-auto max-w-[1500px]">
          <OrderManagementPanel
            onAdd={() => setAddOpen(true)}
            title="إدارة الطلبات"
          />
        </div>
        <Dialog open={addOpen} onOpenChange={setAddOpen}>
          <DialogContent className="max-h-[94vh] w-[min(96vw,1000px)] overflow-y-auto rounded-3xl bg-[#f8fafc] p-2 sm:p-4">
            <NewOrder embedded />
          </DialogContent>
        </Dialog>
      </main>
    </DashboardLayout>
  );
}
