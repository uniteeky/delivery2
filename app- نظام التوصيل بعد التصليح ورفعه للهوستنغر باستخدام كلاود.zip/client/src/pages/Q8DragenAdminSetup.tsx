import { useState } from "react";
import { useLocation } from "wouter";
import { KeyRound, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function Q8DragenAdminSetup() {
  const [, navigate] = useLocation();
  const [form, setForm] = useState({ username: "", password: "", confirmPassword: "" });
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    if (form.password !== form.confirmPassword) {
      setError("كلمتا المرور غير متطابقتين");
      return;
    }
    setPending(true);
    try {
      const response = await fetch("/api/auth/q8dragen-admin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ username: form.username, password: form.password }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "تعذر إنشاء حساب المدير");
      navigate("/404");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "تعذر إنشاء حساب المدير");
    } finally {
      setPending(false);
    }
  }

  return <main dir="rtl" className="flex min-h-screen items-center justify-center bg-[#fffaf4] px-4 py-8 text-slate-900"><Card className="w-full max-w-lg rounded-[2rem] border-orange-100 shadow-xl shadow-orange-100/40"><CardHeader className="p-6 sm:p-8"><div className="flex items-start gap-3"><div className="rounded-2xl bg-orange-100 p-3 text-orange-600"><KeyRound className="h-6 w-6" /></div><div><CardTitle className="text-2xl font-black">إنشاء حساب المدير</CardTitle><p className="mt-2 text-sm leading-7 text-slate-500">أدخل اسم المستخدم وكلمة المرور لإنشاء أول حساب مدير معتمد.</p></div></div></CardHeader><CardContent className="p-6 pt-0 sm:p-8 sm:pt-0"><form onSubmit={submit} className="space-y-5"><div className="space-y-2"><Label htmlFor="admin-username">اسم المستخدم</Label><Input id="admin-username" required minLength={3} maxLength={80} autoComplete="username" value={form.username} onChange={(event) => setForm((current) => ({ ...current, username: event.target.value }))} placeholder="admin" className="h-12 rounded-xl" /></div><div className="space-y-2"><Label htmlFor="admin-password">كلمة المرور</Label><Input id="admin-password" required minLength={8} type="password" autoComplete="new-password" value={form.password} onChange={(event) => setForm((current) => ({ ...current, password: event.target.value }))} className="h-12 rounded-xl" /></div><div className="space-y-2"><Label htmlFor="admin-confirm-password">تأكيد كلمة المرور</Label><Input id="admin-confirm-password" required minLength={8} type="password" autoComplete="new-password" value={form.confirmPassword} onChange={(event) => setForm((current) => ({ ...current, confirmPassword: event.target.value }))} className="h-12 rounded-xl" /></div>{error ? <p className="rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700">{error}</p> : null}<div className="rounded-2xl bg-slate-50 p-4 text-sm leading-7 text-slate-600"><ShieldCheck className="mb-1 inline h-4 w-4 text-emerald-600" /> هذه الصفحة مخصصة لإعداد أول مدير فقط.</div><Button type="submit" disabled={pending} className="h-12 w-full rounded-xl bg-orange-500 font-bold text-white hover:bg-orange-600">{pending ? "جارٍ إنشاء الحساب..." : "إنشاء حساب المدير"}</Button></form></CardContent></Card></main>;
}
