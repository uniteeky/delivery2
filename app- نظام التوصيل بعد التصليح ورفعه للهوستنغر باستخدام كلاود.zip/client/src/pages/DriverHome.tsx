import { useEffect, useMemo, useState } from "react";
import { useLocation } from "wouter";
import { Camera, CheckCircle2, Clock3, ExternalLink, MapPin, Menu, Package, Phone, ShieldCheck, Truck, UserRound, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/i18n";
import { useAuth } from "@/_core/hooks/useAuth";
import { getDriverOrderStats, splitDriverOrders } from "@shared/operations";
import DriverAlerts from "@/components/DriverAlerts";
import { unlockDriverAudio } from "@/lib/driverAudio";
import { requestDriverNotificationPermission, type DriverNotificationPermission } from "@/lib/browserNotifications";
import { useDriverScreenWakeLock } from "@/components/DriverScreenWakeLock";
import LanguageSwitcher from "@/components/LanguageSwitcher";
import { useUiText } from "@/lib/uiText";

const mapHref = (value?: string | null) => value ? (/^https?:\/\//i.test(value) ? value : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(value)}`) : null;

async function prepareDriverPhoto(file: File) {
  const readBase64 = (source: Blob) => new Promise<string>((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(String(reader.result).split(",")[1] ?? ""); reader.onerror = () => reject(reader.error); reader.readAsDataURL(source); });
  const sourceUrl = URL.createObjectURL(file);
  try {
    const image = await new Promise<HTMLImageElement>((resolve, reject) => { const element = new Image(); element.onload = () => resolve(element); element.onerror = () => reject(new Error("تعذر قراءة الصورة")); element.src = sourceUrl; });
    const largestSide = 1600;
    const scale = Math.min(1, largestSide / Math.max(image.naturalWidth, image.naturalHeight));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
    canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
    const context = canvas.getContext("2d");
    if (!context) throw new Error("تعذر تجهيز الصورة");
    context.drawImage(image, 0, 0, canvas.width, canvas.height);
    const compressed = await new Promise<Blob>((resolve, reject) => canvas.toBlob((blob) => blob ? resolve(blob) : reject(new Error("تعذر ضغط الصورة")), "image/jpeg", 0.82));
    return { dataBase64: await readBase64(compressed), fileName: `${file.name.replace(/\.[^.]+$/, "") || "delivery-photo"}.jpg`, mimeType: "image/jpeg" };
  } finally { URL.revokeObjectURL(sourceUrl); }
}

function statusLabel(status: string, tr: (arabic: string) => string) {
  if (status === "assigned") return tr("بانتظار بدء التوصيل");
  if (status === "picked_up") return tr("صور الاستلام مطلوبة");
  if (status === "in_transit") return tr("وصلت العنوان");
  if (status === "delivered") return tr("تم التسليم");
  return status;
}

function historyLabel(item: { action: string; detail?: string | null }, tr: (arabic: string) => string) {
  const detail = String(item.detail ?? "").trim();
  if (detail && !detail.startsWith("{")) return detail;
  if (item.action === "assigned") return tr("تم إسناد الطلب للسائق");
  if (item.action === "picked_up") return tr("بدأ التوصيل");
  if (item.action === "in_transit") return tr("وصل السائق إلى عنوان التسليم");
  if (item.action === "delivered") return tr("تم تسليم الطلب");
  if (item.action === "transferred") return tr("تم تحويل الطلب");
  return null;
}

function PhotoTile({ label, done, uploading, error, onFile, tr }: { label: string; done: boolean; uploading: boolean; error?: string; onFile: (file?: File) => void; tr: (arabic: string) => string }) {
  return <label className={`flex min-h-28 cursor-pointer flex-col items-center justify-center rounded-2xl border px-2 py-3 text-center text-xs font-bold transition ${done ? "border-emerald-400/60 bg-emerald-500/15 text-emerald-100" : error ? "border-rose-400/60 bg-rose-500/15 text-rose-100" : "border-white/15 bg-white/5 text-slate-100 hover:bg-white/10"}`}><span className="flex items-center gap-1">{done ? <CheckCircle2 className="h-5 w-5 text-emerald-300" /> : <Camera className="h-5 w-5 text-orange-300" />}{label}</span><span className="mt-2 text-[11px]">{uploading ? tr("جارٍ تجهيز الصورة ورفعها...") : done ? tr("تم الرفع ✓") : error ? tr("فشل الرفع — اضغط للمحاولة") : tr("اضغط للتصوير")}</span>{error ? <span className="mt-1 text-[10px] leading-4">{error}</span> : null}<input type="file" accept="image/*" capture="environment" className="hidden" disabled={uploading} onChange={(event) => { onFile(event.target.files?.[0]); event.currentTarget.value = ""; }} /></label>;
}

function ContactButton({ label, phone, tone, caption, tr }: { label: string; phone?: string | null; tone: "orange" | "sky"; caption?: string | null; tr: (arabic: string) => string }) {
  const classes = tone === "orange" ? "border-orange-300/40 bg-orange-500/15 text-orange-50" : "border-sky-300/40 bg-sky-500/15 text-sky-50";
  const displayLabel = tr(label);
  if (!phone) return <p className={`flex min-h-16 items-center justify-center gap-2 rounded-2xl border px-3 text-center text-xs font-black ${classes}`}><Phone className="h-4 w-4" />{displayLabel}: {tr("غير مسجل")}</p>;
  return <a href={`tel:${phone}`} dir="ltr" className={`flex min-h-16 flex-col items-center justify-center gap-1 rounded-2xl border px-3 py-2 text-center text-sm font-black ${classes}`}><span className="flex items-center gap-2"><Phone className="h-5 w-5" />{displayLabel}: {phone}</span>{caption ? <span dir="rtl" className="text-xs font-semibold opacity-90">{caption}</span> : null}</a>;
}

function OrderContacts({ pickupPhone, pickupContactName, deliveryPhone, customerName, tr }: { pickupPhone?: string | null; pickupContactName?: string | null; deliveryPhone?: string | null; customerName?: string | null; tr: (arabic: string) => string }) {
  return <section className="mt-4 rounded-2xl border border-white/15 bg-black/15 p-3"><p className="mb-3 text-center text-sm font-black">{tr("بيانات الاتصال")}</p><div className="grid grid-cols-1 gap-2 sm:grid-cols-2"><ContactButton label="هاتف الاستلام" phone={pickupPhone} tone="orange" caption={pickupContactName ? `${tr("مستلم الطلب")}: ${pickupContactName}` : null} tr={tr} /><ContactButton label="هاتف التسليم" phone={deliveryPhone} tone="sky" tr={tr} caption={customerName ? `${tr("العميل")}: ${customerName}` : null} /></div></section>;
}

function FullAddress({ title, value, locationUrl, accent, tr }: { title: string; value?: string | null; locationUrl?: string | null; accent: "sky" | "orange"; tr: (arabic: string) => string }) {
  const tone = accent === "sky" ? "border-sky-300/25 bg-sky-500/10 text-sky-100" : "border-orange-300/25 bg-orange-500/10 text-orange-100";
  return <div className={`mt-3 rounded-2xl border p-3 ${tone}`}><p className="text-xs font-black">{title}</p>{value ? <p className="mt-1 whitespace-pre-wrap break-words text-sm leading-6">{value}</p> : <p className="mt-1 text-sm opacity-80">{tr("العنوان غير متوفر")}</p>}{locationUrl ? <a href={locationUrl} target="_blank" rel="noreferrer" className="mt-2 inline-flex items-center gap-1 rounded-lg bg-white/15 px-3 py-2 text-xs font-black underline"><ExternalLink className="h-3.5 w-3.5" />{tr("فتح اللوكيشن")}</a> : null}</div>;
}

function OrderMediaGallery({ media, tr }: { media?: Array<{ kind: string; fileUrl: string }>; tr: (arabic: string) => string }) {
  const labels: Record<string, string> = { order: tr("صورة الاستلام"), invoice: tr("صورة الفاتورة"), delivery: tr("صورة التسليم") };
  if (!media?.length) return <p className="mt-4 rounded-2xl bg-black/15 p-3 text-center text-xs text-slate-300">{tr("لا توجد صور مرفقة بهذا الطلب.")}</p>;
  return <div className="mt-4"><p className="mb-2 text-sm font-black">{tr("صور الطلب")}</p><div className="grid grid-cols-3 gap-2">{media.map((item, index) => <a key={`${item.kind}-${item.fileUrl}`} href={item.fileUrl} target="_blank" rel="noreferrer" className="overflow-hidden rounded-xl border border-white/15 bg-black/15"><img src={item.fileUrl} alt={labels[item.kind] || tr("صورة الطلب")} className="h-20 w-full object-cover" /><span className="block p-1 text-center text-[10px] font-bold">{labels[item.kind] || `${tr("صورة")} ${index + 1}`}</span></a>)}</div></div>;
}

function TransferOrderControl({ orderId, selectedDriverId, drivers, transferring, onSelect, onTransfer, tr }: { orderId: number; selectedDriverId?: string; drivers: Array<{ id: number; name: string | null; vehicleLabel?: string | null }>; transferring: boolean; onSelect: (value: string) => void; onTransfer: () => void; tr: (arabic: string) => string }) {
  if (!drivers.length) return null;
  return <section className="mt-4 rounded-2xl border border-violet-300/25 bg-violet-500/10 p-3"><p className="text-sm font-black text-violet-100">{tr("تحويل الطلب إلى سائق آخر")}</p><div className="mt-3 flex gap-2"><select aria-label={tr("اختيار سائق التحويل")} value={selectedDriverId ?? ""} onChange={(event) => onSelect(event.target.value)} className="h-11 min-w-0 flex-1 rounded-xl border border-violet-300/25 bg-slate-900 px-3 text-sm text-white"><option value="">{tr("اختر السائق")}</option>{drivers.map((driver) => <option key={driver.id} value={String(driver.id)}>{driver.name || tr("سائق")}{driver.vehicleLabel ? ` · ${driver.vehicleLabel}` : ""}</option>)}</select><Button type="button" disabled={!selectedDriverId || transferring} onClick={onTransfer} className="shrink-0 rounded-xl bg-violet-500 hover:bg-violet-600">{transferring ? tr("جارٍ التحويل") : tr("تحويل")}</Button></div></section>;
}

export default function DriverHome() {
  const { isAuthenticated, loading, user, logout } = useAuth();
  const [, navigate] = useLocation();
  const { t, language } = useLanguage();
  const tr = useUiText();
  const brandingQuery = trpc.platform.branding.useQuery(undefined, { staleTime: 60_000 });
  const hasDriverRole = user?.role === "driver" || user?.roles?.includes("driver");
  const access = isAuthenticated && Boolean(hasDriverRole);
  const transferAccess = trpc.platform.canTransfer.useQuery(undefined, { enabled: access, refetchInterval: 15_000, refetchOnWindowFocus: true });
  useDriverScreenWakeLock(access);

  const orders = trpc.driver.myOrders.useQuery(undefined, { enabled: access, refetchInterval: 3000, refetchIntervalInBackground: true, refetchOnWindowFocus: "always", refetchOnMount: "always" });
  const driver = trpc.driver.me.useQuery(undefined, { enabled: access });
  const activeShift = trpc.driver.activeShift.useQuery(undefined, { enabled: access, refetchInterval: 15000, refetchIntervalInBackground: true });
  const activeShiftDrivers = trpc.driver.activeShiftDrivers.useQuery(undefined, { enabled: access, refetchInterval: 15000 });
  const [working, setWorking] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [notice, setNotice] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [gpsActive, setGpsActive] = useState(false);
  const [gpsUnavailableAtStart, setGpsUnavailableAtStart] = useState(false);
  const [audioReady, setAudioReady] = useState(false);
  const [notificationPermission, setNotificationPermission] = useState<DriverNotificationPermission>("default");
  const [mediaUploaded, setMediaUploaded] = useState<Record<string, boolean>>({});
  const [uploadingKey, setUploadingKey] = useState<string | null>(null);
  const [photoErrors, setPhotoErrors] = useState<Record<string, string>>({});
  const [showDelivered, setShowDelivered] = useState(false);
  const [transferTargets, setTransferTargets] = useState<Record<number, string>>({});
  const [cashCollectedDrafts, setCashCollectedDrafts] = useState<Record<number, string>>({});
  const [transferringId, setTransferringId] = useState<number | null>(null);

  const startShift = trpc.shifts.start.useMutation({ onSuccess: () => { setNotice({ type: "success", text: gpsUnavailableAtStart ? tr("تم بدء العمل بدون GPS، وسنواصل محاولة تحديد موقعك.") : tr("تم بدء العمل") }); void activeShift.refetch(); }, onError: (error) => setNotice({ type: "error", text: error.message || t("operationsError") }), onSettled: () => setWorking(false) });
  const endShift = trpc.shifts.end.useMutation({ onSuccess: (receipt) => { setNotice({ type: "success", text: `${tr("تم إنهاء العمل")}. ${tr("إجمالي المبالغ المحصلة في النوبة")}: ${Number(receipt.cashCollectedTotal ?? 0).toFixed(3)} ${tr("د.ك")} (${receipt.cashCollectionCount ?? 0} ${tr("طلب مستلم")}).` }); void activeShift.refetch(); }, onError: (error) => setNotice({ type: "error", text: error.message || t("operationsError") }), onSettled: () => setWorking(false) });
  const updateLocation = trpc.driver.updateLocation.useMutation();
  const beginDeliveryMutation = trpc.driver.beginDelivery.useMutation();
  const returnOrderMutation = trpc.driver.returnOrder.useMutation({ onSuccess: async (result) => { setNotice({ type: "success", text: tr("تم إرجاع الطلب إلى الشركة وإلغاء العمولة والحصة تلقائياً.") }); await orders.refetch(); }, onError: (error) => setNotice({ type: "error", text: error.message || t("operationsError") }), onSettled: () => setWorking(false) });
  const updateStatus = trpc.orders.updateStatus.useMutation({ onSuccess: () => void orders.refetch(), onError: (error) => setNotice({ type: "error", text: error.message || t("operationsError") }), onSettled: () => setWorking(false) });
  const completeDelivery = trpc.driver.completeDelivery.useMutation({ onSuccess: async () => { await Promise.all([orders.refetch(), activeShift.refetch()]); }, onError: (error) => setNotice({ type: "error", text: error.message || t("operationsError") }), onSettled: () => setWorking(false) });
  const transferOrder = trpc.driver.transferOrder.useMutation({ onSuccess: () => { setNotice({ type: "success", text: tr("تم تحويل الطلب وحفظ اسم المحول.") }); void orders.refetch(); }, onError: (error) => setNotice({ type: "error", text: error.message || t("operationsError") }), onSettled: () => setTransferringId(null) });
  const uploadMedia = trpc.orders.attachMedia.useMutation();

  const uniqueOrders = useMemo(() => Array.from(new Map((orders.data ?? []).map((order) => [order.id, order])).values()), [orders.data]);
  const { active: activeOrders, delivered: deliveredOrders } = splitDriverOrders(uniqueOrders);
  const orderStats = getDriverOrderStats(uniqueOrders);
  const transferDrivers = transferAccess.data?.allowed ? (activeShiftDrivers.data ?? []).filter((candidate) => candidate.id !== driver.data?.id) : [];
  const missingProfile = isAuthenticated && !driver.isLoading && !driver.error && driver.data === null;
  const hasPhoto = (order: (typeof uniqueOrders)[number] | null | undefined, kind: "order" | "invoice" | "delivery") => Boolean(order && (mediaUploaded[`${order.id}:${kind}`] || order.media?.some((media) => media.kind === kind)));

  const getLocation = () => new Promise<{ latitude: string; longitude: string } | null>((resolve) => {
    if (!navigator.geolocation) return resolve(null);
    navigator.geolocation.getCurrentPosition((position) => resolve({ latitude: String(position.coords.latitude), longitude: String(position.coords.longitude) }), () => resolve(null), { enableHighAccuracy: false, timeout: 20000, maximumAge: 60000 });
  });
  const beginWork = async () => { setAudioReady(await unlockDriverAudio()); setNotificationPermission(await requestDriverNotificationPermission()); if (activeShift.data?.id || !driver.data?.id) return; setWorking(true); const location = await getLocation(); setGpsUnavailableAtStart(!location); startShift.mutate({ driverId: driver.data.id, ...(location ?? {}) }); };
  const finishWork = async () => { if (!activeShift.data?.id) return; setWorking(true); const location = await getLocation(); endShift.mutate({ shiftId: activeShift.data.id, ...(location ?? {}) }); };
  const beginDelivery = async (order: (typeof activeOrders)[number]) => { setWorking(true); const location = await getLocation(); try { await beginDeliveryMutation.mutateAsync({ orderId: order.id, ...(location ?? {}) }); await orders.refetch(); setNotice({ type: "success", text: tr("بدأ التوصيل. صوّر الاستلام والفاتورة من داخل بطاقة الطلب.") }); } catch (error) { setNotice({ type: "error", text: error instanceof Error ? error.message : tr("تعذر بدء التوصيل. حاول مرة أخرى.") }); } finally { setWorking(false); } };
  const returnOrder = async (order: (typeof activeOrders)[number]) => { if (!window.confirm(tr("تأكيد إرجاع الطلب إلى الشركة؟ ستصبح عمولة السائق وحصة الشركة صفراً تلقائياً."))) return; setWorking(true); try { await returnOrderMutation.mutateAsync({ orderId: order.id, note: tr("أعاد السائق الطلب إلى الشركة") }); } finally { setWorking(false); } };
  const arriveAtDestination = async (order: (typeof activeOrders)[number]) => { if (!hasPhoto(order, "order") || !hasPhoto(order, "invoice")) return setNotice({ type: "error", text: tr("ارفع صورة الاستلام وصورة الفاتورة أولاً.") }); setWorking(true); const location = await getLocation(); try { await updateStatus.mutateAsync({ orderId: order.id, status: "in_transit", note: tr("وصل السائق إلى عنوان التسليم"), ...(location ?? {}) }); setNotice({ type: "success", text: tr("تم تسجيل الوصول. صوّر التسليم من داخل بطاقة الطلب.") }); } catch { /* error is shown by mutation */ } };
  const uploadOrderPhoto = async (order: (typeof uniqueOrders)[number], kind: "order" | "invoice" | "delivery", file?: File) => {
    if (!file) return;
    const key = `${order.id}:${kind}`;
    setUploadingKey(key);
    setPhotoErrors((current) => { const next = { ...current }; delete next[key]; return next; });
    try {
      const prepared = await prepareDriverPhoto(file);
      const uploaded = await uploadMedia.mutateAsync({ orderId: order.id, kind, fileName: prepared.fileName, mimeType: prepared.mimeType, dataBase64: prepared.dataBase64 });
      if (!uploaded.url) throw new Error("لم يتم تأكيد حفظ الصورة");
      setMediaUploaded((current) => ({ ...current, [key]: true }));
      await orders.refetch();
      if (kind === "delivery") {
        setWorking(true);
        const location = await getLocation();
        await completeDelivery.mutateAsync({ orderId: order.id, cashCollectedAmount: cashCollectedDrafts[order.id] ?? String(order.cashToCollectAmount ?? "0.000"), ...(location ?? {}) });
        setNotice({ type: "success", text: `شكراً للتوصيل. تم إنهاء الطلب ${order.orderNumber} وحفظ الصورة وتسجيل المبلغ المستلم.` });
      } else {
        const otherPickupImageReady = kind === "order" ? hasPhoto(order, "invoice") : kind === "invoice" ? hasPhoto(order, "order") : false;
        if (otherPickupImageReady) {
          setNotice({ type: "success", text: "تم إرفاق صورة الاستلام والفاتورة بنجاح ✓ يمكنك الآن الضغط على وصلت العنوان من بطاقة الطلب." });
        } else setNotice({ type: "success", text: "تم إرفاق الصورة بنجاح ✓" });
      }
    } catch (error) { const message = error instanceof Error ? error.message : "تعذر رفع الصورة"; const friendly = message.includes("الحجم") || message.includes("TOO_LARGE") ? "الصورة كبيرة جداً. التقطها مرة أخرى." : `تعذر رفع الصورة: ${message.slice(0, 180)}`; setPhotoErrors((current) => ({ ...current, [key]: friendly })); setNotice({ type: "error", text: friendly }); } finally { setUploadingKey(null); }
  };
  const transferCurrentOrder = (orderId: number) => { const toDriverId = Number(transferTargets[orderId]); if (!toDriverId) return setNotice({ type: "error", text: t("selectDriver") }); setTransferringId(orderId); transferOrder.mutate({ orderId, toDriverId }); };

  useEffect(() => { if (!activeShift.data?.id || !driver.data?.id || !navigator.geolocation) { setGpsActive(false); return; } const watchId = navigator.geolocation.watchPosition((position) => { setGpsActive(true); updateLocation.mutate({ latitude: String(position.coords.latitude), longitude: String(position.coords.longitude) }); }, () => setGpsActive(false), { enableHighAccuracy: true, maximumAge: 15000, timeout: 20000 }); return () => navigator.geolocation.clearWatch(watchId); }, [activeShift.data?.id, driver.data?.id]);

  if (loading) return <div className="flex min-h-screen items-center justify-center bg-slate-950 text-slate-300">{t("preparingAccount")}</div>;
  if (!isAuthenticated || !hasDriverRole) return <div dir={language === "ar" ? "rtl" : "ltr"} className="flex min-h-screen items-center justify-center bg-slate-950 p-5"><Card className="w-full max-w-sm rounded-3xl border-white/10 bg-slate-900 text-white"><CardContent className="p-7 text-center"><ShieldCheck className="mx-auto h-12 w-12 text-orange-300" /><h1 className="mt-4 text-xl font-black">{!isAuthenticated ? t("driverLoginRequired") : t("unauthorizedTitle")}</h1><Button onClick={() => navigate(!isAuthenticated ? "/local-login" : "/")} className="mt-6 w-full rounded-2xl bg-orange-500">{t("backHome")}</Button></CardContent></Card></div>;

  return (
    <div dir={language === "ar" ? "rtl" : "ltr"} className="min-h-screen bg-slate-950 text-white">
      <DriverAlerts orders={activeOrders.filter((order) => order.status === "assigned")} />
      <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
        <SheetContent side={language === "ar" ? "right" : "left"} className="z-[70] w-[min(84vw,21rem)] border-white/10 bg-slate-950 p-0 text-white [&>button]:text-white">
          <SheetHeader className="border-b border-white/10 p-5 text-right"><SheetTitle className="text-white">{tr("قائمة السائق")}</SheetTitle><SheetDescription className="text-slate-400">{tr("تنقّل سريع داخل حساب السائق.")}</SheetDescription></SheetHeader>
          <div className="space-y-2 p-4"><Button type="button" variant="outline" onClick={() => { setMenuOpen(false); navigate("/driver"); }} className="w-full justify-start border-white/15 bg-white/5 text-white hover:bg-white/10 hover:text-white"><Truck className="ml-2 h-4 w-4" />{tr("واجهة السائق")}</Button><Button type="button" variant="outline" onClick={() => { setMenuOpen(false); navigate("/driver/new-order"); }} className="w-full justify-start border-white/15 bg-white/5 text-white hover:bg-white/10 hover:text-white"><Package className="ml-2 h-4 w-4" />{t("driverCreateOrder")}</Button><Button type="button" variant="outline" onClick={() => { setMenuOpen(false); navigate("/driver/account"); }} className="w-full justify-start border-white/15 bg-white/5 text-white hover:bg-white/10 hover:text-white"><UserRound className="ml-2 h-4 w-4" />{t("accountSettings")}</Button><div className="border-t border-white/10 pt-3"><LanguageSwitcher /></div><Button type="button" variant="outline" onClick={() => { setMenuOpen(false); void logout().finally(() => window.location.assign("/local-login")); }} className="w-full justify-start border-rose-400/30 bg-rose-500/10 text-rose-100 hover:bg-rose-500/20 hover:text-white"><X className="ml-2 h-4 w-4" />{t("logout")}</Button></div>
        </SheetContent>
      </Sheet>
      <div className="mx-auto min-h-screen w-full max-w-xl bg-slate-900 pb-24 shadow-2xl">
        <header className="border-b border-white/10 bg-slate-900 px-5 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3"><img src={brandingQuery.data?.logoUrl || "/manus-storage/city-center-logo-user_665f44b4.png"} alt="" className="h-10 w-10 rounded-xl object-contain" /><div><p className="text-xs text-slate-400">{brandingQuery.data?.brandName || t("driverWelcome")}</p><h1 className="font-black">{user?.name || t("driverNameFallback")}</h1></div></div>
            <button type="button" onClick={() => setMenuOpen(true)} className="rounded-xl p-2 text-slate-300"><Menu className="h-5 w-5" /></button>
          </div>
          <div className={`mt-4 flex items-center justify-between rounded-2xl border p-3 ${activeShift.data ? "border-emerald-400/20 bg-emerald-500/10" : "border-orange-400/20 bg-orange-500/10"}`}>
            <div><p className="font-bold">{activeShift.data ? tr("أنت على رأس العمل") : tr("لست في العمل")}</p><p className="mt-1 text-xs text-slate-400">{activeShift.data ? (gpsActive ? tr("GPS يعمل الآن") : tr("GPS غير متاح، والعمل مستمر")) : tr("اضغط لبدء العمل")}</p>{activeShift.data ? <p className="mt-1 text-xs font-bold text-emerald-200">{tr("المبالغ المحصلة في هذه النوبة")}: {Number(activeShift.data.cashCollectedTotal ?? 0).toFixed(3)} {tr("د.ك")} · {activeShift.data.cashCollectionCount ?? 0} {tr("طلب مستلم")}</p> : null}{activeShift.data && audioReady ? <p className="mt-1 text-[11px] text-emerald-300">{tr("صوت التنبيه مفعّل")}</p> : null}{notificationPermission === "denied" ? <p className="mt-1 text-[11px] text-amber-300">{tr("إشعارات المتصفح موقوفة")}</p> : null}</div>
            <Button size="sm" disabled={working || missingProfile} onClick={() => void (activeShift.data ? finishWork() : beginWork())} className={activeShift.data ? "rounded-xl bg-rose-500 hover:bg-rose-600" : "rounded-xl bg-orange-500 hover:bg-orange-600"}><MapPin className="ml-1 h-4 w-4" />{activeShift.data ? tr("إنهاء العمل") : tr("بدء العمل")}</Button>
          </div>
        </header>
        <main className="space-y-5 px-5 pt-5">
          {notice ? <div role="status" className={`rounded-2xl p-3 text-sm ${notice.type === "success" ? "bg-emerald-500/15 text-emerald-100" : "bg-rose-500/15 text-rose-100"}`}>{notice.text}</div> : null}
          <div className="grid grid-cols-3 gap-2"><div className="rounded-2xl bg-white/5 p-3 text-center"><b className="text-2xl">{orderStats.pickup}</b><p className="mt-1 text-[11px] text-slate-400">{tr("بانتظار التوصيل")}</p></div><div className="rounded-2xl bg-orange-500/10 p-3 text-center"><b className="text-2xl text-orange-100">{orderStats.active}</b><p className="mt-1 text-[11px] text-orange-200">{tr("قيد التوصيل")}</p></div><div className="rounded-2xl bg-emerald-500/10 p-3 text-center"><b className="text-2xl text-emerald-100">{orderStats.delivered}</b><p className="mt-1 text-[11px] text-emerald-200">{t("delivered")}</p></div></div>
          <div className="flex items-center justify-between"><div><h2 className="text-xl font-black">{t("myOrders")}</h2><p className="mt-1 text-xs text-slate-400">{tr("ابدأ التوصيل ثم اتبع خطوات التصوير.")}</p></div><Button onClick={() => navigate("/driver/new-order")} className="rounded-xl bg-orange-500"><Package className="ml-1 h-4 w-4" />{t("driverCreateOrder")}</Button></div>
          {activeOrders.map((order) => {
            const pickupDone = hasPhoto(order, "order");
            const invoiceDone = hasPhoto(order, "invoice");
            const deliveryDone = hasPhoto(order, "delivery");
            const count = [pickupDone, invoiceDone, deliveryDone].filter(Boolean).length;
            return <Card key={order.id} className={`rounded-3xl border text-white ${order.status === "in_transit" ? "border-orange-300/30 bg-orange-500/10" : "border-white/10 bg-white/5"}`}><CardContent className="p-4"><div className="flex items-start justify-between"><div><p className="font-black">{order.orderNumber}</p><p className="mt-1 text-xs text-slate-400">{[order.deliveryGovernorateName, order.deliveryAreaName || order.area].filter(Boolean).join(" · ") || t("noArea")}</p>{order.customerName ? <p className="mt-2 font-bold">{t("recipientName")}: {order.customerName}</p> : null}<p className="mt-2 rounded-lg bg-emerald-500/10 px-2 py-1 text-xs font-black text-emerald-100">{tr("المطلوب استلامه من العميل")}: {Number(order.cashToCollectAmount ?? 0).toFixed(3)} {tr("د.ك")}</p>{order.cashCollectionNote ? <p className="mt-1 rounded-lg bg-amber-500/10 px-2 py-1 text-xs text-amber-100">{tr("ملاحظة التحصيل")}: {order.cashCollectionNote}</p> : null}{order.driverCommission !== undefined && Number(order.driverCommission) > 0 ? <p className="mt-2 rounded-lg bg-emerald-500/10 px-2 py-1 text-xs font-black text-emerald-100">{tr("عمولتك عند التسليم")}: {Number(order.driverCommission).toFixed(3)} {tr("د.ك")}</p> : null}{order.deliveryFee !== undefined ? <p className="mt-1 text-xs text-slate-300">{tr("سعر التوصيل")}: {Number(order.deliveryFee).toFixed(3)} {tr("د.ك")}</p> : null}</div><Badge className="bg-white/10 text-white">{statusLabel(order.status, tr)}</Badge></div>{order.transferredByName ? <p className="mt-3 rounded-xl bg-amber-500/10 p-2 text-sm text-amber-100">{tr("هذا الطلب محول من")}: {order.transferredByName}</p> : null}<FullAddress title={`${t("pickupAddress")}${order.pickupGovernorateName || order.pickupAreaName ? ` · ${[order.pickupGovernorateName, order.pickupAreaName].filter(Boolean).join(" · ")}` : ""}`} value={order.pickupAddress} locationUrl={order.pickupLocationUrl} accent="sky" tr={tr} /><FullAddress title={`${t("deliveryAddress")}${order.deliveryGovernorateName || order.deliveryAreaName ? ` · ${[order.deliveryGovernorateName, order.deliveryAreaName].filter(Boolean).join(" · ")}` : ""}`} value={order.deliveryAddress} accent="orange" tr={tr} /><OrderContacts pickupPhone={order.pickupPhone || order.companyPhone} pickupContactName={order.pickupContactName} deliveryPhone={order.customerPhone} customerName={order.customerName} tr={tr} /><div className="mt-4 rounded-2xl bg-black/15 p-3"><div className="flex justify-between text-xs"><b>{tr("تقدم صور الطلب")}</b><b className="text-orange-200">{count}/3</b></div><div className="mt-2 h-2 overflow-hidden rounded-full bg-white/10"><div className="h-full bg-orange-400" style={{ width: `${(count / 3) * 100}%` }} /></div><p className="mt-2 text-[11px] text-slate-400">{tr("الاستلام")} {pickupDone ? "✓" : "○"} · {tr("فاتورة")} {invoiceDone ? "✓" : "○"} · {tr("تسليم")} {deliveryDone ? "✓" : "○"}</p></div><TransferOrderControl orderId={order.id} selectedDriverId={transferTargets[order.id]} drivers={transferDrivers} transferring={transferringId === order.id} onSelect={(value) => setTransferTargets((current) => ({ ...current, [order.id]: value }))} onTransfer={() => transferCurrentOrder(order.id)} tr={tr} />{order.status === "assigned" ? <Button disabled={working} onClick={() => void beginDelivery(order)} className="mt-4 w-full rounded-xl bg-orange-500 py-5 text-base font-black">{t("startDelivery")}</Button> : null}{order.status === "picked_up" ? <section className="mt-4 rounded-2xl border border-sky-300/20 bg-sky-500/5 p-3"><p className="mb-3 text-center text-sm font-black text-sky-100">{tr("صوّر الاستلام والفاتورة من هنا")}</p><div className="grid grid-cols-2 gap-3"><PhotoTile label={tr("صورة الاستلام")} done={pickupDone} uploading={uploadingKey === `${order.id}:order`} error={photoErrors[`${order.id}:order`]} onFile={(file) => void uploadOrderPhoto(order, "order", file)} tr={tr} /><PhotoTile label={tr("صورة الفاتورة")} done={invoiceDone} uploading={uploadingKey === `${order.id}:invoice`} error={photoErrors[`${order.id}:invoice`]} onFile={(file) => void uploadOrderPhoto(order, "invoice", file)} tr={tr} /></div>{pickupDone && invoiceDone ? <Button disabled={working} onClick={() => void arriveAtDestination(order)} className="mt-3 w-full rounded-xl bg-orange-500 py-5 text-base font-black">{tr("وصلت العنوان")}</Button> : <p className="mt-3 text-center text-xs text-sky-100">{tr("ارفع الصورتين لتفعيل زر وصلت العنوان.")}</p>}</section> : null}{order.status === "in_transit" ? <section className="mt-4 rounded-2xl border border-emerald-300/20 bg-emerald-500/5 p-3"><p className="mb-3 text-center text-sm font-black text-emerald-100">{tr("أدخل قيمة ما استلمته نقداً من العميل ثم صوّر التسليم؛ سيُسجل المبلغ في حساب النوبة.")}</p><label className="mb-3 block text-sm font-bold text-emerald-50">{tr("المبلغ الذي استلمته فعلياً من العميل (د.ك)")}<Input type="number" min="0" step="0.001" value={cashCollectedDrafts[order.id] ?? String(order.cashToCollectAmount ?? "0.000")} onChange={(event) => setCashCollectedDrafts((current) => ({ ...current, [order.id]: event.target.value }))} className="mt-2 border-white/10 bg-slate-900 text-white" dir="ltr" inputMode="decimal" /></label>{order.cashCollectionNote ? <p className="mb-3 rounded-xl bg-amber-500/10 p-2 text-xs text-amber-100">{tr("ملاحظة التحصيل")}: {order.cashCollectionNote}</p> : null}<PhotoTile label={tr("صورة التسليم")} done={deliveryDone} uploading={uploadingKey === `${order.id}:delivery`} error={photoErrors[`${order.id}:delivery`]} onFile={(file) => void uploadOrderPhoto(order, "delivery", file)} tr={tr} /></section> : null}{order.status === "picked_up" || order.status === "in_transit" ? <Button type="button" disabled={working} variant="outline" onClick={() => void returnOrder(order)} className="mt-3 w-full rounded-xl border-rose-300/40 bg-rose-500/10 py-4 font-bold text-rose-100 hover:bg-rose-500/20 hover:text-white">{tr("إرجاع الطلب إلى الشركة")}</Button> : null}</CardContent></Card>;
          })}
          <button type="button" onClick={() => setShowDelivered((value) => !value)} className="flex w-full items-center justify-between rounded-2xl border border-emerald-400/30 bg-emerald-500/10 p-4"><span className="flex items-center gap-3"><CheckCircle2 className="h-6 w-6 text-emerald-200" /><span><b>{t("deliveredOrders")}</b><small className="block text-emerald-200">{deliveredOrders.length} {tr("طلب")}</small></span></span><span>{showDelivered ? "−" : "+"}</span></button>
          {showDelivered ? deliveredOrders.map((order) => <Card key={order.id} className="rounded-3xl border-emerald-300/50 bg-emerald-500/15 text-white"><CardContent className="p-4"><div className="flex items-start justify-between"><div><p className="font-black">{order.orderNumber}</p><p className="mt-1 text-xs text-emerald-100">{[order.deliveryGovernorateName, order.deliveryAreaName || order.area].filter(Boolean).join(" · ") || t("noArea")}</p>{order.customerName ? <p className="mt-2 font-bold">{t("recipientName")}: {order.customerName}</p> : null}<p className="mt-2 rounded-lg bg-emerald-500/10 px-2 py-1 text-xs font-black text-emerald-100">{tr("المطلوب من العميل")}: {Number(order.cashToCollectAmount ?? 0).toFixed(3)} {tr("د.ك")} · {tr("المستلم")}: {order.cashCollectionRecorded ? `${Number(order.cashCollectedAmount ?? 0).toFixed(3)} ${tr("د.ك")}` : tr("غير مسجل")}</p>{order.cashCollectionNote ? <p className="mt-1 rounded-lg bg-amber-500/10 px-2 py-1 text-xs text-amber-100">{tr("ملاحظة التحصيل")}: {order.cashCollectionNote}</p> : null}{order.driverCommission !== undefined && Number(order.driverCommission) > 0 ? <p className="mt-2 rounded-lg bg-emerald-500/10 px-2 py-1 text-xs font-black text-emerald-100">{tr("العمولة المستحقة")}: {Number(order.driverCommission).toFixed(3)} {tr("د.ك")}</p> : null}{order.deliveryFee !== undefined ? <p className="mt-1 text-xs text-slate-300">{tr("سعر التوصيل")}: {Number(order.deliveryFee).toFixed(3)} {tr("د.ك")}</p> : null}</div><Badge className="bg-emerald-500 text-white">{t("delivered")}</Badge></div>{order.transferredByName ? <p className="mt-3 rounded-xl bg-amber-500/10 p-2 text-sm text-amber-100">{tr("هذا الطلب محول من")}: {order.transferredByName}</p> : null}<FullAddress title={`${t("pickupAddress")}${order.pickupGovernorateName || order.pickupAreaName ? ` · ${[order.pickupGovernorateName, order.pickupAreaName].filter(Boolean).join(" · ")}` : ""}`} value={order.pickupAddress} locationUrl={order.pickupLocationUrl} accent="sky" tr={tr} /><FullAddress title={`${t("deliveryAddress")}${order.deliveryGovernorateName || order.deliveryAreaName ? ` · ${[order.deliveryGovernorateName, order.deliveryAreaName].filter(Boolean).join(" · ")}` : ""}`} value={order.deliveryAddress} accent="orange" tr={tr} /><OrderContacts pickupPhone={order.pickupPhone || order.companyPhone} pickupContactName={order.pickupContactName} deliveryPhone={order.customerPhone} customerName={order.customerName} tr={tr} /><OrderMediaGallery media={order.media} tr={tr} /><div className="mt-4 rounded-2xl bg-emerald-950/25 p-3"><p className="text-sm font-black text-emerald-100">{tr("سجل الطلب")}</p>{order.history?.length ? <div className="mt-2 space-y-2">{order.history.slice(0, 4).map((item) => <p key={`${item.action}-${item.createdAt.toISOString()}`} className="border-r-2 border-emerald-300/50 pr-2 text-xs text-emerald-50">{historyLabel(item, tr) || item.action} <span className="mr-1 text-emerald-200/80">· {item.createdAt.toLocaleString(language === "ar" ? "ar-KW" : language === "bn" ? "bn-BD" : language === "hi" ? "hi-IN" : "en-KW")}</span></p>)}</div> : <p className="mt-2 text-xs text-emerald-100">{tr("تم حفظ التسليم والصورة بنجاح.")}</p>}</div></CardContent></Card>) : null}
        </main>
      </div>
    </div>
  );
}
