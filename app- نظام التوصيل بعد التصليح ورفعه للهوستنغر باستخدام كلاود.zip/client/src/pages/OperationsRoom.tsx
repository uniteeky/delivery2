import { useMemo, useState } from "react";
import { useLocation } from "wouter";
import DashboardLayout from "@/components/DashboardLayout";
import DriverMap from "@/components/DriverMap";
import OrderManagementPanel from "@/components/OrderManagementPanel";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/i18n";
import {
  Activity,
  Clock3,
  FileDown,
  Image as ImageIcon,
  PackageCheck,
  RefreshCw,
  Truck,
  UsersRound,
} from "lucide-react";
import { friendlyError } from "@/lib/errorMessage";

const formatDate = (
  value: Date | string | null | undefined,
  language: string
) =>
  value
    ? new Date(value).toLocaleString(language === "ar" ? "ar-KW" : "en-KW", {
        dateStyle: "short",
        timeStyle: "short",
      })
    : "—";

export default function OperationsRoom() {
  const { t, language } = useLanguage();
  const [, navigate] = useLocation();
  const summary = trpc.dashboard.summary.useQuery(undefined, {
    refetchInterval: 15_000,
  });
  const locations = trpc.dashboard.driverLocations.useQuery(undefined, {
    refetchInterval: 15_000,
  });
  const recentOrders = trpc.dashboard.recentOrders.useQuery(undefined, {
    refetchInterval: 15_000,
  });
  const companies = trpc.companies.list.useQuery({ page: 1, pageSize: 100 });
  const drivers = trpc.drivers.list.useQuery();
  const locationsDirectory = trpc.locations.directory.useQuery(undefined, {
    staleTime: 300_000,
  });
  const [opsFilter, setOpsFilter] = useState<"day" | "week" | "month">("day");
  const [fromDate, setFromDate] = useState(() =>
    new Date().toISOString().slice(0, 10)
  );
  const [toDate, setToDate] = useState(() =>
    new Date().toISOString().slice(0, 10)
  );
  const [companyId, setCompanyId] = useState("all");
  const [driverId, setDriverId] = useState("all");
  const [source, setSource] = useState("all");
  const [governorateId, setGovernorateId] = useState("all");
  const [areaId, setAreaId] = useState("all");
  const [status, setStatus] = useState("all");
  const [paymentMethod, setPaymentMethod] = useState("all");
  const [expandedOrder, setExpandedOrder] = useState<number | null>(null);
  const reportFilters = useMemo(
    () => ({
      fromDate: fromDate || undefined,
      toDate: toDate || undefined,
      companyId: companyId === "all" ? undefined : Number(companyId),
      driverId: driverId === "all" ? undefined : Number(driverId),
      governorateId:
        governorateId === "all" ? undefined : Number(governorateId),
      areaId: areaId === "all" ? undefined : Number(areaId),
      status:
        status === "all"
          ? undefined
          : (status as
              | "pending"
              | "assigned"
              | "picked_up"
              | "in_transit"
              | "delivered"
              | "failed"),
      paymentMethod:
        paymentMethod === "all"
          ? undefined
          : (paymentMethod as "paid" | "cash_on_delivery"),
      source:
        source === "all"
          ? undefined
          : (source as "supervisor" | "company" | "external"),
    }),
    [
      fromDate,
      toDate,
      companyId,
      driverId,
      governorateId,
      areaId,
      status,
      paymentMethod,
      source,
    ]
  );
  const report = trpc.supervisorReports.get.useQuery(reportFilters);
  const filteredRecentOrders = (recentOrders.data ?? []).filter(order => {
    const created = new Date(order.updatedAt ?? order.createdAt).getTime();
    const span =
      opsFilter === "day"
        ? 24 * 60 * 60 * 1000
        : opsFilter === "week"
          ? 7 * 24 * 60 * 60 * 1000
          : 31 * 24 * 60 * 60 * 1000;
    return Date.now() - created <= span;
  });
  const refresh = () => {
    void summary.refetch();
    void locations.refetch();
    void recentOrders.refetch();
    void report.refetch();
  };
  let labels =
    language === "ar"
      ? {
          report: "التقارير التشغيلية التفصيلية",
          governorate: "المحافظة",
          area: "المنطقة",
          status: "الحالة",
          payment: "طريقة الدفع",
          paid: "مدفوع",
          cod: "الدفع عند الاستلام",
          deliveredStatus: "تم التسليم",
          notDeliveredStatus: "لم يتم التسليم",
          reportHint:
            "تقارير الشركات والسائقين والورديات مع سجل الطلبات والوسائط التاريخية.",
          from: "من تاريخ",
          to: "إلى تاريخ",
          company: "الشركة",
          driver: "السائق",
          all: "الكل",
          source: "مصدر الطلب",
          supervisor: "المشرف",
          companySource: "الشركة",
          external: "طلب خارجي",
          apply: "تحديث التقرير",
          print: "طباعة التقرير",
          companies: "ملخص الشركات",
          drivers: "مقارنة السائقين",
          orders: "تفاصيل الطلبات",
          shifts: "تحليل الورديات",
          order: "الطلب",
          assigned: "الطلبات المسندة",
          picked: "تم الاستلام",
          delivered: "تم التسليم",
          collected: "المبالغ المحصلة",
          cashDue: "المطلوب تحصيله",
          collection: "التحصيل",
          collectionNote: "ملاحظة التحصيل",
          hours: "ساعات العمل",
          created: "أنشأها",
          in: "تحويلات واردة",
          out: "تحويلات صادرة",
          pickup: "وقت الاستلام",
          delivery: "وقت التسليم",
          media: "الصور التاريخية",
          open: "فتح التفاصيل",
          noData: "لا توجد بيانات ضمن الفلاتر المحددة",
        }
      : {
          report: "Detailed operational reports",
          governorate: "Governorate",
          area: "Area",
          status: "Status",
          payment: "Payment",
          paid: "Paid",
          cod: "Cash on delivery",
          deliveredStatus: "Delivered",
          notDeliveredStatus: "Not delivered",
          reportHint:
            "Company, driver, shift, order history and media reports.",
          from: "From",
          to: "To",
          company: "Company",
          driver: "Driver",
          all: "All",
          source: "Order source",
          supervisor: "Supervisor",
          companySource: "Company",
          external: "External",
          apply: "Refresh report",
          print: "Print report",
          companies: "Company summary",
          drivers: "Driver comparison",
          orders: "Order details",
          shifts: "Shift analytics",
          order: "Order",
          assigned: "Assigned",
          picked: "Picked up",
          delivered: "Delivered",
          collected: "Cash collected",
          cashDue: "Cash due",
          collection: "Collection",
          collectionNote: "Collection note",
          hours: "Hours worked",
          created: "Created",
          in: "Transfers in",
          out: "Transfers out",
          pickup: "Pickup time",
          delivery: "Delivery time",
          media: "Historical photos",
          open: "Open details",
          noData: "No data for the selected filters",
        };
  if (language === "bn")
    labels = {
      ...labels,
      report: "বিস্তারিত কার্যক্রম প্রতিবেদন",
      reportHint: "কোম্পানি, চালক, শিফট, অর্ডার ইতিহাস ও মিডিয়া প্রতিবেদন।",
      from: "শুরুর তারিখ",
      to: "শেষ তারিখ",
      company: "কোম্পানি",
      driver: "চালক",
      all: "সব",
      source: "অর্ডারের উৎস",
      supervisor: "সুপারভাইজার",
      companySource: "কোম্পানি",
      external: "বাহ্যিক অর্ডার",
      apply: "প্রতিবেদন আপডেট",
      print: "প্রতিবেদন প্রিন্ট",
      companies: "কোম্পানি সারাংশ",
      drivers: "চালক তুলনা",
      orders: "অর্ডারের বিবরণ",
      shifts: "শিফট বিশ্লেষণ",
      order: "অর্ডার",
      assigned: "বরাদ্দ",
      picked: "সংগ্রহ করা হয়েছে",
      delivered: "ডেলিভারি হয়েছে",
      hours: "কাজের ঘণ্টা",
      created: "তৈরি",
      in: "ভিতরের স্থানান্তর",
      out: "বাইরের স্থানান্তর",
      pickup: "সংগ্রহের সময়",
      delivery: "ডেলিভারির সময়",
      media: "ঐতিহাসিক ছবি",
      open: "বিস্তারিত খুলুন",
      noData: "নির্বাচিত ফিল্টারে কোনো তথ্য নেই",
    };
  if (language === "hi")
    labels = {
      ...labels,
      report: "विस्तृत संचालन रिपोर्ट",
      reportHint: "कंपनी, चालक, शिफ्ट, ऑर्डर इतिहास और मीडिया रिपोर्ट।",
      from: "प्रारंभ तिथि",
      to: "अंतिम तिथि",
      company: "कंपनी",
      driver: "चालक",
      all: "सभी",
      source: "ऑर्डर स्रोत",
      supervisor: "सुपरवाइज़र",
      companySource: "कंपनी",
      external: "बाहरी ऑर्डर",
      apply: "रिपोर्ट अपडेट",
      print: "रिपोर्ट प्रिंट",
      companies: "कंपनी सारांश",
      drivers: "चालक तुलना",
      orders: "ऑर्डर विवरण",
      shifts: "शिफ्ट विश्लेषण",
      order: "ऑर्डर",
      assigned: "सौंपे गए",
      picked: "उठाया गया",
      delivered: "डिलीवर",
      hours: "काम के घंटे",
      created: "बनाए गए",
      in: "अंदर स्थानांतरण",
      out: "बाहर स्थानांतरण",
      pickup: "पिकअप समय",
      delivery: "डिलीवरी समय",
      media: "ऐतिहासिक तस्वीरें",
      open: "विवरण खोलें",
      noData: "चयनित फ़िल्टर में कोई डेटा नहीं",
    };
  const stats = [
    {
      label: t("ordersToday"),
      value: summary.data?.ordersToday ?? 0,
      icon: PackageCheck,
      tone: "text-orange-600 bg-orange-50",
    },
    {
      label: t("inTransit"),
      value: summary.data?.inTransit ?? 0,
      icon: Truck,
      tone: "text-blue-600 bg-blue-50",
    },
    {
      label: t("delivered"),
      value: summary.data?.delivered ?? 0,
      icon: Activity,
      tone: "text-emerald-600 bg-emerald-50",
    },
    {
      label: t("activeDrivers"),
      value: summary.data?.activeDrivers ?? 0,
      icon: UsersRound,
      tone: "text-violet-600 bg-violet-50",
    },
  ];
  const statusLabels: Record<string, string> = {
    pending: t("statusNew"),
    assigned: t("statusAssigned"),
    picked_up: t("statusPickedUp"),
    in_transit: t("statusInTransit"),
    delivered: t("statusDelivered"),
    failed: t("statusFailed"),
  };
  const mediaKindLabels: Record<string, string> = {
    order: t("orderPhoto"),
    invoice: t("invoicePhoto"),
    delivery: t("deliveryPhoto"),
  };
  return (
    <DashboardLayout>
      <div
        dir={language === "ar" ? "rtl" : "ltr"}
        className="min-h-screen bg-[#f8fafc] p-4 sm:p-6 lg:p-8"
      >
        <div className="mx-auto max-w-7xl">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between print:hidden">
            <div>
              <div className="flex items-center gap-2 text-sm font-semibold text-blue-600">
                <Activity className="h-4 w-4" /> {t("operationsRoom")}
              </div>
              <h1 className="mt-2 text-3xl font-black tracking-tight">
                {t("operationsRoomTitle")}
              </h1>
              <p className="mt-2 text-sm text-slate-500">
                {t("operationsRoomDescription")}
              </p>
            </div>
            <Button
              variant="outline"
              onClick={refresh}
              disabled={
                summary.isFetching || locations.isFetching || report.isFetching
              }
              className="rounded-xl bg-white"
            >
              <RefreshCw className="ml-2 h-4 w-4" /> {t("retry")}
            </Button>
          </div>
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4 print:hidden">
            {stats.map(({ label, value, icon: Icon, tone }) => (
              <Card
                key={label}
                className="rounded-3xl border-slate-100 shadow-sm"
              >
                <CardContent className="p-5">
                  <div
                    className={`flex h-10 w-10 items-center justify-center rounded-xl ${tone}`}
                  >
                    <Icon className="h-5 w-5" />
                  </div>
                  <p className="mt-5 text-sm font-semibold text-slate-500">
                    {label}
                  </p>
                  <p className="mt-1 text-3xl font-black text-slate-900">
                    {value}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
          <OrderManagementPanel
            onAdd={() => navigate("/orders/manage")}
            title="إدارة الطلبات داخل غرفة العمليات"
          />
          <div className="mt-6 grid gap-6 xl:grid-cols-[1.4fr_0.6fr] print:hidden">
            <Card className="rounded-3xl border-slate-100 shadow-sm">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>{t("liveDriverMapTitle")}</span>
                  <Badge className="rounded-full bg-sky-50 text-sky-700 hover:bg-sky-50">
                    {locations.data?.length ?? 0} {t("driversOnMap")}
                  </Badge>
                </CardTitle>
                <p className="text-sm text-slate-500">
                  {t("liveDriverMapDescription")}
                </p>
              </CardHeader>
              <CardContent>
                {locations.error ? (
                  <div className="rounded-2xl bg-red-50 p-5 text-sm text-red-700">
                    {t("locationsError")}{" "}
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => locations.refetch()}
                      className="mr-2 rounded-lg"
                    >
                      {t("retry")}
                    </Button>
                  </div>
                ) : (
                  <DriverMap locations={locations.data ?? []} />
                )}
              </CardContent>
            </Card>
            <Card className="rounded-3xl border-slate-100 shadow-sm">
              <CardHeader>
                <CardTitle>{t("recentOrderActivity")}</CardTitle>
                <p className="text-sm text-slate-500">
                  {t("recentOrderActivityDescription")}
                </p>
                <div className="mt-3 flex gap-2">
                  <Button
                    size="sm"
                    type="button"
                    onClick={() => setOpsFilter("day")}
                    className={`rounded-xl ${opsFilter === "day" ? "bg-blue-600 text-white" : "bg-slate-100 text-slate-600"}`}
                  >
                    {t("daily")}
                  </Button>
                  <Button
                    size="sm"
                    type="button"
                    onClick={() => setOpsFilter("week")}
                    className={`rounded-xl ${opsFilter === "week" ? "bg-blue-600 text-white" : "bg-slate-100 text-slate-600"}`}
                  >
                    {t("weekly")}
                  </Button>
                  <Button
                    size="sm"
                    type="button"
                    onClick={() => setOpsFilter("month")}
                    className={`rounded-xl ${opsFilter === "month" ? "bg-blue-600 text-white" : "bg-slate-100 text-slate-600"}`}
                  >
                    {t("monthly")}
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {recentOrders.isLoading ? (
                  <p className="rounded-xl bg-slate-50 p-4 text-sm text-slate-500">
                    {t("loading")}
                  </p>
                ) : recentOrders.error ? (
                  <p className="rounded-xl bg-red-50 p-4 text-sm text-red-700">
                    {t("operationsError")}
                  </p>
                ) : filteredRecentOrders.length === 0 ? (
                  <p className="rounded-xl bg-slate-50 p-4 text-sm text-slate-500">
                    {t("noOrders")}
                  </p>
                ) : (
                  filteredRecentOrders.map(order => (
                    <div
                      key={order.id}
                      className="rounded-2xl border border-slate-100 bg-white p-3"
                    >
                      <div className="flex items-center justify-between gap-3">
                        <strong className="text-sm">{order.orderNumber}</strong>
                        <Badge variant="outline" className="rounded-full">
                          {statusLabels[order.status] || order.status}
                        </Badge>
                      </div>
                      <p className="mt-1 text-xs font-semibold text-emerald-800">
                        {labels.cashDue}:{" "}
                        {Number(order.cashToCollectAmount ?? 0).toFixed(3)} د.ك
                        · {labels.collected}:{" "}
                        {order.cashCollectionRecorded
                          ? `${Number(order.cashCollectedAmount ?? 0).toFixed(3)} د.ك`
                          : "—"}
                      </p>
                      {order.cashCollectionNote ? (
                        <p className="mt-1 text-[11px] text-amber-800">
                          {labels.collectionNote}: {order.cashCollectionNote}
                        </p>
                      ) : null}
                      <p className="mt-2 text-xs text-slate-500">
                        {[
                          order.deliveryGovernorateName,
                          order.deliveryAreaName || order.area,
                          order.deliveryAddress,
                        ]
                          .filter(Boolean)
                          .join(" · ") || t("noArea")}
                      </p>
                      {order.pickupContactName ? (
                        <p className="mt-1 text-xs text-slate-500">
                          مستلم الفرع: {order.pickupContactName}{" "}
                          {order.pickupPhone ? `· ${order.pickupPhone}` : ""}
                        </p>
                      ) : null}
                      <p className="mt-1 text-xs font-semibold text-emerald-800">
                        المطلوب تحصيله:{" "}
                        {Number(order.cashToCollectAmount ?? 0).toFixed(3)} د.ك
                        · المستلم:{" "}
                        {order.cashCollectionRecorded
                          ? `${Number(order.cashCollectedAmount ?? 0).toFixed(3)} د.ك`
                          : "غير مسجل"}
                      </p>
                      {order.cashCollectionNote ? (
                        <p className="mt-1 text-xs text-amber-800">
                          {labels.collectionNote}: {order.cashCollectionNote}
                        </p>
                      ) : null}
                      <div className="mt-2 flex items-center gap-1 text-[11px] text-slate-400">
                        <Clock3 className="h-3 w-3" />{" "}
                        {new Date(
                          order.updatedAt ?? order.createdAt
                        ).toLocaleString(
                          language === "ar"
                            ? "ar-KW"
                            : language === "bn"
                              ? "bn-BD"
                              : language === "hi"
                                ? "hi-IN"
                                : "en-KW"
                        )}
                      </div>
                    </div>
                  ))
                )}
              </CardContent>
            </Card>
          </div>
          <section className="mt-8" id="supervisor-report">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
              <div>
                <h2 className="text-2xl font-black text-slate-900">
                  {labels.report}
                </h2>
                <p className="mt-1 text-sm text-slate-500">
                  {labels.reportHint}
                </p>
              </div>
              <Button
                onClick={() => window.print()}
                className="rounded-xl bg-slate-900 text-white print:hidden"
              >
                <FileDown className="ml-2 h-4 w-4" />
                {labels.print}
              </Button>
            </div>
            <Card className="mt-5 rounded-3xl border-slate-100 bg-white shadow-sm print:hidden">
              <CardContent className="grid gap-3 p-4 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-6">
                <label className="text-sm font-semibold text-slate-600">
                  {labels.from}
                  <Input
                    type="date"
                    value={fromDate}
                    onChange={e => setFromDate(e.target.value)}
                    className="mt-1 bg-white"
                  />
                </label>
                <label className="text-sm font-semibold text-slate-600">
                  {labels.to}
                  <Input
                    type="date"
                    value={toDate}
                    onChange={e => setToDate(e.target.value)}
                    className="mt-1 bg-white"
                  />
                </label>
                <label className="text-sm font-semibold text-slate-600">
                  {labels.company}
                  <select
                    value={companyId}
                    onChange={e => setCompanyId(e.target.value)}
                    className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-white px-3 text-sm"
                  >
                    <option value="all">{labels.all}</option>
                    {(companies.data?.items ?? []).map(company => (
                      <option key={company.id} value={company.id}>
                        {company.name}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="text-sm font-semibold text-slate-600">
                  {labels.driver}
                  <select
                    value={driverId}
                    onChange={e => setDriverId(e.target.value)}
                    className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-white px-3 text-sm"
                  >
                    <option value="all">{labels.all}</option>
                    {(drivers.data ?? []).map(driver => (
                      <option key={driver.id} value={driver.id}>
                        {driver.name}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="text-sm font-semibold text-slate-600">
                  {labels.governorate}
                  <select
                    value={governorateId}
                    onChange={e => {
                      setGovernorateId(e.target.value);
                      setAreaId("all");
                    }}
                    className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-white px-3 text-sm"
                  >
                    <option value="all">{labels.all}</option>
                    {(locationsDirectory.data ?? []).map(item => (
                      <option key={item.id} value={item.id}>
                        {item.nameAr}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="text-sm font-semibold text-slate-600">
                  {labels.area}
                  <select
                    disabled={governorateId === "all"}
                    value={areaId}
                    onChange={e => setAreaId(e.target.value)}
                    className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-white px-3 text-sm"
                  >
                    <option value="all">{labels.all}</option>
                    {(
                      locationsDirectory.data?.find(
                        item => String(item.id) === governorateId
                      )?.areas ?? []
                    ).map(area => (
                      <option key={area.id} value={area.id}>
                        {area.nameAr}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="text-sm font-semibold text-slate-600">
                  {labels.status}
                  <select
                    value={status}
                    onChange={e => setStatus(e.target.value)}
                    className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-white px-3 text-sm"
                  >
                    <option value="all">{labels.all}</option>
                    <option value="pending">{t("statusNew")}</option>
                    <option value="assigned">{t("statusAssigned")}</option>
                    <option value="picked_up">{t("statusPickedUp")}</option>
                    <option value="in_transit">{t("statusInTransit")}</option>
                    <option value="delivered">{labels.deliveredStatus}</option>
                    <option value="failed">{t("statusFailed")}</option>
                  </select>
                </label>
                <label className="text-sm font-semibold text-slate-600">
                  {labels.payment}
                  <select
                    value={paymentMethod}
                    onChange={e => setPaymentMethod(e.target.value)}
                    className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-white px-3 text-sm"
                  >
                    <option value="all">{labels.all}</option>
                    <option value="paid">{labels.paid}</option>
                    <option value="cash_on_delivery">{labels.cod}</option>
                  </select>
                </label>
                <label className="text-sm font-semibold text-slate-600">
                  {labels.source}
                  <select
                    value={source}
                    onChange={e => setSource(e.target.value)}
                    className="mt-1 h-10 w-full rounded-md border border-slate-200 bg-white px-3 text-sm"
                  >
                    <option value="all">{labels.all}</option>
                    <option value="supervisor">{labels.supervisor}</option>
                    <option value="company">{labels.companySource}</option>
                    <option value="external">{labels.external}</option>
                  </select>
                </label>
              </CardContent>
            </Card>
            {report.isLoading ? (
              <p className="mt-5 rounded-2xl bg-white p-6 text-sm text-slate-500">
                {t("loading")}
              </p>
            ) : report.error ? (
              <div className="mt-5 flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-red-50 p-6 text-sm text-red-700"><span>{friendlyError(report.error)}</span><Button type="button" variant="outline" onClick={() => void report.refetch()} disabled={report.isFetching} className="rounded-xl">{t("retry")}</Button></div>
            ) : (
              <>
                <div className="mt-5 grid gap-5 lg:grid-cols-2">
                  <Card className="rounded-3xl border-slate-100 shadow-sm">
                    <CardHeader>
                      <CardTitle>{labels.companies}</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {report.data?.companySummaries.length ? (
                        report.data.companySummaries.map(item => (
                          <div
                            key={`${item.companyId ?? item.source}-${item.companyName}`}
                            className="rounded-2xl border border-slate-100 bg-slate-50 p-4"
                          >
                            <div className="flex justify-between gap-3">
                              <strong>{item.companyName}</strong>
                              <Badge variant="outline">
                                {item.orders} {labels.order}
                              </Badge>
                            </div>
                            <div className="mt-3 grid grid-cols-2 gap-2 text-xs text-slate-600">
                              <span>
                                {labels.picked}: <b>{item.pickedUp}</b>
                              </span>
                              <span>
                                {labels.delivered}: <b>{item.delivered}</b>
                              </span>
                            </div>
                          </div>
                        ))
                      ) : (
                        <p className="text-sm text-slate-500">
                          {labels.noData}
                        </p>
                      )}
                    </CardContent>
                  </Card>
                  <Card className="rounded-3xl border-slate-100 shadow-sm">
                    <CardHeader>
                      <CardTitle>{labels.drivers}</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {report.data?.driverSummaries.length ? (
                        report.data.driverSummaries.map(item => (
                          <div
                            key={item.driverId}
                            className="rounded-2xl border border-slate-100 bg-slate-50 p-4"
                          >
                            <div className="flex justify-between gap-3">
                              <strong>{item.driverName}</strong>
                              <Badge className="bg-emerald-600">
                                {item.delivered} {labels.delivered}
                              </Badge>
                            </div>
                            <div className="mt-3 grid grid-cols-2 gap-2 text-xs text-slate-600 sm:grid-cols-6">
                              <span>
                                {labels.assigned}: <b>{item.assignedOrders}</b>
                              </span>
                              <span>
                                {labels.picked}: <b>{item.pickedUp}</b>
                              </span>
                              <span>
                                {labels.created}: <b>{item.createdOrders}</b>
                              </span>
                              <span>
                                {labels.in}: <b>{item.transferredIn}</b>
                              </span>
                              <span>
                                {labels.out}: <b>{item.transferredOut}</b>
                              </span>
                              <span>
                                {labels.collected}:{" "}
                                <b>
                                  {Number(item.cashCollectedTotal ?? 0).toFixed(
                                    3
                                  )}
                                </b>{" "}
                                ({item.cashCollectionCount ?? 0})
                              </span>
                            </div>
                          </div>
                        ))
                      ) : (
                        <p className="text-sm text-slate-500">
                          {labels.noData}
                        </p>
                      )}
                    </CardContent>
                  </Card>
                </div>
                <Card className="mt-5 rounded-3xl border-slate-100 shadow-sm">
                  <CardHeader>
                    <CardTitle>{labels.shifts}</CardTitle>
                  </CardHeader>
                  <CardContent className="overflow-x-auto">
                    <table className="w-full min-w-[840px] text-sm">
                      <thead>
                        <tr className="border-b text-right text-slate-500">
                          <th className="p-3">{labels.driver}</th>
                          <th className="p-3">{labels.from}</th>
                          <th className="p-3">{labels.to}</th>
                          <th className="p-3">{labels.hours}</th>
                          <th className="p-3">{labels.delivered}</th>
                          <th className="p-3">{labels.collected}</th>
                          <th className="p-3">{labels.collection}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {report.data?.shiftRows.map(shift => (
                          <tr
                            key={shift.id}
                            className="border-b border-slate-100"
                          >
                            <td className="p-3 font-semibold">
                              {shift.driverName ?? "—"}
                            </td>
                            <td className="p-3">
                              {formatDate(shift.startedAt, language)}
                            </td>
                            <td className="p-3">
                              {formatDate(shift.endedAt, language)}
                            </td>
                            <td className="p-3">{shift.hoursWorked}</td>
                            <td className="p-3">{shift.deliveredCount}</td>
                            <td className="p-3 font-black text-emerald-700">
                              {Number(shift.cashCollectedTotal ?? 0).toFixed(3)}{" "}
                              د.ك · {shift.cashCollectionCount ?? 0}
                            </td>
                            <td className="p-3">
                              {shift.cashCollectionCount
                                ? labels.collected
                                : "—"}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {!report.data?.shiftRows.length && (
                      <p className="p-4 text-sm text-slate-500">
                        {labels.noData}
                      </p>
                    )}
                  </CardContent>
                </Card>
                <Card className="mt-5 rounded-3xl border-slate-100 shadow-sm">
                  <CardHeader>
                    <CardTitle>{labels.orders}</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {report.data?.orderRows.length ? (
                      report.data.orderRows.map(order => (
                        <div
                          key={order.id}
                          className="rounded-2xl border border-slate-100 bg-white p-4"
                        >
                          <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                            <div>
                              <strong>{order.orderNumber}</strong>
                              <span className="mr-2 text-sm text-slate-500">
                                {order.companyName ??
                                  (order.source === "external"
                                    ? labels.external
                                    : "—")}
                              </span>
                            </div>
                            <Badge variant="outline">
                              {statusLabels[order.status] || order.status}
                            </Badge>
                          </div>
                          <div className="mt-3 grid gap-2 text-xs text-slate-600 sm:grid-cols-6">
                            <span>
                              {labels.driver}:{" "}
                              <b>{order.assignedDriverName ?? "—"}</b>
                            </span>
                            <span>
                              {labels.pickup}:{" "}
                              <b>{formatDate(order.pickupAt, language)}</b>
                            </span>
                            <span>
                              {labels.delivery}:{" "}
                              <b>{formatDate(order.deliveryAt, language)}</b>
                            </span>
                            <span>
                              {labels.created}:{" "}
                              <b>{formatDate(order.createdAt, language)}</b>
                            </span>
                            <span>
                              {labels.cashDue}:{" "}
                              <b>
                                {Number(order.cashToCollectAmount ?? 0).toFixed(
                                  3
                                )}{" "}
                                د.ك
                              </b>
                            </span>
                            <span>
                              {labels.collected}:{" "}
                              <b>
                                {order.cashCollectionRecorded
                                  ? `${Number(order.cashCollectedAmount ?? 0).toFixed(3)} د.ك`
                                  : "—"}
                              </b>
                            </span>
                            <span>
                              {labels.payment}:{" "}
                              <b>
                                {Number(order.cashToCollectAmount ?? 0) > 0
                                  ? labels.cod
                                  : labels.paid}
                              </b>
                            </span>
                            {order.cashCollectionNote ? (
                              <span className="sm:col-span-2">
                                {labels.collectionNote}:{" "}
                                <b>{order.cashCollectionNote}</b>
                              </span>
                            ) : null}
                          </div>
                          <div className="mt-3 flex flex-wrap gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              className="rounded-lg bg-white"
                              onClick={() =>
                                setExpandedOrder(
                                  expandedOrder === order.id ? null : order.id
                                )
                              }
                            >
                              <ImageIcon className="ml-1 h-4 w-4" />
                              {labels.media} ({order.media.length})
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="rounded-lg bg-white"
                              onClick={() => navigate(`/orders/${order.id}`)}
                            >
                              {labels.open}
                            </Button>
                          </div>
                          {expandedOrder === order.id && (
                            <div className="mt-4 grid gap-3 border-t border-slate-100 pt-4 sm:grid-cols-3">
                              {order.media.length ? (
                                order.media.map(item => (
                                  <a
                                    key={`${item.kind}-${item.createdAt}`}
                                    href={item.fileUrl}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="overflow-hidden rounded-xl border bg-slate-50"
                                  >
                                    <img
                                      src={item.fileUrl}
                                      alt={`${item.kind} ${order.orderNumber}`}
                                      className="h-36 w-full object-cover"
                                    />
                                    <span className="block p-2 text-xs font-semibold text-slate-600">
                                      {mediaKindLabels[item.kind] || item.kind}{" "}
                                      · {formatDate(item.createdAt, language)}
                                    </span>
                                  </a>
                                ))
                              ) : (
                                <p className="text-sm text-slate-500">
                                  {labels.noData}
                                </p>
                              )}
                            </div>
                          )}
                        </div>
                      ))
                    ) : (
                      <p className="p-4 text-sm text-slate-500">
                        {labels.noData}
                      </p>
                    )}
                  </CardContent>
                </Card>
              </>
            )}
          </section>
        </div>
      </div>
    </DashboardLayout>
  );
}
