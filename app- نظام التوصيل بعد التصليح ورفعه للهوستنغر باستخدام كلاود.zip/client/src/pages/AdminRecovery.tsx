import { useState } from "react";
import { Link, useLocation } from "wouter";
import { ArrowRight, KeyRound, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useLanguage } from "@/i18n";
import LanguageSwitcher from "@/components/LanguageSwitcher";
import { friendlyError } from "@/lib/errorMessage";

const copy = {
  ar: {
    title: "استعادة دخول المدير",
    description: "أدخل رمز الاستعادة الذي استلمته من مسؤول الاستضافة، ثم بيانات حساب المدير وكلمة مرور جديدة.",
    secret: "رمز الاستعادة الخاص",
    login: "الرقم المدني أو اسم المستخدم أو البريد الإلكتروني (اختياري)",
    password: "كلمة المرور الجديدة (12 حرفًا على الأقل)",
    confirm: "تأكيد كلمة المرور الجديدة",
    mismatch: "كلمتا المرور غير متطابقتين.",
    success: "تم تغيير كلمة مرور حساب المدير. انتقل الآن إلى صفحة الدخول.",
    failure: "تعذرت استعادة الدخول. تحقق من البيانات وحاول مجددًا.",
    privacy: "لا ترسل رمز الاستعادة أو كلمة المرور في المحادثات. الرمز يعمل مرة واحدة فقط ويُحفظ أثره دون تخزين الرمز نفسه.",
    back: "العودة للرئيسية",
    submit: "تغيير كلمة المرور",
    pending: "جارٍ التحقق...",
  },
  en: {
    title: "Recover admin access",
    description: "Enter the recovery code supplied for your hosting account, your admin login, and a new password.",
    secret: "Private recovery code",
    login: "Civil ID, username, or email (optional)",
    password: "New password (at least 12 characters)",
    confirm: "Confirm new password",
    mismatch: "The passwords do not match.",
    success: "The admin password has been changed. You can now sign in.",
    failure: "Recovery failed. Check the information and try again.",
    privacy: "Do not share the recovery code or password in chat. The code works once, and only a fingerprint is retained for audit.",
    back: "Back to home",
    submit: "Reset password",
    pending: "Verifying...",
  },
} as const;

export default function AdminRecovery() {
  const [, navigate] = useLocation();
  const { language, direction } = useLanguage();
  const text = language === "ar" ? copy.ar : copy.en;
  const [form, setForm] = useState({ secret: "", login: "", password: "", confirmPassword: "" });
  const [status, setStatus] = useState<{ type: "error" | "success"; message: string } | null>(null);
  const [pending, setPending] = useState(false);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (form.password !== form.confirmPassword) {
      setStatus({ type: "error", message: text.mismatch });
      return;
    }
    setPending(true);
    setStatus(null);
    try {
      const response = await fetch("/api/auth/admin-recovery", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-admin-recovery-secret": form.secret },
        cache: "no-store",
        body: JSON.stringify({ login: form.login, newPassword: form.password }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(typeof data.error === "string" ? data.error : text.failure);
      setStatus({ type: "success", message: text.success });
      setForm({ secret: "", login: "", password: "", confirmPassword: "" });
      window.setTimeout(() => navigate("/local-login"), 1400);
    } catch (error) {
      setStatus({ type: "error", message: friendlyError(error, text.failure) });
    } finally {
      setPending(false);
    }
  }

  const update = (key: keyof typeof form) => (event: React.ChangeEvent<HTMLInputElement>) =>
    setForm((current) => ({ ...current, [key]: event.target.value }));

  return (
    <main dir={direction} className="min-h-screen bg-[#fffaf4] px-4 py-8 text-slate-900 sm:px-6">
      <div className="mx-auto max-w-lg">
        <div className="mb-5 flex items-center justify-between gap-3">
          <Link href="/" className="inline-flex items-center gap-2 text-sm font-bold text-slate-600 hover:text-orange-600">
            <ArrowRight className="h-4 w-4" /> {text.back}
          </Link>
          <LanguageSwitcher />
        </div>
        <Card className="rounded-[2rem] border-orange-100 shadow-xl shadow-orange-100/40">
          <CardHeader className="p-6 sm:p-8">
            <div className="flex items-start gap-3">
              <div className="rounded-2xl bg-orange-100 p-3 text-orange-600"><KeyRound className="h-6 w-6" /></div>
              <div>
                <CardTitle className="text-2xl font-black">{text.title}</CardTitle>
                <p className="mt-2 text-sm leading-7 text-slate-500">{text.description}</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-6 pt-0 sm:p-8 sm:pt-0">
            <form onSubmit={submit} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="recovery-secret">{text.secret}</Label>
                <Input id="recovery-secret" type="password" required value={form.secret} onChange={update("secret")} className="h-12 rounded-xl" autoComplete="off" maxLength={256} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="recovery-login">{text.login}</Label>
                <Input id="recovery-login" value={form.login} onChange={update("login")} className="h-12 rounded-xl" autoComplete="username" maxLength={320} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="recovery-password">{text.password}</Label>
                <Input id="recovery-password" type="password" minLength={12} maxLength={128} required value={form.password} onChange={update("password")} className="h-12 rounded-xl" autoComplete="new-password" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="recovery-confirm-password">{text.confirm}</Label>
                <Input id="recovery-confirm-password" type="password" minLength={12} maxLength={128} required value={form.confirmPassword} onChange={update("confirmPassword")} className="h-12 rounded-xl" autoComplete="new-password" />
              </div>
              {status ? <p role="status" className={`rounded-xl p-3 text-sm font-semibold ${status.type === "success" ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"}`}>{status.message}</p> : null}
              <div className="rounded-2xl bg-slate-50 p-4 text-sm leading-7 text-slate-600">
                <ShieldCheck className="mb-1 inline h-4 w-4 text-emerald-600" /> {text.privacy}
              </div>
              <Button type="submit" disabled={pending} className="h-12 w-full rounded-xl bg-orange-500 font-bold text-white hover:bg-orange-600">
                {pending ? text.pending : text.submit}
              </Button>
            </form>
            <p className="mt-5 text-center text-sm text-slate-500">
              <Link href="/local-login" className="font-bold text-orange-600 hover:underline">{language === "ar" ? "لديك كلمة المرور؟ سجّل الدخول" : "Already have a password? Sign in"}</Link>
            </p>
          </CardContent>
        </Card>
      </div>
    </main>
  );
}
