import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import LocationPicker from "@/components/LocationPicker";
import { trpc } from "@/lib/trpc";
import { useUiText } from "@/lib/uiText";

export default function CompanyAreaRatePanel({ company }: { company: { id: number; name: string } }) {
  const tr = useUiText();
  const utils = trpc.useUtils();
  const [governorateId, setGovernorateId] = useState<number | undefined>();
  const [areaId, setAreaId] = useState<number | undefined>();
  const [governorateAmount, setGovernorateAmount] = useState("0.000");
  const [areaAmount, setAreaAmount] = useState("0.000");
  const [notice, setNotice] = useState("");

  const rates = trpc.companies.areaRates.useQuery({ companyId: company.id });
  const governorateRates = trpc.companies.governorateRates.useQuery({ companyId: company.id });
  const setRate = trpc.companies.setAreaRate.useMutation({
    onSuccess: async () => {
      setNotice(tr("تم حفظ سعر المنطقة"));
      await utils.companies.areaRates.invalidate({ companyId: company.id });
    },
    onError: (error) => setNotice(error.message),
  });
  const setGovernorateRate = trpc.companies.setGovernorateRate.useMutation({
    onSuccess: async () => {
      setNotice(tr("تم حفظ سعر المحافظة"));
      await utils.companies.governorateRates.invalidate({ companyId: company.id });
      await utils.companies.areaRates.invalidate({ companyId: company.id });
    },
    onError: (error) => setNotice(error.message),
  });

  const selectedGovernorateRate = governorateRates.data?.find((item) => item.governorateId === governorateId);
  const selectedAreaRate = rates.data?.find((item) => item.areaId === areaId);

  useEffect(() => {
    setGovernorateAmount(selectedGovernorateRate ? String(selectedGovernorateRate.amount) : "0.000");
  }, [governorateId, selectedGovernorateRate?.amount]);

  useEffect(() => {
    const inherited = governorateRates.data?.find((item) => item.governorateId === governorateId);
    const effective = selectedAreaRate?.amount ?? inherited?.amount ?? "0.000";
    setAreaAmount(String(effective));
  }, [areaId, governorateId, selectedAreaRate?.amount, governorateRates.data]);

  return (
    <Card className="mt-4 rounded-2xl border-violet-100 bg-violet-50/50 shadow-none">
      <CardContent className="space-y-4 p-4">
        <div>
          <p className="font-black text-violet-950">{tr("تعرفة التوصيل حسب المحافظة والمنطقة")} · {company.name}</p>
          <p className="mt-1 text-xs text-violet-800">{tr("حدد سعراً عاماً للمحافظة، ويمكنك وضع سعر خاص لأي منطقة داخلها. سعر المنطقة الخاص يتقدم على سعر المحافظة.")}</p>
        </div>

        <LocationPicker
          kind="delivery"
          governorateId={governorateId}
          areaId={areaId}
          onGovernorateChange={(id) => { setGovernorateId(id); setAreaId(undefined); }}
          onAreaChange={setAreaId}
          compact
        />

        {governorateId ? (
          <div className="flex flex-wrap items-end gap-2 rounded-xl border border-violet-100 bg-white p-3">
            <label className="block text-sm font-bold">
              {tr("السعر الافتراضي للمحافظة")}
              <Input type="number" min="0" step="0.001" value={governorateAmount} onChange={(event) => setGovernorateAmount(event.target.value)} className="mt-1 w-44 bg-white" />
            </label>
            <Button type="button" disabled={setGovernorateRate.isPending} onClick={() => setGovernorateRate.mutate({ companyId: company.id, governorateId, amount: governorateAmount || "0.000" })} className="rounded-xl bg-violet-700 text-white">
              {setGovernorateRate.isPending ? tr("جارٍ الحفظ") : tr("حفظ سعر المحافظة")}
            </Button>
          </div>
        ) : null}

        {governorateId && areaId ? (
          <div className="flex flex-wrap items-end gap-2 rounded-xl border border-indigo-100 bg-white p-3">
            <div>
              <p className="text-sm font-bold text-slate-800">{tr("سعر خاص لهذه المنطقة")}</p>
              <p className="mt-1 text-xs text-slate-500">{selectedAreaRate ? tr("هذا السعر الخاص يتقدم على سعر المحافظة.") : `${tr("لم يحدد سعر خاص؛ السعر الموروث حالياً")}: ${Number(selectedGovernorateRate?.amount ?? "0").toFixed(3)} ${tr("د.ك")}`}</p>
              <Input type="number" min="0" step="0.001" value={areaAmount} onChange={(event) => setAreaAmount(event.target.value)} className="mt-1 w-44 bg-white" />
            </div>
            <Button type="button" disabled={setRate.isPending} onClick={() => setRate.mutate({ companyId: company.id, areaId, amount: areaAmount || "0.000" })} className="rounded-xl bg-indigo-700 text-white">
              {setRate.isPending ? tr("جارٍ الحفظ") : tr("حفظ سعر المنطقة")}
            </Button>
          </div>
        ) : null}

        {notice ? <p role="status" className="text-xs font-bold text-violet-800">{notice}</p> : null}

        <div className="flex flex-wrap gap-2">
          {(governorateRates.data ?? []).map((rate) => (
            <button type="button" key={`gov-${rate.id}`} onClick={() => { setGovernorateId(rate.governorateId); setAreaId(undefined); setGovernorateAmount(String(rate.amount)); }} className="rounded-full border border-violet-100 bg-white px-3 py-1.5 text-xs font-semibold text-violet-900">
              {rate.governorateName} · {tr("المحافظة")}: {Number(rate.amount).toFixed(3)} {tr("د.ك")}
            </button>
          ))}
          {(rates.data ?? []).map((rate) => (
            <button type="button" key={`area-${rate.id}`} onClick={() => { setGovernorateId(rate.governorateId); setAreaId(rate.areaId); setAreaAmount(String(rate.amount)); }} className="rounded-full border border-indigo-100 bg-white px-3 py-1.5 text-xs font-semibold text-indigo-900">
              {rate.areaName}: {Number(rate.amount).toFixed(3)} {tr("د.ك")}
            </button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
