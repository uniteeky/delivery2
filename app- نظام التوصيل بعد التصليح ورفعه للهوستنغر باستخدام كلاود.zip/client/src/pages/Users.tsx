import { useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import TripsPanel from "@/components/TripsPanel";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { friendlyError } from "@/lib/errorMessage";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/i18n";
import {
  Clock3,
  KeyRound,
  Mail,
  Power,
  ShieldCheck,
  UsersRound,
} from "lucide-react";

const permissionLabels = {
  dashboard_view: "لوحة المعلومات",
  orders_view: "عرض الطلبات",
  orders_manage: "إدارة الطلبات والتعيين",
  drivers_view: "عرض السائقين",
  companies_view: "عرض الشركات",
  audit_view: "سجل التدقيق",
  finance_view: "عرض المحاسبة",
  finance_edit: "تعديل الرسوم",
  company_media_pickup: "صورة الاستلام للشركة",
  company_media_invoice: "صورة الفاتورة للشركة",
  company_media_delivery: "صورة التسليم للشركة",
} as const;

function ManagerAccountCard() {
  const utils = trpc.useUtils();
  const [form, setForm] = useState({ civilId: "", email: "", password: "" });
  const createManager = trpc.users.createManagerAccount.useMutation({
    onSuccess: () => {
      setForm({ civilId: "", email: "", password: "" });
      void utils.users.list.invalidate();
    },
  });
  return (
    <Card className="mt-6 rounded-3xl border-emerald-100 bg-emerald-50/70 shadow-sm">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-xl font-black">
          <ShieldCheck className="h-5 w-5 text-emerald-600" />
          إنشاء حساب مدير
        </CardTitle>
        <p className="text-sm leading-7 text-slate-600">
          متاح للمدير المعتمد فقط. يُنشأ الحساب بالبريد الإلكتروني والرقم المدني
          وكلمة المرور، ويُعتمد فوراً بصلاحيات المدير الكاملة.
        </p>
      </CardHeader>
      <CardContent>
        <form
          className="grid gap-3 sm:grid-cols-2"
          onSubmit={event => {
            event.preventDefault();
            createManager.mutate(form);
          }}
        >
          <Input
            required
            maxLength={12}
            inputMode="numeric"
            placeholder="الرقم المدني"
            value={form.civilId}
            onChange={event =>
              setForm(current => ({ ...current, civilId: event.target.value }))
            }
          />
          <Input
            required
            type="email"
            placeholder="البريد الإلكتروني"
            value={form.email}
            onChange={event =>
              setForm(current => ({ ...current, email: event.target.value }))
            }
          />
          <Input
            required
            minLength={8}
            type="password"
            placeholder="كلمة مرور المدير"
            value={form.password}
            onChange={event =>
              setForm(current => ({ ...current, password: event.target.value }))
            }
          />
          <Button
            type="submit"
            disabled={createManager.isPending}
            className="rounded-xl bg-emerald-600 text-white hover:bg-emerald-700"
          >
            {createManager.isPending
              ? "جارٍ إنشاء المدير..."
              : "إنشاء مدير معتمد"}
          </Button>
          {createManager.error ? (
            <p className="text-sm font-semibold text-red-700 sm:col-span-2">
              {friendlyError(createManager.error)}
            </p>
          ) : null}
          {createManager.isSuccess ? (
            <p className="text-sm font-semibold text-emerald-700 sm:col-span-2">
              تم إنشاء حساب المدير واعتماده فوراً.
            </p>
          ) : null}
        </form>
      </CardContent>
    </Card>
  );
}

function BusinessAccountCard() {
  const companies = trpc.companies.list.useQuery({ page: 1, pageSize: 100 });
  const utils = trpc.useUtils();
  const [form, setForm] = useState({ companyId: "", companyName: "", companyPhone: "", companyAddress: "", username: "", password: "", role: "company" as "company" | "trader" });
  const [createNew, setCreateNew] = useState(true);
  const create = trpc.users.createBusinessAccount.useMutation({ onSuccess: () => { setForm(current => ({ ...current, companyName: "", companyPhone: "", companyAddress: "", username: "", password: "" })); void utils.companies.list.invalidate(); } });
  const submit = (event: React.FormEvent) => { event.preventDefault(); create.mutate({ companyId: createNew ? undefined : Number(form.companyId), companyName: createNew ? form.companyName : undefined, companyPhone: createNew ? form.companyPhone : undefined, companyAddress: createNew ? form.companyAddress : undefined, username: form.username || undefined, password: form.password || undefined, role: form.role }); };
  return <Card className="mt-6 rounded-3xl border-blue-100 bg-blue-50/60 shadow-sm"><CardHeader><CardTitle className="text-xl font-black">إنشاء شركة أو حساب تاجر</CardTitle><p className="text-sm leading-7 text-slate-600">أنشئ الشركة وحدها، أو أنشئ معها حساب دخول، أو اربط حساباً بشركة موجودة.</p></CardHeader><CardContent><form onSubmit={submit} className="grid gap-3 sm:grid-cols-2"><select value={form.role} onChange={event => setForm(current => ({ ...current, role: event.target.value as typeof current.role }))} className="h-11 rounded-xl border border-slate-200 bg-white px-3"><option value="company">شركة</option><option value="trader">تاجر</option></select><select value={createNew ? "new" : form.companyId} onChange={event => { const value = event.target.value; setCreateNew(value === "new"); setForm(current => ({ ...current, companyId: value === "new" ? "" : value })); }} className="h-11 rounded-xl border border-slate-200 bg-white px-3"><option value="new">إنشاء شركة أو متجر جديد</option>{(companies.data?.items ?? []).map(company => <option key={company.id} value={company.id}>ربط بـ {company.name} · {company.code}</option>)}</select>{createNew ? <><Input required placeholder="اسم الشركة أو المتجر" value={form.companyName} onChange={event => setForm(current => ({ ...current, companyName: event.target.value }))} className="h-11 rounded-xl" /><Input placeholder="هاتف الشركة (اختياري)" value={form.companyPhone} onChange={event => setForm(current => ({ ...current, companyPhone: event.target.value }))} dir="ltr" className="h-11 rounded-xl" /><Input placeholder="العنوان (اختياري)" value={form.companyAddress} onChange={event => setForm(current => ({ ...current, companyAddress: event.target.value }))} className="h-11 rounded-xl sm:col-span-2" /></> : null}<Input placeholder="اسم المستخدم (اختياري إذا تريد شركة بلا حساب)" minLength={3} value={form.username} onChange={event => setForm(current => ({ ...current, username: event.target.value }))} dir="ltr" className="h-11 rounded-xl" /><Input placeholder="كلمة المرور (اختياري)" minLength={8} type="text" value={form.password} onChange={event => setForm(current => ({ ...current, password: event.target.value }))} dir="ltr" className="h-11 rounded-xl" /><Button type="submit" disabled={create.isPending} className="rounded-xl bg-blue-600 text-white hover:bg-blue-700 sm:col-span-2">{create.isPending ? "جارٍ الحفظ..." : "حفظ الشركة والحساب"}</Button>{create.error ? <p className="text-sm font-semibold text-red-700 sm:col-span-2">{friendlyError(create.error)}</p> : null}{create.data ? <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-900 sm:col-span-2"><p className="font-black">تم الحفظ بنجاح: {create.data.companyName}</p>{create.data.accountCreated === false ? <p className="mt-1">تم إنشاء الشركة بدون حساب دخول.</p> : <><p className="mt-2" dir="ltr">Username: <b>{create.data.username}</b></p><p dir="ltr">Password: <b>{create.data.password}</b></p></>}</div> : null}</form></CardContent></Card>;
}

export default function Users() {
  const { t, language } = useLanguage();
  const roleLabels = {
    admin: t("roleAdmin"),
    supervisor: t("roleSupervisor"),
    accountant: t("roleAccountant"),
    driver: t("roleDriver"),
    company: t("roleCompany"),
    trader: language === "ar" ? "تاجر" : "Trader",
  } as const;
  const utils = trpc.useUtils();
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  const [driverFormUserId, setDriverFormUserId] = useState<number | null>(null);
  const [driverForm, setDriverForm] = useState({
    vehicleLabel: "",
    licenseNumber: "",
    vehicleType: "car" as
      | "car"
      | "refrigerated_car"
      | "motorcycle"
      | "semi_truck"
      | "refrigerated_semi_truck"
      | "truck"
      | "refrigerated_truck",
  });
  const [driverFormError, setDriverFormError] = useState("");
  const [resetUserId, setResetUserId] = useState<number | null>(null);
  const [resetForm, setResetForm] = useState({
    password: "",
    confirmPassword: "",
  });
  const [resetError, setResetError] = useState("");
  const [editUserId, setEditUserId] = useState<number | null>(null);
  const [editForm, setEditForm] = useState({
    name: "",
    phone: "",
    email: "",
    companyId: "",
  });
  const [editError, setEditError] = useState("");
  const [staffForm, setStaffForm] = useState({
    civilId: "",
    name: "",
    phone: "",
    email: "",
    password: "",
    companyId: "",
    role: "supervisor" as "supervisor" | "accountant" | "driver",
  });
  const [roleDrafts, setRoleDrafts] = useState<
    Record<number, "admin" | "supervisor" | "accountant" | "driver" | "company" | "trader">
  >({});
  const users = trpc.users.list.useQuery({ page: 1, pageSize: 100 });
  const companies = trpc.companies.list.useQuery({ page: 1, pageSize: 100 });
  const audit = trpc.audit.list.useQuery({ page: 1, pageSize: 20 });
  const permissions = trpc.users.permissions.useQuery(
    { userId: selectedUserId ?? 0 },
    { enabled: Boolean(selectedUserId) }
  );
  const setPermission = trpc.users.setPermission.useMutation({
    onSuccess: () => permissions.refetch(),
  });
  const update = trpc.users.updateAccess.useMutation({
    onSuccess: () => {
      utils.users.list.invalidate();
      utils.dashboard.summary.invalidate();
    },
  });
  const setRole = trpc.users.setRole.useMutation({
    onSuccess: () => {
      utils.users.list.invalidate();
      utils.auth.me.invalidate();
    },
    onError: error => window.alert(error.message),
  });
  const createDriver = trpc.users.createDriver.useMutation({
    onSuccess: () => {
      utils.users.list.invalidate();
      utils.dashboard.summary.invalidate();
    },
  });
  const createStaff = trpc.users.createStaffAccount.useMutation({
    onSuccess: () => {
      utils.users.list.invalidate();
      setStaffForm({
        civilId: "",
        name: "",
        phone: "",
        email: "",
        password: "",
        companyId: "",
        role: "supervisor",
      });
    },
  });
  const resetPassword = trpc.users.resetPassword.useMutation({
    onSuccess: () => {
      setResetUserId(null);
      setResetForm({ password: "", confirmPassword: "" });
      setResetError("");
      void audit.refetch();
    },
  });
  const updateProfile = trpc.users.updateProfile.useMutation({
    onSuccess: () => {
      setEditUserId(null);
      setEditError("");
      void users.refetch();
      void audit.refetch();
    },
    onError: error => setEditError(error.message),
  });
  const auditEntries = (audit.data?.items ?? [])
    .filter(
      entry =>
        (entry.entityType === "user" ||
          entry.entityType === "user_permission" ||
          entry.entityType === "user_role" ||
          entry.action.startsWith("account.")) &&
        (!selectedUserId ||
          entry.entityId === String(selectedUserId) ||
          entry.entityId?.startsWith(`${selectedUserId}:`))
    )
    .slice(0, 10);
  return (
    <DashboardLayout>
      <div
        dir={language === "ar" ? "rtl" : "ltr"}
        className="min-h-screen bg-[#f8fafc] p-4 sm:p-6 lg:p-8"
      >
        <div className="mx-auto max-w-6xl">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <div className="flex items-center gap-2 text-sm font-semibold text-violet-600">
                <UsersRound className="h-4 w-4" /> {t("administration")}
              </div>
              <h1 className="mt-2 text-3xl font-black tracking-tight">
                {t("users")}
              </h1>
              <p className="mt-2 text-sm text-slate-500">
                {t("usersRoleManagementHint")}
              </p>
            </div>
            <Button
              onClick={() =>
                document
                  .getElementById("driver-onboarding")
                  ?.scrollIntoView({ behavior: "smooth" })
              }
              className="rounded-xl bg-orange-500 text-white hover:bg-orange-600"
            >
              <UsersRound className="ml-2 h-4 w-4" /> {t("driverRegistration")}
            </Button>
          </div>
          <Card
            id="driver-onboarding"
            className="mt-6 rounded-3xl border-orange-100 bg-orange-50/60 shadow-sm"
          >
            <CardContent className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center">
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-white text-orange-600">
                <Mail className="h-6 w-6" />
              </span>
              <div className="min-w-0">
                <p className="font-black">{t("usersOnboardingTitle")}</p>
                <p className="mt-1 text-sm leading-7 text-slate-600">
                  {t("usersOnboardingHint")}
                </p>
              </div>
              <Button
                variant="outline"
                onClick={() => users.refetch()}
                className="rounded-xl bg-white sm:mr-auto"
              >
                {t("refreshAccounts")}
              </Button>
            </CardContent>
          </Card>
          <ManagerAccountCard />
          <BusinessAccountCard />
          <Card className="mt-6 rounded-3xl border-violet-100 bg-violet-50/50 shadow-sm">
            <CardHeader>
              <CardTitle className="text-xl font-black">
                {t("staffAccount")}
              </CardTitle>
              <p className="text-sm leading-7 text-slate-600">
                {t("usersOnboardingHint")}
              </p>
            </CardHeader>
            <CardContent>
              <form
                className="grid gap-3 sm:grid-cols-2"
                onSubmit={event => {
                  event.preventDefault();
                  createStaff.mutate({
                    civilId: staffForm.civilId,
                    name: staffForm.name,
                    phone: staffForm.phone,
                    password: staffForm.password,
                    email: staffForm.email || undefined,
                    role: staffForm.role,
                  });
                }}
              >
                <Input
                  required
                  maxLength={12}
                  inputMode="numeric"
                  placeholder={t("civilId")}
                  value={staffForm.civilId}
                  onChange={event =>
                    setStaffForm(current => ({
                      ...current,
                      civilId: event.target.value,
                    }))
                  }
                />
                <Input
                  required
                  placeholder={t("fullName")}
                  value={staffForm.name}
                  onChange={event =>
                    setStaffForm(current => ({
                      ...current,
                      name: event.target.value,
                    }))
                  }
                />
                <Input
                  required
                  placeholder={t("phoneLabel")}
                  value={staffForm.phone}
                  onChange={event =>
                    setStaffForm(current => ({
                      ...current,
                      phone: event.target.value,
                    }))
                  }
                />
                <Input
                  type="email"
                  placeholder={t("emailOptional")}
                  value={staffForm.email}
                  onChange={event =>
                    setStaffForm(current => ({
                      ...current,
                      email: event.target.value,
                    }))
                  }
                />
                <Input
                  required
                  minLength={8}
                  type="password"
                  placeholder={t("initialPassword")}
                  value={staffForm.password}
                  onChange={event =>
                    setStaffForm(current => ({
                      ...current,
                      password: event.target.value,
                    }))
                  }
                />
                <select
                  className="h-10 rounded-xl border border-slate-200 bg-white px-3"
                  value={staffForm.role}
                  onChange={event =>
                    setStaffForm(current => ({
                      ...current,
                      role: event.target.value as
                        | "supervisor"
                        | "accountant"
                        | "driver",
                    }))
                  }
                >
                  <option value="supervisor">مشرف</option>
                  <option value="accountant">محاسب</option>
                  <option value="driver">سائق</option>
                </select>

                <Button
                  type="submit"
                  disabled={createStaff.isPending}
                  className="rounded-xl bg-violet-600 text-white hover:bg-violet-700 sm:col-span-2"
                >
                  {createStaff.isPending
                    ? t("creatingStaff")
                    : t("createStaffPending")}
                </Button>
                {createStaff.error ? (
                  <p className="text-sm font-semibold text-red-700 sm:col-span-2">
                    {friendlyError(createStaff.error)}
                  </p>
                ) : null}
              </form>
            </CardContent>
          </Card>
          <Card className="mt-6 rounded-3xl border-slate-100 shadow-sm">
            <CardHeader>
              <CardTitle className="text-xl font-black">
                {t("registeredAccounts")}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {(users.data?.items ?? []).length === 0 ? (
                  <div className="rounded-2xl border border-dashed p-10 text-center text-sm text-slate-500">
                    {t("noOtherAccounts")} {t("appearsAfterLogin")}
                  </div>
                ) : (
                  (users.data?.items ?? []).map(user => (
                    <div
                      key={user.id}
                      className="flex flex-col gap-4 rounded-2xl border border-slate-100 bg-white p-4 sm:flex-row sm:items-center"
                    >
                      <div className="flex min-w-0 items-center gap-3">
                        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-violet-50 text-violet-600">
                          <ShieldCheck className="h-5 w-5" />
                        </span>
                        <div className="min-w-0">
                          <p className="truncate font-black">
                            {user.name || t("accountFallback")}
                          </p>
                          <p className="mt-1 truncate text-xs text-slate-500">
                            {user.civilId
                              ? `${t("civilIdMaskedPrefix")}: ${user.civilId}`
                              : user.email || t("noEmailFallback")}
                          </p>
                        </div>
                      </div>
                      <div className="flex flex-wrap items-center gap-2 sm:mr-auto">
                        <Badge className="rounded-full bg-violet-50 text-violet-700 hover:bg-violet-50">
                          {t("primaryRoleLabel")}: {roleLabels[user.role]}
                        </Badge>
                        {user.requestedRole &&
                        user.requestedRole !== user.role ? (
                          <Badge className="rounded-full bg-amber-50 text-amber-700 hover:bg-amber-50">
                            {language === "ar" ? "الدور المطلوب" : "Requested"}:{" "}
                            {roleLabels[user.requestedRole]}
                          </Badge>
                        ) : null}
                        {(user.roles ?? [])
                          .filter(role => role !== user.role)
                          .map(role => (
                            <Badge
                              key={role}
                              className="rounded-full bg-blue-50 text-blue-700 hover:bg-blue-50"
                            >
                              {t("additionalRoleLabel")}:{" "}
                              {roleLabels[role as keyof typeof roleLabels]}
                            </Badge>
                          ))}
                        <Badge
                          className={`rounded-full ${user.approvalStatus === "approved" ? "bg-emerald-50 text-emerald-700 hover:bg-emerald-50" : user.approvalStatus === "pending" ? "bg-amber-50 text-amber-700 hover:bg-amber-50" : "bg-red-50 text-red-700 hover:bg-red-50"}`}
                        >
                          {user.approvalStatus === "approved"
                            ? t("approved")
                            : user.approvalStatus === "pending"
                              ? t("pendingApproval")
                              : t("rejected")}
                        </Badge>
                        <Badge
                          className={`rounded-full ${user.status === "active" ? "bg-blue-50 text-blue-700 hover:bg-blue-50" : "bg-slate-100 text-slate-600 hover:bg-slate-100"}`}
                        >
                          {user.status === "active"
                            ? t("active")
                            : t("inactive")}
                        </Badge>
                        {user.role !== "admin" ? (
                          <div className="flex flex-col gap-2 rounded-xl border border-slate-200 bg-slate-50 p-2">
                            <div className="flex items-center gap-1">
                              <select
                                aria-label={`${t("primaryRoleLabel")} ${user.name || t("accountFallback")}`}
                                className="h-8 rounded-lg border-0 bg-white px-2 text-xs"
                                value={roleDrafts[user.id] ?? user.role}
                                onChange={event =>
                                  setRoleDrafts(current => ({
                                    ...current,
                                    [user.id]: event.target.value as
                                      | "admin"
                                      | "supervisor"
                                      | "accountant"
                                      | "driver"
                                      | "company"
                                      | "trader",
                                  }))
                                }
                              >
                                <option value="admin">
                                  {roleLabels.admin} {t("primaryRoleSuffix")}
                                </option>
                                <option value="supervisor">
                                  {roleLabels.supervisor}{" "}
                                  {t("primaryRoleSuffix")}
                                </option>
                                <option value="accountant">
                                  {roleLabels.accountant}{" "}
                                  {t("primaryRoleSuffix")}
                                </option>
                                <option value="driver">
                                  {roleLabels.driver} {t("primaryRoleSuffix")}
                                </option>
                                <option value="company">
                                  {roleLabels.company} {t("primaryRoleSuffix")}
                                </option>
                                <option value="trader">
                                  {roleLabels.trader} {t("primaryRoleSuffix")}
                                </option>
                              </select>
                              <Button
                                size="sm"
                                variant="outline"
                                disabled={
                                  update.isPending ||
                                  (roleDrafts[user.id] ?? user.role) ===
                                    user.role
                                }
                                onClick={() => {
                                  const nextRole =
                                    roleDrafts[user.id] ?? user.role;
                                  if (
                                    nextRole !== user.role &&
                                    window.confirm(
                                      `تأكيد تغيير الدور الأساسي إلى ${roleLabels[nextRole]}؟`
                                    )
                                  )
                                    update.mutate({
                                      userId: user.id,
                                      role: nextRole,
                                    });
                                }}
                                className="h-8 rounded-lg px-2 text-xs"
                              >
                                {t("savePrimaryRole")}
                              </Button>
                            </div>
                            <div
                              className="flex flex-wrap gap-2 text-xs"
                              aria-label={`${t("additionalRoleLabel")} ${user.name || t("accountFallback")}`}
                            >
                              {(
                                [
                                  "supervisor",
                                  "accountant",
                                  "driver",
                                  "company",
                                  "trader",
                                ] as const
                              ).map(role => {
                                const checked = (
                                  user.roles ?? [user.role]
                                ).includes(role);
                                const primary = user.role === role;
                                return (
                                  <label
                                    key={role}
                                    className={`flex items-center gap-1 rounded-lg px-2 py-1 ${primary ? "bg-slate-200 text-slate-500" : "bg-white"}`}
                                  >
                                    <input
                                      type="checkbox"
                                      checked={checked}
                                      disabled={primary || setRole.isPending}
                                      onChange={event => {
                                        if (
                                          window.confirm(
                                            `${event.target.checked ? "منح" : "سحب"} دور ${roleLabels[role]} من ${user.name || "الحساب"}؟`
                                          )
                                        )
                                          setRole.mutate({
                                            userId: user.id,
                                            role,
                                            granted: event.target.checked,
                                          });
                                      }}
                                    />
                                    {roleLabels[role]}
                                  </label>
                                );
                              })}
                            </div>
                          </div>
                        ) : null}
                        {user.role !== "admin" &&
                          user.approvalStatus === "pending" && (
                            <>
                              <Button
                                size="sm"
                                onClick={() =>
                                  update.mutate(
                                    {
                                      userId: user.id,
                                      approvalStatus: "approved",
                                      status: "active",
                                    },
                                    {
                                      onSuccess: () => {
                                        if (user.role === "driver") {
                                          setDriverFormUserId(user.id);
                                          setDriverForm({
                                            vehicleLabel: "",
                                            licenseNumber: "",
                                            vehicleType: "car",
                                          });
                                        }
                                      },
                                    }
                                  )
                                }
                                className="rounded-xl bg-emerald-600 text-white hover:bg-emerald-700"
                              >
                                <ShieldCheck className="ml-1 h-4 w-4" />{" "}
                                {t("approve")}
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() =>
                                  update.mutate({
                                    userId: user.id,
                                    approvalStatus: "rejected",
                                    status: "inactive",
                                  })
                                }
                                className="rounded-xl text-red-700"
                              >
                                {t("reject")}
                              </Button>
                            </>
                          )}
                        {user.role !== "admin" &&
                          (user.role === "supervisor" ||
                            user.role === "accountant" ||
                            user.role === "company" ||
                            user.role === "trader") && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setSelectedUserId(user.id)}
                              className="rounded-xl"
                            >
                              <KeyRound className="ml-1 h-4 w-4" />{" "}
                              {t("permissions")}
                            </Button>
                          )}
                        {user.role !== "admin" && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() =>
                              update.mutate({
                                userId: user.id,
                                status:
                                  user.status === "active"
                                    ? "inactive"
                                    : "active",
                              })
                            }
                            className="rounded-xl"
                          >
                            <Power className="ml-1 h-4 w-4" />{" "}
                            {user.status === "active"
                              ? t("suspend")
                              : t("activate")}
                          </Button>
                        )}
                        {user.role !== "admin" && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setEditUserId(user.id);
                              setEditForm({
                                name: user.name || "",
                                phone: user.phone || "",
                                email: user.email || "",
                                companyId: user.companyId
                                  ? String(user.companyId)
                                  : "",
                              });
                              setEditError("");
                            }}
                            className="rounded-xl"
                          >
                            {t("editData")}
                          </Button>
                        )}
                        {user.role !== "admin" && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setResetUserId(user.id);
                              setResetForm({
                                password: "",
                                confirmPassword: "",
                              });
                              setResetError("");
                            }}
                            className="rounded-xl"
                          >
                            <KeyRound className="ml-1 h-4 w-4" />{" "}
                            {t("resetCode")}
                          </Button>
                        )}
                        {user.role !== "admin" && (
                          <Button
                            size="sm"
                            onClick={() => {
                              setDriverFormUserId(user.id);
                              setDriverForm({
                                vehicleLabel: "",
                                licenseNumber: "",
                                vehicleType: "car",
                              });
                              setDriverFormError("");
                            }}
                            disabled={createDriver.isPending}
                            className="rounded-xl bg-orange-500 text-white hover:bg-orange-600"
                          >
                            {user.role === "driver"
                              ? "بيانات المركبة"
                              : "بيانات المركبة"}
                          </Button>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
          {editUserId ? (
            <Dialog
              open={Boolean(editUserId)}
              onOpenChange={open => {
                if (!open) setEditUserId(null);
              }}
            >
              <DialogContent
                className="w-[min(94vw,640px)] rounded-3xl p-6"
                dir={language === "ar" ? "rtl" : "ltr"}
              >
                <DialogHeader>
                  <DialogTitle className="text-2xl font-black">
                    {t("editAccountTitle")}
                  </DialogTitle>
                  <p className="text-sm text-slate-500">
                    {t("editAccountHint")}
                  </p>
                </DialogHeader>
                <form
                  className="grid gap-3 sm:grid-cols-2"
                  onSubmit={event => {
                    event.preventDefault();
                    updateProfile.mutate({
                      userId: editUserId,
                      name: editForm.name,
                      phone: editForm.phone,
                      email: editForm.email || undefined,
                      companyId: editForm.companyId
                        ? Number(editForm.companyId)
                        : undefined,
                    });
                  }}
                >
                  <Input
                    required
                    minLength={2}
                    placeholder={t("fullName")}
                    value={editForm.name}
                    onChange={event =>
                      setEditForm(current => ({
                        ...current,
                        name: event.target.value,
                      }))
                    }
                  />
                  <Input
                    required
                    minLength={5}
                    placeholder={t("phoneLabel")}
                    value={editForm.phone}
                    onChange={event =>
                      setEditForm(current => ({
                        ...current,
                        phone: event.target.value,
                      }))
                    }
                  />
                  <Input
                    type="email"
                    placeholder={t("emailOptional")}
                    value={editForm.email}
                    onChange={event =>
                      setEditForm(current => ({
                        ...current,
                        email: event.target.value,
                      }))
                    }
                  />
                  <select
                    className="h-10 rounded-xl border border-slate-200 bg-white px-3"
                    value={editForm.companyId}
                    onChange={event =>
                      setEditForm(current => ({
                        ...current,
                        companyId: event.target.value,
                      }))
                    }
                  >
                    <option value="">{t("noCompany")}</option>
                    {(companies.data?.items ?? []).map(company => (
                      <option key={company.id} value={company.id}>
                        {company.name} · {company.code}
                      </option>
                    ))}
                  </select>
                  {editError || updateProfile.error ? (
                    <p
                      role="alert"
                      className="rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700 sm:col-span-2"
                    >
                      {editError || updateProfile.error?.message}
                    </p>
                  ) : null}
                  <div className="flex gap-2 sm:col-span-2">
                    <Button
                      type="submit"
                      disabled={updateProfile.isPending}
                      className="rounded-xl bg-violet-600 text-white hover:bg-violet-700"
                    >
                      {updateProfile.isPending
                        ? t("creatingStaff")
                        : t("saveAccountData")}
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setEditUserId(null)}
                      className="rounded-xl"
                    >
                      {t("cancel")}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          ) : null}
          {resetUserId ? (
            <Dialog
              open={Boolean(resetUserId)}
              onOpenChange={open => {
                if (!open) setResetUserId(null);
              }}
            >
              <DialogContent
                className="w-[min(94vw,560px)] rounded-3xl p-6"
                dir={language === "ar" ? "rtl" : "ltr"}
              >
                <DialogHeader>
                  <DialogTitle className="text-2xl font-black">
                    {t("tempResetTitle")}
                  </DialogTitle>
                  <p className="text-sm leading-7 text-slate-500">
                    {t("tempResetHint")}
                  </p>
                </DialogHeader>
                <form
                  className="space-y-4"
                  onSubmit={event => {
                    event.preventDefault();
                    if (resetForm.password.length < 8) {
                      setResetError(t("passwordMinLengthError"));
                      return;
                    }
                    if (resetForm.password !== resetForm.confirmPassword) {
                      setResetError(t("passwordsMismatch"));
                      return;
                    }
                    setResetError("");
                    resetPassword.mutate({
                      userId: resetUserId,
                      temporaryPassword: resetForm.password,
                      confirmPassword: resetForm.confirmPassword,
                    });
                  }}
                >
                  <Input
                    required
                    minLength={8}
                    type="password"
                    placeholder={t("tempPassword")}
                    value={resetForm.password}
                    onChange={event =>
                      setResetForm(current => ({
                        ...current,
                        password: event.target.value,
                      }))
                    }
                  />
                  <Input
                    required
                    minLength={8}
                    type="password"
                    placeholder={t("confirmTempPassword")}
                    value={resetForm.confirmPassword}
                    onChange={event =>
                      setResetForm(current => ({
                        ...current,
                        confirmPassword: event.target.value,
                      }))
                    }
                  />
                  {resetError || resetPassword.error ? (
                    <p
                      role="alert"
                      className="rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700"
                    >
                      {resetError || resetPassword.error?.message}
                    </p>
                  ) : null}
                  <div className="flex gap-2">
                    <Button
                      type="submit"
                      disabled={resetPassword.isPending}
                      className="rounded-xl bg-violet-600 text-white hover:bg-violet-700"
                    >
                      {resetPassword.isPending
                        ? t("creatingStaff")
                        : t("saveTempPassword")}
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setResetUserId(null)}
                      className="rounded-xl"
                    >
                      {t("cancel")}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          ) : null}
          {driverFormUserId ? (
            <Dialog
              open={Boolean(driverFormUserId)}
              onOpenChange={open => {
                if (!open) setDriverFormUserId(null);
              }}
            >
              <DialogContent
                className="w-[min(94vw,640px)] rounded-3xl p-6"
                dir={language === "ar" ? "rtl" : "ltr"}
              >
                <DialogHeader>
                  <DialogTitle className="text-2xl font-black">
                    {t("driverProfileTitle")}
                  </DialogTitle>
                  <p className="text-sm text-slate-500">
                    {t("driverProfileHint")}
                  </p>
                </DialogHeader>
                <form
                  className="space-y-4"
                  onSubmit={event => {
                    event.preventDefault();
                    if (driverForm.vehicleLabel.trim().length < 2) {
                      setDriverFormError(t("driverProfileRequired"));
                      return;
                    }
                    setDriverFormError("");
                    createDriver.mutate(
                      {
                        userId: driverFormUserId,
                        vehicleLabel: driverForm.vehicleLabel.trim(),
                        licenseNumber:
                          driverForm.licenseNumber.trim() || undefined,
                        vehicleType: driverForm.vehicleType,
                      },
                      {
                        onSuccess: () => setDriverFormUserId(null),
                        onError: error => setDriverFormError(error.message),
                      }
                    );
                  }}
                >
                  <div className="space-y-2">
                    <label
                      className="text-sm font-bold"
                      htmlFor="driver-vehicle"
                    >
                      بيانات المركبة / الموديل
                    </label>
                    <Input
                      id="driver-vehicle"
                      required
                      minLength={2}
                      maxLength={120}
                      value={driverForm.vehicleLabel}
                      onChange={event =>
                        setDriverForm(current => ({
                          ...current,
                          vehicleLabel: event.target.value,
                        }))
                      }
                      placeholder={t("vehicleExample")}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold" htmlFor="driver-type">
                      نوع المركبة
                    </label>
                    <select
                      id="driver-type"
                      className="h-10 w-full rounded-xl border bg-white px-3"
                      value={driverForm.vehicleType}
                      onChange={event =>
                        setDriverForm(current => ({
                          ...current,
                          vehicleType: event.target
                            .value as typeof current.vehicleType,
                        }))
                      }
                    >
                      <option value="car">سيارة</option>
                      <option value="refrigerated_car">سيارة تبريد</option>
                      <option value="motorcycle">دراجة نارية</option>
                      <option value="semi_truck">نصف شاحنة</option>
                      <option value="refrigerated_semi_truck">
                        نصف شاحنة تبريد
                      </option>
                      <option value="truck">شاحنة</option>
                      <option value="refrigerated_truck">شاحنة تبريد</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label
                      className="text-sm font-bold"
                      htmlFor="driver-license"
                    >
                      رقم لوحة المركبة (اختياري)
                    </label>
                    <Input
                      id="driver-license"
                      maxLength={80}
                      value={driverForm.licenseNumber}
                      onChange={event =>
                        setDriverForm(current => ({
                          ...current,
                          licenseNumber: event.target.value,
                        }))
                      }
                      placeholder={t("licenseNumber")}
                    />
                  </div>
                  {driverFormError ? (
                    <p
                      role="alert"
                      className="rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700"
                    >
                      {driverFormError}
                    </p>
                  ) : null}
                  <div className="flex gap-2">
                    <Button
                      type="submit"
                      disabled={createDriver.isPending}
                      className="rounded-xl bg-orange-500 text-white hover:bg-orange-600"
                    >
                      {createDriver.isPending
                        ? t("savingDriverProfile")
                        : t("saveDriverProfile")}
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setDriverFormUserId(null)}
                      className="rounded-xl"
                    >
                      {t("cancel")}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          ) : null}
          {selectedUserId ? (
            <Dialog
              open={Boolean(selectedUserId)}
              onOpenChange={open => {
                if (!open) setSelectedUserId(null);
              }}
            >
              <DialogContent
                className="max-h-[90vh] w-[min(94vw,900px)] overflow-y-auto rounded-3xl p-6"
                dir={language === "ar" ? "rtl" : "ltr"}
              >
                <DialogHeader>
                  <DialogTitle className="text-2xl font-black">
                    بيانات الحساب والصلاحيات
                  </DialogTitle>
                  <p className="text-sm text-slate-500">
                    اختر الحساب ثم امنح أو اسحب الصلاحيات. يتم الحفظ مباشرة مع
                    سجل تدقيق دائم.
                  </p>
                </DialogHeader>
                <div className="rounded-2xl bg-slate-50 p-4 text-sm">
                  <p className="font-bold">
                    {(users.data?.items ?? []).find(
                      item => item.id === selectedUserId
                    )?.name || `الحساب رقم ${selectedUserId}`}
                  </p>
                  <p className="mt-1 text-slate-500">
                    {(users.data?.items ?? []).find(
                      item => item.id === selectedUserId
                    )?.email || "تسجيل محلي بالرقم المدني"}
                  </p>
                </div>
                {permissions.isLoading ? (
                  <p className="rounded-xl bg-slate-50 p-4 text-center text-sm text-slate-500">
                    جارٍ تحميل الصلاحيات...
                  </p>
                ) : permissions.error ? (
                  <div className="rounded-xl bg-red-50 p-4 text-sm text-red-700">
                    تعذر تحميل الصلاحيات.{" "}
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => permissions.refetch()}
                      className="mr-2"
                    >
                      إعادة المحاولة
                    </Button>
                  </div>
                ) : (
                  <div className="grid gap-3 sm:grid-cols-2">
                    {(
                      Object.keys(permissionLabels) as Array<
                        keyof typeof permissionLabels
                      >
                    ).map(key => {
                      const granted =
                        permissions.data?.some(
                          item => item.permissionKey === key && item.granted
                        ) ?? false;
                      return (
                        <Button
                          key={key}
                          variant="outline"
                          disabled={setPermission.isPending}
                          onClick={() =>
                            setPermission.mutate({
                              userId: selectedUserId,
                              permissionKey: key,
                              granted: !granted,
                            })
                          }
                          className={`min-h-14 justify-between rounded-xl text-right ${granted ? "border-emerald-200 bg-emerald-50 text-emerald-800" : "bg-white text-slate-500"}`}
                        >
                          <span>{permissionLabels[key]}</span>
                          <span>
                            {setPermission.isPending
                              ? "جارٍ الحفظ"
                              : granted
                                ? "ممنوحة"
                                : "غير ممنوحة"}
                          </span>
                        </Button>
                      );
                    })}
                  </div>
                )}
                {setPermission.error ? (
                  <p className="rounded-xl bg-red-50 p-3 text-sm text-red-700">
                    تعذر حفظ الصلاحية: {friendlyError(setPermission.error)}
                  </p>
                ) : null}
                {setPermission.isSuccess ? (
                  <p className="rounded-xl bg-emerald-50 p-3 text-sm text-emerald-700">
                    تم حفظ تغيير الصلاحية.
                  </p>
                ) : null}
              </DialogContent>
            </Dialog>
          ) : null}
          <TripsPanel />
          <Card className="mt-6 rounded-3xl border-slate-100 shadow-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-xl font-black">
                <Clock3 className="h-5 w-5 text-violet-600" />
                سجل تغييرات الحسابات
              </CardTitle>
              <p className="text-sm text-slate-500">
                {selectedUserId
                  ? `سجل الحساب المحدد رقم ${selectedUserId}`
                  : "آخر التغييرات الإدارية المسجلة"}
                ، دون عرض كلمات المرور أو البيانات الحساسة.
              </p>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {audit.isLoading ? (
                  <p className="rounded-xl bg-slate-50 p-4 text-center text-sm text-slate-500">
                    جارٍ تحميل سجل التدقيق...
                  </p>
                ) : audit.error ? (
                  <div className="rounded-xl bg-red-50 p-4 text-sm text-red-700">
                    تعذر تحميل سجل التدقيق.{" "}
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => audit.refetch()}
                      className="mr-2 rounded-lg"
                    >
                      إعادة المحاولة
                    </Button>
                  </div>
                ) : auditEntries.length ? (
                  auditEntries.map(entry => (
                    <div
                      key={String(entry.id)}
                      className="flex flex-col gap-1 rounded-xl bg-slate-50 p-3 text-sm sm:flex-row sm:items-center sm:justify-between"
                    >
                      <span className="font-semibold text-slate-800">
                        {entry.action}
                      </span>
                      <span className="text-xs text-slate-500">
                        المستخدم: {entry.entityId || "-"} ·{" "}
                        {new Date(entry.createdAt).toLocaleString("ar-KW")}
                      </span>
                    </div>
                  ))
                ) : (
                  <p className="rounded-xl bg-slate-50 p-4 text-center text-sm text-slate-500">
                    لا توجد تغييرات حسابات مسجلة بعد.
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
          <div className="mt-5 rounded-2xl border border-blue-100 bg-blue-50 p-4 text-sm leading-7 text-blue-900">
            الحسابات لا تُحذف من النظام؛ يمكن إيقافها مع الاحتفاظ بسجل العمليات
            المرتبط بها. تغيير الدور والحالة يُسجّل في سجل التدقيق.
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
