import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { ArrowRight, LockKeyhole, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/i18n";

export default function LocalLogin() {
  const { t, language } = useLanguage();
  const [, navigate] = useLocation();
  const brandingQuery = trpc.platform.branding.useQuery(undefined, { staleTime: 60_000 });
  const [civilId, setCivilId] = useState("");
  const [password, setPassword] = useState("");
  const [email, setEmail] = useState("");
  const [managerBootstrapAvailable, setManagerBootstrapAvailable] = useState(false);
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);

  useEffect(() => {
    fetch("/api/auth/manager-bootstrap/status", { credentials: "include" })
      .then((response) => response.ok ? response.json() : { available: false })
      .then((data) => setManagerBootstrapAvailable(Boolean(data.available)))
      .catch(() => setManagerBootstrapAvailable(false));
  }, []);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setPending(true);
    setError("");
    try {
      const endpoint = managerBootstrapAvailable ? "/api/auth/manager-bootstrap" : "/api/auth/local-login";
      const body = managerBootstrapAvailable ? { civilId, password, email } : { username: civilId, password };
      const response = await fetch(endpoint, { method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include", body: JSON.stringify(body) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || t("loginErrorFallback"));
      navigate(data.role === "driver" ? "/driver" : data.role === "company" || data.role === "trader" ? "/company" : "/");
      window.location.reload();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : t("loginErrorFallback"));
    } finally {
      setPending(false);
    }
  }

  const managerTitle = language === "ar" ? "تهيئة حساب المدير الأول" : "Set up the first manager account";
  const managerHint = language === "ar" ? "لا يوجد مدير محلي معتمد بعد. أدخل البريد الإلكتروني والرقم المدني وكلمة المرور لإنشاء المدير المعتمد فوراً." : "No local manager exists yet. Enter email, Civil ID, and password to create the first approved manager.";
  const brandName = brandingQuery.data?.brandName || t("brandName");
  const brandLogo = brandingQuery.data?.logoUrl || "/manus-storage/city-center-logo-user_665f44b4.png";

  return (
    <main dir={language === "ar" ? "rtl" : "ltr"} className="min-h-screen bg-[#fffaf4] px-4 py-8 text-slate-900 sm:px-6">
      <div className="mx-auto max-w-lg">
        <Link href="/" className="mb-5 inline-flex items-center gap-2 text-sm font-bold text-slate-600 hover:text-orange-600"><ArrowRight className="h-4 w-4" /> {t("backHome")}</Link>
        <div className="mb-5 flex items-center gap-3">
          <img src={brandLogo} alt={brandName} className="h-12 w-12 rounded-2xl bg-white p-1 object-contain shadow-sm" />
          <span className="text-lg font-black">{brandName}</span>
        </div>
        <Card className="rounded-[2rem] border-orange-100 shadow-xl shadow-orange-100/40">
          <CardHeader className="p-6 sm:p-8">
            <div className="flex items-start gap-3">
              <div className="rounded-2xl bg-orange-100 p-3 text-orange-600"><LockKeyhole className="h-6 w-6" /></div>
              <div><CardTitle className="text-2xl font-black">{managerBootstrapAvailable ? managerTitle : t("localLoginTitle")}</CardTitle><p className="mt-2 text-sm leading-7 text-slate-500">{managerBootstrapAvailable ? managerHint : t("localLoginHint")}</p></div>
            </div>
          </CardHeader>
          <CardContent className="p-6 pt-0 sm:p-8 sm:pt-0">
            <form onSubmit={submit} className="space-y-5">
              {managerBootstrapAvailable ? <div className="space-y-2"><Label htmlFor="email">{language === "ar" ? "البريد الإلكتروني" : "Email"}</Label><Input id="email" type="email" required value={email} onChange={(event) => setEmail(event.target.value)} placeholder="manager@example.com" className="h-12 rounded-xl" /></div> : null}
              <div className="space-y-2"><Label htmlFor="civilId">{managerBootstrapAvailable ? t("civilId") : "اسم المستخدم أو الرقم المدني"}</Label><Input id="civilId" inputMode="text" maxLength={80} required value={civilId} onChange={(event) => setCivilId(event.target.value)} placeholder={managerBootstrapAvailable ? t("civilIdPlaceholder") : "admin أو الرقم المدني"} className="h-12 rounded-xl" /></div>
              <div className="space-y-2"><Label htmlFor="password">{t("password")}</Label><Input id="password" type="password" minLength={8} required value={password} onChange={(event) => setPassword(event.target.value)} placeholder={t("passwordPlaceholder")} className="h-12 rounded-xl" /></div>
              {error ? <p className="rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700">{error}</p> : null}
              <div className="rounded-2xl bg-slate-50 p-4 text-sm leading-7 text-slate-600"><ShieldCheck className="mb-1 inline h-4 w-4 text-emerald-600" /> {t("secureNote")}</div>
              <Button type="submit" disabled={pending} className="h-12 w-full rounded-xl bg-orange-500 font-bold text-white hover:bg-orange-600">{pending ? t("signingIn") : managerBootstrapAvailable ? (language === "ar" ? "إنشاء المدير والدخول" : "Create manager and sign in") : t("loginSafe")}</Button>
            </form>
            <p className="mt-5 text-center text-sm text-slate-500"><Link href="/admin-recovery" className="font-bold text-orange-600 hover:underline">{language === "ar" ? "نسيت كلمة مرور المدير؟" : "Forgot the admin password?"}</Link></p>
            {!managerBootstrapAvailable ? <p className="mt-6 text-center text-sm text-slate-500">{t("noDriverAccount")} <Link href="/register-driver" className="font-bold text-orange-600 hover:underline">{t("registerNew")}</Link></p> : null}
          </CardContent>
        </Card>
      </div>
    </main>
  );
}
