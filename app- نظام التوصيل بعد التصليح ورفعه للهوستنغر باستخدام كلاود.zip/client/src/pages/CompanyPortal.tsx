import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import LocationPicker from "@/components/LocationPicker";
import { trpc } from "@/lib/trpc";
import { useUiText } from "@/lib/uiText";
import { useState } from "react";
import { useLanguage } from "@/i18n";
import {
  Image as ImageIcon,
  PackageSearch,
  ShieldCheck,
  Share2,
} from "lucide-react";
import {
  buildWhatsAppUrl,
  composeWhatsAppOrderMessage,
} from "@shared/whatsapp";
import { friendlyError } from "@/lib/errorMessage";

export default function CompanyPortal() {
  const { t, language } = useLanguage();
  const tr = useUiText();
  const statusLabels: Record<string, string> = {
    pending: t("statusNew"),
    assigned: t("statusAssigned"),
    picked_up: t("statusPickedUp"),
    in_transit: t("statusInTransit"),
    delivered: t("statusDelivered"),
    failed: t("statusFailed"),
  };
  const mediaLabels: Record<string, string> = {
    order: t("orderPhoto"),
    invoice: t("invoicePhoto"),
    delivery: t("deliveryPhoto"),
  };
  const vehicleTypes = {
    car: "سيارة",
    refrigerated_car: "سيارة تبريد",
    motorcycle: "دراجة نارية",
    semi_truck: "نصف شاحنة",
    refrigerated_semi_truck: "نصف شاحنة تبريد",
    truck: "شاحنة",
    refrigerated_truck: "شاحنة تبريد",
  } as const;
  const initialForm = {
    requestedVehicleType: "",
    assignedDriverId: "",
    customerName: "",
    customerPhone: "",
    pickupAddress: "",
    pickupGovernorateId: "",
    pickupAreaId: "",
    pickupScheduledAt: "",
    deliveryAddress: "",
    deliveryGovernorateId: "",
    deliveryAreaId: "",
    deliveryScheduledAt: "",
    cashToCollectAmount: "0.000",
    cashCollectionNote: "",
    area: "",
    notes: "",
  };
  const [form, setForm] = useState(initialForm);
  const [bulkRows, setBulkRows] = useState<Array<Record<string, string>>>([]);
  const [bulkError, setBulkError] = useState("");
  const orders = trpc.companyPortal.myOrders.useQuery();
  const portalDrivers = trpc.companyPortal.drivers.useQuery();
  const createOrder = trpc.companyPortal.createOrder.useMutation({
    onSuccess: () => {
      setForm(initialForm);
      orders.refetch();
    },
  });
  const update =
    (key: keyof typeof form) =>
    (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
      setForm(current => ({ ...current, [key]: event.target.value }));
  const shareOrderOnWhatsApp = (
    order: NonNullable<typeof orders.data>[number]
  ) => {
    const mode = order.status === "delivered" ? "completed" : "summary";
    const message = composeWhatsAppOrderMessage(order, mode, {
      title: t("orderDetailsTitle"),
      orderNumber: t("orderNumberLabel"),
      status: t("statusLabel"),
      pickupAddress: t("pickupAddress"),
      deliveryAddress: t("deliveryAddress"),
      customer: t("customerName"),
      phone: t("customerPhone"),
      area: t("area"),
      notes: t("notes"),
      completedAt: t("completedAt"),
      media: t("whatsappMedia"),
      driverIntro: t("whatsappDriverIntro"),
      completedIntro: t("whatsappCompletedIntro"),
      summaryIntro: t("whatsappSummaryIntro"),
    });
    window.open(buildWhatsAppUrl(message), "_blank", "noopener,noreferrer");
  };
  return (
    <DashboardLayout>
      <main
        dir={language === "ar" ? "rtl" : "ltr"}
        className="min-h-screen bg-[#f8fafc] p-4 text-slate-900 sm:p-6 lg:p-8"
      >
        <div className="mx-auto max-w-6xl">
          <div className="flex items-start gap-3">
            <div className="rounded-2xl bg-blue-100 p-3 text-blue-700">
              <ShieldCheck className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm font-bold text-blue-700">
                {t("companyPortal")}
              </p>
              <h1 className="mt-1 text-3xl font-black">{t("companyOrders")}</h1>
              <p className="mt-2 text-sm leading-7 text-slate-500">
                {t("companyPortalHint")}
              </p>
            </div>
          </div>
          <Card className="mt-6 rounded-3xl border-blue-100 shadow-sm">
            <CardHeader>
              <CardTitle className="text-xl font-black">
                {t("newCompanyOrder")}
              </CardTitle>
              <p className="text-sm text-slate-500">{t("companyPortalHint")}</p>
            </CardHeader>
            <CardContent>
              <form
                onSubmit={event => {
                  event.preventDefault();
                  createOrder.mutate({
                    ...form,
                    pickupGovernorateId: form.pickupGovernorateId
                      ? Number(form.pickupGovernorateId)
                      : undefined,
                    pickupAreaId: form.pickupAreaId
                      ? Number(form.pickupAreaId)
                      : undefined,
                    deliveryGovernorateId: form.deliveryGovernorateId
                      ? Number(form.deliveryGovernorateId)
                      : undefined,
                    deliveryAreaId: form.deliveryAreaId
                      ? Number(form.deliveryAreaId)
                      : undefined,
                    pickupScheduledAt: form.pickupScheduledAt
                      ? new Date(form.pickupScheduledAt).toISOString()
                      : undefined,
                    deliveryScheduledAt: form.deliveryScheduledAt
                      ? new Date(form.deliveryScheduledAt).toISOString()
                      : undefined,
                    customerName: form.customerName || undefined,
                    customerPhone: form.customerPhone || undefined,
                    area: form.area || undefined,
                    requestedVehicleType: (form.requestedVehicleType ||
                      undefined) as keyof typeof vehicleTypes | undefined,
                    assignedDriverId: form.assignedDriverId
                      ? Number(form.assignedDriverId)
                      : undefined,
                    cashToCollectAmount: form.cashToCollectAmount || "0.000",
                    cashCollectionNote:
                      form.cashCollectionNote.trim() || undefined,
                    notes: form.notes || undefined,
                  });
                }}
                className="grid gap-4 sm:grid-cols-2"
              >
                <div className="space-y-2">
                  <Label htmlFor="portal-vehicle">نوع المركبة (اختياري)</Label>
                  <select
                    id="portal-vehicle"
                    value={form.requestedVehicleType}
                    onChange={event =>
                      setForm(current => ({
                        ...current,
                        requestedVehicleType: event.target.value,
                        assignedDriverId: "",
                      }))
                    }
                    className="h-11 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm"
                  >
                    <option value="">كل المركبات</option>
                    {Object.entries(vehicleTypes).map(([key, label]) => (
                      <option key={key} value={key}>
                        {label}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="portal-driver">
                    السائق المسموح (اختياري)
                  </Label>
                  <select
                    id="portal-driver"
                    value={form.assignedDriverId}
                    onChange={event =>
                      setForm(current => ({
                        ...current,
                        assignedDriverId: event.target.value,
                      }))
                    }
                    className="h-11 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm"
                  >
                    <option value="">بدون سائق — يصل تنبيه للمشرف</option>
                    {(portalDrivers.data ?? [])
                      .filter(
                        driver =>
                          !form.requestedVehicleType ||
                          driver.vehicleType === form.requestedVehicleType
                      )
                      .map(driver => (
                        <option key={driver.id} value={driver.id}>
                          {driver.name || "سائق"} ·{" "}
                          {vehicleTypes[
                            driver.vehicleType as keyof typeof vehicleTypes
                          ] || "مركبة"}
                        </option>
                      ))}
                  </select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="company-customer">{t("customerName")}</Label>
                  <Input
                    id="company-customer"
                    value={form.customerName}
                    onChange={update("customerName")}
                    className="h-11 rounded-xl"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="company-phone">{t("customerPhone")}</Label>
                  <Input
                    id="company-phone"
                    value={form.customerPhone}
                    onChange={update("customerPhone")}
                    className="h-11 rounded-xl"
                  />
                </div>
                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="company-pickup">{t("pickupAddress")} *</Label>
                  <Textarea
                    id="company-pickup"
                    required
                    minLength={5}
                    value={form.pickupAddress}
                    onChange={update("pickupAddress")}
                    placeholder={t("pickupAddressHint")}
                    className="min-h-24 rounded-xl"
                  />
                </div>
                <div className="sm:col-span-2">
                  <LocationPicker
                    kind="pickup"
                    governorateId={
                      form.pickupGovernorateId
                        ? Number(form.pickupGovernorateId)
                        : undefined
                    }
                    areaId={
                      form.pickupAreaId ? Number(form.pickupAreaId) : undefined
                    }
                    onGovernorateChange={id =>
                      setForm(current => ({
                        ...current,
                        pickupGovernorateId: id ? String(id) : "",
                        pickupAreaId: "",
                      }))
                    }
                    onAreaChange={id =>
                      setForm(current => ({
                        ...current,
                        pickupAreaId: id ? String(id) : "",
                      }))
                    }
                  />
                </div>
                <div className="grid gap-4 sm:grid-cols-2 sm:col-span-2">
                  <div className="space-y-2">
                    <Label htmlFor="company-pickup-time">
                      {t("optionalPickupTime")}
                    </Label>
                    <Input
                      id="company-pickup-time"
                      type="datetime-local"
                      value={form.pickupScheduledAt}
                      onChange={update("pickupScheduledAt")}
                      className="h-11 rounded-xl text-left"
                      dir="ltr"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="company-delivery-time">
                      {t("optionalDeliveryTime")}
                    </Label>
                    <Input
                      id="company-delivery-time"
                      type="datetime-local"
                      value={form.deliveryScheduledAt}
                      onChange={update("deliveryScheduledAt")}
                      className="h-11 rounded-xl text-left"
                      dir="ltr"
                    />
                  </div>
                </div>
                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="company-address">
                    {t("deliveryAddress")} *
                  </Label>
                  <Textarea
                    id="company-address"
                    required
                    minLength={5}
                    value={form.deliveryAddress}
                    onChange={update("deliveryAddress")}
                    placeholder={t("deliveryAddressHint")}
                    className="min-h-24 rounded-xl"
                  />
                </div>
                <div className="sm:col-span-2">
                  <LocationPicker
                    kind="delivery"
                    governorateId={
                      form.deliveryGovernorateId
                        ? Number(form.deliveryGovernorateId)
                        : undefined
                    }
                    areaId={
                      form.deliveryAreaId
                        ? Number(form.deliveryAreaId)
                        : undefined
                    }
                    onGovernorateChange={id =>
                      setForm(current => ({
                        ...current,
                        deliveryGovernorateId: id ? String(id) : "",
                        deliveryAreaId: "",
                      }))
                    }
                    onAreaChange={id =>
                      setForm(current => ({
                        ...current,
                        deliveryAreaId: id ? String(id) : "",
                      }))
                    }
                  />
                </div>
                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="portal-cash-due">
                    {tr("المبلغ المطلوب استلامه من العميل")} ({tr("د.ك")})
                  </Label>
                  <Input
                    id="portal-cash-due"
                    type="number"
                    min="0"
                    step="0.001"
                    value={form.cashToCollectAmount}
                    onChange={update("cashToCollectAmount")}
                    className="h-11 rounded-xl"
                    dir="ltr"
                    inputMode="decimal"
                  />
                </div>
                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="portal-cash-note">
                    {tr("ملاحظة مبلغ الاستلام (اختياري)")}
                  </Label>
                  <Input
                    id="portal-cash-note"
                    value={form.cashCollectionNote}
                    onChange={update("cashCollectionNote")}
                    className="h-11 rounded-xl"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="company-area">{t("area")}</Label>
                  <Input
                    id="company-area"
                    value={form.area}
                    onChange={update("area")}
                    className="h-11 rounded-xl"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="company-notes">{t("notes")}</Label>
                  <Input
                    id="company-notes"
                    value={form.notes}
                    onChange={update("notes")}
                    className="h-11 rounded-xl"
                  />
                </div>
                {createOrder.error ? (
                  <p className="text-sm font-semibold text-red-600 sm:col-span-2">
                    {friendlyError(createOrder.error)}
                  </p>
                ) : null}
                <button
                  disabled={createOrder.isPending}
                  className="h-11 rounded-xl bg-blue-600 px-5 font-bold text-white hover:bg-blue-700 disabled:opacity-60 sm:col-span-2"
                >
                  {createOrder.isPending ? t("sendingOrder") : t("sendOrder")}
                </button>
              </form>
            </CardContent>
          </Card>
          <div className="mt-6 space-y-4">
            {orders.isLoading ? (
              <Card className="rounded-3xl">
                <CardContent className="p-8 text-center text-slate-500">
                  {t("loadingOrders")}
                </CardContent>
              </Card>
            ) : orders.error ? (
              <Card className="rounded-3xl border-red-100">
                <CardContent className="flex flex-wrap items-center justify-center gap-3 p-8 text-center text-red-700">
                  <span>{friendlyError(orders.error)}</span>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => void orders.refetch()}
                    disabled={orders.isFetching}
                    className="rounded-xl"
                  >
                    {t("retry")}
                  </Button>
                </CardContent>
              </Card>
            ) : (orders.data ?? []).length === 0 ? (
              <Card className="rounded-3xl border-dashed">
                <CardContent className="p-12 text-center">
                  <PackageSearch className="mx-auto h-10 w-10 text-slate-300" />
                  <p className="mt-4 font-bold">{t("noOrdersYet")}</p>
                  <p className="mt-2 text-sm text-slate-500">
                    {t("ordersAppearHere")}
                  </p>
                </CardContent>
              </Card>
            ) : (
              (orders.data ?? []).map(order => (
                <Card
                  key={order.id}
                  className="rounded-3xl border-slate-100 shadow-sm"
                >
                  <CardHeader className="flex flex-row items-start justify-between gap-4">
                    <div>
                      <CardTitle className="text-lg font-black">
                        {order.orderNumber}
                      </CardTitle>
                      <p className="mt-1 text-sm text-slate-500">
                        {order.customerName || t("noCustomerName")} ·{" "}
                        {[
                          order.deliveryGovernorateName,
                          order.deliveryAreaName || order.area,
                        ]
                          .filter(Boolean)
                          .join(" · ") || t("noArea")}
                      </p>
                    </div>
                    <div className="flex flex-wrap items-center justify-end gap-2">
                      <Badge className="bg-blue-50 text-blue-700 hover:bg-blue-50">
                        {statusLabels[order.status] || order.status}
                      </Badge>
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        onClick={() => shareOrderOnWhatsApp(order)}
                        className="rounded-xl"
                      >
                        <Share2 className="ml-1 h-4 w-4" />
                        {order.status === "delivered"
                          ? t("whatsappCompleted")
                          : t("whatsappSummary")}
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-3 text-sm sm:grid-cols-2">
                      {order.pickupContactName ? (
                        <div>
                          <span className="font-bold text-slate-500">
                            {tr("مستلم الطلب من الفرع")}:
                          </span>{" "}
                          {order.pickupContactName}
                        </div>
                      ) : null}
                      {order.pickupPhone ? (
                        <div>
                          <span className="font-bold text-slate-500">
                            {tr("هاتف الفرع")}:
                          </span>{" "}
                          {order.pickupPhone}
                        </div>
                      ) : null}
                      {order.pickupAddress ? (
                        <div>
                          <span className="font-bold text-slate-500">
                            {t("pickupAddress")}:
                          </span>{" "}
                          {order.pickupAddress}
                        </div>
                      ) : null}
                      <div>
                        <span className="font-bold text-slate-500">
                          {t("deliveryAddress")}:
                        </span>{" "}
                        {order.deliveryAddress}
                      </div>
                      <div>
                        <span className="font-bold text-slate-500">
                          {t("phoneLabel")}:
                        </span>{" "}
                        {order.customerPhone || t("notAdded")}
                      </div>
                      <div className="sm:col-span-2">
                        <span className="font-bold text-slate-500">
                          {t("notesLabel")}:
                        </span>{" "}
                        {order.notes || t("noNotes")}
                      </div>
                      <div className="sm:col-span-2 rounded-xl bg-emerald-50 p-3 text-emerald-900">
                        <b>{tr("المبلغ المطلوب استلامه من العميل")}:</b>{" "}
                        {Number(order.cashToCollectAmount ?? 0).toFixed(3)}{" "}
                        {tr("د.ك")} · <b>{tr("المبلغ المستلم من السائق")}:</b>{" "}
                        {order.cashCollectionRecorded
                          ? `${Number(order.cashCollectedAmount ?? 0).toFixed(3)} ${tr("د.ك")}`
                          : tr("لم يسجل بعد")}
                        {order.cashCollectionNote ? (
                          <p className="mt-1 text-xs">
                            <b>{tr("ملاحظة التحصيل")}:</b>{" "}
                            {order.cashCollectionNote}
                          </p>
                        ) : null}
                      </div>
                    </div>
                    {order.media.length ? (
                      <div className="mt-5 grid gap-3 sm:grid-cols-3">
                        {order.media.map(media => (
                          <a
                            key={`${media.kind}-${media.fileUrl}`}
                            href={media.fileUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="group overflow-hidden rounded-2xl border border-slate-100 bg-slate-50"
                          >
                            <div className="flex items-center gap-2 p-3 text-sm font-bold text-slate-700">
                              <ImageIcon className="h-4 w-4 text-orange-500" />
                              {mediaLabels[media.kind] || t("orderPhoto")}
                            </div>
                            <img
                              src={media.fileUrl}
                              alt={mediaLabels[media.kind] || t("orderPhoto")}
                              className="aspect-video w-full object-cover transition group-hover:scale-105"
                            />
                          </a>
                        ))}
                      </div>
                    ) : (
                      <div className="mt-5 rounded-2xl bg-slate-50 p-4 text-sm text-slate-500">
                        {t("noMediaAvailable")}
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>
      </main>
    </DashboardLayout>
  );
}
