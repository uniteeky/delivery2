import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import DriverCompensationPanel from "@/components/DriverCompensationPanel";
import CompanyAreaRatePanel from "@/pages/CompanyAreaRatePanel";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/i18n";
import { useUiText } from "@/lib/uiText";
import {
  BarChart3,
  Building2,
  CalendarRange,
  CarFront,
  CircleDollarSign,
  FileDown,
  FilePlus2,
  ImageIcon,
  Landmark,
  PackageCheck,
  ReceiptText,
  TrendingDown,
  TrendingUp,
} from "lucide-react";
import { useEffect, useMemo, useState, type FormEvent } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

const financialCategories = [
  "company_payment",
  "delivery_revenue",
  "salary",
  "rent",
  "installment",
  "utilities",
  "insurance",
  "fuel",
  "marketing",
  "maintenance",
  "purchase",
  "sale",
  "other",
] as const;

const periods = ["month", "quarter", "semiannual", "year", "custom"] as const;
const statuses = [
  "pending",
  "assigned",
  "picked_up",
  "in_transit",
  "delivered",
  "failed",
] as const;
type FinanceCategory = (typeof financialCategories)[number];
type Period = (typeof periods)[number];
type OrderStatus = (typeof statuses)[number];

const statusColors: Record<OrderStatus, string> = {
  pending: "bg-slate-100 text-slate-700",
  assigned: "bg-sky-100 text-sky-700",
  picked_up: "bg-violet-100 text-violet-700",
  in_transit: "bg-amber-100 text-amber-700",
  delivered: "bg-emerald-100 text-emerald-700",
  failed: "bg-rose-100 text-rose-700",
};

const chartColors = [
  "#059669",
  "#0ea5e9",
  "#8b5cf6",
  "#f59e0b",
  "#e11d48",
  "#14b8a6",
  "#64748b",
];

function toDateInput(date: Date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function periodRange(period: Exclude<Period, "custom">) {
  const today = new Date();
  const end = toDateInput(today);
  const year = today.getFullYear();
  const month = today.getMonth();
  if (period === "month")
    return { fromDate: toDateInput(new Date(year, month, 1)), toDate: end };
  if (period === "quarter")
    return {
      fromDate: toDateInput(new Date(year, Math.floor(month / 3) * 3, 1)),
      toDate: end,
    };
  if (period === "semiannual")
    return {
      fromDate: toDateInput(new Date(year, month < 6 ? 0 : 6, 1)),
      toDate: end,
    };
  return { fromDate: toDateInput(new Date(year, 0, 1)), toDate: end };
}

function money(value: string | number | null | undefined, currency = "د.ك") {
  return `${Number(value ?? 0).toFixed(3)} ${currency}`;
}

function formatDate(value: Date | string | null | undefined, locale: string) {
  if (!value) return "—";
  return new Date(value).toLocaleDateString(locale, {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

function SummaryCard({
  title,
  value,
  helper,
  icon: Icon,
  tone,
}: {
  title: string;
  value: string | number;
  helper: string;
  icon: typeof CircleDollarSign;
  tone: "emerald" | "sky" | "rose" | "violet";
}) {
  const toneClass = {
    emerald: "bg-emerald-50 text-emerald-700",
    sky: "bg-sky-50 text-sky-700",
    rose: "bg-rose-50 text-rose-700",
    violet: "bg-violet-50 text-violet-700",
  }[tone];
  return (
    <Card className="border-slate-200/80 shadow-sm">
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-sm font-medium text-slate-500">{title}</p>
            <p
              className="mt-2 text-2xl font-black tracking-tight text-slate-950"
              dir="ltr"
            >
              {value}
            </p>
            <p className="mt-1 text-xs text-slate-500">{helper}</p>
          </div>
          <span
            className={`grid h-11 w-11 place-items-center rounded-2xl ${toneClass}`}
          >
            <Icon className="h-5 w-5" />
          </span>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Finance() {
  const { language, t } = useLanguage();
  const tr = useUiText();
  const { user } = useAuth();
  const locale =
    language === "ar"
      ? "ar-KW"
      : language === "bn"
        ? "bn-BD"
        : language === "hi"
          ? "hi-IN"
          : "en-KW";
  const displayMoney = (value: string | number | null | undefined) =>
    money(value, tr("د.ك"));
  const categoryLabels: Record<FinanceCategory, string> = {
    company_payment: tr("مدفوعات الشركات"),
    delivery_revenue: tr("إيرادات التوصيل"),
    salary: tr("رواتب"),
    rent: tr("إيجارات"),
    installment: tr("أقساط"),
    utilities: tr("مرافق"),
    insurance: tr("تأمين"),
    fuel: tr("وقود"),
    marketing: tr("تسويق"),
    maintenance: tr("صيانة"),
    purchase: tr("مشتريات"),
    sale: tr("مبيعات"),
    other: tr("أخرى"),
  };
  const statusLabels: Record<OrderStatus, string> = {
    pending: tr("بانتظار الإسناد"),
    assigned: tr("مسند"),
    picked_up: tr("تم الاستلام"),
    in_transit: tr("قيد التوصيل"),
    delivered: tr("تم التسليم"),
    failed: tr("غير مكتمل"),
  };
  const mediaLabel = (kind: "order" | "invoice" | "delivery") =>
    kind === "order"
      ? tr("استلام")
      : kind === "invoice"
        ? tr("فاتورة")
        : tr("تسليم");
  const initialRange = useMemo(() => periodRange("month"), []);
  const [period, setPeriod] = useState<Period>("month");
  const [fromDate, setFromDate] = useState(initialRange.fromDate);
  const [toDate, setToDate] = useState(initialRange.toDate);
  const [companyId, setCompanyId] = useState("all");
  const [driverId, setDriverId] = useState("all");
  const [governorateId, setGovernorateId] = useState("all");
  const [areaId, setAreaId] = useState("all");
  const [status, setStatus] = useState<OrderStatus | "all">("all");
  const [scope, setScope] = useState<"all" | "company" | "external">("all");
  const [feeDrafts, setFeeDrafts] = useState<Record<number, string>>({});
  const [commissionDrafts, setCommissionDrafts] = useState<
    Record<number, string>
  >({});
  const [companyShareDrafts, setCompanyShareDrafts] = useState<
    Record<number, string>
  >({});
  const [notice, setNotice] = useState<string | null>(null);
  const [rateCompanyId, setRateCompanyId] = useState("");
  const [form, setForm] = useState({
    type: "expense" as "income" | "expense",
    category: "other" as FinanceCategory,
    amount: "",
    description: "",
    reference: "",
    transactionDate: toDateInput(new Date()),
    companyId: "all",
  });

  const isAdmin = user?.role === "admin" || user?.roles?.includes("admin");
  const canViewPricing =
    isAdmin ||
    ["accountant", "supervisor"].includes(user?.role ?? "") ||
    user?.roles?.some(role => ["accountant", "supervisor"].includes(role)) ===
      true;
  const permissions = trpc.auth.permissions.useQuery(undefined, {
    enabled: Boolean(canViewPricing),
  });
  const canEdit = Boolean(
    canViewPricing &&
      (isAdmin ||
        permissions.data?.some(
          item => item.permissionKey === "finance_edit" && item.granted
        ))
  );
  const filterOptions = trpc.finance.filterOptions.useQuery(undefined, {
    enabled: Boolean(canViewPricing),
  });
  const rateCompany = filterOptions.data?.companies.find(
    company => String(company.id) === rateCompanyId
  );
  useEffect(() => {
    if (!rateCompanyId && filterOptions.data?.companies.length)
      setRateCompanyId(String(filterOptions.data.companies[0].id));
  }, [filterOptions.data, rateCompanyId]);
  const locations = trpc.locations.directory.useQuery(undefined, {
    enabled: Boolean(canViewPricing),
    staleTime: 300_000,
  });
  const queryInput = useMemo(
    () => ({
      fromDate: fromDate || undefined,
      toDate: toDate || undefined,
      companyId: companyId === "all" ? undefined : Number(companyId),
      driverId: driverId === "all" ? undefined : Number(driverId),
      governorateId:
        governorateId === "all" ? undefined : Number(governorateId),
      areaId: areaId === "all" ? undefined : Number(areaId),
      status: status === "all" ? undefined : status,
      scope,
    }),
    [
      areaId,
      companyId,
      driverId,
      fromDate,
      governorateId,
      scope,
      status,
      toDate,
    ]
  );
  const accounting = trpc.finance.accountingReport.useQuery(queryInput, {
    enabled: Boolean(canViewPricing),
  });
  const utils = trpc.useUtils();
  const updateCompensation = trpc.finance.updateCompensation.useMutation({
    onSuccess: async () => {
      setNotice(tr("تم حفظ الرسوم والعمولات والحصص."));
      await Promise.all([
        utils.finance.accountingReport.invalidate(),
        utils.finance.summary.invalidate(),
      ]);
    },
    onError: error => setNotice(error.message),
  });
  const createEntry = trpc.finance.createEntry.useMutation({
    onSuccess: async () => {
      setNotice(tr("تم حفظ القيد المالي."));
      setForm(current => ({
        ...current,
        amount: "",
        description: "",
        reference: "",
      }));
      await utils.finance.accountingReport.invalidate();
    },
    onError: error => setNotice(error.message),
  });

  const report = accounting.data;
  const totals = report?.totals ?? {
    sales: "0.000",
    deliveryFees: "0.000",
    driverCommissions: "0.000",
    cashToCollect: "0.000",
    cashCollected: "0.000",
    cashCollectionCount: 0,
    income: "0.000",
    revenue: "0.000",
    expense: "0.000",
    balance: "0.000",
    orders: 0,
    deliveredOrders: 0,
  };
  const pieData = (report?.categoryTotals ?? [])
    .filter(row => row.income > 0 || row.expense > 0)
    .map(row => ({
      name: categoryLabels[row.category as FinanceCategory] ?? row.category,
      value: Math.max(row.income, row.expense),
      type: row.expense > row.income ? tr("مصروف") : tr("إيراد"),
    }));
  const periodData = (report?.periodSeries ?? []).map(row => ({
    ...row,
    label: new Date(`${row.period}-01T00:00:00.000Z`).toLocaleDateString(
      locale,
      { month: "short", year: "2-digit" }
    ),
  }));

  const selectPeriod = (nextPeriod: Period) => {
    setPeriod(nextPeriod);
    if (nextPeriod === "custom") return;
    const range = periodRange(nextPeriod);
    setFromDate(range.fromDate);
    setToDate(range.toDate);
  };

  const submitEntry = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!form.amount || !form.description) return;
    createEntry.mutate({
      type: form.type,
      category: form.category,
      amount: form.amount,
      description: form.description,
      reference: form.reference || undefined,
      companyId: form.companyId === "all" ? undefined : Number(form.companyId),
      transactionDate: `${form.transactionDate}T00:00:00.000Z`,
    });
  };

  return (
    <DashboardLayout>
      <div
        dir={language === "ar" ? "rtl" : "ltr"}
        className="min-w-0 bg-slate-50 px-3 py-5 sm:px-6 lg:px-8"
      >
        <div className="mx-auto w-full max-w-7xl space-y-6">
          <header className="flex flex-col gap-4 border-b border-slate-200 pb-5 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <div className="flex items-center gap-2 text-sm font-bold text-emerald-700">
                <BarChart3 className="h-4 w-4" /> {tr("المحاسبة والتقارير")}
              </div>
              <h1 className="mt-2 text-3xl font-black tracking-tight text-slate-950 sm:text-4xl">
                {tr("النظام المالي والمحاسبي")}
              </h1>
              <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-500">
                {tr(
                  "دفتر مالي محمي للمدير والمحاسب فقط، يعرض الطلبات ووسائط الإثبات والإيرادات والمصروفات وفق الفترة والشركة والسائق."
                )}
              </p>
            </div>
            <Button
              onClick={() => window.print()}
              variant="outline"
              className="h-11 rounded-xl border-slate-300 bg-white print:hidden"
            >
              <FileDown className="ml-2 h-4 w-4" />
              {tr("طباعة التقرير")}
            </Button>
          </header>

          {!canViewPricing ? (
            <Card className="border-amber-200 bg-amber-50">
              <CardContent className="p-6 text-sm font-semibold text-amber-900">
                {tr("بيانات المحاسبة والأسعار متاحة للمدير والمحاسب فقط.")}
              </CardContent>
            </Card>
          ) : (
            <>
              <Card className="border-slate-200 shadow-sm print:hidden">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <CalendarRange className="h-5 w-5 text-emerald-700" />
                    {tr("فترة الربح والخسارة")}
                  </CardTitle>
                  <CardDescription>
                    {tr(
                      "اختر فترة جاهزة أو نطاقاً مخصصاً، ثم أضف الفلاتر التشغيلية."
                    )}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex flex-wrap gap-2">
                    {periods.map(item => (
                      <Button
                        key={item}
                        type="button"
                        variant={period === item ? "default" : "outline"}
                        onClick={() => selectPeriod(item)}
                        className={`rounded-xl ${period === item ? "bg-slate-900 text-white hover:bg-slate-800" : "bg-white"}`}
                      >
                        {tr(
                          (
                            {
                              month: "شهري",
                              quarter: "ربع سنوي",
                              semiannual: "نصف سنوي",
                              year: "سنوي",
                              custom: "مخصص",
                            } as Record<Period, string>
                          )[item]
                        )}
                      </Button>
                    ))}
                  </div>
                  <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
                    <label className="text-sm font-semibold text-slate-700">
                      {t("fromDate")}
                      <Input
                        type="date"
                        value={fromDate}
                        onChange={event => {
                          setPeriod("custom");
                          setFromDate(event.target.value);
                        }}
                        className="mt-1.5 bg-white"
                      />
                    </label>
                    <label className="text-sm font-semibold text-slate-700">
                      {t("toDate")}
                      <Input
                        type="date"
                        value={toDate}
                        onChange={event => {
                          setPeriod("custom");
                          setToDate(event.target.value);
                        }}
                        className="mt-1.5 bg-white"
                      />
                    </label>
                    <label className="text-sm font-semibold text-slate-700">
                      {tr("الشركة")}
                      <select
                        value={companyId}
                        onChange={event => setCompanyId(event.target.value)}
                        className="mt-1.5 h-10 w-full rounded-md border border-input bg-white px-3 text-sm"
                      >
                        <option value="all">{tr("كل الشركات")}</option>
                        {(filterOptions.data?.companies ?? []).map(company => (
                          <option key={company.id} value={company.id}>
                            {company.name}
                          </option>
                        ))}
                      </select>
                    </label>
                    <label className="text-sm font-semibold text-slate-700">
                      {tr("السائق")}
                      <select
                        value={driverId}
                        onChange={event => setDriverId(event.target.value)}
                        className="mt-1.5 h-10 w-full rounded-md border border-input bg-white px-3 text-sm"
                      >
                        <option value="all">{tr("كل السائقين")}</option>
                        {(filterOptions.data?.drivers ?? []).map(driver => (
                          <option key={driver.id} value={driver.id}>
                            {driver.name}
                          </option>
                        ))}
                      </select>
                    </label>
                    <label className="text-sm font-semibold text-slate-700">
                      {tr("محافظة التسليم")}
                      <select
                        value={governorateId}
                        onChange={event => {
                          setGovernorateId(event.target.value);
                          setAreaId("all");
                        }}
                        className="mt-1.5 h-10 w-full rounded-md border border-input bg-white px-3 text-sm"
                      >
                        <option value="all">{tr("كل المحافظات")}</option>
                        {(locations.data ?? []).map(item => (
                          <option key={item.id} value={item.id}>
                            {item.nameAr}
                          </option>
                        ))}
                      </select>
                    </label>
                    <label className="text-sm font-semibold text-slate-700">
                      {tr("منطقة التسليم")}
                      <select
                        disabled={governorateId === "all"}
                        value={areaId}
                        onChange={event => setAreaId(event.target.value)}
                        className="mt-1.5 h-10 w-full rounded-md border border-input bg-white px-3 text-sm"
                      >
                        <option value="all">{tr("كل المناطق")}</option>
                        {(
                          locations.data?.find(
                            item => String(item.id) === governorateId
                          )?.areas ?? []
                        ).map(area => (
                          <option key={area.id} value={area.id}>
                            {area.nameAr}
                          </option>
                        ))}
                      </select>
                    </label>
                    <label className="text-sm font-semibold text-slate-700">
                      {tr("حالة الطلب")}
                      <select
                        value={status}
                        onChange={event =>
                          setStatus(event.target.value as OrderStatus | "all")
                        }
                        className="mt-1.5 h-10 w-full rounded-md border border-input bg-white px-3 text-sm"
                      >
                        <option value="all">{tr("كل الحالات")}</option>
                        {statuses.map(item => (
                          <option key={item} value={item}>
                            {statusLabels[item]}
                          </option>
                        ))}
                      </select>
                    </label>
                    <label className="text-sm font-semibold text-slate-700">
                      {tr("نطاق الكشف")}
                      <select
                        value={scope}
                        onChange={event =>
                          setScope(event.target.value as typeof scope)
                        }
                        className="mt-1.5 h-10 w-full rounded-md border border-input bg-white px-3 text-sm"
                      >
                        <option value="all">{tr("الشامل")}</option>
                        <option value="company">{tr("طلبات الشركات")}</option>
                        <option value="external">
                          {tr("الطلبات الخارجية")}
                        </option>
                      </select>
                    </label>
                  </div>
                </CardContent>
              </Card>

              <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4 2xl:grid-cols-8">
                <SummaryCard
                  title={tr("حصة الشركة من الطلبات")}
                  value={displayMoney(totals.sales)}
                  helper={`${totals.deliveredOrders} ${tr("طلبات مسلّمة")} / ${totals.orders}`}
                  icon={PackageCheck}
                  tone="emerald"
                />
                <SummaryCard
                  title={tr("رسوم التوصيل")}
                  value={displayMoney(totals.deliveryFees)}
                  helper={tr(
                    "السعر الظاهر للعميل ويُحتسب للمتعذر فقط عند تفعيل الخيار"
                  )}
                  icon={PackageCheck}
                  tone="sky"
                />
                <SummaryCard
                  title={tr("عمولات السائقين")}
                  value={displayMoney(totals.driverCommissions)}
                  helper={tr(
                    "عمولات الطلبات المسلّمة أو المعدّلة يدوياً للمتعذر"
                  )}
                  icon={CarFront}
                  tone="violet"
                />
                <SummaryCard
                  title={tr("المبلغ المطلوب تحصيله من العملاء")}
                  value={displayMoney(totals.cashToCollect)}
                  helper={tr(
                    "إجمالي قيمة البضائع المطلوب استلامها ضمن الفلاتر"
                  )}
                  icon={ReceiptText}
                  tone="sky"
                />
                <SummaryCard
                  title={tr("المبلغ الذي استلمه السائقون")}
                  value={displayMoney(totals.cashCollected)}
                  helper={`${totals.cashCollectionCount ?? 0} ${tr("عملية تحصيل مسجلة")}`}
                  icon={CircleDollarSign}
                  tone="emerald"
                />
                <SummaryCard
                  title={tr("إجمالي الإيرادات")}
                  value={displayMoney(totals.revenue)}
                  helper={`${displayMoney(totals.income)} ${tr("قيود إيراد إضافية")}`}
                  icon={TrendingUp}
                  tone="sky"
                />
                <SummaryCard
                  title={tr("إجمالي المصروفات")}
                  value={displayMoney(totals.expense)}
                  helper={tr("رواتب وإيجارات وأقساط ومصروفات تشغيلية")}
                  icon={TrendingDown}
                  tone="rose"
                />
                <SummaryCard
                  title={tr("صافي الربح / الخسارة")}
                  value={displayMoney(totals.balance)}
                  helper={
                    Number(totals.balance) >= 0
                      ? tr("نتيجة موجبة للفترة المحددة")
                      : tr("تحتاج مراجعة المصروفات والإيرادات")
                  }
                  icon={CircleDollarSign}
                  tone="violet"
                />
              </section>

              <Card className="overflow-hidden border-slate-200 bg-slate-950 text-white shadow-xl print:hidden">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-white">
                    <BarChart3 className="h-5 w-5 text-cyan-300" />
                    {tr("لوحة الأداء ثلاثية الأبعاد")}
                  </CardTitle>
                  <CardDescription className="text-slate-300">
                    {tr(
                      "مقارنة الإيرادات والمصروفات والتحصيل حسب الفترة المحددة."
                    )}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="relative h-64 overflow-hidden rounded-2xl bg-gradient-to-br from-slate-900 via-slate-800 to-cyan-950 p-5 [perspective:900px]">
                    <div className="absolute inset-x-6 bottom-8 top-6 flex items-end justify-around gap-3 [transform:rotateX(8deg)_rotateY(-8deg)]">
                      {periodData.length ? (
                        periodData.slice(-8).map(row => {
                          const max = Math.max(
                            ...periodData.map(
                              item =>
                                Math.max(
                                  Number(item.revenue),
                                  Number(item.expense)
                                ),
                              1
                            )
                          );
                          const revenue = Math.max(
                            8,
                            (Number(row.revenue) / max) * 88
                          );
                          const expense = Math.max(
                            8,
                            (Number(row.expense) / max) * 88
                          );
                          return (
                            <div
                              key={row.period}
                              className="flex h-full flex-1 items-end justify-center gap-1"
                            >
                              <div className="group relative flex h-full items-end">
                                <div
                                  className="w-4 rounded-t-md bg-gradient-to-t from-emerald-500 to-cyan-300 shadow-[8px_8px_0_rgba(6,182,212,.18)]"
                                  style={{ height: `${revenue}%` }}
                                  title={`${row.label}: ${displayMoney(row.revenue)}`}
                                />
                              </div>
                              <div className="group relative flex h-full items-end">
                                <div
                                  className="w-4 rounded-t-md bg-gradient-to-t from-rose-600 to-amber-300 shadow-[8px_8px_0_rgba(244,63,94,.18)]"
                                  style={{ height: `${expense}%` }}
                                  title={`${row.label}: ${displayMoney(row.expense)}`}
                                />
                              </div>
                              <span className="absolute bottom-0 translate-y-5 text-[10px] text-slate-300">
                                {row.label}
                              </span>
                            </div>
                          );
                        })
                      ) : (
                        <div className="m-auto text-sm text-slate-300">
                          {tr("لا توجد بيانات للفترة الحالية")}
                        </div>
                      )}
                    </div>
                    <div className="absolute bottom-3 left-5 flex gap-4 text-xs text-slate-300">
                      <span>
                        <i className="mr-1 inline-block h-2 w-2 rounded-full bg-cyan-300" />
                        {tr("الإيرادات")}
                      </span>
                      <span>
                        <i className="mr-1 inline-block h-2 w-2 rounded-full bg-rose-400" />
                        {tr("المصروفات")}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <section className="grid gap-6 xl:grid-cols-[1.45fr_1fr]">
                <Card className="border-slate-200 shadow-sm">
                  <CardHeader>
                    <CardTitle>{tr("اتجاه الإيرادات والمصروفات")}</CardTitle>
                    <CardDescription>
                      {tr(
                        "مبيعات الطلبات مع القيود المالية الفعلية مجمعة شهرياً."
                      )}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="h-[300px]">
                    {accounting.isLoading ? (
                      <div className="grid h-full place-items-center text-sm text-slate-500">
                        {tr("جارٍ تحميل التقرير…")}
                      </div>
                    ) : periodData.length ? (
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={periodData}
                          margin={{ top: 8, right: 8, left: -16, bottom: 0 }}
                        >
                          <CartesianGrid vertical={false} stroke="#e2e8f0" />
                          <XAxis
                            dataKey="label"
                            tickLine={false}
                            axisLine={false}
                          />
                          <YAxis
                            tickLine={false}
                            axisLine={false}
                            tickFormatter={value => Number(value).toFixed(0)}
                          />
                          <Tooltip
                            formatter={(value: number) => displayMoney(value)}
                          />
                          <Legend />
                          <Bar
                            dataKey="revenue"
                            name={tr("إيرادات التوصيل")}
                            fill="#059669"
                            radius={[5, 5, 0, 0]}
                          />
                          <Bar
                            dataKey="expense"
                            name={tr("إجمالي المصروفات")}
                            fill="#e11d48"
                            radius={[5, 5, 0, 0]}
                          />
                        </BarChart>
                      </ResponsiveContainer>
                    ) : (
                      <div className="grid h-full place-items-center rounded-xl bg-slate-50 text-sm text-slate-500">
                        {tr(
                          "لا توجد قيود أو طلبات مسلّمة لعرضها ضمن الفلاتر الحالية."
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
                <Card className="border-slate-200 shadow-sm">
                  <CardHeader>
                    <CardTitle>{tr("تصنيف القيود المالية")}</CardTitle>
                    <CardDescription>
                      {tr("أكبر فئات الإيرادات أو المصروفات في الفترة.")}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="h-[300px]">
                    {pieData.length ? (
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Tooltip
                            formatter={(value: number) => displayMoney(value)}
                          />
                          <Legend verticalAlign="bottom" height={42} />
                          <Pie
                            data={pieData}
                            dataKey="value"
                            nameKey="name"
                            innerRadius={56}
                            outerRadius={88}
                            paddingAngle={3}
                          >
                            {pieData.map((item, index) => (
                              <Cell
                                key={`${item.name}-${index}`}
                                fill={chartColors[index % chartColors.length]}
                              />
                            ))}
                          </Pie>
                        </PieChart>
                      </ResponsiveContainer>
                    ) : (
                      <div className="grid h-full place-items-center rounded-xl bg-slate-50 text-sm text-slate-500">
                        {tr("لا توجد قيود مصنفة ضمن الفترة.")}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </section>

              {canEdit ? (
                <Card className="border-emerald-200 shadow-sm print:hidden">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <FilePlus2 className="h-5 w-5 text-emerald-700" />
                      {tr("إضافة قيد مالي")}
                    </CardTitle>
                    <CardDescription>
                      {tr(
                        "أدخل الإيراد أو المصروف مع التصنيف والشركة المرجعية عند الحاجة."
                      )}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <form
                      onSubmit={submitEntry}
                      className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4"
                    >
                      <select
                        value={form.type}
                        onChange={event =>
                          setForm({
                            ...form,
                            type: event.target.value as "income" | "expense",
                          })
                        }
                        className="h-11 rounded-md border border-input bg-white px-3 text-sm"
                      >
                        <option value="expense">{tr("مصروف")}</option>
                        <option value="income">{tr("إيراد")}</option>
                      </select>
                      <select
                        value={form.category}
                        onChange={event =>
                          setForm({
                            ...form,
                            category: event.target.value as FinanceCategory,
                          })
                        }
                        className="h-11 rounded-md border border-input bg-white px-3 text-sm"
                      >
                        {financialCategories.map(category => (
                          <option key={category} value={category}>
                            {categoryLabels[category]}
                          </option>
                        ))}
                      </select>
                      <Input
                        required
                        inputMode="decimal"
                        placeholder={tr("المبلغ بالدينار الكويتي")}
                        value={form.amount}
                        onChange={event =>
                          setForm({ ...form, amount: event.target.value })
                        }
                        className="h-11 bg-white"
                        dir="ltr"
                      />
                      <Input
                        required
                        placeholder={tr("وصف القيد")}
                        value={form.description}
                        onChange={event =>
                          setForm({ ...form, description: event.target.value })
                        }
                        className="h-11 bg-white"
                      />
                      <Input
                        placeholder={tr("المرجع أو رقم الفاتورة")}
                        value={form.reference}
                        onChange={event =>
                          setForm({ ...form, reference: event.target.value })
                        }
                        className="h-11 bg-white"
                      />
                      <Input
                        required
                        type="date"
                        value={form.transactionDate}
                        onChange={event =>
                          setForm({
                            ...form,
                            transactionDate: event.target.value,
                          })
                        }
                        className="h-11 bg-white"
                      />
                      <select
                        value={form.companyId}
                        onChange={event =>
                          setForm({ ...form, companyId: event.target.value })
                        }
                        className="h-11 rounded-md border border-input bg-white px-3 text-sm"
                      >
                        <option value="all">
                          {tr("شركة مرتبطة (اختياري)")}
                        </option>
                        {(filterOptions.data?.companies ?? []).map(company => (
                          <option key={company.id} value={company.id}>
                            {company.name}
                          </option>
                        ))}
                      </select>
                      <Button
                        type="submit"
                        disabled={createEntry.isPending}
                        className="h-11 rounded-xl bg-emerald-700 text-white hover:bg-emerald-800"
                      >
                        {createEntry.isPending
                          ? tr("جارٍ الحفظ…")
                          : tr("حفظ القيد")}
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              ) : null}

              {notice ? (
                <p
                  role="status"
                  className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-semibold text-emerald-800"
                >
                  {notice}
                </p>
              ) : null}

              <DriverCompensationPanel canEdit={canEdit} />
              {canEdit ? (
                <Card className="border-slate-200 shadow-sm">
                  <CardHeader>
                    <CardTitle>
                      {tr("تعرفة التوصيل حسب الشركة والمنطقة")}
                    </CardTitle>
                    <CardDescription>
                      {tr(
                        "احفظ سعراً افتراضياً لكل شركة ومنطقة؛ سيظهر تلقائياً عند إدخال الطلب، ويمكن تعديله للطلب الواحد."
                      )}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <label className="mb-3 block max-w-sm text-sm font-semibold">
                      {tr("الشركة")}
                      <select
                        value={rateCompanyId}
                        onChange={event => setRateCompanyId(event.target.value)}
                        className="mt-1.5 h-10 w-full rounded-md border border-input bg-white px-3 text-sm"
                      >
                        {(filterOptions.data?.companies ?? []).map(company => (
                          <option key={company.id} value={company.id}>
                            {company.name}
                          </option>
                        ))}
                      </select>
                    </label>
                    {rateCompany ? (
                      <CompanyAreaRatePanel company={rateCompany} />
                    ) : (
                      <p className="text-sm text-slate-500">
                        {tr("لا توجد شركات مضافة بعد.")}
                      </p>
                    )}
                  </CardContent>
                </Card>
              ) : null}

              <Card className="border-slate-200 shadow-sm">
                <CardHeader>
                  <CardTitle>{tr("كشف عمولات السائقين")}</CardTitle>
                  <CardDescription>
                    {tr(
                      "الراتب الأساسي للإطلاع، والعمولة المستحقة حسب الطلبات الموصلة أو المعتمدة يدوياً."
                    )}
                  </CardDescription>
                </CardHeader>
                <CardContent className="overflow-x-auto px-0 pb-0">
                  <table className="w-full min-w-[760px] text-right text-sm">
                    <thead className="bg-slate-50 text-xs font-bold text-slate-500">
                      <tr>
                        <th className="px-4 py-3">{tr("السائق")}</th>
                        <th className="px-4 py-3">{tr("طريقة الأجر")}</th>
                        <th className="px-4 py-3">{tr("الراتب الأساسي")}</th>
                        <th className="px-4 py-3">
                          {tr("العمولة الافتراضية")}
                        </th>
                        <th className="px-4 py-3">{tr("طلبات العمولة")}</th>
                        <th className="px-4 py-3">{tr("العمولة المستحقة")}</th>
                        <th className="px-4 py-3">
                          {tr("المبالغ التي استلمها")}
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {(report?.driverStatements ?? []).map(driver => (
                        <tr
                          key={driver.driverId}
                          className="border-t border-slate-100"
                        >
                          <td className="px-4 py-3 font-bold">
                            {driver.driverName}
                          </td>
                          <td className="px-4 py-3">
                            {driver.payType === "salary"
                              ? tr("راتب فقط")
                              : driver.payType === "salary_commission"
                                ? tr("راتب مع عمولة")
                                : tr("سائق تعاقد")}
                          </td>
                          <td className="px-4 py-3" dir="ltr">
                            {displayMoney(driver.baseSalary)}
                          </td>
                          <td className="px-4 py-3" dir="ltr">
                            {displayMoney(driver.defaultCommission)}
                          </td>
                          <td className="px-4 py-3">
                            {driver.commissionOrders}
                          </td>
                          <td
                            className="px-4 py-3 font-black text-emerald-700"
                            dir="ltr"
                          >
                            {displayMoney(driver.earnedCommission)}
                          </td>
                          <td
                            className="px-4 py-3 font-black text-sky-800"
                            dir="ltr"
                          >
                            {displayMoney(driver.cashCollectedTotal)} (
                            {driver.cashCollectionCount})
                          </td>
                        </tr>
                      ))}
                      {!(report?.driverStatements ?? []).length ? (
                        <tr>
                          <td
                            colSpan={7}
                            className="px-4 py-6 text-center text-slate-500"
                          >
                            {tr("لا توجد بيانات سائقين في التقرير.")}
                          </td>
                        </tr>
                      ) : null}
                    </tbody>
                  </table>
                </CardContent>
              </Card>

              <Card className="border-slate-200 shadow-sm">
                <CardHeader className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <ReceiptText className="h-5 w-5 text-slate-700" />
                      {tr("دفتر الطلبات والفواتير وإثباتات التوصيل")}
                    </CardTitle>
                    <CardDescription>
                      {tr(
                        "تظهر الأسعار وإدارة السعر داخل هذه الصفحة للمحاسب والمدير فقط."
                      )}
                    </CardDescription>
                  </div>
                  <Badge
                    variant="outline"
                    className="w-fit border-slate-300 bg-white"
                  >
                    {report?.orderLedger.length ?? 0} {tr("طلب")}
                  </Badge>
                </CardHeader>
                <CardContent className="overflow-x-auto px-0 pb-0">
                  <table className="w-full min-w-[1460px] text-right text-sm">
                    <thead className="bg-slate-50 text-xs font-bold text-slate-500">
                      <tr>
                        <th className="px-3 py-2">{tr("الطلب")}</th>
                        <th className="px-3 py-2">{tr("الشركة / السائق")}</th>
                        <th className="px-3 py-2">{tr("المستلم والعنوان")}</th>
                        <th className="px-3 py-2">{tr("المطلوب / المستلم")}</th>
                        <th className="px-3 py-2">{tr("الحالة")}</th>
                        <th className="px-3 py-2">{tr("الإثباتات")}</th>
                        <th className="px-3 py-2">{tr("سعر التوصيل")}</th>
                        <th className="px-3 py-2">{tr("عمولة السائق")}</th>
                        <th className="px-3 py-2">{tr("حصة الشركة")}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {accounting.isLoading ? (
                        <tr>
                          <td
                            colSpan={9}
                            className="px-3 py-8 text-center text-slate-500"
                          >
                            {tr("جارٍ تحميل دفتر الطلبات…")}
                          </td>
                        </tr>
                      ) : report?.orderLedger.length ? (
                        report.orderLedger.map(order => (
                          <tr
                            key={order.id}
                            className="border-t border-slate-100 align-top hover:bg-slate-50/70"
                          >
                            <td className="px-3 py-2">
                              <p
                                className="font-black text-slate-950"
                                dir="ltr"
                              >
                                {order.orderNumber}
                              </p>
                              <p className="mt-0.5 text-[11px] text-slate-500">
                                {formatDate(order.updatedAt, locale)}
                              </p>
                            </td>
                            <td className="px-3 py-2">
                              <p className="font-semibold text-slate-800">
                                {order.companyName ??
                                  (order.source === "external"
                                    ? tr("طلب خارجي")
                                    : tr("غير مرتبط"))}
                              </p>
                              <p className="mt-0.5 flex items-center gap-1 text-[11px] text-slate-500">
                                <CarFront className="h-3 w-3" />
                                {order.driverName ?? tr("غير مسند")}
                              </p>
                            </td>
                            <td className="px-3 py-2">
                              <p className="font-semibold text-slate-800">
                                {order.customerName ?? "—"}
                              </p>
                              <p
                                className="mt-0.5 max-w-[220px] truncate text-[11px] text-slate-500"
                                title={order.deliveryAddress}
                              >
                                {order.deliveryGovernorateName
                                  ? `${order.deliveryGovernorateName} · `
                                  : ""}
                                {order.deliveryAreaName
                                  ? `${order.deliveryAreaName} · `
                                  : order.area
                                    ? `${order.area} · `
                                    : ""}
                                {order.deliveryAddress}
                              </p>
                              {order.pickupContactName ? (
                                <p className="mt-1 text-[10px] text-slate-500">
                                  {tr("مستلم الطلب من الفرع")}:{" "}
                                  {order.pickupContactName}
                                </p>
                              ) : null}
                            </td>
                            <td className="px-3 py-2">
                              <p className="font-bold text-emerald-800">
                                {tr("المطلوب")}:{" "}
                                {displayMoney(order.cashToCollectAmount)}
                              </p>
                              <p className="mt-1 text-xs text-sky-800">
                                {tr("المستلم")}:{" "}
                                {order.cashCollectionRecorded
                                  ? displayMoney(order.cashCollectedAmount)
                                  : tr("غير مسجل")}
                              </p>
                              {order.cashCollectionNote ? (
                                <p className="mt-1 max-w-[180px] whitespace-normal text-[10px] text-amber-800">
                                  {tr("ملاحظة التحصيل")}:{" "}
                                  {order.cashCollectionNote}
                                </p>
                              ) : null}
                            </td>
                            <td className="px-3 py-2">
                              <Badge
                                className={`px-2 py-0.5 text-[11px] ${statusColors[order.status]}`}
                              >
                                {statusLabels[order.status]}
                              </Badge>
                              {order.returnedToCompany ? (
                                <p className="mt-1 text-[10px] font-bold text-rose-700">
                                  {tr("راجع للشركة")}
                                </p>
                              ) : null}
                            </td>
                            <td className="px-3 py-2">
                              <div className="flex max-w-[145px] flex-wrap gap-1">
                                {order.media.length ? (
                                  order.media.map(media => (
                                    <a
                                      key={media.id}
                                      href={media.fileUrl}
                                      target="_blank"
                                      rel="noreferrer"
                                      className="inline-flex items-center gap-1 rounded-md border border-slate-200 bg-white px-1.5 py-1 text-[11px] font-semibold text-slate-700 hover:border-emerald-400 hover:text-emerald-700"
                                    >
                                      <ImageIcon className="h-3 w-3" />
                                      {mediaLabel(media.kind)}
                                    </a>
                                  ))
                                ) : (
                                  <span className="text-[11px] text-slate-400">
                                    {tr("لا صور")}
                                  </span>
                                )}
                              </div>
                            </td>
                            {(
                              [
                                "deliveryFee",
                                "driverCommission",
                                "companyShare",
                              ] as const
                            ).map(field => {
                              const draft =
                                field === "deliveryFee"
                                  ? feeDrafts[order.id]
                                  : field === "driverCommission"
                                    ? commissionDrafts[order.id]
                                    : companyShareDrafts[order.id];
                              const value =
                                draft ?? String(order[field] ?? "0.000");
                              const updateDraft =
                                field === "deliveryFee"
                                  ? setFeeDrafts
                                  : field === "driverCommission"
                                    ? setCommissionDrafts
                                    : setCompanyShareDrafts;
                              return (
                                <td key={field} className="px-3 py-2">
                                  {canEdit ? (
                                    <div className="flex min-w-[150px] items-center gap-1.5">
                                      <Input
                                        aria-label={`${field === "deliveryFee" ? tr("سعر التوصيل") : field === "driverCommission" ? tr("عمولة السائق") : tr("حصة الشركة")} ${order.orderNumber}`}
                                        value={value}
                                        onFocus={event =>
                                          event.currentTarget.select()
                                        }
                                        onChange={event =>
                                          updateDraft(current => ({
                                            ...current,
                                            [order.id]: event.target.value,
                                          }))
                                        }
                                        className="h-8 w-24 cursor-text border-amber-300 bg-amber-50 px-2 text-left text-sm font-black text-slate-950 focus-visible:ring-amber-500"
                                        dir="ltr"
                                        inputMode="decimal"
                                        placeholder="0.000"
                                      />
                                      <Button
                                        type="button"
                                        size="sm"
                                        disabled={updateCompensation.isPending}
                                        onClick={() =>
                                          updateCompensation.mutate({
                                            orderId: order.id,
                                            [field]: value,
                                          })
                                        }
                                        className="h-8 bg-amber-600 px-2 text-xs text-white hover:bg-amber-700"
                                      >
                                        {tr("حفظ")}
                                      </Button>
                                    </div>
                                  ) : (
                                    <span
                                      className="font-black text-emerald-700"
                                      dir="ltr"
                                    >
                                      {displayMoney(value)}
                                    </span>
                                  )}
                                  {field === "deliveryFee" && canEdit ? (
                                    <label className="mt-1 flex items-center gap-1 text-[10px] text-slate-600">
                                      <input
                                        type="checkbox"
                                        checked={Boolean(
                                          order.deliveryFeeChargeOnFailure
                                        )}
                                        onChange={event =>
                                          updateCompensation.mutate({
                                            orderId: order.id,
                                            deliveryFeeChargeOnFailure:
                                              event.target.checked,
                                          })
                                        }
                                      />
                                      {tr("يُحصّل عند التعذر")}
                                    </label>
                                  ) : null}
                                </td>
                              );
                            })}
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td
                            colSpan={9}
                            className="px-3 py-8 text-center text-slate-500"
                          >
                            {tr("لا توجد طلبات ضمن الفلاتر الحالية.")}
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </CardContent>
              </Card>

              <section className="grid gap-6 xl:grid-cols-2">
                <Card className="border-slate-200 shadow-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Building2 className="h-5 w-5 text-sky-700" />
                      {tr("كشف الشركات")}
                    </CardTitle>
                    <CardDescription>
                      {tr(
                        "حصة الشركة ورسوم التوصيل وعمولات السائقين المسجلة لكل شركة."
                      )}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {report?.companyStatements.length ? (
                      report.companyStatements.map(row => (
                        <div
                          key={row.companyId}
                          className="rounded-xl border border-slate-200 bg-white p-4"
                        >
                          <div className="flex items-start justify-between gap-4">
                            <div>
                              <p className="font-bold text-slate-900">
                                {row.companyName}
                              </p>
                              <p className="mt-1 text-xs text-slate-500">
                                {row.deliveredOrders} {tr("طلبات مسلّمة")} /{" "}
                                {row.orders} · {row.entries} {tr("قيود")}
                              </p>
                            </div>
                            <p
                              className={`font-black ${row.balance >= 0 ? "text-emerald-700" : "text-rose-700"}`}
                              dir="ltr"
                            >
                              {displayMoney(row.balance)}
                            </p>
                          </div>
                          <div className="mt-3 grid grid-cols-2 gap-2 text-xs sm:grid-cols-5">
                            <span className="rounded-lg bg-sky-50 p-2 text-sky-800">
                              {tr("حصة الشركة")}
                              <br />
                              <b dir="ltr">{displayMoney(row.sales)}</b>
                            </span>
                            <span className="rounded-lg bg-amber-50 p-2 text-amber-800">
                              {tr("رسوم التوصيل")}
                              <br />
                              <b dir="ltr">{displayMoney(row.deliveryFees)}</b>
                            </span>
                            <span className="rounded-lg bg-violet-50 p-2 text-violet-800">
                              {tr("عمولات السائقين")}
                              <br />
                              <b dir="ltr">
                                {displayMoney(row.driverCommissions)}
                              </b>
                            </span>
                            <span className="rounded-lg bg-sky-50 p-2 text-sky-800">
                              {tr("المطلوب من العملاء / المستلم")}
                              <br />
                              <b dir="ltr">
                                {displayMoney(row.cashToCollect)} /{" "}
                                {displayMoney(row.cashCollected)}
                              </b>
                              <br />
                              {row.cashCollectionCount} {tr("عملية تحصيل")}
                            </span>
                            <span className="rounded-lg bg-emerald-50 p-2 text-emerald-800">
                              {tr("إيرادات يدوية")}
                              <br />
                              <b dir="ltr">{displayMoney(row.income)}</b>
                            </span>
                            <span className="rounded-lg bg-rose-50 p-2 text-rose-800">
                              {tr("مصروفات")}
                              <br />
                              <b dir="ltr">{displayMoney(row.expense)}</b>
                            </span>
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="rounded-xl bg-slate-50 p-5 text-sm text-slate-500">
                        {tr("لا توجد بيانات شركات ضمن الفلاتر.")}
                      </p>
                    )}
                  </CardContent>
                </Card>
                <Card className="border-slate-200 shadow-sm">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Landmark className="h-5 w-5 text-violet-700" />
                      {tr("التقرير التصنيفي التفصيلي")}
                    </CardTitle>
                    <CardDescription>
                      {tr("تفصيل القيود حسب الفئة المالية.")}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    {report?.categoryTotals.length ? (
                      report.categoryTotals.map(row => (
                        <div
                          key={row.category}
                          className="flex items-center justify-between gap-4 rounded-xl border border-slate-200 bg-white px-4 py-3"
                        >
                          <div>
                            <p className="font-bold text-slate-900">
                              {categoryLabels[
                                row.category as FinanceCategory
                              ] ?? row.category}
                            </p>
                            <p className="mt-1 text-xs text-slate-500">
                              {row.entries} {tr("قيود")}
                            </p>
                          </div>
                          <div
                            className="grid grid-cols-3 gap-3 text-left text-xs"
                            dir="ltr"
                          >
                            <span className="text-emerald-700">
                              +{displayMoney(row.income)}
                            </span>
                            <span className="text-rose-700">
                              -{displayMoney(row.expense)}
                            </span>
                            <span className="font-black text-slate-800">
                              {displayMoney(row.balance)}
                            </span>
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="rounded-xl bg-slate-50 p-5 text-sm text-slate-500">
                        {tr("لا توجد قيود مصنفة ضمن الفلاتر.")}
                      </p>
                    )}
                  </CardContent>
                </Card>
              </section>

              <Card className="border-slate-200 shadow-sm">
                <CardHeader>
                  <CardTitle>{tr("القيود المالية")}</CardTitle>
                  <CardDescription>
                    {tr(
                      "جميع الإيرادات والمصروفات التي أُدخلت يدوياً ضمن الفترة المحددة."
                    )}
                  </CardDescription>
                </CardHeader>
                <CardContent className="overflow-x-auto px-0 pb-0">
                  <table className="w-full min-w-[860px] text-right text-sm">
                    <thead className="bg-slate-50 text-xs font-bold text-slate-500">
                      <tr>
                        <th className="px-5 py-3">{tr("التاريخ")}</th>
                        <th className="px-4 py-3">{tr("النوع")}</th>
                        <th className="px-4 py-3">{tr("التصنيف")}</th>
                        <th className="px-4 py-3">{tr("الشركة")}</th>
                        <th className="px-4 py-3">{tr("البيان")}</th>
                        <th className="px-4 py-3">{tr("المبلغ")}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {report?.entries.length ? (
                        report.entries.map(entry => (
                          <tr
                            key={entry.id}
                            className="border-t border-slate-100"
                          >
                            <td className="px-5 py-3 text-slate-600">
                              {formatDate(entry.transactionDate, locale)}
                            </td>
                            <td className="px-4 py-3">
                              <Badge
                                className={
                                  entry.type === "income"
                                    ? "bg-emerald-100 text-emerald-700"
                                    : "bg-rose-100 text-rose-700"
                                }
                              >
                                {entry.type === "income"
                                  ? tr("إيراد")
                                  : tr("مصروف")}
                              </Badge>
                            </td>
                            <td className="px-4 py-3 font-semibold text-slate-800">
                              {categoryLabels[
                                entry.category as FinanceCategory
                              ] ?? entry.category}
                            </td>
                            <td className="px-4 py-3 text-slate-600">
                              {entry.companyName ?? "—"}
                            </td>
                            <td className="px-4 py-3 text-slate-700">
                              {entry.description}
                            </td>
                            <td
                              className="px-4 py-3 font-black text-slate-950"
                              dir="ltr"
                            >
                              {displayMoney(entry.amount)}
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td
                            colSpan={6}
                            className="px-5 py-10 text-center text-slate-500"
                          >
                            {tr("لا توجد قيود مالية ضمن الفلاتر.")}
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
