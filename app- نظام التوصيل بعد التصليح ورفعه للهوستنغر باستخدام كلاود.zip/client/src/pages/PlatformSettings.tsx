import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/i18n";
import { formatOrderNumber } from "@shared/order-number";
import { ImagePlus, LoaderCircle } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { friendlyError } from "@/lib/errorMessage";

type FormState = {
  brandName: string;
  logoUrl: string;
  primaryColor: string;
  accentColor: string;
  subscriptionStartsAt: string;
  subscriptionEndsAt: string;
  allowDriverTransfer: boolean;
  allowSupervisorTransfer: boolean;
  allowManagerTransfer: boolean;
  hideDriverDeliveryFee: boolean;
  orderNumberFormat: "numeric" | "alphabetic";
  nextOrderNumber: number;
};

function toLocalDateTime(value: Date | string | null | undefined) {
  if (!value) return "";
  const date = value instanceof Date ? value : new Date(value);
  return Number.isNaN(date.getTime()) ? "" : date.toISOString().slice(0, 16);
}

function toIsoOrNull(value: string) {
  return value ? new Date(value).toISOString() : null;
}

function readFileBase64(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(",")[1] ?? "");
    reader.onerror = () => reject(reader.error ?? new Error("تعذر قراءة الصورة"));
    reader.readAsDataURL(file);
  });
}

const initialForm: FormState = {
  brandName: "City Center",
  logoUrl: "/manus-storage/city-center-logo-user_665f44b4.png",
  primaryColor: "#f97316",
  accentColor: "#0f172a",
  subscriptionStartsAt: "",
  subscriptionEndsAt: "",
  allowDriverTransfer: true,
  allowSupervisorTransfer: true,
  allowManagerTransfer: true,
  hideDriverDeliveryFee: true,
  orderNumberFormat: "numeric",
  nextOrderNumber: 1,
};

const MAX_LOGO_BYTES = 8 * 1024 * 1024;
const LOGO_TYPES = ["image/png", "image/jpeg", "image/webp"] as const;

export default function PlatformSettings() {
  const { language } = useLanguage();
  const isArabic = language === "ar";
  const utils = trpc.useUtils();
  const settingsQuery = trpc.platform.settings.useQuery();
  const logoInput = useRef<HTMLInputElement>(null);
  const [form, setForm] = useState<FormState>(initialForm);
  const [notice, setNotice] = useState("");
  const [logoError, setLogoError] = useState("");
  const updateMutation = trpc.platform.updateSettings.useMutation({
    onSuccess: async () => {
      setNotice(isArabic ? "تم حفظ إعدادات الموقع" : "Site settings saved");
      await Promise.all([utils.platform.settings.invalidate(), utils.platform.branding.invalidate(), utils.platform.canTransfer.invalidate()]);
    },
    onError: (error) => setNotice(error.message),
  });
  const uploadLogoMutation = trpc.platform.uploadLogo.useMutation();

  useEffect(() => {
    const settings = settingsQuery.data;
    if (!settings) return;
    setForm({
      brandName: settings.brandName,
      logoUrl: settings.logoUrl ?? "",
      primaryColor: settings.primaryColor,
      accentColor: settings.accentColor,
      subscriptionStartsAt: toLocalDateTime(settings.subscriptionStartsAt),
      subscriptionEndsAt: toLocalDateTime(settings.subscriptionEndsAt),
      allowDriverTransfer: settings.allowDriverTransfer,
      allowSupervisorTransfer: settings.allowSupervisorTransfer,
      allowManagerTransfer: settings.allowManagerTransfer,
      hideDriverDeliveryFee: settings.hideDriverDeliveryFee,
      orderNumberFormat: settings.orderNumberFormat,
      nextOrderNumber: settings.nextOrderNumber,
    });
  }, [settingsQuery.data]);

  function updateField<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  async function handleLogoFile(file?: File) {
    if (!file) return;
    setLogoError("");
    setNotice("");
    if (!LOGO_TYPES.includes(file.type as (typeof LOGO_TYPES)[number])) {
      setLogoError(isArabic ? "اختر صورة PNG أو JPG أو WebP." : "Choose a PNG, JPG, or WebP image.");
      return;
    }
    if (file.size > MAX_LOGO_BYTES) {
      setLogoError(isArabic ? "حجم الشعار يجب ألا يتجاوز 8 ميجابايت." : "The logo must be 8 MB or smaller.");
      return;
    }
    try {
      const dataBase64 = await readFileBase64(file);
      const uploaded = await uploadLogoMutation.mutateAsync({ mimeType: file.type as (typeof LOGO_TYPES)[number], dataBase64 });
      updateField("logoUrl", uploaded.logoUrl);
      setNotice(isArabic ? "تم رفع الشعار. اضغط حفظ إعدادات الموقع لتطبيقه." : "Logo uploaded. Save site settings to apply it.");
    } catch (error) {
      setLogoError(error instanceof Error ? error.message : (isArabic ? "تعذر رفع الشعار." : "Logo upload failed."));
    }
  }

  function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setNotice("");
    updateMutation.mutate({
      ...form,
      logoUrl: form.logoUrl.trim() || null,
      subscriptionStartsAt: toIsoOrNull(form.subscriptionStartsAt),
      subscriptionEndsAt: toIsoOrNull(form.subscriptionEndsAt),
    });
  }

  const mode = settingsQuery.data?.mode;
  const modeLabel = mode === "read_only"
    ? (isArabic ? "قراءة فقط" : "Read only")
    : mode === "not_started"
      ? (isArabic ? "لم يبدأ بعد" : "Not started")
      : (isArabic ? "فعال" : "Active");
  const reminder = settingsQuery.data?.reminderDays;
  const transferOptions: Array<{ key: keyof Pick<FormState, "allowDriverTransfer" | "allowSupervisorTransfer" | "allowManagerTransfer">; label: string }> = [
    { key: "allowDriverTransfer", label: isArabic ? "السائق يستطيع تحويل الطلب" : "Drivers can transfer orders" },
    { key: "allowSupervisorTransfer", label: isArabic ? "المشرف يستطيع تحويل الطلب" : "Supervisors can transfer orders" },
    { key: "allowManagerTransfer", label: isArabic ? "المدير يستطيع تحويل الطلب" : "Managers can transfer orders" },
  ];

  return (
    <DashboardLayout>
      <div dir={isArabic ? "rtl" : "ltr"} className="mx-auto max-w-5xl space-y-6 p-4 sm:p-6">
        <div>
          <p className="text-sm font-bold text-orange-600">{isArabic ? "إعدادات النسخة المستقلة" : "Independent site settings"}</p>
          <h1 className="mt-1 text-3xl font-black text-slate-900">{isArabic ? "هوية الموقع والاشتراك" : "Site identity and subscription"}</h1>
          <p className="mt-2 text-sm leading-7 text-slate-500">{isArabic ? "هذه الصفحة للأدمن فقط. حسابات الشركة والأدوار الأخرى لا تستطيع تعديل الهوية أو تاريخ الاشتراك." : "Admin only. Company accounts and other roles cannot change site identity or subscription dates."}</p>
        </div>

        {settingsQuery.isLoading ? <Card><CardContent className="p-6 text-sm text-slate-500">{isArabic ? "جارٍ تحميل الإعدادات..." : "Loading settings..."}</CardContent></Card> : null}
        {settingsQuery.error ? <Card className="border-rose-200"><CardContent className="p-6 text-sm text-rose-700">{friendlyError(settingsQuery.error)}</CardContent></Card> : null}

        {settingsQuery.data ? <form onSubmit={submit} className="space-y-6">
          <Card className="rounded-3xl border-slate-100 shadow-sm">
            <CardHeader>
              <CardTitle>{isArabic ? "هوية الشركة" : "Company identity"}</CardTitle>
              <CardDescription>{isArabic ? "غيّر الاسم والشعار والألوان؛ تظهر التغييرات على الصفحة الرئيسية ولوحة التحكم بعد الحفظ." : "Change the name, logo, and colors. The homepage and dashboard update after saving."}</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-5 md:grid-cols-2">
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="brandName">{isArabic ? "اسم الشركة / الموقع" : "Company / site name"}</Label>
                <Input id="brandName" value={form.brandName} onChange={(event) => updateField("brandName", event.target.value)} required maxLength={180} />
              </div>
              <div className="space-y-3 md:col-span-2">
                <Label>{isArabic ? "شعار الموقع" : "Site logo"}</Label>
                <div className="flex flex-wrap items-center gap-4 rounded-2xl border border-slate-100 bg-slate-50 p-4">
                  <div className="flex h-24 w-24 shrink-0 items-center justify-center overflow-hidden rounded-2xl border border-slate-200 bg-white p-2">
                    {form.logoUrl ? <img src={form.logoUrl} alt={isArabic ? "معاينة شعار الموقع" : "Site logo preview"} className="max-h-full max-w-full object-contain" /> : <ImagePlus className="h-8 w-8 text-slate-300" />}
                  </div>
                  <div className="min-w-0 flex-1 space-y-3">
                    <div className="flex flex-wrap gap-2">
                      <Button type="button" variant="outline" disabled={uploadLogoMutation.isPending} onClick={() => logoInput.current?.click()} className="rounded-xl">
                        {uploadLogoMutation.isPending ? <LoaderCircle className="ml-2 h-4 w-4 animate-spin" /> : <ImagePlus className="ml-2 h-4 w-4" />}
                        {uploadLogoMutation.isPending ? (isArabic ? "جارٍ رفع الشعار..." : "Uploading logo...") : (isArabic ? "اختر شعاراً من الجهاز" : "Choose logo from device")}
                      </Button>
                      <input ref={logoInput} type="file" accept="image/png,image/jpeg,image/webp" className="hidden" disabled={uploadLogoMutation.isPending} onChange={(event) => { void handleLogoFile(event.target.files?.[0]); event.currentTarget.value = ""; }} />
                    </div>
                    <p className="text-xs leading-6 text-slate-500">{isArabic ? "PNG أو JPG أو WebP، بحد أقصى 8 ميجابايت. بعد الرفع اضغط حفظ إعدادات الموقع." : "PNG, JPG, or WebP, up to 8 MB. After uploading, click Save site settings."}</p>
                    {logoError ? <p role="alert" className="text-sm font-semibold text-rose-700">{logoError}</p> : null}
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="logoUrl">{isArabic ? "أو رابط مباشر للشعار" : "Or enter a direct logo URL"}</Label>
                  <Input id="logoUrl" value={form.logoUrl} onChange={(event) => updateField("logoUrl", event.target.value)} placeholder="/manus-storage/company-logo.png" maxLength={512} />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="primaryColor">{isArabic ? "اللون الأساسي" : "Primary color"}</Label>
                <div className="flex gap-2"><Input id="primaryColor" type="color" value={form.primaryColor} onChange={(event) => updateField("primaryColor", event.target.value)} className="h-10 w-16 p-1" /><Input aria-label={isArabic ? "رمز اللون الأساسي" : "Primary color hex"} value={form.primaryColor} onChange={(event) => updateField("primaryColor", event.target.value)} pattern="^#[0-9a-fA-F]{6}$" /></div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="accentColor">{isArabic ? "اللون المساند" : "Accent color"}</Label>
                <div className="flex gap-2"><Input id="accentColor" type="color" value={form.accentColor} onChange={(event) => updateField("accentColor", event.target.value)} className="h-10 w-16 p-1" /><Input aria-label={isArabic ? "رمز اللون المساند" : "Accent color hex"} value={form.accentColor} onChange={(event) => updateField("accentColor", event.target.value)} pattern="^#[0-9a-fA-F]{6}$" /></div>
              </div>
              <div className="flex items-center gap-3 rounded-2xl border border-slate-100 p-4 md:col-span-2">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl text-white" style={{ backgroundColor: form.primaryColor }}>Aa</span>
                <span className="flex h-10 w-10 items-center justify-center rounded-xl text-white" style={{ backgroundColor: form.accentColor }}>Aa</span>
                <span className="font-bold">{form.brandName || (isArabic ? "اسم الموقع" : "Site name")}</span>
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-3xl border-slate-100 shadow-sm">
            <CardHeader>
              <CardTitle>{isArabic ? "الاشتراك ووضع القراءة فقط" : "Subscription and read-only mode"}</CardTitle>
              <CardDescription>{isArabic ? "عند انتهاء التاريخ يتوقف التعديل تلقائياً ولا تحذف البيانات." : "After expiry, writes are blocked automatically and data is preserved."}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-5">
              <div className="grid gap-5 md:grid-cols-2"><div className="space-y-2"><Label htmlFor="subscriptionStartsAt">{isArabic ? "بداية الاشتراك" : "Subscription starts"}</Label><Input id="subscriptionStartsAt" type="datetime-local" value={form.subscriptionStartsAt} onChange={(event) => updateField("subscriptionStartsAt", event.target.value)} /></div><div className="space-y-2"><Label htmlFor="subscriptionEndsAt">{isArabic ? "نهاية الاشتراك" : "Subscription ends"}</Label><Input id="subscriptionEndsAt" type="datetime-local" value={form.subscriptionEndsAt} onChange={(event) => updateField("subscriptionEndsAt", event.target.value)} /></div></div>
              <div className="rounded-2xl bg-slate-50 p-4 text-sm"><strong>{isArabic ? "الحالة الحالية:" : "Current status:"}</strong> <span className="font-bold text-orange-600">{modeLabel}</span>{reminder ? <span className="mr-3 text-slate-500">{isArabic ? `متبقٍ ${reminder} أيام` : `${reminder} day(s) remaining`}</span> : null}</div>
            </CardContent>
          </Card>

          <Card className="rounded-3xl border-slate-100 shadow-sm">
            <CardHeader><CardTitle>{isArabic ? "صلاحيات تحويل الطلبات" : "Order transfer permissions"}</CardTitle><CardDescription>{isArabic ? "الأقسام ثابتة، وهذه العمليات يمكن تشغيلها أو إيقافها حسب الاتفاق." : "Core modules stay available; these operations can be enabled or disabled."}</CardDescription></CardHeader>
            <CardContent className="space-y-3">
              {transferOptions.map(({ key, label }) => <label key={key} className="flex cursor-pointer items-center justify-between rounded-2xl border border-slate-100 p-4"><span className="font-bold text-slate-700">{label}</span><input type="checkbox" checked={form[key]} onChange={(event) => updateField(key, event.target.checked)} className="h-5 w-5 accent-orange-500" /></label>)}
            </CardContent>
          </Card>

          <Card className="rounded-3xl border-slate-100 shadow-sm">
            <CardHeader><CardTitle>{isArabic ? "عرض الأسعار للسائق" : "Driver price visibility"}</CardTitle><CardDescription>{isArabic ? "يظهر للسائق أجرته فقط افتراضياً. يمكنك السماح له برؤية رسم التوصيل أيضاً؛ ولا تظهر له حصة الشركة." : "Drivers see their commission only by default. You can also allow delivery fee visibility; company share stays private."}</CardDescription></CardHeader>
            <CardContent><label className="flex cursor-pointer items-center justify-between rounded-2xl border border-slate-100 p-4"><span className="font-bold text-slate-700">{isArabic ? "إخفاء سعر التوصيل عن السائق" : "Hide delivery fee from drivers"}</span><input type="checkbox" checked={form.hideDriverDeliveryFee} onChange={(event) => updateField("hideDriverDeliveryFee", event.target.checked)} className="h-5 w-5 accent-orange-500" /></label></CardContent>
          </Card>

          <Card className="rounded-3xl border-slate-100 shadow-sm">
            <CardHeader>
              <CardTitle>{isArabic ? "تسلسل أرقام الطلبات والفواتير" : "Order and invoice numbering"}</CardTitle>
              <CardDescription>{isArabic ? "يستخدم الطلب والفاتورة المرفقة الرقم نفسه. النمط ورقم البداية يؤثران على الطلبات الجديدة فقط." : "Orders and their attached invoices share one number. Format and starting value apply to new orders only."}</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-5 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="orderNumberFormat">{isArabic ? "طريقة الترقيم" : "Numbering format"}</Label>
                <select id="orderNumberFormat" value={form.orderNumberFormat} onChange={(event) => updateField("orderNumberFormat", event.target.value as FormState["orderNumberFormat"])} className="h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm">
                  <option value="numeric">{isArabic ? "أرقام: 000001، 000002..." : "Numbers: 000001, 000002..."}</option>
                  <option value="alphabetic">{isArabic ? "حروف: A، B... Z، AA..." : "Letters: A, B... Z, AA..."}</option>
                </select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="nextOrderNumber">{isArabic ? "رقم بداية الطلبات الجديدة" : "Next order starting value"}</Label>
                <Input id="nextOrderNumber" type="number" min={1} max={2147483646} step={1} value={form.nextOrderNumber} onChange={(event) => updateField("nextOrderNumber", Number(event.target.value))} required />
                <p className="text-xs leading-5 text-slate-500">{isArabic ? `الرقم التالي سيكون ${formatOrderNumber(Math.max(1, form.nextOrderNumber || 1), form.orderNumberFormat)}. تبقى أرقام الطلبات السابقة كما هي، وتُتجاوز الأرقام المستخدمة تلقائياً.` : `The next number will be ${formatOrderNumber(Math.max(1, form.nextOrderNumber || 1), form.orderNumberFormat)}. Existing order numbers stay unchanged and used numbers are skipped automatically.`}</p>
              </div>
            </CardContent>
          </Card>

          <div className="flex flex-wrap items-center gap-3"><Button type="submit" disabled={updateMutation.isPending || uploadLogoMutation.isPending} className="rounded-xl bg-orange-500 px-6 text-white hover:bg-orange-600">{updateMutation.isPending ? (isArabic ? "جارٍ الحفظ..." : "Saving...") : (isArabic ? "حفظ إعدادات الموقع" : "Save site settings")}</Button>{notice ? <p role="status" className="rounded-xl bg-emerald-50 px-4 py-2 text-sm font-bold text-emerald-700">{notice}</p> : null}</div>
        </form> : null}
      </div>
    </DashboardLayout>
  );
}
