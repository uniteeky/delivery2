import { useState } from "react";
import { Link, useLocation } from "wouter";
import {
  ArrowRight,
  CheckCircle2,
  Eye,
  EyeOff,
  ShieldCheck,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/i18n";
import { friendlyError } from "@/lib/errorMessage";

export default function DriverRegistration() {
  const { t, language } = useLanguage();
  const [, navigate] = useLocation();
  const [showPassword, setShowPassword] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    civilId: "",
    requestedRole: "driver" as "driver" | "supervisor" | "accountant",
    name: "",
    phone: "",
    password: "",
    confirmPassword: "",
  });
  const register = trpc.auth.registerDriver.useMutation({
    onSuccess: () => setSubmitted(true),
  });
  const update =
    (key: keyof typeof form) => (event: React.ChangeEvent<HTMLInputElement>) =>
      setForm(current => ({ ...current, [key]: event.target.value }));
  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    if (form.password !== form.confirmPassword) return;
    register.mutate({
      civilId: form.civilId,
      requestedRole: form.requestedRole,
      name: form.name,
      phone: form.phone,
      password: form.password,
      preferredLanguage: language,
    });
  };
  const roleCopy =
    language === "ar"
      ? {
          title: "نوع الحساب",
          driver: "سائق",
          supervisor: "مشرف",
          accountant: "محاسب",
          hint: "سيتم تفعيل الدور بعد موافقة المدير، ويمكنه إضافة أدوار أخرى لاحقاً حسب الصلاحيات.",
        }
      : language === "bn"
        ? {
            title: "অনুরোধ করা ভূমিকা",
            driver: "ড্রাইভার",
            supervisor: "সুপারভাইজার",
            accountant: "হিসাবরক্ষক",
            hint: "ম্যানেজারের অনুমোদনের পর ভূমিকা সক্রিয় হবে এবং তিনি অতিরিক্ত ভূমিকা দিতে পারবেন।",
          }
        : language === "hi"
          ? {
              title: "अनुरोधित भूमिका",
              driver: "ड्राइवर",
              supervisor: "सुपरवाइज़र",
              accountant: "लेखाकार",
              hint: "मैनेजर की स्वीकृति के बाद भूमिका सक्रिय होगी और अतिरिक्त भूमिकाएं दी जा सकेंगी।",
            }
          : {
              title: "Account type",
              driver: "Driver",
              supervisor: "Supervisor",
              accountant: "Accountant",
              hint: "The manager must approve this role and may grant additional roles later.",
            };

  return (
    <main
      dir={language === "ar" ? "rtl" : "ltr"}
      className="min-h-screen bg-[#fffaf4] px-4 py-8 text-slate-900 sm:px-6"
    >
      <div className="mx-auto max-w-2xl">
        <Link
          href="/"
          className="mb-6 inline-flex items-center gap-2 text-sm font-bold text-slate-600 hover:text-orange-600"
        >
          <ArrowRight className="h-4 w-4" /> {t("backHome")}
        </Link>
        <Card className="rounded-[2rem] border-orange-100 shadow-xl shadow-orange-100/40">
          <CardHeader className="border-b border-slate-100 p-6 sm:p-8">
            <div className="flex items-start gap-3">
              <div className="rounded-2xl bg-orange-100 p-3 text-orange-600">
                <ShieldCheck className="h-6 w-6" />
              </div>
              <div>
                <CardTitle className="text-2xl font-black">
                  {language === "ar"
                    ? "تسجيل حساب جديد"
                    : "Register a new account"}
                </CardTitle>
                <p className="mt-2 text-sm leading-7 text-slate-500">
                  {language === "ar"
                    ? "اختر الدور المطلوب، ثم يراجع المدير الحساب ويعتمد الدور ويمكنه إضافة أدوار أخرى لاحقاً."
                    : "Choose a requested role. A manager will approve it and may grant additional roles later."}
                </p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-6 sm:p-8">
            {submitted ? (
              <div className="rounded-3xl bg-emerald-50 p-8 text-center text-emerald-900">
                <CheckCircle2 className="mx-auto h-12 w-12 text-emerald-600" />
                <h2 className="mt-4 text-xl font-black">
                  {t("registrationSubmitted")}
                </h2>
                <p className="mx-auto mt-3 max-w-md text-sm leading-7">
                  {t("registrationSuccessGuidance")}
                </p>
                <Button
                  className="mt-6 rounded-xl bg-slate-900 text-white hover:bg-slate-800"
                  onClick={() => navigate("/")}
                >
                  {t("backHome")}
                </Button>
              </div>
            ) : (
              <form onSubmit={submit} className="space-y-5">
                <div className="grid gap-5 sm:grid-cols-2">
                  <div className="space-y-2 sm:col-span-2">
                    <Label htmlFor="requestedRole">
                      {roleCopy.title}{" "}
                      <span className="text-orange-600">*</span>
                    </Label>
                    <select
                      id="requestedRole"
                      value={form.requestedRole}
                      onChange={event =>
                        setForm(current => ({
                          ...current,
                          requestedRole: event.target
                            .value as typeof current.requestedRole,
                        }))
                      }
                      className="h-12 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm"
                    >
                      <option value="driver">{roleCopy.driver}</option>
                      <option value="supervisor">{roleCopy.supervisor}</option>
                      <option value="accountant">{roleCopy.accountant}</option>
                    </select>
                    <p className="text-xs leading-6 text-slate-500">
                      {roleCopy.hint}
                    </p>
                  </div>
                  <div className="space-y-2 sm:col-span-2">
                    <Label htmlFor="name">
                      {t("fullName")} <span className="text-orange-600">*</span>
                    </Label>
                    <Input
                      id="name"
                      required
                      minLength={2}
                      value={form.name}
                      onChange={update("name")}
                      placeholder={t("fullName")}
                      className="h-12 rounded-xl bg-white"
                    />
                  </div>
                  <div className="space-y-2 sm:col-span-2">
                    <Label htmlFor="civilId">
                      {t("civilId")} <span className="text-orange-600">*</span>
                    </Label>
                    <Input
                      id="civilId"
                      inputMode="numeric"
                      maxLength={12}
                      required
                      value={form.civilId}
                      onChange={update("civilId")}
                      placeholder={t("civilIdPlaceholder")}
                      className="h-12 rounded-xl bg-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">
                      {t("phoneLabel")}{" "}
                      <span className="text-orange-600">*</span>
                    </Label>
                    <Input
                      id="phone"
                      required
                      value={form.phone}
                      onChange={update("phone")}
                      placeholder={t("registrationPhonePlaceholder")}
                      className="h-12 rounded-xl"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">
                      {t("password")} <span className="text-orange-600">*</span>
                    </Label>
                    <div className="relative">
                      <Input
                        id="password"
                        type={showPassword ? "text" : "password"}
                        minLength={8}
                        required
                        value={form.password}
                        onChange={update("password")}
                        className="h-12 rounded-xl pl-12"
                        placeholder={t("passwordLengthHint")}
                      />
                      <button
                        type="button"
                        aria-label={
                          showPassword ? t("hidePassword") : t("showPassword")
                        }
                        onClick={() => setShowPassword(value => !value)}
                        className="absolute left-3 top-3 text-slate-400"
                      >
                        {showPassword ? (
                          <EyeOff className="h-5 w-5" />
                        ) : (
                          <Eye className="h-5 w-5" />
                        )}
                      </button>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">
                      {t("confirmPassword")}{" "}
                      <span className="text-orange-600">*</span>
                    </Label>
                    <Input
                      id="confirmPassword"
                      type="password"
                      minLength={8}
                      required
                      value={form.confirmPassword}
                      onChange={update("confirmPassword")}
                      className="h-12 rounded-xl"
                    />
                  </div>
                </div>
                {form.confirmPassword &&
                form.password !== form.confirmPassword ? (
                  <p className="text-sm font-semibold text-red-600">
                    {t("passwordsMismatch")}.
                  </p>
                ) : null}
                {register.error ? (
                  <p className="rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700">
                    {friendlyError(register.error)}
                  </p>
                ) : null}
                <div className="rounded-2xl bg-slate-50 p-4 text-sm leading-7 text-slate-600">
                  {t("vehicleManagerOnly")}
                </div>
                <Button
                  type="submit"
                  disabled={
                    register.isPending || form.password !== form.confirmPassword
                  }
                  className="h-12 w-full rounded-xl bg-orange-500 font-bold text-white hover:bg-orange-600"
                >
                  {register.isPending
                    ? t("submittingRegistration")
                    : t("submitRegistration")}
                </Button>
              </form>
            )}
          </CardContent>
        </Card>
      </div>
    </main>
  );
}
