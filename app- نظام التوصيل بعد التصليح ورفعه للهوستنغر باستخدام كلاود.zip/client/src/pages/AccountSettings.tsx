import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { LOCAL_LOGIN_PATH } from "@/lib/local-auth-routing";
import { KeyRound, LogOut, ShieldCheck } from "lucide-react";
import { useState } from "react";
import { useLanguage } from "@/i18n";

export default function AccountSettings() {
  const { user, logout } = useAuth();
  const { t, language } = useLanguage();
  const utils = trpc.useUtils();
  const [civilId, setCivilId] = useState("");
  const [form, setForm] = useState({ currentPassword: "", newPassword: "", confirmPassword: "" });
  const [notice, setNotice] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const setCivilIdMutation = trpc.auth.setOwnCivilId.useMutation({
    onSuccess: async () => { setNotice({ type: "success", text: language === "ar" ? "تم حفظ الرقم المدني في حسابك." : "Civil ID saved to your account." }); await utils.auth.me.invalidate(); },
    onError: (error) => setNotice({ type: "error", text: error.message }),
  });
  const changePassword = trpc.auth.changeLocalPassword.useMutation({ onSuccess: async () => { setForm({ currentPassword: "", newPassword: "", confirmPassword: "" }); setNotice({ type: "success", text: t("passwordChanged") }); await utils.auth.me.invalidate(); } });
  const submitPassword = (event: React.FormEvent) => { event.preventDefault(); setNotice(null); if (form.newPassword.length < 8) { setNotice({ type: "error", text: t("passwordHint") }); return; } if (form.newPassword !== form.confirmPassword) { setNotice({ type: "error", text: t("passwordMismatch") }); return; } changePassword.mutate(form); };
  const submitCivilId = (event: React.FormEvent) => { event.preventDefault(); setNotice(null); setCivilIdMutation.mutate({ civilId }); };
  const isArabic = language === "ar";

  if (!user) return <main dir={isArabic ? "rtl" : "ltr"} className="min-h-screen bg-[#fffaf4] p-5 text-slate-900"><div className="mx-auto flex min-h-[90vh] w-full max-w-xl items-center"><Card className="w-full rounded-3xl border-orange-100 shadow-xl"><CardHeader><CardTitle className="text-2xl font-black">{isArabic ? "الدخول المحلي" : "Local sign-in"}</CardTitle><p className="mt-2 text-sm leading-7 text-slate-500">{isArabic ? "استخدم الرقم المدني وكلمة المرور للدخول إلى منصة سيتي سنتر." : "Use Civil ID and password to access City Center."}</p></CardHeader><CardContent><Button type="button" onClick={() => window.location.assign(LOCAL_LOGIN_PATH)} className="h-12 w-full rounded-xl bg-orange-500 font-bold text-white hover:bg-orange-600">{isArabic ? "الانتقال إلى الدخول المحلي" : "Go to local sign-in"}</Button></CardContent></Card></div></main>;

  return <main dir={isArabic ? "rtl" : "ltr"} className="min-h-screen bg-slate-950 p-5 text-white"><div className="mx-auto flex min-h-[90vh] w-full max-w-xl items-center"><Card className="w-full rounded-3xl border-white/10 bg-slate-900 text-white shadow-2xl"><CardHeader><div className="flex items-center gap-3"><span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-orange-500/15 text-orange-300"><ShieldCheck className="h-6 w-6" /></span><div><CardTitle className="text-2xl font-black">{t("accountSettings")}</CardTitle><p className="mt-1 text-sm text-slate-400">{user.email || user.name || t("userFallback")}</p></div></div></CardHeader><CardContent>
    {user.loginMethod !== "local-civil-id" ? <section className="mb-5 rounded-2xl border border-orange-400/20 bg-orange-400/10 p-4"><h2 className="font-bold">{isArabic ? "إعداد الرقم المدني" : "Set Civil ID"}</h2><p className="mt-1 text-sm leading-7 text-slate-300">{isArabic ? "احفظ الرقم المدني لاستخدامه في الدخول المحلي لاحقاً." : "Save a Civil ID for future local sign-in."}</p><form onSubmit={submitCivilId} className="mt-3 flex gap-2"><Input required inputMode="numeric" maxLength={12} value={civilId || user.civilId || ""} onChange={(event) => setCivilId(event.target.value)} placeholder={isArabic ? "12 رقماً" : "12 digits"} className="h-11 border-white/10 bg-white/5 text-white placeholder:text-slate-500" /><Button type="submit" disabled={setCivilIdMutation.isPending} className="h-11 whitespace-nowrap bg-orange-500 text-white hover:bg-orange-600">{isArabic ? "حفظ الرقم" : "Save ID"}</Button></form></section> : null}
    {user.loginMethod === "local-civil-id" ? <form onSubmit={submitPassword} className="space-y-3"><div className="flex items-center gap-2 text-sm font-bold"><KeyRound className="h-4 w-4 text-emerald-300" />{t("newPassword")}</div><Input type="password" required minLength={8} value={form.currentPassword} onChange={(event) => setForm((current) => ({ ...current, currentPassword: event.target.value }))} placeholder={t("currentPassword")} className="h-12 rounded-xl border-white/10 bg-white/5 text-white placeholder:text-slate-500" /><Input type="password" required minLength={8} value={form.newPassword} onChange={(event) => setForm((current) => ({ ...current, newPassword: event.target.value }))} placeholder={t("newPassword")} className="h-12 rounded-xl border-white/10 bg-white/5 text-white placeholder:text-slate-500" /><Input type="password" required minLength={8} value={form.confirmPassword} onChange={(event) => setForm((current) => ({ ...current, confirmPassword: event.target.value }))} placeholder={t("confirmPassword")} className="h-12 rounded-xl border-white/10 bg-white/5 text-white placeholder:text-slate-500" /><Button type="submit" disabled={changePassword.isPending} className="h-12 w-full rounded-xl bg-emerald-600 text-white hover:bg-emerald-700">{changePassword.isPending ? t("saving") : t("saveNewPassword")}</Button></form> : null}
    {notice ? <p role="status" className={notice.type === "success" ? "mt-4 rounded-xl bg-emerald-500/10 p-3 text-sm text-emerald-300" : "mt-4 rounded-xl bg-rose-500/10 p-3 text-sm text-rose-300"}>{notice.text}</p> : null}<Button variant="outline" onClick={async () => { await logout(); window.location.assign(LOCAL_LOGIN_PATH); }} className="mt-3 h-11 w-full rounded-xl border-white/10 bg-transparent text-slate-300 hover:bg-white/10 hover:text-white"><LogOut className="ml-2 h-4 w-4" /> {t("logout")}</Button></CardContent></Card></div></main>;
}
