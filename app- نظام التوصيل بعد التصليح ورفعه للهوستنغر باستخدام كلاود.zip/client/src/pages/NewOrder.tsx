import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import LocationPicker from "@/components/LocationPicker";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/_core/hooks/useAuth";
import { LOCAL_LOGIN_PATH } from "@/lib/local-auth-routing";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/i18n";
import { useUiText } from "@/lib/uiText";
import { ArrowRight, ClipboardList, MapPin, PackageCheck } from "lucide-react";
import { friendlyError } from "@/lib/errorMessage";

const empty = {
  companyId: "",
  companyAddressId: "",
  vehicleType: "",
  driverId: "",
  pickupContactName: "",
  pickupPhone: "",
  pickupAddress: "",
  pickupLocationUrl: "",
  pickupGovernorateId: "",
  pickupAreaId: "",
  customerName: "",
  customerPhone: "",
  deliveryGovernorateId: "",
  deliveryAreaId: "",
  deliveryFee: "",
  driverCommission: "",
  companyShare: "",
  deliveryFeeChargeOnFailure: false,
  cashToCollectAmount: "0.000",
  cashCollectionNote: "",
  area: "",
  deliveryAddress: "",
  notes: "",
};

export default function NewOrder({ embedded = false }: { embedded?: boolean }) {
  const { t, language } = useLanguage();
  const tr = useUiText();
  const { isAuthenticated, user } = useAuth();
  const [, navigate] = useLocation();
  const [form, setForm] = useState(empty);
  const [success, setSuccess] = useState<string | null>(null);
  const companies = trpc.companies.list.useQuery(
    { page: 1, pageSize: 100 },
    { enabled: isAuthenticated }
  );
  const companyAddresses = trpc.companies.addresses.useQuery(
    { companyId: Number(form.companyId) },
    { enabled: isAuthenticated && Boolean(form.companyId) }
  );
  const companyAreaRates = trpc.companies.areaRates.useQuery(
    { companyId: Number(form.companyId) },
    { enabled: isAuthenticated && Boolean(form.companyId) }
  );
  const companyGovernorateRates = trpc.companies.governorateRates.useQuery(
    { companyId: Number(form.companyId) },
    { enabled: isAuthenticated && Boolean(form.companyId) }
  );
  const drivers = trpc.drivers.list.useQuery(undefined, {
    enabled: isAuthenticated,
  });
  const vehicleTypes = {
    car: "سيارة",
    refrigerated_car: "سيارة تبريد",
    motorcycle: "دراجة نارية",
    semi_truck: "نصف شاحنة",
    refrigerated_semi_truck: "نصف شاحنة تبريد",
    truck: "شاحنة",
    refrigerated_truck: "شاحنة تبريد",
  } as const;
  const filteredDrivers = (drivers.data ?? []).filter(
    driver => !form.vehicleType || driver.vehicleType === form.vehicleType
  );
  const create = trpc.orders.create.useMutation({
    onSuccess: order => {
      setSuccess(order.orderNumber);
      setForm(empty);
    },
  });
  const canManageFees =
    user?.role === "admin" ||
    user?.role === "accountant" ||
    user?.role === "supervisor" ||
    user?.roles?.some(role =>
      ["admin", "accountant", "supervisor"].includes(role)
    ) === true;
  const set = (key: keyof typeof empty, value: string) =>
    setForm(current => ({ ...current, [key]: value }));
  const selectedCompany = (companies.data?.items ?? []).find(
    company => String(company.id) === form.companyId
  );
  const selectableAddresses = companyAddresses.data?.length
    ? companyAddresses.data
    : selectedCompany?.address
      ? [
          {
            id: 0,
            label: tr("العنوان الرئيسي"),
            address: selectedCompany.address,
            phone: selectedCompany.phone,
            pickupContactName: selectedCompany.name,
            locationUrl: null,
            governorateId: null,
            areaId: null,
            isDefault: true,
            active: true,
          },
        ]
      : [];
  const selectCompany = (companyId: string) => {
    const company = (companies.data?.items ?? []).find(
      item => String(item.id) === companyId
    );
    setForm(current => ({
      ...current,
      companyId,
      companyAddressId: "",
      pickupContactName: "",
      pickupPhone: "",
      pickupAddress: "",
      pickupLocationUrl: "",
      pickupGovernorateId: "",
      pickupAreaId: "",
      deliveryFee: company?.defaultDeliveryFee
        ? String(company.defaultDeliveryFee)
        : "0.000",
    }));
  };
  const selectCompanyAddress = (addressId: string) => {
    const selected = selectableAddresses.find(
      item => String(item.id) === addressId
    );
    if (!selected) return;
    setForm(current => ({
      ...current,
      companyAddressId: addressId,
      pickupContactName:
        selected.pickupContactName?.trim() ||
        `${selectedCompany?.name ?? tr("الشركة")} — ${selected.label}`,
      pickupPhone: selected.phone ?? "",
      pickupAddress: selected.address,
      pickupLocationUrl: selected.locationUrl ?? "",
      pickupGovernorateId: selected.governorateId
        ? String(selected.governorateId)
        : "",
      pickupAreaId: selected.areaId ? String(selected.areaId) : "",
    }));
  };
  useEffect(() => {
    if (
      !form.companyId ||
      form.companyAddressId ||
      companyAddresses.isLoading ||
      !selectableAddresses.length
    )
      return;
    const defaultAddress =
      selectableAddresses.find(item => item.isDefault) ??
      selectableAddresses[0];
    selectCompanyAddress(String(defaultAddress.id));
  }, [
    form.companyId,
    form.companyAddressId,
    companyAddresses.data,
    companyAddresses.isLoading,
  ]);
  const canSend = Boolean(
    form.driverId &&
      form.pickupContactName.trim().length >= 2 &&
      form.pickupPhone.trim().length >= 5 &&
      form.pickupAddress.trim().length >= 5 &&
      form.customerPhone.trim().length >= 5 &&
      form.deliveryAddress.trim().length >= 5
  );
  useEffect(() => {
    if (!form.deliveryGovernorateId) return;
    const areaRate = form.deliveryAreaId
      ? companyAreaRates.data?.find(
          item => item.areaId === Number(form.deliveryAreaId)
        )
      : undefined;
    const governorateRate = companyGovernorateRates.data?.find(
      item => item.governorateId === Number(form.deliveryGovernorateId)
    );
    const effectiveRate = String(
      areaRate?.amount ??
        governorateRate?.amount ??
        selectedCompany?.defaultDeliveryFee ??
        "0.000"
    );
    setForm(current =>
      current.deliveryFee === effectiveRate
        ? current
        : { ...current, deliveryFee: effectiveRate }
    );
  }, [
    companyAreaRates.data,
    companyGovernorateRates.data,
    form.deliveryAreaId,
    form.deliveryGovernorateId,
    selectedCompany?.defaultDeliveryFee,
  ]);
  const setDeliveryLocation = (
    key: "deliveryGovernorateId" | "deliveryAreaId",
    value: number | undefined
  ) =>
    setForm(current => {
      if (key === "deliveryGovernorateId") {
        const governorateRate = value
          ? companyGovernorateRates.data?.find(
              item => item.governorateId === value
            )
          : undefined;
        return {
          ...current,
          deliveryGovernorateId: value ? String(value) : "",
          deliveryAreaId: "",
          deliveryFee: String(
            governorateRate?.amount ??
              selectedCompany?.defaultDeliveryFee ??
              "0.000"
          ),
        };
      }
      const areaRate = value
        ? companyAreaRates.data?.find(item => item.areaId === value)
        : undefined;
      const governorateRate = current.deliveryGovernorateId
        ? companyGovernorateRates.data?.find(
            item => item.governorateId === Number(current.deliveryGovernorateId)
          )
        : undefined;
      return {
        ...current,
        deliveryAreaId: value ? String(value) : "",
        deliveryFee: String(
          areaRate?.amount ??
            governorateRate?.amount ??
            selectedCompany?.defaultDeliveryFee ??
            "0.000"
        ),
      };
    });
  const submit = () =>
    create.mutate({
      source: form.companyId ? "supervisor" : "external",
      companyId: form.companyId ? Number(form.companyId) : undefined,
      driverId: Number(form.driverId),
      pickupContactName: form.pickupContactName,
      pickupPhone: form.pickupPhone,
      pickupAddress: form.pickupAddress,
      pickupLocationUrl: form.pickupLocationUrl || undefined,
      pickupGovernorateId: form.pickupGovernorateId
        ? Number(form.pickupGovernorateId)
        : undefined,
      pickupAreaId: form.pickupAreaId ? Number(form.pickupAreaId) : undefined,
      customerName: form.customerName.trim() || undefined,
      customerPhone: form.customerPhone,
      cashToCollectAmount: form.cashToCollectAmount || "0.000",
      cashCollectionNote: form.cashCollectionNote.trim() || undefined,
      deliveryGovernorateId: form.deliveryGovernorateId
        ? Number(form.deliveryGovernorateId)
        : undefined,
      deliveryAreaId: form.deliveryAreaId
        ? Number(form.deliveryAreaId)
        : undefined,
      ...(canManageFees
        ? {
            deliveryFee: form.deliveryFee || "0.000",
            driverCommission: form.driverCommission || undefined,
            companyShare: form.companyShare || undefined,
            deliveryFeeChargeOnFailure: form.deliveryFeeChargeOnFailure,
          }
        : {}),
      area: form.area || undefined,
      deliveryAddress: form.deliveryAddress,
      notes: form.notes || undefined,
    });
  const field = "h-12 rounded-xl";

  if (!isAuthenticated)
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#fffaf4] p-5">
        <Card className="w-full max-w-sm rounded-3xl">
          <CardContent className="p-7 text-center">
            <h1 className="text-xl font-black">{t("newOrderLoginRequired")}</h1>
            <Button
              onClick={() => window.location.assign(LOCAL_LOGIN_PATH)}
              className="mt-5 w-full rounded-xl bg-orange-500 text-white"
            >
              {t("newOrderLoginAction")}
            </Button>
          </CardContent>
        </Card>
      </div>
    );

  const content = (
    <main
      dir={language === "ar" ? "rtl" : "ltr"}
      className="min-h-screen bg-[#f8fafc] p-4 sm:p-6 lg:p-8"
    >
      <div className="mx-auto max-w-2xl">
        <button
          onClick={() => navigate("/")}
          className="mb-5 flex items-center gap-2 text-sm font-bold text-slate-500 hover:text-orange-600"
        >
          <ArrowRight className="h-4 w-4" />
          {t("newOrderBack")}
        </button>
        <div className="mb-6">
          <p className="flex items-center gap-2 text-sm font-semibold text-orange-600">
            <ClipboardList className="h-4 w-4" />
            {t("newOrderSection")}
          </p>
          <h1 className="mt-2 text-3xl font-black">{t("newOrder")}</h1>
          <p className="mt-2 text-sm text-slate-500">
            {tr("أدخل بيانات الاستلام والتسليم ثم أرسل الطلب.")}
          </p>
        </div>
        <Card className="rounded-3xl border-slate-100 shadow-sm">
          <CardHeader>
            <CardTitle className="text-xl font-black">
              {tr("بيانات الطلب")}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="grid gap-5 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="company">{tr("اختيار الشركة المرتبطة")}</Label>
                <select
                  id="company"
                  value={form.companyId}
                  onChange={event => selectCompany(event.target.value)}
                  className="h-12 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm"
                >
                  <option value="">
                    {tr("طلب خارجي — لا توجد شركة مرتبطة")}
                  </option>
                  {(companies.data?.items ?? []).map(company => (
                    <option key={company.id} value={company.id}>
                      {company.name} · {company.code}
                    </option>
                  ))}
                </select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="vehicle-type">نوع المركبة (اختياري)</Label>
                <select
                  id="vehicle-type"
                  value={form.vehicleType}
                  onChange={event => {
                    set("vehicleType", event.target.value);
                    set("driverId", "");
                  }}
                  className="h-12 w-full rounded-xl border border-slate-200 bg-white px-3 text-sm"
                >
                  <option value="">كل أنواع المركبات</option>
                  {Object.entries(vehicleTypes).map(([key, label]) => (
                    <option key={key} value={key}>
                      {label}
                    </option>
                  ))}
                </select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="driver">{tr("تحديد السائق *")}</Label>
                <select
                  id="driver"
                  required
                  value={form.driverId}
                  onChange={event => set("driverId", event.target.value)}
                  className="h-12 w-full rounded-xl border border-orange-200 bg-orange-50 px-3 text-sm font-bold text-slate-800"
                >
                  <option value="">
                    {tr("اختر السائق الذي سيستلم الطلب")}
                  </option>
                  {filteredDrivers.map(driver => (
                    <option key={driver.id} value={driver.id}>
                      {driver.name || tr("سائق")}
                      {driver.vehicleLabel
                        ? ` · ${driver.vehicleLabel}`
                        : ""} ·{" "}
                      {vehicleTypes[
                        driver.vehicleType as keyof typeof vehicleTypes
                      ] || "سيارة"}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            {form.companyId ? (
              <div className="space-y-2 rounded-2xl border border-sky-100 bg-sky-50/60 p-4">
                <Label htmlFor="company-address">
                  {tr("عنوان أو فرع الشركة")} *
                </Label>
                <select
                  id="company-address"
                  value={form.companyAddressId}
                  onChange={event => selectCompanyAddress(event.target.value)}
                  className="h-12 w-full rounded-xl border border-sky-200 bg-white px-3 text-sm"
                >
                  <option value="">{tr("اختر عنوان الشركة")}</option>
                  {selectableAddresses.map(item => (
                    <option key={item.id} value={item.id}>
                      {item.label}
                      {item.phone
                        ? ` · ${item.phone}`
                        : ` · ${tr("بدون هاتف")}`}
                    </option>
                  ))}
                </select>
                {companyAddresses.isLoading ? (
                  <p className="text-xs text-sky-700">
                    {tr("جارٍ تحميل عناوين الشركة…")}
                  </p>
                ) : !selectableAddresses.length ? (
                  <p className="text-xs font-bold text-amber-700">
                    {tr(
                      "لا توجد عناوين مضافة لهذه الشركة؛ أضفها من صفحة الشركات أو أدخل بيانات الاستلام يدوياً."
                    )}
                  </p>
                ) : null}
              </div>
            ) : null}
            <div className="grid gap-5 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="pickupName">{tr("اسم الاستلام *")}</Label>
                <Input
                  id="pickupName"
                  required
                  value={form.pickupContactName}
                  onChange={event =>
                    set("pickupContactName", event.target.value)
                  }
                  placeholder={tr("اسم جهة أو شخص الاستلام")}
                  className={field}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pickupPhone">{tr("هاتف الاستلام *")}</Label>
                <Input
                  id="pickupPhone"
                  required
                  type="tel"
                  inputMode="tel"
                  dir="ltr"
                  value={form.pickupPhone}
                  onChange={event => set("pickupPhone", event.target.value)}
                  className={field}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="pickupAddress">{t("pickupAddress")} *</Label>
              <div className="relative">
                <MapPin className="absolute right-3 top-3 h-4 w-4 text-slate-400" />
                <Textarea
                  id="pickupAddress"
                  required
                  value={form.pickupAddress}
                  onChange={event => set("pickupAddress", event.target.value)}
                  className="min-h-24 rounded-xl pr-10"
                />
              </div>
            </div>
            <LocationPicker
              kind="pickup"
              governorateId={
                form.pickupGovernorateId
                  ? Number(form.pickupGovernorateId)
                  : undefined
              }
              areaId={form.pickupAreaId ? Number(form.pickupAreaId) : undefined}
              onGovernorateChange={id =>
                setForm(current => ({
                  ...current,
                  pickupGovernorateId: id ? String(id) : "",
                  pickupAreaId: "",
                }))
              }
              onAreaChange={id => set("pickupAreaId", id ? String(id) : "")}
            />
            <section className="rounded-2xl border border-sky-100 bg-sky-50/60 p-4">
              <p className="mb-4 font-black text-sky-900">
                {tr("بيانات المستلم")}
              </p>
              <div className="grid gap-5 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="recipientName">
                    {tr("اسم المستلم (اختياري)")}
                  </Label>
                  <Input
                    id="recipientName"
                    value={form.customerName}
                    onChange={event => set("customerName", event.target.value)}
                    placeholder={tr("اسم العميل")}
                    className={field}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="recipientPhone">{tr("هاتف المستلم *")}</Label>
                  <Input
                    id="recipientPhone"
                    required
                    type="tel"
                    inputMode="tel"
                    dir="ltr"
                    value={form.customerPhone}
                    onChange={event => set("customerPhone", event.target.value)}
                    placeholder="50000000"
                    className={field}
                  />
                </div>
              </div>
            </section>
            <LocationPicker
              kind="delivery"
              governorateId={
                form.deliveryGovernorateId
                  ? Number(form.deliveryGovernorateId)
                  : undefined
              }
              areaId={
                form.deliveryAreaId ? Number(form.deliveryAreaId) : undefined
              }
              onGovernorateChange={id =>
                setDeliveryLocation("deliveryGovernorateId", id)
              }
              onAreaChange={id => setDeliveryLocation("deliveryAreaId", id)}
            />
            <div className="space-y-2">
              <Label htmlFor="deliveryAddress">{t("deliveryAddress")} *</Label>
              <div className="relative">
                <MapPin className="absolute right-3 top-3 h-4 w-4 text-slate-400" />
                <Textarea
                  id="deliveryAddress"
                  required
                  value={form.deliveryAddress}
                  onChange={event => set("deliveryAddress", event.target.value)}
                  className="min-h-24 rounded-xl pr-10"
                />
              </div>
            </div>
            <section className="grid gap-4 rounded-2xl border border-emerald-100 bg-emerald-50/70 p-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="cash-to-collect">
                  {tr("المبلغ المطلوب استلامه من العميل (د.ك)")}
                </Label>
                <Input
                  id="cash-to-collect"
                  type="number"
                  min="0"
                  step="0.001"
                  value={form.cashToCollectAmount}
                  onChange={event =>
                    set("cashToCollectAmount", event.target.value)
                  }
                  className="bg-white"
                  dir="ltr"
                  inputMode="decimal"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cash-collection-note">
                  {tr("ملاحظة مبلغ الاستلام (اختياري)")}
                </Label>
                <Input
                  id="cash-collection-note"
                  value={form.cashCollectionNote}
                  onChange={event =>
                    set("cashCollectionNote", event.target.value)
                  }
                  className="bg-white"
                  placeholder={tr("مثال: استلام قيمة البضاعة نقداً")}
                />
              </div>
            </section>
            {canManageFees ? (
              <section className="grid gap-4 rounded-2xl border border-amber-100 bg-amber-50/60 p-4 sm:grid-cols-3">
                <label className="text-sm font-bold">
                  {tr("سعر التوصيل")}
                  <Input
                    type="number"
                    min="0"
                    step="0.001"
                    value={form.deliveryFee}
                    onChange={event => set("deliveryFee", event.target.value)}
                    className="mt-2 bg-white"
                  />
                </label>
                <label className="text-sm font-bold">
                  {tr("عمولة السائق")}
                  <Input
                    type="number"
                    min="0"
                    step="0.001"
                    value={form.driverCommission}
                    onChange={event =>
                      set("driverCommission", event.target.value)
                    }
                    placeholder={tr("تلقائي حسب السائق")}
                    className="mt-2 bg-white"
                  />
                </label>
                <label className="text-sm font-bold">
                  {tr("حصة الشركة")}
                  <Input
                    type="number"
                    min="0"
                    step="0.001"
                    value={form.companyShare}
                    onChange={event => set("companyShare", event.target.value)}
                    placeholder={tr("الباقي بعد العمولة")}
                    className="mt-2 bg-white"
                  />
                </label>
                <label className="flex items-center gap-2 text-sm font-semibold sm:col-span-3">
                  <input
                    type="checkbox"
                    checked={form.deliveryFeeChargeOnFailure}
                    onChange={event =>
                      setForm(current => ({
                        ...current,
                        deliveryFeeChargeOnFailure: event.target.checked,
                      }))
                    }
                  />
                  {tr("احتساب سعر التوصيل إذا أُلغي أو تعذر الطلب")}
                </label>
              </section>
            ) : null}
            <div className="space-y-2">
              <Label htmlFor="notes">{tr("ملاحظات تشغيلية")}</Label>
              <Textarea
                id="notes"
                value={form.notes}
                onChange={event => set("notes", event.target.value)}
                className="min-h-24 rounded-xl"
              />
            </div>
            {create.error ? (
              <p className="rounded-2xl bg-rose-50 p-3 text-sm font-bold text-rose-700">
                {friendlyError(create.error)}
              </p>
            ) : null}
            <Button
              type="button"
              disabled={!canSend || create.isPending}
              onClick={submit}
              className="w-full rounded-2xl bg-orange-500 py-6 text-base font-black text-white hover:bg-orange-600"
            >
              {create.isPending ? t("saving") : tr("إرسال الطلب")}
            </Button>
          </CardContent>
        </Card>
        {success ? (
          <div
            role="dialog"
            className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4"
          >
            <div className="w-full max-w-sm rounded-3xl bg-white p-7 text-center shadow-2xl">
              <PackageCheck className="mx-auto h-12 w-12 text-emerald-600" />
              <h2 className="mt-4 text-2xl font-black">
                {tr("تم إرسال الطلب")}
              </h2>
              <p className="mt-2 text-slate-600">
                {tr("رقم الطلب")}: {success}
              </p>
              <Button
                autoFocus
                onClick={() => setSuccess(null)}
                className="mt-6 w-full rounded-xl bg-orange-500 text-white"
              >
                {t("done")}
              </Button>
            </div>
          </div>
        ) : null}
      </div>
    </main>
  );
  return embedded ? content : <DashboardLayout>{content}</DashboardLayout>;
}
