import { useState } from "react";
import { Link, useLocation } from "wouter";
import { ArrowRight, Building2, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/i18n";
import { friendlyError } from "@/lib/errorMessage";

export default function BusinessRegistration() {
  const { language } = useLanguage();
  const [, navigate] = useLocation();
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    role: "company" as "company" | "trader",
    companyName: "",
    username: "",
    password: "",
    confirmPassword: "",
    phone: "",
    address: "",
  });
  const register = trpc.auth.registerDriver.useMutation({
    onSuccess: () => setSubmitted(true),
  });
  const update =
    (key: keyof typeof form) =>
    (event: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
      setForm(current => ({ ...current, [key]: event.target.value }));

  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    if (form.password !== form.confirmPassword) return;
    register.mutate({
      requestedRole: form.role,
      businessName: form.companyName,
      loginName: form.username,
      name: form.companyName,
      phone: form.phone,
      businessPhone: form.phone,
      businessAddress: form.address,
      password: form.password,
      preferredLanguage: language,
    });
  };

  return (
    <main
      dir={language === "ar" ? "rtl" : "ltr"}
      className="min-h-screen bg-[#fffaf4] px-4 py-8 text-slate-900 sm:px-6"
    >
      <div className="mx-auto max-w-2xl">
        <Link
          href="/"
          className="mb-6 inline-flex items-center gap-2 text-sm font-bold text-slate-600 hover:text-orange-600"
        >
          <ArrowRight className="h-4 w-4" /> العودة للرئيسية
        </Link>
        <Card className="rounded-[2rem] border-orange-100 shadow-xl shadow-orange-100/40">
          <CardHeader className="p-6 sm:p-8">
            <div className="flex items-start gap-3">
              <div className="rounded-2xl bg-orange-100 p-3 text-orange-600">
                <Building2 className="h-6 w-6" />
              </div>
              <div>
                <CardTitle className="text-2xl font-black">
                  تسجيل شركة أو تاجر
                </CardTitle>
                <p className="mt-2 text-sm leading-7 text-slate-500">
                  تنشأ الشركة تلقائياً ويُرسل الطلب للإدارة للمراجعة. لن تتمكن من الدخول قبل الموافقة.
                </p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-6 sm:p-8">
            {submitted ? (
              <div className="rounded-3xl bg-emerald-50 p-8 text-center text-emerald-900">
                <CheckCircle2 className="mx-auto h-12 w-12 text-emerald-600" />
                <h2 className="mt-4 text-xl font-black">تم إرسال طلب التسجيل</h2>
                <p className="mx-auto mt-3 max-w-md text-sm leading-7">
                  ستراجع الإدارة بيانات الشركة أو التاجر، وبعد الموافقة يمكنك تسجيل الدخول باسم المستخدم أو البريد الإلكتروني وكلمة المرور.
                </p>
                <Button
                  className="mt-6 rounded-xl bg-slate-900 text-white"
                  onClick={() => navigate("/")}
                >
                  العودة للرئيسية
                </Button>
              </div>
            ) : (
              <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2">
                <label className="space-y-2 sm:col-span-2">
                  <Label>نوع الحساب</Label>
                  <select
                    value={form.role}
                    onChange={update("role")}
                    className="h-12 w-full rounded-xl border border-slate-200 bg-white px-3"
                  >
                    <option value="company">شركة</option>
                    <option value="trader">تاجر</option>
                  </select>
                </label>
                <label className="space-y-2 sm:col-span-2">
                  <Label>اسم الشركة أو المتجر *</Label>
                  <Input
                    required
                    minLength={2}
                    value={form.companyName}
                    onChange={update("companyName")}
                    autoComplete="organization"
                    className="h-12 rounded-xl"
                  />
                </label>
                <label className="space-y-2">
                  <Label>البريد الإلكتروني أو اسم المستخدم *</Label>
                  <Input
                    required
                    minLength={3}
                    value={form.username}
                    onChange={update("username")}
                    placeholder="store@example.com أو city-store"
                    autoComplete="username"
                    spellCheck={false}
                    dir="ltr"
                    className="h-12 rounded-xl"
                  />
                  <span className="block text-xs leading-5 text-slate-500">
                    استخدم بريداً إلكترونياً صحيحاً أو اسم مستخدم إنجليزياً من 3 أحرف على الأقل.
                  </span>
                </label>
                <label className="space-y-2">
                  <Label>الهاتف *</Label>
                  <Input
                    required
                    minLength={8}
                    value={form.phone}
                    onChange={update("phone")}
                    autoComplete="tel"
                    dir="ltr"
                    className="h-12 rounded-xl"
                  />
                </label>
                <label className="space-y-2">
                  <Label>كلمة المرور *</Label>
                  <Input
                    required
                    minLength={8}
                    type="password"
                    value={form.password}
                    onChange={update("password")}
                    autoComplete="new-password"
                    dir="ltr"
                    className="h-12 rounded-xl"
                  />
                </label>
                <label className="space-y-2">
                  <Label>تأكيد كلمة المرور *</Label>
                  <Input
                    required
                    minLength={8}
                    type="password"
                    value={form.confirmPassword}
                    onChange={update("confirmPassword")}
                    autoComplete="new-password"
                    dir="ltr"
                    className="h-12 rounded-xl"
                  />
                </label>
                <label className="space-y-2 sm:col-span-2">
                  <Label>العنوان (اختياري)</Label>
                  <Input
                    value={form.address}
                    onChange={update("address")}
                    autoComplete="street-address"
                    className="h-12 rounded-xl"
                  />
                </label>
                {form.confirmPassword && form.password !== form.confirmPassword ? (
                  <p className="text-sm font-semibold text-red-600 sm:col-span-2">
                    كلمتا المرور غير متطابقتين.
                  </p>
                ) : null}
                {register.error ? (
                  <p className="rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700 sm:col-span-2">
                    {friendlyError(register.error)}
                  </p>
                ) : null}
                <Button
                  type="submit"
                  disabled={register.isPending || form.password !== form.confirmPassword}
                  className="h-12 rounded-xl bg-orange-500 font-bold text-white hover:bg-orange-600 sm:col-span-2"
                >
                  {register.isPending ? "جارٍ إرسال الطلب..." : "إرسال طلب التسجيل"}
                </Button>
              </form>
            )}
          </CardContent>
        </Card>
      </div>
    </main>
  );
}
