import { useState } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { useAuth } from "@/_core/hooks/useAuth";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import LocationPicker from "@/components/LocationPicker";
import CompanyAreaRatePanel from "@/pages/CompanyAreaRatePanel";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/i18n";
import { useUiText } from "@/lib/uiText";
import {
  Building2,
  CheckCircle2,
  Pencil,
  Phone,
  Plus,
  Power,
  Search,
  Star,
} from "lucide-react";
import { friendlyError } from "@/lib/errorMessage";

type CompanyItem = {
  id: number;
  name: string;
  code: string;
  phone: string | null;
  address: string | null;
  defaultDeliveryFee?: string | null;
  status: "active" | "inactive";
};

function CompanyAddressPanel({ company }: { company: CompanyItem }) {
  const tr = useUiText();
  const utils = trpc.useUtils();
  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [label, setLabel] = useState("");
  const [pickupContactName, setPickupContactName] = useState("");
  const [address, setAddress] = useState("");
  const [phone, setPhone] = useState("");
  const [locationUrl, setLocationUrl] = useState("");
  const [governorateId, setGovernorateId] = useState<number | undefined>();
  const [areaId, setAreaId] = useState<number | undefined>();
  const addresses = trpc.companies.addresses.useQuery({
    companyId: company.id,
  });
  const refresh = () =>
    void utils.companies.addresses.invalidate({ companyId: company.id });
  const resetForm = () => {
    setLabel("");
    setPickupContactName("");
    setAddress("");
    setPhone("");
    setLocationUrl("");
    setGovernorateId(undefined);
    setAreaId(undefined);
  };
  const create = trpc.companies.createAddress.useMutation({
    onSuccess: () => {
      resetForm();
      setFormOpen(false);
      refresh();
    },
  });
  const update = trpc.companies.updateAddress.useMutation({
    onSuccess: () => {
      setEditingId(null);
      resetForm();
      refresh();
    },
  });
  const startEdit = (item: NonNullable<typeof addresses.data>[number]) => {
    setEditingId(item.id);
    setLabel(item.label);
    setPickupContactName(item.pickupContactName ?? "");
    setAddress(item.address);
    setPhone(item.phone ?? "");
    setLocationUrl(item.locationUrl ?? "");
    setGovernorateId(item.governorateId ?? undefined);
    setAreaId(item.areaId ?? undefined);
    setFormOpen(true);
  };
  const save = () => {
    if (!label.trim() || address.trim().length < 5) return;
    const fields = {
      label: label.trim(),
      address: address.trim(),
      phone: phone.trim() || undefined,
      locationUrl: locationUrl.trim() || undefined,
      governorateId: governorateId ?? null,
      areaId: areaId ?? null,
    };
    if (editingId)
      update.mutate({
        addressId: editingId,
        ...fields,
        pickupContactName: pickupContactName.trim() || null,
      });
    else
      create.mutate({
        companyId: company.id,
        ...fields,
        pickupContactName: pickupContactName.trim() || undefined,
        governorateId: governorateId ?? undefined,
        areaId: areaId ?? undefined,
        isDefault: (addresses.data?.length ?? 0) === 0,
      });
  };
  const busy = create.isPending || update.isPending;

  return (
    <section className="mt-4 rounded-2xl border border-sky-100 bg-sky-50/60 p-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="font-black text-sky-950">{tr("عناوين وفروع الشركة")}</p>
          <p className="mt-1 text-xs text-sky-800">
            {tr(
              "أدخل اسم مسؤول الاستلام، والمحافظة والمنطقة والعنوان الكامل ورقم الهاتف لكل فرع."
            )}
          </p>
        </div>
        <Button
          type="button"
          size="sm"
          onClick={() => {
            setEditingId(null);
            resetForm();
            setFormOpen(value => !value);
          }}
          className="rounded-xl bg-sky-700 text-white hover:bg-sky-800"
        >
          <Plus className="ml-1 h-4 w-4" />
          {tr("إضافة عنوان")}
        </Button>
      </div>
      {company.address && !addresses.data?.length ? (
        <div className="mt-3 flex flex-wrap items-center gap-x-3 gap-y-1 rounded-xl border border-white bg-white/80 p-3 text-xs text-slate-700">
          <Star className="h-4 w-4 text-amber-500" />
          <span className="font-bold">{tr("العنوان الرئيسي الحالي")}:</span>
          <span>{company.address}</span>
          {company.phone ? (
            <a
              href={`tel:${company.phone}`}
              dir="ltr"
              className="inline-flex items-center gap-1 font-bold text-sky-700"
            >
              <Phone className="h-3 w-3" />
              {company.phone}
            </a>
          ) : null}
        </div>
      ) : null}
      {formOpen ? (
        <div className="mt-4 grid gap-3 rounded-2xl border border-sky-200 bg-white p-4 sm:grid-cols-2">
          <div className="space-y-1">
            <Label>{tr("اسم الفرع أو العنوان")} *</Label>
            <Input
              value={label}
              onChange={event => setLabel(event.target.value)}
              placeholder={tr("مثال: فرع السالمية")}
              className="h-10 rounded-xl"
            />
          </div>
          <div className="space-y-1">
            <Label>{tr("اسم مستلم الطلب من الفرع (اختياري)")}</Label>
            <Input
              value={pickupContactName}
              onChange={event => setPickupContactName(event.target.value)}
              placeholder={tr("اسم الشخص المسؤول عن تسليم الطلب للسائق")}
              className="h-10 rounded-xl"
            />
          </div>
          <div className="space-y-1">
            <Label>{tr("هاتف هذا الفرع")}</Label>
            <Input
              value={phone}
              onChange={event => setPhone(event.target.value)}
              type="tel"
              inputMode="tel"
              dir="ltr"
              placeholder="50000000"
              className="h-10 rounded-xl"
            />
          </div>
          <div className="space-y-1 sm:col-span-2">
            <Label>{tr("رابط اللوكيشن (اختياري)")}</Label>
            <Input
              value={locationUrl}
              onChange={event => setLocationUrl(event.target.value)}
              placeholder="https://maps.google.com/..."
              dir="ltr"
              className="h-10 rounded-xl"
            />
          </div>
          <div className="space-y-1 sm:col-span-2">
            <Label>{tr("العنوان الكامل للفرع")} *</Label>
            <Textarea
              value={address}
              onChange={event => setAddress(event.target.value)}
              placeholder={tr("اكتب العنوان الكامل لموقع الاستلام")}
              className="min-h-20 rounded-xl"
            />
          </div>
          <div className="sm:col-span-2">
            <LocationPicker
              kind="branch"
              governorateId={governorateId}
              areaId={areaId}
              onGovernorateChange={id => {
                setGovernorateId(id);
                setAreaId(undefined);
              }}
              onAreaChange={setAreaId}
              compact
            />
          </div>
          <div className="flex gap-2 sm:col-span-2">
            <Button
              type="button"
              disabled={
                busy || label.trim().length < 2 || address.trim().length < 5
              }
              onClick={save}
              className="rounded-xl bg-sky-700 text-white"
            >
              {busy
                ? tr("جارٍ الحفظ")
                : editingId
                  ? tr("حفظ التعديل")
                  : tr("حفظ العنوان")}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => setFormOpen(false)}
              className="rounded-xl"
            >
              {tr("إلغاء")}
            </Button>
          </div>
        </div>
      ) : null}
      <div className="mt-3 space-y-2">
        {addresses.isLoading ? (
          <p className="text-xs text-slate-500">{tr("جارٍ تحميل العناوين…")}</p>
        ) : addresses.data?.length ? (
          addresses.data.map(item => (
            <div
              key={item.id}
              className={`flex flex-col gap-2 rounded-xl border p-3 sm:flex-row sm:items-center ${item.active ? "border-sky-100 bg-white" : "border-slate-200 bg-slate-100 opacity-70"}`}
            >
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <p className="font-bold text-slate-900">{item.label}</p>
                  {item.isDefault ? (
                    <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100">
                      {tr("الافتراضي")}
                    </Badge>
                  ) : null}
                  {!item.active ? (
                    <Badge className="bg-slate-200 text-slate-700 hover:bg-slate-200">
                      {tr("موقوف")}
                    </Badge>
                  ) : null}
                </div>
                {item.pickupContactName ? (
                  <p className="mt-1 text-xs text-slate-700">
                    {tr("مستلم الطلب من الفرع")}: {item.pickupContactName}
                  </p>
                ) : null}
                <p className="mt-1 text-xs text-slate-600">{item.address}</p>
                {item.locationUrl ? (
                  <a
                    href={item.locationUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="mt-1 inline-flex text-xs font-bold text-emerald-700 underline"
                  >
                    {tr("فتح اللوكيشن")}
                  </a>
                ) : null}
                {item.phone ? (
                  <a
                    href={`tel:${item.phone}`}
                    dir="ltr"
                    className="mt-1 inline-flex items-center gap-1 text-xs font-bold text-sky-700"
                  >
                    <Phone className="h-3 w-3" />
                    {item.phone}
                  </a>
                ) : (
                  <p className="mt-1 text-xs text-slate-400">
                    {tr("لا يوجد هاتف لهذا العنوان")}
                  </p>
                )}
              </div>
              <div className="flex flex-wrap gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => startEdit(item)}
                  className="rounded-lg"
                >
                  <Pencil className="ml-1 h-3.5 w-3.5" />
                  {tr("تعديل")}
                </Button>
                {!item.isDefault ? (
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      update.mutate({ addressId: item.id, isDefault: true })
                    }
                    className="rounded-lg"
                  >
                    {tr("اجعله الافتراضي")}
                  </Button>
                ) : null}
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() =>
                    update.mutate({ addressId: item.id, active: !item.active })
                  }
                  className="rounded-lg"
                >
                  {item.active ? tr("إيقاف") : tr("تفعيل")}
                </Button>
              </div>
            </div>
          ))
        ) : (
          <p className="rounded-xl border border-dashed border-sky-200 bg-white/70 p-3 text-xs text-sky-800">
            {tr(
              "أضف عنواناً أو فرعاً جديداً للشركة؛ سيظهر هنا وفي إنشاء الطلب."
            )}
          </p>
        )}
      </div>
      {create.error || update.error ? (
        <p role="alert" className="mt-3 text-xs font-bold text-rose-700">
          {create.error?.message ?? update.error?.message}
        </p>
      ) : null}
    </section>
  );
}

function CompanyCard({
  company,
  canViewPricing,
}: {
  company: CompanyItem;
  canViewPricing: boolean;
}) {
  const tr = useUiText();
  const utils = trpc.useUtils();
  const [editingFee, setEditingFee] = useState(false);
  const [fee, setFee] = useState(company.defaultDeliveryFee ?? "0.000");
  const update = trpc.companies.update.useMutation({
    onSuccess: () => void utils.companies.list.invalidate(),
  });
  return (
    <div className="rounded-3xl border border-slate-100 bg-white p-4 shadow-sm">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start">
        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-orange-50 text-orange-600">
          <Building2 className="h-5 w-5" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="font-black text-slate-950">{company.name}</p>
          <p className="mt-1 text-xs text-slate-500">{company.code}</p>
          {canViewPricing ? (
            <div className="mt-2 text-xs text-slate-600">
              {editingFee ? (
                <span className="inline-flex items-center gap-2">
                  <Input
                    value={fee}
                    onChange={event => setFee(event.target.value)}
                    className="h-8 w-24 rounded-lg"
                    dir="ltr"
                    inputMode="decimal"
                  />
                  <Button
                    size="sm"
                    onClick={() => {
                      update.mutate({
                        companyId: company.id,
                        defaultDeliveryFee: fee,
                      });
                      setEditingFee(false);
                    }}
                    className="h-8 rounded-lg bg-slate-900 text-white"
                  >
                    {tr("حفظ")}
                  </Button>
                </span>
              ) : (
                <button
                  type="button"
                  onClick={() => setEditingFee(true)}
                  className="font-bold text-orange-600 underline"
                >
                  {tr("رسوم التوصيل")}: {company.defaultDeliveryFee}
                </button>
              )}
            </div>
          ) : null}
        </div>
        <div className="flex flex-wrap items-center gap-2 sm:mr-auto">
          <Badge
            className={
              company.status === "active"
                ? "bg-emerald-50 text-emerald-700 hover:bg-emerald-50"
                : "bg-slate-100 text-slate-600 hover:bg-slate-100"
            }
          >
            {company.status === "active" ? tr("نشطة") : tr("موقوفة")}
          </Badge>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() =>
              update.mutate({
                companyId: company.id,
                status: company.status === "active" ? "inactive" : "active",
              })
            }
            className="rounded-xl"
          >
            <Power className="ml-1 h-4 w-4" />
            {company.status === "active" ? tr("إيقاف") : tr("تفعيل")}
          </Button>
        </div>
      </div>
      <CompanyAddressPanel company={company} />
      {canViewPricing ? <CompanyAreaRatePanel company={company} /> : null}
      {update.error ? (
        <p role="alert" className="mt-3 text-xs text-rose-700">
          {friendlyError(update.error)}
        </p>
      ) : null}
    </div>
  );
}

export default function Companies() {
  const { t, language } = useLanguage();
  const tr = useUiText();
  const { user } = useAuth();
  const canViewPricing = Boolean(
    user?.role === "admin" ||
      user?.role === "accountant" ||
      user?.role === "supervisor" ||
      user?.roles?.some(role =>
        ["admin", "accountant", "supervisor"].includes(role)
      )
  );
  const [query, setQuery] = useState("");
  const [formOpen, setFormOpen] = useState(false);
  const [name, setName] = useState("");
  const [address, setAddress] = useState("");
  const [pickupContactName, setPickupContactName] = useState("");
  const [phone, setPhone] = useState("");
  const [locationUrl, setLocationUrl] = useState("");
  const [governorateId, setGovernorateId] = useState<number | undefined>();
  const [areaId, setAreaId] = useState<number | undefined>();
  const [fee, setFee] = useState("");
  const utils = trpc.useUtils();
  const companies = trpc.companies.list.useQuery({ page: 1, pageSize: 100 });
  const create = trpc.companies.create.useMutation({
    onSuccess: () => {
      setName("");
      setAddress("");
      setPickupContactName("");
      setPhone("");
      setLocationUrl("");
      setGovernorateId(undefined);
      setAreaId(undefined);
      setFee("");
      setFormOpen(false);
      void utils.companies.list.invalidate();
    },
  });
  const submitCompany = () =>
    create.mutate({
      name: name.trim(),
      address: address.trim() || undefined,
      locationUrl: locationUrl.trim() || undefined,
      pickupContactName: pickupContactName.trim() || undefined,
      phone: phone.trim() || undefined,
      governorateId,
      areaId,
      defaultDeliveryFee: fee || undefined,
    });
  const items = (companies.data?.items ?? []).filter(company =>
    `${company.name} ${company.code}`
      .toLowerCase()
      .includes(query.toLowerCase())
  );
  return (
    <DashboardLayout>
      <main
        dir={language === "ar" ? "rtl" : "ltr"}
        className="min-h-screen bg-[#f8fafc] p-4 sm:p-6 lg:p-8"
      >
        <div className="mx-auto max-w-6xl">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <div className="flex items-center gap-2 text-sm font-semibold text-orange-600">
                <Building2 className="h-4 w-4" />
                {t("administration")}
              </div>
              <h1 className="mt-2 text-3xl font-black tracking-tight">
                {t("companies")}
              </h1>
              <p className="mt-2 text-sm text-slate-500">
                {tr(
                  "أضف بيانات الشركة وعنوان الاستلام الافتراضي، ثم أضف فروعاً أخرى عند الحاجة."
                )}
              </p>
            </div>
            <Button
              type="button"
              onClick={() => setFormOpen(value => !value)}
              className="rounded-xl bg-orange-500 text-white hover:bg-orange-600"
            >
              <Plus className="ml-2 h-4 w-4" />
              {t("addCompany")}
            </Button>
          </div>
          {formOpen ? (
            <Card className="mt-6 rounded-3xl border-orange-100 shadow-sm">
              <CardHeader>
                <CardTitle className="text-xl font-black">
                  {t("newCompany")}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  <div className="space-y-2">
                    <Label>{t("companyName")}</Label>
                    <Input
                      value={name}
                      onChange={event => setName(event.target.value)}
                      className="h-11 rounded-xl"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>{tr("اسم مستلم الطلب في الفرع (اختياري)")}</Label>
                    <Input
                      value={pickupContactName}
                      onChange={event =>
                        setPickupContactName(event.target.value)
                      }
                      className="h-11 rounded-xl"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>{tr("العنوان الكامل للفرع الرئيسي")}</Label>
                    <Input
                      value={address}
                      onChange={event => setAddress(event.target.value)}
                      className="h-11 rounded-xl"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>{tr("رابط اللوكيشن (اختياري)")}</Label>
                    <Input
                      value={locationUrl}
                      onChange={event => setLocationUrl(event.target.value)}
                      placeholder="https://maps.google.com/..."
                      dir="ltr"
                      className="h-11 rounded-xl"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>{tr("هاتف الفرع الرئيسي")}</Label>
                    <Input
                      value={phone}
                      onChange={event => setPhone(event.target.value)}
                      className="h-11 rounded-xl"
                      dir="ltr"
                      inputMode="tel"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>{t("deliveryFee")}</Label>
                    <Input
                      value={fee}
                      onChange={event => setFee(event.target.value)}
                      className="h-11 rounded-xl"
                      dir="ltr"
                      inputMode="decimal"
                    />
                  </div>
                  <div className="sm:col-span-2 lg:col-span-3">
                    <LocationPicker
                      kind="branch"
                      governorateId={governorateId}
                      areaId={areaId}
                      onGovernorateChange={id => {
                        setGovernorateId(id);
                        setAreaId(undefined);
                      }}
                      onAreaChange={setAreaId}
                      compact
                    />
                  </div>
                </div>
                <div className="mt-5 flex justify-end">
                  <Button
                    type="button"
                    disabled={create.isPending || name.trim().length < 2}
                    onClick={submitCompany}
                    className="rounded-xl bg-slate-900 text-white"
                  >
                    {create.isPending ? t("savingCompany") : t("saveCompany")}
                  </Button>
                </div>
                {create.error ? (
                  <div
                    role="alert"
                    className="mt-3 flex flex-wrap items-center justify-between gap-3 rounded-xl bg-rose-50 p-3 text-sm font-bold text-rose-700"
                  >
                    <span>{friendlyError(create.error)}</span>
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      onClick={submitCompany}
                      disabled={create.isPending}
                      className="rounded-lg"
                    >
                      {t("retry")}
                    </Button>
                  </div>
                ) : null}
              </CardContent>
            </Card>
          ) : null}
          <Card className="mt-6 rounded-3xl border-slate-100 shadow-sm">
            <CardHeader>
              <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <CardTitle className="text-xl font-black">
                    {t("companyList")}
                  </CardTitle>
                  <p className="mt-1 text-sm text-slate-500">
                    {companies.data?.total ?? 0} {t("registeredCompanies")}
                  </p>
                </div>
                <div className="flex w-full gap-2 sm:max-w-xs">
                  <div className="relative min-w-0 flex-1">
                    <Search className="absolute right-3 top-3 h-4 w-4 text-slate-400" />
                    <Input
                      value={query}
                      onChange={event => setQuery(event.target.value)}
                      placeholder={t("searchCompany")}
                      className="h-11 rounded-xl pr-9"
                    />
                  </div>
                  {companies.error ? (
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => void companies.refetch()}
                      disabled={companies.isFetching}
                      className="rounded-xl"
                    >
                      {t("retry")}
                    </Button>
                  ) : null}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {companies.isLoading ? (
                <p className="rounded-2xl bg-slate-50 p-6 text-center text-sm text-slate-500">
                  {t("loadingCompanies")}
                </p>
              ) : companies.error ? (
                <p
                  role="alert"
                  className="rounded-2xl bg-rose-50 p-5 text-center text-sm text-rose-700"
                >
                  {friendlyError(companies.error)}
                </p>
              ) : (
                <div className="space-y-4">
                  {items.map(company => (
                    <CompanyCard
                      key={company.id}
                      company={company}
                      canViewPricing={canViewPricing}
                    />
                  ))}
                  {items.length === 0 ? (
                    <p className="rounded-2xl border border-dashed p-10 text-center text-sm text-slate-500">
                      {t("noCompanies")}
                    </p>
                  ) : null}
                </div>
              )}
            </CardContent>
          </Card>
          <div className="mt-5 flex items-center gap-3 rounded-2xl border border-blue-100 bg-blue-50 p-4 text-sm text-blue-800">
            <CheckCircle2 className="h-5 w-5 shrink-0" />
            <span>
              {tr(
                "عند اختيار الشركة والفرع في إنشاء الطلب، تُنسخ بيانات الفرع تلقائياً ويمكن مراجعتها قبل الإرسال."
              )}
            </span>
          </div>
        </div>
      </main>
    </DashboardLayout>
  );
}
