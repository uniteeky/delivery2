export const LOCAL_LOGIN_PATH = "/local-login";

export type SessionRoutingUser = {
  loginMethod?: string | null;
  mustChangePassword?: boolean | null;
};

export function requiresExternalAccountSetup(user: SessionRoutingUser | null | undefined) {
  return Boolean(user?.mustChangePassword && user.loginMethod !== "local-civil-id");
}

export function shouldStayOnLocalAccessPage(pathname: string) {
  return pathname === LOCAL_LOGIN_PATH || pathname === "/register-driver";
}
