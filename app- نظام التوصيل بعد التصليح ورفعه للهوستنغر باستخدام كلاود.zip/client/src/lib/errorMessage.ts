export const NETWORK_ERROR_MESSAGE = "الاتصال بالإنترنت غير متاح، تحقق من الشبكة وحاول مرة أخرى.";

const NETWORK_ERROR_PATTERN = /failed to fetch|networkerror|network request failed|load failed|unexpected token\s+['\"]?<|doctype|fetch failed/i;

export function friendlyError(error: unknown, fallback = "حدث خطأ غير متوقع. حاول مرة أخرى.") {
  const raw = error instanceof Error ? error.message : typeof error === "string" ? error : "";
  const offline = typeof navigator !== "undefined" && navigator.onLine === false;
  if (offline || NETWORK_ERROR_PATTERN.test(raw)) {
    return NETWORK_ERROR_MESSAGE;
  }
  if (/رمز الشركة مستخدم|رمز الشركة.*مستخدم|duplicate.*code/i.test(raw)) {
    return "رمز الشركة مستخدم مسبقاً. اختر رمزاً مختلفاً ثم حاول مرة أخرى.";
  }
  if (/unknown column.*accountStatus|accountStatus.*unknown|column.*does not exist/i.test(raw)) {
    return "قاعدة البيانات في الاستضافة تحتاج تحديثاً. ارفع آخر نسخة ثم أعد تشغيل التطبيق.";
  }
  if (/failed query|\bsql\b|duplicate entry|\bER_[A-Z_]+/i.test(raw)) {
    return "تعذر حفظ البيانات. تحقق من المدخلات أو استخدم رمزاً غير مستخدم ثم حاول مرة أخرى.";
  }
  return raw || fallback;
}
