const DRIVER_ALERT_AUDIO_URL = "/manus-storage/city-center-driver-order-alert_201c275b.m4a";
export const DRIVER_AUDIO_READY_EVENT = "city-center-driver-audio-ready";
let sharedContext: AudioContext | null = null;
let activeTimer: number | null = null;
let activeAudio: HTMLAudioElement | null = null;

function getAudioContext() {
  if (typeof window === "undefined") return null;
  const AudioContextClass = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AudioContextClass) return null;
  sharedContext ??= new AudioContextClass();
  return sharedContext;
}

export async function unlockDriverAudio(): Promise<boolean> {
  const context = getAudioContext();
  if (!context) return false;
  try {
    if (context.state === "suspended") await context.resume();
    const oscillator = context.createOscillator();
    const gain = context.createGain();
    gain.gain.value = 0.0001;
    oscillator.connect(gain);
    gain.connect(context.destination);
    oscillator.start();
    oscillator.stop(context.currentTime + 0.04);
    try {
      activeAudio ??= new Audio(DRIVER_ALERT_AUDIO_URL);
      activeAudio.loop = false;
      activeAudio.volume = 0.001;
      activeAudio.currentTime = 0;
      await activeAudio.play();
      activeAudio.pause();
      activeAudio.currentTime = 0;
      activeAudio.volume = 1;
    } catch {
      // Web Audio remains unlocked and supplies the fallback tone if media playback is blocked.
    }
    window.sessionStorage.setItem("city-center-driver-audio-ready", "true");
    window.dispatchEvent(new Event(DRIVER_AUDIO_READY_EVENT));
    return true;
  } catch {
    return false;
  }
}

function tone(context: AudioContext, startAt: number, frequency: number, duration: number, volume: number) {
  const oscillator = context.createOscillator();
  const gain = context.createGain();
  oscillator.type = "sine";
  oscillator.frequency.setValueAtTime(frequency, startAt);
  gain.gain.setValueAtTime(0.0001, startAt);
  gain.gain.exponentialRampToValueAtTime(volume, startAt + 0.015);
  gain.gain.exponentialRampToValueAtTime(0.0001, startAt + duration);
  oscillator.connect(gain);
  gain.connect(context.destination);
  oscillator.start(startAt);
  oscillator.stop(startAt + duration + 0.02);
}

async function playFallbackTone(): Promise<boolean> {
  const context = getAudioContext();
  if (!context) return false;
  try {
    if (context.state === "suspended") await context.resume();
    const startAt = context.currentTime + 0.02;
    tone(context, startAt, 880, 0.22, 0.22);
    tone(context, startAt + 0.25, 1175, 0.22, 0.22);
    tone(context, startAt + 0.5, 880, 0.3, 0.22);
    return true;
  } catch {
    return false;
  }
}

export async function playDriverAlert(): Promise<boolean> {
  if (typeof window !== "undefined") {
    try {
      activeAudio ??= new Audio(DRIVER_ALERT_AUDIO_URL);
      activeAudio.loop = false;
      activeAudio.volume = 1;
      activeAudio.currentTime = 0;
      await activeAudio.play();
      return true;
    } catch {
      return playFallbackTone();
    }
  }
  return false;
}

export function startRepeatingDriverAlert() {
  stopRepeatingDriverAlert();
  if (typeof window !== "undefined") {
    try {
      activeAudio ??= new Audio(DRIVER_ALERT_AUDIO_URL);
      activeAudio.loop = true;
      activeAudio.volume = 1;
      void activeAudio.play().catch(() => { void playFallbackTone(); });
      activeTimer = window.setInterval(() => {
        if (!activeAudio || activeAudio.paused) void playFallbackTone();
      }, 2200);
      return;
    } catch {
      // Fall through to WebAudio fallback.
    }
  }
  void playFallbackTone();
  if (typeof window !== "undefined") activeTimer = window.setInterval(() => void playFallbackTone(), 1800);
}

export function stopRepeatingDriverAlert() {
  if (activeTimer !== null && typeof window !== "undefined") window.clearInterval(activeTimer);
  activeTimer = null;
  if (activeAudio) {
    activeAudio.pause();
    activeAudio.currentTime = 0;
  }
}
