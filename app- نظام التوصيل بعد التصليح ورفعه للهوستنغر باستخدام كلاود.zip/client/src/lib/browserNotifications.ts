export type DriverNotificationPermission = "granted" | "denied" | "default" | "unsupported";

export async function requestDriverNotificationPermission(): Promise<DriverNotificationPermission> {
  if (typeof window === "undefined" || !("Notification" in window)) return "unsupported";
  try {
    return await Notification.requestPermission();
  } catch {
    return "unsupported";
  }
}

export async function showBrowserNotification(title: string, body: string, tag: string, data: Record<string, string> = { url: "/driver" }) {
  if (typeof navigator === "undefined" || !("serviceWorker" in navigator)) return false;
  try {
    const registration = await navigator.serviceWorker.ready;
    await registration.showNotification(title, { body, tag, requireInteraction: true, data });
    return true;
  } catch {
    return false;
  }
}
