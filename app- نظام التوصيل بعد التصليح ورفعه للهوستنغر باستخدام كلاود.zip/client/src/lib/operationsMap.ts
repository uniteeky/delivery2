export type OperationsMapPoint = {
  latitude: string | number;
  longitude: string | number;
};

export type OperationsMapViewport = {
  west: number;
  south: number;
  east: number;
  north: number;
};

const KUWAIT_VIEWPORT: OperationsMapViewport = { west: 47.78, south: 29.15, east: 48.18, north: 29.57 };

export function getOperationsMapViewport(points: OperationsMapPoint[]): OperationsMapViewport {
  const valid = points.map((point) => ({ lat: Number(point.latitude), lng: Number(point.longitude) })).filter((point) => Number.isFinite(point.lat) && Number.isFinite(point.lng));
  if (!valid.length) return KUWAIT_VIEWPORT;
  const minLat = Math.min(...valid.map((point) => point.lat));
  const maxLat = Math.max(...valid.map((point) => point.lat));
  const minLng = Math.min(...valid.map((point) => point.lng));
  const maxLng = Math.max(...valid.map((point) => point.lng));
  const latPadding = Math.max(0.008, (maxLat - minLat) * 0.18);
  const lngPadding = Math.max(0.008, (maxLng - minLng) * 0.18);
  return { west: minLng - lngPadding, south: minLat - latPadding, east: maxLng + lngPadding, north: maxLat + latPadding };
}

export function createOpenStreetMapEmbedUrl(viewport: OperationsMapViewport) {
  const bbox = [viewport.west, viewport.south, viewport.east, viewport.north].join(",");
  return `https://www.openstreetmap.org/export/embed.html?bbox=${encodeURIComponent(bbox)}&layer=mapnik`;
}

export function getOperationsMapMarkerPosition(point: OperationsMapPoint, viewport: OperationsMapViewport) {
  const lat = Number(point.latitude);
  const lng = Number(point.longitude);
  const horizontalSpan = Math.max(viewport.east - viewport.west, 0.0001);
  const mercatorY = (latitude: number) => Math.log(Math.tan(Math.PI / 4 + (Math.max(-85, Math.min(85, latitude)) * Math.PI) / 360));
  const northY = mercatorY(viewport.north);
  const southY = mercatorY(viewport.south);
  const verticalSpan = Math.max(northY - southY, 0.0001);
  return { left: Math.min(98, Math.max(2, ((lng - viewport.west) / horizontalSpan) * 100)), top: Math.min(98, Math.max(2, ((northY - mercatorY(lat)) / verticalSpan) * 100)) };
}

export function scaleOperationsMapViewport(viewport: OperationsMapViewport, scale: number): OperationsMapViewport {
  const centerLng = (viewport.west + viewport.east) / 2;
  const centerLat = (viewport.south + viewport.north) / 2;
  const halfLng = Math.max(0.002, ((viewport.east - viewport.west) / 2) * scale);
  const halfLat = Math.max(0.002, ((viewport.north - viewport.south) / 2) * scale);
  return { west: centerLng - halfLng, east: centerLng + halfLng, south: centerLat - halfLat, north: centerLat + halfLat };
}
