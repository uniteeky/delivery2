import { describe, expect, it } from "vitest";
import { LOCAL_LOGIN_PATH, requiresExternalAccountSetup, shouldStayOnLocalAccessPage } from "./local-auth-routing";

describe("local account routing", () => {
  it("does not force a local Civil-ID user into the legacy account setup flow", () => {
    expect(requiresExternalAccountSetup({ loginMethod: "local-civil-id", mustChangePassword: true })).toBe(false);
  });

  it("keeps the legacy setup requirement only for non-local accounts", () => {
    expect(requiresExternalAccountSetup({ loginMethod: "oauth", mustChangePassword: true })).toBe(true);
    expect(requiresExternalAccountSetup({ loginMethod: "local-civil-id", mustChangePassword: false })).toBe(false);
  });

  it("uses the local login page as the non-OAuth access boundary", () => {
    expect(LOCAL_LOGIN_PATH).toBe("/local-login");
    expect(shouldStayOnLocalAccessPage("/local-login")).toBe(true);
    expect(shouldStayOnLocalAccessPage("/orders/new")).toBe(false);
  });
});
