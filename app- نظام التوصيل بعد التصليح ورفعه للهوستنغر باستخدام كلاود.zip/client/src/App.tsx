import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import DriverHome from "@/pages/DriverHome";
import DriverAccount from "@/pages/DriverAccount";
import DriverNewOrder from "@/pages/DriverNewOrder";
import NewOrder from "./pages/NewOrder";
import OrdersManagement from "./pages/OrdersManagement";
import Companies from "./pages/Companies";
import Finance from "./pages/Finance";
import Users from "@/pages/Users";
import OperationsRoom from "@/pages/OperationsRoom";
import Messaging from "@/pages/Messaging";
import AccountSettings from "@/pages/AccountSettings";
import Backups from "./pages/Backups";
import DriverRegistration from "./pages/DriverRegistration";
import BusinessRegistration from "./pages/BusinessRegistration";
import CompanyPortal from "@/pages/CompanyPortal";
import OrderDetails from "@/pages/OrderDetails";
import LocalLogin from "./pages/LocalLogin";
import AdminRecovery from "./pages/AdminRecovery";
import PlatformSettings from "@/pages/PlatformSettings";
import Locations from "@/pages/Locations";
import { LanguageProvider, useLanguage } from "./i18n";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { requiresExternalAccountSetup } from "@/lib/local-auth-routing";
import { canAccessDashboardPath } from "@shared/operations";
import { useEffect } from "react";
import { useLocation } from "wouter";
import NetworkStatusBanner from "@/components/NetworkStatusBanner";
import PlatformBrandingRuntime from "@/components/PlatformBrandingRuntime";

function ProtectedRoute({ path, children }: { path: string; children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const { t, language } = useLanguage();
  const [, navigate] = useLocation();
  const permissions = trpc.auth.permissions.useQuery(undefined, { enabled: Boolean(user && user.status === "active" && user.approvalStatus === "approved") });
  const granted = (permissions.data ?? []).filter((item) => item.granted).map((item) => item.permissionKey);
  const roles = user ? [user.role, ...(user.roles ?? [])] : [];
  const allowed = user ? canAccessDashboardPath(roles, path, granted) : true;
  const fallback = roles.includes("admin") ? "/" : roles.includes("supervisor") ? "/" : roles.includes("accountant") ? "/finance" : roles.includes("company") || roles.includes("trader") ? "/company" : "/driver";
  const mustChangePassword = requiresExternalAccountSetup(user);
  useEffect(() => { if (!loading && user && mustChangePassword && path !== "/account") navigate("/account"); else if (!loading && user && !allowed) navigate(fallback); }, [loading, user, mustChangePassword, path, allowed, fallback, navigate]);
  if (loading) return <div dir={language === "ar" ? "rtl" : "ltr"} className="flex min-h-screen items-center justify-center bg-background text-muted-foreground">{t("platformPreparing")}</div>;
  if (!user) return <>{children}</>;
  if (!allowed) return <div dir={language === "ar" ? "rtl" : "ltr"} className="flex min-h-screen items-center justify-center bg-background p-6 text-center"><div><h1 className="text-xl font-black">{t("unauthorizedTitle")}</h1><p className="mt-2 text-sm text-muted-foreground">{t("unauthorizedDescription")}</p></div></div>;
  return <>{children}</>;
}

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/register-business"} component={BusinessRegistration} />
      <Route path={"/register-driver"} component={DriverRegistration} />
      <Route path={"/register"} component={DriverRegistration} />
      <Route path={"/local-login"} component={LocalLogin} />
      <Route path={"/admin-recovery"} component={AdminRecovery} />
      <Route path={"/company"}>{() => <ProtectedRoute path="/company"><CompanyPortal /></ProtectedRoute>}</Route>
      <Route path={"/driver"}>{() => <ProtectedRoute path="/driver"><DriverHome /></ProtectedRoute>}</Route>
      <Route path={"/driver/account"}>{() => <ProtectedRoute path="/driver"><DriverAccount /></ProtectedRoute>}</Route>
      <Route path={"/driver/new-order"}>{() => <ProtectedRoute path="/driver/new-order"><DriverNewOrder /></ProtectedRoute>}</Route>
      <Route path={"/account"}>{() => <ProtectedRoute path="/account"><AccountSettings /></ProtectedRoute>}</Route>
      <Route path={"/orders/new"}>{() => <ProtectedRoute path="/orders/new"><NewOrder /></ProtectedRoute>}</Route>
      <Route path={"/orders/manage"}>{() => <ProtectedRoute path="/orders/manage"><OrdersManagement /></ProtectedRoute>}</Route>
      <Route path={"/orders/:id"}>{() => <ProtectedRoute path="/orders/:id"><OrderDetails /></ProtectedRoute>}</Route>
      <Route path={"/companies"}>{() => <ProtectedRoute path="/companies"><Companies /></ProtectedRoute>}</Route>
      <Route path={"/locations"}>{() => <ProtectedRoute path="/locations"><Locations /></ProtectedRoute>}</Route>
      <Route path={"/finance"}>{() => <ProtectedRoute path="/finance"><Finance /></ProtectedRoute>}</Route>
      <Route path={"/users"}>{() => <ProtectedRoute path="/users"><Users /></ProtectedRoute>}</Route>
      <Route path={"/operations-room"}>{() => <ProtectedRoute path="/operations-room"><OperationsRoom /></ProtectedRoute>}</Route>
      <Route path={"/operations"}>{() => <ProtectedRoute path="/operations-room"><OperationsRoom /></ProtectedRoute>}</Route>
      <Route path={"/messaging"}>{() => <ProtectedRoute path="/messaging"><Messaging /></ProtectedRoute>}</Route>
      <Route path={"/backups"}>{() => <ProtectedRoute path="/backups"><Backups /></ProtectedRoute>}</Route>
      <Route path={"/platform-settings"}>{() => <ProtectedRoute path="/platform-settings"><PlatformSettings /></ProtectedRoute>}</Route>
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <LanguageProvider>
          <PlatformBrandingRuntime />
          <TooltipProvider>
            <Toaster />
            <Router />
            <NetworkStatusBanner />
          </TooltipProvider>
        </LanguageProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
