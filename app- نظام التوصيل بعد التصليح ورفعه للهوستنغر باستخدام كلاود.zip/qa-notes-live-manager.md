# Live manager QA

The live domain retained the authenticated manager session. The Users page rendered the Add Driver workflow, account list, role controls, audit history, and driver profile sync controls. The New Order page rendered with `الحساب الحالي: مدير`, company selection, external/company order modes, optional pickup and delivery times, and a driver selector populated with approved active drivers. No mutation was submitted during this verification.

## Operations-room route QA

The direct `/operations` URL returns the localized 404 page; the current application exposes the operations room as an embedded section in the manager dashboard rather than a standalone route. The live dashboard itself displayed “غرفة عمليات المشرف — 1 سائق ظاهر على الخريطة” and a driver marker, with the map refresh note indicating 15-second updates. This is recorded as an implementation/navigation finding, not marked as a defect without confirming the intended route contract.

## Official operations-room QA

The official route is `/operations-room`. In the authenticated manager session it rendered the localized Operations Room title, retry control, KPI cards, a live driver map, one visible driver marker, and the 15-second update description. The earlier `/operations` 404 was only an incorrect guessed URL.

## Driver-route QA

The authenticated live session could open `/driver` and rendered the driver interface in Arabic, including GPS and shift start, notification enablement, install prompt, trips, orders, and account settings. No GPS start, notification permission, order mutation, or shift mutation was triggered. Because the session identity may carry a driver role in addition to manager privileges, this observation is not treated as an authorization defect without checking the effective role list.

## Confirmed GPS/shift test

After explicit confirmation, the connected driver session was opened and “تفعيل GPS وبدء الوردية” was pressed. The UI did not reach an active shift state. It remained on “الوردية غير مفعلة”, showed “جارٍ تجهيز الحساب...” and “تعذر تحميل بيانات التشغيل. اسحب للتحديث أو حاول مرة أخرى.” No location permission prompt or active-shift confirmation appeared, so no GPS position or shift record was intentionally verified from this attempt.

## Driver route guard deployment check

The source change and TypeScript/Vitest checks passed, but a live reload before saving the new checkpoint still showed the previous driver interface and generic data-loading error. The guard therefore requires a fresh checkpoint/deployment before final live verification.

## Deployment marker check

After checkpoint 9054b3e0, the public `/api/build-version` endpoint still returned `cc-ops-2026-08-20-r6` with the earlier release marker. The public `/driver` page therefore still showed the pre-guard driver UI. The source fix is verified locally, but live deployment synchronization remains open.

## Post-restart deployment check

The public build-version endpoint still returned r6 after the project services were restarted. The local project is on checkpoint dba163af with r7 in source, but the public domain has not synchronized that checkpoint yet. The live guard cannot be claimed verified until the public marker changes.

## r7 live verification complete

The public build-version endpoint eventually returned `cc-ops-2026-08-20-r7` with the new release marker. Reloading `/driver` in the manager-only session then showed the localized unauthorized state and no GPS, shift, or driver-order controls. This confirms the DriverHome route guard is live and prevents the earlier generic driver data error for manager-only accounts.

## Real device GPS verification

The user supplied a screenshot from an iPhone Safari session showing the driver shift active, the GPS/shift control changed to the end-shift state, a seven-order alert, and pickup recorded. Immediately afterward, the manager Operations Room on the live r7 domain showed `1 سائق ظاهر على الخريطة`, the marker name `Nndjdjdj`, and a fresh last-update time at approximately 9:18 PM. This confirms the real device location reached the operations map.

## Users translation and direction QA

The live manager Users page rendered the Arabic onboarding notice, staff-account form, translated placeholders, approval-oriented action controls, account list, and manager controls in the current release. The captured viewport remained usable and no mutation was submitted during this verification.

## Backups translation QA

The live Backups page loaded in Arabic on release r7 with the RTL layout, translated headings and controls, and the external-destination placeholder shown as “Google Drive أو S3”. No settings were submitted or changed during this check.

## LocalLogin translation QA

The live LocalLogin page rendered in Arabic with the Civil ID and password labels/placeholders, safe-login note, registration link, and RTL layout. No credentials were entered and no login request was submitted.

## 2026-08-20 — Driver Hindi browser smoke

The persisted browser session opened `/driver` in Hindi. The driver shell, GPS start control, alert control, trip section, order section, and bottom navigation rendered in Hindi with the expected mobile-first stacked layout. The page also displayed the localized operational-data error state (`ऑपरेशनल डेटा लोड नहीं हो सका...`) and retained the empty-state cards; no shift, GPS, order, or alert mutation was submitted.

## 2026-08-20 — Driver language switch QA

The driver menu exposed all four language choices and account actions. Switching from Hindi to English updated the driver shell, GPS/shift control, alert control, trips, order states, and menu labels to English and changed the layout to LTR. No operational mutation was submitted.

## 2026-08-20 — Driver English reload QA

After a fresh reload, `/driver` persisted English correctly. The mobile shell remained LTR and showed translated GPS/shift, alert, trip, order, empty-state, and bottom-navigation labels. The operational-data request returned the localized error state again; no retry, GPS, shift, or order action was triggered.

## 2026-08-20 — Finance route guard QA

Navigating the current driver session to `/finance` did not expose accounting data or controls. After the app settled, the browser remained on the guarded `/driver` interface, showing only driver-scoped controls and localized operational empty/error states. No financial mutation was submitted.

## 2026-08-20 — Users route guard QA

Navigating the current driver session to `/users` did not expose user records, role assignment, approvals, or audit controls. Once the app settled, it returned to the driver interface with only driver-scoped controls. No account or permission mutation was submitted.

## 2026-08-20 — Driver operational query fix QA

The browser previously reported generic operational-data failure because `driver.me` and `driver.activeShift` returned `undefined`, which tRPC treats as a query error. After changing both procedures to return `null` for absent records, `/driver` now loads without the generic error. It clearly reports that the account has a driver role but no linked operational driver profile, keeps counters/trips/orders at safe empty states, and disables GPS/shift start until a manager completes vehicle and driver setup.

## 2026-08-20 — Operations-room route guard QA

Navigating the current driver session to `/operations-room` returned to the driver interface after settling. No operations map, driver markers, order-wide KPIs, or reports were exposed; the driver setup notice and scoped empty states remained visible. No operational mutation was submitted.

## 2026-08-20 — Post-fix log review

The browser console still contains historical `driver.me` and `driver.activeShift` undefined errors from 22:28:52, before the fix. The post-fix browser reload at 22:31–22:33 showed the explicit missing-profile state and no new generic operational-data error. The dev-server log has no newer runtime exception; its older lifecycle warning predates the fix.
