# ترحيل MySQL في Hostinger

## المسار الموصى به

استخدم ترحيلات Drizzle المضمّنة في مجلد `drizzle/`، ولا تنشئ ترحيلات جديدة في بيئة الإنتاج.

```bash
npm ci
npm run db:migrate
npm run db:check-accounts
```

الأمر `db:check-accounts` يتحقق من أن أعمدة أدوار المستخدمين في `users` و`userRoles` تدعم الأدوار التالية: `company` و`trader` و`supervisor` و`driver` و`accountant`.

## قاعدة موجودة قديمة

1. خذ نسخة احتياطية من قاعدة MySQL عبر hPanel.
2. نفّذ الأوامر السابقة متى توفرت طرفية Node.js.
3. إذا لم تتوفر طرفية إطلاقاً، يمكن تنفيذ `hostinger-account-roles-upgrade.sql` في phpMyAdmin كحل توافق لأعمدة الأدوار فقط، ثم نفّذ الترحيلات الكاملة لاحقاً.

> لا تستخدم `hostinger-ccdapp-empty-schema.sql`. إنه لا يمثل المخطط الحالي.

راجع `HOSTINGER_DEPLOYMENT_AR.md` لمتغيرات البيئة وإعداد تطبيق Node.js.
