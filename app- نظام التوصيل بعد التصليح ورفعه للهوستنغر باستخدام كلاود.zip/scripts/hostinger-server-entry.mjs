// Hostinger detects server.js as the conventional Node application entry file.
// Keep this wrapper tiny so production startup still runs the verified bundle.
import "./dist/index.js";
