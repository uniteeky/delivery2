// Temporary startup task: applies Drizzle migrations once, then the app starts normally.
// Enabled only when RUN_MIGRATIONS_ON_START=1. Remove that variable after the first successful run.
import path from "node:path";
import { fileURLToPath } from "node:url";
import mysql from "mysql2/promise";
import { drizzle } from "drizzle-orm/mysql2";
import { migrate } from "drizzle-orm/mysql2/migrator";

export async function runMigrations() {
  const url = process.env.DATABASE_URL;
  if (!url) {
    console.error("[migrate-on-start] DATABASE_URL is missing; skipping migrations.");
    return false;
  }
  const folder = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../drizzle");
  let connection;
  try {
    connection = await mysql.createConnection(url);
    await migrate(drizzle(connection), { migrationsFolder: folder });
    console.log("[migrate-on-start] Migrations applied successfully.");
    return true;
  } catch (error) {
    console.error("[migrate-on-start] Migration failed:", error);
    return false;
  } finally {
    if (connection) await connection.end().catch(() => {});
  }
}
