import { createWriteStream } from "node:fs";
import { mkdir, readdir, stat } from "node:fs/promises";
import { dirname, join, relative, resolve } from "node:path";
import { createGzip } from "node:zlib";
import { pipeline } from "node:stream/promises";
import { Readable } from "node:stream";

const root = resolve(new URL("..", import.meta.url).pathname);
const outputDir = join(root, "exports");
const stamp = new Date().toISOString().replace(/[:.]/g, "-");
const output = join(outputDir, `city-center-delivery-source-${stamp}.tar.gz`);
const excluded = new Set(["node_modules", ".git", "dist", "exports", ".manus-logs"]);
const isExcluded = (path) => path.split("/").some((part) => excluded.has(part) || part === ".env" || part.startsWith(".env."));

async function collect(current) {
  const entries = await readdir(current, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const absolute = join(current, entry.name);
    const rel = relative(root, absolute).replaceAll("\\", "/");
    if (isExcluded(rel)) continue;
    if (entry.isDirectory()) files.push(...await collect(absolute));
    else files.push({ absolute, rel });
  }
  return files;
}

await mkdir(outputDir, { recursive: true });
const files = await collect(root);
async function* tarEntries() {
  for (const file of files) {
    const bytes = await (await import("node:fs/promises")).readFile(file.absolute);
    const header = Buffer.alloc(512);
    header.write(file.rel, 0, 100, "utf8");
    header.write("0000644\0", 100, 8, "ascii");
    header.write("0000000\0", 108, 8, "ascii");
    header.write("0000000\0", 116, 8, "ascii");
    header.write(bytes.length.toString(8).padStart(11, "0") + "\0", 124, 12, "ascii");
    header.write(Math.floor(Date.now() / 1000).toString(8).padStart(11, "0") + "\0", 136, 12, "ascii");
    header.fill(32, 148, 156);
    header.write("0", 156, 1, "ascii");
    header.write("ustar\0", 257, 6, "ascii");
    header.write("00", 263, 2, "ascii");
    const checksum = header.reduce((sum, value) => sum + value, 0);
    header.write(checksum.toString(8).padStart(6, "0") + "\0 ", 148, 8, "ascii");
    yield header;
    yield bytes;
    const padding = Buffer.alloc((512 - (bytes.length % 512)) % 512);
    if (padding.length) yield padding;
  }
  yield Buffer.alloc(1024);
}
await pipeline(Readable.from(tarEntries()), createGzip(), createWriteStream(output));
console.log(`Exported ${files.length} files to ${output}`);
