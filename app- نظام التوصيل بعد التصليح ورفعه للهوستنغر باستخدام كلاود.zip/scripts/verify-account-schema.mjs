import mysql from "mysql2/promise";

const databaseUrl = process.env.DATABASE_URL;

if (!databaseUrl) {
  console.error("DATABASE_URL is required to verify the MySQL account schema.");
  process.exit(1);
}

const connection = await mysql.createConnection(databaseUrl);

try {
  const [databaseRows] = await connection.query(
    "SELECT DATABASE() AS databaseName"
  );
  const databaseName = databaseRows[0]?.databaseName;
  if (!databaseName)
    throw new Error("The MySQL connection did not select a database.");

  const [columns] = await connection.query(
    `SELECT TABLE_NAME AS tableName, COLUMN_NAME AS columnName, COLUMN_TYPE AS columnType
     FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = ?
       AND ((TABLE_NAME = 'users' AND COLUMN_NAME IN ('role', 'registrationRole'))
         OR (TABLE_NAME = 'userRoles' AND COLUMN_NAME = 'role'))`,
    [databaseName]
  );

  const requiredColumns = [
    ["users", "role"],
    ["users", "registrationRole"],
    ["userRoles", "role"],
  ];
  const missingOrOutdated = requiredColumns.filter(([tableName, columnName]) => {
    const column = columns.find(
      item => item.tableName === tableName && item.columnName === columnName
    );
    return !column || !String(column.columnType).includes("'trader'");
  });

  if (missingOrOutdated.length) {
    const names = missingOrOutdated
      .map(([tableName, columnName]) => `${tableName}.${columnName}`)
      .join(", ");
    throw new Error(
      `MySQL account-role schema is outdated (${names}). Run npm run db:migrate, then run this check again.`
    );
  }

  console.log(
    "MySQL account-role schema is ready for company, trader, supervisor, driver, and accountant accounts."
  );
} finally {
  await connection.end();
}
