#!/usr/bin/env bash
set -euo pipefail

archive="/home/ubuntu/city-center-delivery-hostinger-oauth-production.zip"
staging_root="/tmp/ccd-hostinger-runtime-verify"
app_root="$staging_root/city-center-delivery-hostinger-admin-bootstrap"
log_path="/tmp/ccd-hostinger-production-runtime.log"
response_path="/tmp/ccd-hostinger-build-version.json"

rm -rf "$staging_root"
rm -f "$log_path" "$response_path"
mkdir -p "$staging_root"
unzip -qq "$archive" -d "$staging_root"

cd "$app_root"
npm install --omit=dev --ignore-scripts

PORT=4912 NODE_ENV=production npm start >"$log_path" 2>&1 &
server_pid=$!
cleanup() {
  kill "$server_pid" 2>/dev/null || true
  wait "$server_pid" 2>/dev/null || true
}
trap cleanup EXIT

for attempt in {1..12}; do
  if curl -fsS "http://127.0.0.1:4912/api/build-version" >"$response_path"; then
    cat "$log_path"
    cat "$response_path"
    exit 0
  fi
  sleep 1
done

cat "$log_path" >&2
exit 1
