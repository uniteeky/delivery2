import { createDecipheriv, createHash } from "node:crypto";
import { chmod, readFile, writeFile } from "node:fs/promises";
import mysql from "mysql2";

const inputPath = "/home/ubuntu/city-center-manus-snapshot.json";
const outputPath = "/home/ubuntu/city-center-manus-live-data.sql";
const exportOrder = [
  "users",
  "userRoles",
  "userPermissions",
  "companies",
  "companyUsers",
  "drivers",
  "driverLocations",
  "trips",
  "shifts",
  "orders",
  "orderEvents",
  "orderMedia",
  "orderTransfers",
  "financialEntries",
  "messageThreads",
  "threadMembers",
  "messages",
  "notifications",
  "auditLogs",
];

const columnRenames = {
  users: { requestedRole: "registrationRole", status: "accountStatus" },
  companies: { status: "accountStatus" },
  trips: { status: "tripStatus" },
  orders: { source: "orderSource", status: "orderStatus" },
  financialEntries: { type: "financialEntryType", category: "financialCategory" },
  orderEvents: { type: "eventType" },
  orderMedia: { kind: "mediaKind" },
  messageThreads: { type: "messageThreadType" },
};

if (!process.env.JWT_SECRET) {
  throw new Error("JWT_SECRET is required to decrypt the live backup.");
}

const quoteIdentifier = (value) => `\`${value.replaceAll("`", "``")}\``;
const toMySqlTimestamp = (column, value) => {
  if (typeof value !== "string" || !column.endsWith("At")) return value;
  return value.replace("T", " ").replace(/\.\d{3}Z$/, "").replace(/Z$/, "");
};

function decryptSecureUsers(payload) {
  const [ivText, tagText, dataText] = payload.split(".");
  if (!ivText || !tagText || !dataText) throw new Error("The backup user payload is invalid.");
  const key = createHash("sha256").update(process.env.JWT_SECRET).digest();
  const decipher = createDecipheriv("aes-256-gcm", key, Buffer.from(ivText, "base64url"));
  decipher.setAuthTag(Buffer.from(tagText, "base64url"));
  const decrypted = Buffer.concat([decipher.update(Buffer.from(dataText, "base64url")), decipher.final()]).toString("utf8");
  return JSON.parse(decrypted);
}

const backup = JSON.parse(await readFile(inputPath, "utf8"));
if (backup.format !== "city-center-delivery-backup" || backup.version !== 2 || !backup.secureUsers || !backup.tables) {
  throw new Error("Unsupported City Center backup format.");
}

const secureUsers = new Map(decryptSecureUsers(backup.secureUsers).map((user) => [user.id, user]));
const migratedTables = {
  ...backup.tables,
  users: (backup.tables.users ?? []).map((user) => ({ ...user, ...(secureUsers.get(user.id) ?? {}) })),
};

const statements = [
  "-- City Center live-data migration generated from an encrypted Manus backup.",
  "-- Contains private business data and password hashes. Keep confidential.",
  "SET FOREIGN_KEY_CHECKS=0;",
];
const counts = [];

for (const table of exportOrder) {
  const rows = migratedTables[table] ?? [];
  counts.push({ table, rows: rows.length });
  for (const row of rows) {
    const renamed = Object.fromEntries(Object.entries(row).map(([column, value]) => [columnRenames[table]?.[column] ?? column, value]));
    const columns = Object.keys(renamed);
    const values = columns.map((column) => mysql.escape(toMySqlTimestamp(column, renamed[column]))).join(", ");
    statements.push(`INSERT INTO ${quoteIdentifier(table)} (${columns.map(quoteIdentifier).join(", ")}) VALUES (${values});`);
  }
}

statements.push("SET FOREIGN_KEY_CHECKS=1;");
await writeFile(outputPath, `${statements.join("\n")}\n`, { mode: 0o600 });
await chmod(outputPath, 0o600);
console.log(JSON.stringify({ outputPath, totalRows: counts.reduce((sum, item) => sum + item.rows, 0), counts }));
