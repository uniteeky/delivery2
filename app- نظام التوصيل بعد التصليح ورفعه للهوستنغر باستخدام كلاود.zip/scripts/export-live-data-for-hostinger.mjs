import { chmod, writeFile } from "node:fs/promises";
import mysql from "mysql2";
import mysqlPromise from "mysql2/promise";

const destination = "/home/ubuntu/city-center-manus-live-data.sql";
const tables = [
  "users",
  "userRoles",
  "userPermissions",
  "companies",
  "companyUsers",
  "drivers",
  "driverLocations",
  "trips",
  "shifts",
  "orders",
  "orderEvents",
  "orderMedia",
  "orderTransfers",
  "financialEntries",
  "messageThreads",
  "threadMembers",
  "messages",
  "notifications",
  "auditLogs",
];

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL is required for the live-data export.");
}

const quoteIdentifier = (value) => `\`${value.replaceAll("`", "``")}\``;
const connection = await mysqlPromise.createConnection(process.env.DATABASE_URL);

try {
  const output = [
    "-- City Center operational-data migration generated from the live Manus database.",
    "-- Contains private business data and password hashes. Keep this file confidential.",
    "SET FOREIGN_KEY_CHECKS=0;",
  ];
  const counts = [];

  for (const table of tables) {
    const [rows] = await connection.query(`SELECT * FROM ${quoteIdentifier(table)}`);
    counts.push({ table, rows: rows.length });
    if (rows.length === 0) continue;

    const columns = Object.keys(rows[0]);
    const columnList = columns.map(quoteIdentifier).join(", ");
    for (const row of rows) {
      const values = columns.map((column) => mysql.escape(row[column])).join(", ");
      output.push(`INSERT INTO ${quoteIdentifier(table)} (${columnList}) VALUES (${values});`);
    }
  }

  output.push("SET FOREIGN_KEY_CHECKS=1;");
  await writeFile(destination, `${output.join("\n")}\n`, { mode: 0o600 });
  await chmod(destination, 0o600);
  console.log(JSON.stringify({ destination, counts, totalRows: counts.reduce((sum, item) => sum + item.rows, 0) }));
} finally {
  await connection.end();
}
