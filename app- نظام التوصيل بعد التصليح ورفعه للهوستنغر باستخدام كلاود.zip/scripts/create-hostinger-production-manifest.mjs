import { readFile, writeFile } from "node:fs/promises";

const sourcePath = "/home/ubuntu/city-center-delivery/package.json";
const outputPath = "/tmp/ccd-hostinger-auth/package/city-center-delivery-hostinger-admin-bootstrap/package.json";

const source = JSON.parse(await readFile(sourcePath, "utf8"));
const manifest = {
  name: "city-center-delivery-hostinger-production",
  version: source.version,
  private: true,
  type: "module",
  license: source.license,
  scripts: {
    build: "echo Using prebuilt City Center production artifacts",
    start: "NODE_ENV=production node server.js",
  },
  dependencies: source.dependencies,
};

await writeFile(outputPath, `${JSON.stringify(manifest, null, 2)}\n`, "utf8");
