export type RecentOrderOption = {
  id: number;
  orderNumber: string;
  status: string;
  cashToCollectAmount?: string | number | null;
  cashCollectedAmount?: string | number | null;
  cashCollectionRecorded?: boolean | null;
  cashCollectionNote?: string | null;
};

export function filterRecentOrderOptions(orders: RecentOrderOption[] | undefined, search: string) {
  return (orders ?? []).filter((order) => !search || order.orderNumber.toLowerCase().includes(search.toLowerCase())).slice(0, 20);
}

export function recentOrdersPickerState(input: { isLoading: boolean; hasError: boolean; optionCount: number }) {
  if (input.isLoading) return { disabled: true, label: "جارٍ تحميل الطلبات..." };
  if (input.hasError) return { disabled: true, label: "تعذر تحميل القائمة" };
  if (input.optionCount === 0) return { disabled: false, label: "لا توجد طلبات حديثة", manualFallback: true };
  return { disabled: false, label: "اختر من الطلبات الحديثة", manualFallback: true };
}

export function normalizeManualOrderId(value: string) {
  return value.replace(/\D/g, "");
}

export function canSubmitManualOrderId(value: string) {
  return Number(normalizeManualOrderId(value)) > 0;
}

export function manualFallbackMessage(hasRecentOrdersError: boolean, hasRecentOrders: boolean) {
  if (hasRecentOrdersError) return "تعذر تحميل القائمة؛ أدخل رقم الطلب يدويًا.";
  if (!hasRecentOrders) return "لا توجد طلبات حديثة؛ أدخل رقم الطلب يدويًا.";
  return "يمكنك اختيار طلب أو إدخال رقمه يدويًا.";
}

export const __tripsPanelTestOnly = true;
