export type OrderNumberFormat = "numeric" | "alphabetic";

export function formatOrderNumber(sequence: number, format: OrderNumberFormat) {
  if (!Number.isSafeInteger(sequence) || sequence < 1) {
    throw new Error("Order sequence must be a positive integer");
  }

  const token = format === "numeric"
    ? String(sequence).padStart(6, "0")
    : toAlphabeticToken(sequence);

  return `CC-${token}`;
}

function toAlphabeticToken(sequence: number) {
  let value = sequence;
  let result = "";
  while (value > 0) {
    value -= 1;
    result = String.fromCharCode(65 + (value % 26)) + result;
    value = Math.floor(value / 26);
  }
  return result;
}
