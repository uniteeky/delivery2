export type CashCollectionRow = {
  cashCollectedAmount: string | number | null;
  cashCollectionRecorded?: boolean | null;
};

export function summarizeCashCollections(rows: CashCollectionRow[]) {
  const recorded = rows.filter((row) => row.cashCollectionRecorded === true);
  const total = recorded.reduce((sum, row) => sum + Number(row.cashCollectedAmount ?? 0), 0);
  return {
    cashCollectedTotal: total.toFixed(3),
    cashCollectionCount: recorded.length,
  };
}
