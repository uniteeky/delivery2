export type WhatsAppOrderMode = "driver" | "completed" | "summary";

export type WhatsAppOrder = {
  orderNumber: string;
  status: string;
  pickupAddress?: string | null;
  deliveryAddress: string;
  customerName?: string | null;
  customerPhone?: string | null;
  area?: string | null;
  notes?: string | null;
  deliveredAt?: Date | number | string | null;
  media?: Array<{ kind: "order" | "invoice" | "delivery"; fileUrl: string }>;
};

export type WhatsAppOrderLabels = {
  title: string;
  orderNumber: string;
  status: string;
  pickupAddress: string;
  deliveryAddress: string;
  customer: string;
  phone: string;
  area: string;
  notes: string;
  completedAt: string;
  media: string;
  driverIntro: string;
  completedIntro: string;
  summaryIntro: string;
};

function clean(value?: string | null) {
  return value?.trim() || undefined;
}

function formatDate(value: WhatsAppOrder["deliveredAt"]) {
  if (!value) return undefined;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? undefined : date.toLocaleString();
}

export function composeWhatsAppOrderMessage(order: WhatsAppOrder, mode: WhatsAppOrderMode, labels: WhatsAppOrderLabels) {
  const lines = [mode === "driver" ? labels.driverIntro : mode === "completed" ? labels.completedIntro : labels.summaryIntro, `${labels.title}: ${order.orderNumber}`, `${labels.orderNumber}: ${order.orderNumber}`, `${labels.status}: ${order.status}`];
  const pickup = clean(order.pickupAddress);
  const delivery = clean(order.deliveryAddress);
  const customer = clean(order.customerName);
  const phone = clean(order.customerPhone);
  const area = clean(order.area);
  const notes = clean(order.notes);
  if (pickup) lines.push(`${labels.pickupAddress}: ${pickup}`);
  if (delivery) lines.push(`${labels.deliveryAddress}: ${delivery}`);
  if (customer) lines.push(`${labels.customer}: ${customer}`);
  if (mode === "driver" && phone) lines.push(`${labels.phone}: ${phone}`);
  if (area) lines.push(`${labels.area}: ${area}`);
  if (mode === "driver" && notes) lines.push(`${labels.notes}: ${notes}`);
  const completedAt = formatDate(order.deliveredAt);
  if (mode === "completed" && completedAt) lines.push(`${labels.completedAt}: ${completedAt}`);
  const media = mode === "completed" ? (order.media ?? []).filter((item) => item.kind === "delivery" && clean(item.fileUrl)) : [];
  if (media.length) {
    lines.push(`${labels.media}:`);
    media.forEach((item) => lines.push(item.fileUrl));
  }
  return lines.join("\n");
}

export function buildWhatsAppUrl(message: string) {
  return `https://wa.me/?text=${encodeURIComponent(message)}`;
}
