export const ROLE_LABELS = {
  admin: "المدير",
  supervisor: "السوبر فايزر",
  accountant: "المحاسب",
  driver: "السائق",
  company: "الشركة",
  trader: "التاجر",
} as const;

export type PlatformRole = keyof typeof ROLE_LABELS;
export const ASSIGNABLE_ROLES = ["supervisor", "accountant", "driver", "company", "trader"] as const;
export type AssignableRole = (typeof ASSIGNABLE_ROLES)[number];
export type RoleAwareUser = { role: PlatformRole; roles?: readonly PlatformRole[] };

export function getEffectiveRoles(user: RoleAwareUser): PlatformRole[] {
  return Array.from(new Set([user.role, ...(user.roles ?? [])]));
}

export function hasRole(user: RoleAwareUser | null | undefined, role: PlatformRole) {
  return Boolean(user && getEffectiveRoles(user).includes(role));
}
export type OrderStatus = "pending" | "assigned" | "picked_up" | "in_transit" | "delivered" | "failed";

export const ORDER_STATUS_LABELS: Record<OrderStatus, string> = {
  pending: "جديد",
  assigned: "تم التعيين",
  picked_up: "تم الاستلام",
  in_transit: "قيد التوصيل",
  delivered: "تم التسليم",
  failed: "تعذر التسليم",
};

const transitions: Record<OrderStatus, readonly OrderStatus[]> = {
  pending: ["assigned", "failed"],
  assigned: ["picked_up", "failed"],
  picked_up: ["in_transit", "delivered", "failed"],
  in_transit: ["delivered", "failed"],
  delivered: [],
  failed: ["assigned", "in_transit"],
};

export function canTransitionOrder(from: OrderStatus, to: OrderStatus) {
  return from === to || transitions[from].includes(to);
}

export type TripStatus = "open" | "active" | "closed";

export function canAddOrderToTrip(orderStatus: OrderStatus, tripStatus: TripStatus) {
  return tripStatus !== "closed" && (orderStatus === "pending" || orderStatus === "assigned" || orderStatus === "failed");
}

export function normalizeTripPickup(value?: string | null) {
  return (value ?? "").trim().replace(/\s+/g, " ").toLocaleLowerCase();
}

export function canGroupOrdersInAutomaticTrip(input: { pickupAddress?: string | null; candidatePickupAddress?: string | null; pickupScheduledAt?: Date | null; candidatePickupScheduledAt?: Date | null; windowMinutes?: number }) {
  const pickup = normalizeTripPickup(input.pickupAddress);
  const candidatePickup = normalizeTripPickup(input.candidatePickupAddress);
  if (pickup !== candidatePickup) return false;
  if (!input.pickupScheduledAt || !input.candidatePickupScheduledAt) return true;
  const windowMinutes = input.windowMinutes ?? 90;
  return Math.abs(input.pickupScheduledAt.getTime() - input.candidatePickupScheduledAt.getTime()) <= windowMinutes * 60 * 1000;
}

export function getDriverOrderStats(orders: Array<{ id: number; status: OrderStatus }>) {
  const unique = Array.from(new Map(orders.map((order) => [order.id, order])).values());
  return {
    pickup: unique.filter((order) => order.status === "assigned").length,
    active: unique.filter((order) => order.status === "picked_up" || order.status === "in_transit").length,
    delivered: unique.filter((order) => order.status === "delivered").length,
  };
}

export function splitDriverOrders<T extends { id: number; status: OrderStatus }>(orders: T[]) {
  const unique = Array.from(new Map(orders.map((order) => [order.id, order])).values());
  return {
    active: unique.filter((order) => order.status !== "delivered"),
    delivered: unique.filter((order) => order.status === "delivered"),
  };
}

export function canTransitionTrip(from: TripStatus, to: Exclude<TripStatus, "open">) {
  return (from === "open" && to === "active") || (from === "active" && to === "closed");
}

export function canStartDriverShift(hasActiveShift: boolean) {
  return !hasActiveShift;
}

export function buildShiftStartValues(driverId: number, latitude: string | undefined, longitude: string | undefined, startedAt = new Date()) {
  return { driverId, startedAt, startLatitude: latitude, startLongitude: longitude };
}

export function buildShiftEndValues(latitude: string | undefined, longitude: string | undefined, endedAt = new Date()) {
  return { endedAt, endLatitude: latitude, endLongitude: longitude };
}

export function canManageCompany(role: PlatformRole | readonly PlatformRole[]) {
  return Array.isArray(role) ? role.includes("admin") : role === "admin";
}

export function canOperateOrders(role: PlatformRole | readonly PlatformRole[]) {
  const roles = Array.isArray(role) ? role : [role];
  return roles.some((item) => item === "admin" || item === "supervisor" || item === "driver");
}

export type CompanyMediaKind = "order" | "invoice" | "delivery";

export const COMPANY_MEDIA_PERMISSION: Record<CompanyMediaKind, string> = {
  order: "company_media_pickup",
  invoice: "company_media_invoice",
  delivery: "company_media_delivery",
};

export function canViewCompanyMedia(role: PlatformRole | readonly PlatformRole[], isOwnCompanyOrder: boolean, permissionKey: string) {
  const roles = Array.isArray(role) ? role : [role];
  return roles.includes("admin") || (roles.includes("company") && isOwnCompanyOrder && Object.values(COMPANY_MEDIA_PERMISSION).includes(permissionKey));
}

export function canAccessDashboardPath(role: PlatformRole | readonly PlatformRole[], path: string, grantedPermissions: string[]) {
  const roles = Array.isArray(role) ? role : [role];
  if (roles.includes("admin")) return true;
  if (roles.includes("driver") && (path === "/driver" || path === "/driver/new-order" || path === "/driver/account" || path === "/orders/:id")) return true;
  if ((roles.includes("company") || roles.includes("trader")) && (path === "/company" || path === "/account")) return true;
  if (path === "/account") return true;
  const accountantPath = path === "/" || path === "/messaging" || path === "/finance" || path === "/orders/new" || path === "/orders/manage" || path === "/orders/:id" || path === "/companies";
  if (roles.includes("accountant") && accountantPath) {
    const required = path === "/finance" ? "finance_view" : path === "/orders/new" || path === "/orders/manage" ? "orders_manage" : path === "/orders/:id" ? "orders_view" : path === "/companies" ? "companies_view" : "dashboard_view";
    return grantedPermissions.includes(required);
  }
  const supervisorPath = path === "/" || path === "/operations-room" || path === "/messaging" || path === "/orders/new" || path === "/orders/manage" || path === "/orders/:id" || path === "/companies" || path === "/locations" || path === "/driver" || path === "/finance" || path === "/users" || path === "/backups";
  if (roles.includes("supervisor") && supervisorPath) {
    const required = path === "/locations" ? null : path === "/orders/new" || path === "/orders/manage" ? "orders_manage" : path === "/orders/:id" ? "orders_view" : path === "/companies" ? "companies_view" : path === "/driver" ? "drivers_view" : path === "/finance" ? "finance_view" : path === "/users" ? "users_view" : path === "/backups" ? "backup_view" : "dashboard_view";
    if (required === null) return true;
    return grantedPermissions.includes(required);
  }
  return false;
}

export function filterCompanyMediaForPortal<T extends { kind: CompanyMediaKind }>(media: T[], grantedPermissions: string[]) {
  return media.filter((item) => {
    const permissionKey = COMPANY_MEDIA_PERMISSION[item.kind];
    return grantedPermissions.includes(permissionKey) && canViewCompanyMedia("company", true, permissionKey);
  });
}

export function canViewFinancials(role: PlatformRole | readonly PlatformRole[]) {
  const roles = Array.isArray(role) ? role : [role];
  return roles.includes("admin") || roles.includes("accountant");
}


export function getDashboardQuickActionPath(titleKey: string) {
  if (titleKey === "newOrder") return "/orders/new";
  if (titleKey === "users") return "/users";
  if (titleKey === "finance") return "/finance";
  return "/operations-room";
}
