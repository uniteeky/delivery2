export type OrderAllocationRecord = {
  status: string;
  deliveryFeeChargeOnFailure: boolean;
  driverCommissionManual: boolean;
  companyShareManual: boolean;
  returnedToCompany: boolean;
};

export function shouldCountDeliveryFee(order: OrderAllocationRecord) {
  return order.status === "delivered" || (order.status === "failed" && order.deliveryFeeChargeOnFailure);
}

export function shouldCountDriverCommission(order: OrderAllocationRecord) {
  return order.status === "delivered" || (order.status === "failed" && order.driverCommissionManual);
}

export function shouldCountCompanyShare(order: OrderAllocationRecord) {
  return order.status === "delivered" || (order.status === "failed" && order.companyShareManual);
}
