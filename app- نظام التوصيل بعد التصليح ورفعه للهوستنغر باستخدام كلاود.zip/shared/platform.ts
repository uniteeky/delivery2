export type SubscriptionMode = "active" | "not_started" | "read_only";

export type SubscriptionStateInput = {
  startsAt?: Date | string | null;
  endsAt?: Date | string | null;
};

function asTime(value: Date | string | null | undefined) {
  if (!value) return undefined;
  const time = value instanceof Date ? value.getTime() : new Date(value).getTime();
  return Number.isFinite(time) ? time : undefined;
}

export function getSubscriptionMode(input: SubscriptionStateInput, now = new Date()): SubscriptionMode {
  const nowTime = now.getTime();
  const startsAt = asTime(input.startsAt);
  const endsAt = asTime(input.endsAt);
  if (startsAt !== undefined && nowTime < startsAt) return "not_started";
  if (endsAt !== undefined && nowTime >= endsAt) return "read_only";
  return "active";
}

export function getSubscriptionReminderDays(endsAt: Date | string | null | undefined, now = new Date()) {
  const endTime = asTime(endsAt);
  if (endTime === undefined || endTime <= now.getTime()) return null;
  const remainingDays = Math.ceil((endTime - now.getTime()) / 86_400_000);
  return remainingDays === 1 || remainingDays === 2 || remainingDays === 3 ? remainingDays : null;
}

export function canWriteDuringSubscription(mode: SubscriptionMode) {
  return mode === "active";
}

export const DEFAULT_PLATFORM_SETTINGS = {
  brandName: "City Center",
  logoUrl: "/manus-storage/city-center-logo-user_665f44b4.png",
  primaryColor: "#f97316",
  accentColor: "#0f172a",
  allowDriverTransfer: true,
  allowSupervisorTransfer: true,
  allowManagerTransfer: true,
  hideDriverDeliveryFee: true,
  orderNumberFormat: "numeric" as const,
  nextOrderNumber: 1,
} as const;
