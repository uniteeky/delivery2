export type DriverPayType = "salary" | "salary_commission" | "contractor";

export type CommissionRate = {
  companyId: number | null;
  areaId: number | null;
  amount: string | number;
};

export function resolveDriverCommission(input: {
  payType: DriverPayType;
  defaultCommission: string | number;
  companyId: number | null;
  areaId: number | null;
  rates: CommissionRate[];
  returnedToCompany?: boolean;
}) {
  if (input.returnedToCompany || input.payType === "salary") return 0;

  const exact = input.rates.find((rate) => rate.companyId === input.companyId && rate.areaId === input.areaId && input.companyId !== null && input.areaId !== null);
  if (exact) return Number(exact.amount);

  const companyOnly = input.companyId === null ? undefined : input.rates.find((rate) => rate.companyId === input.companyId && rate.areaId === null);
  if (companyOnly) return Number(companyOnly.amount);

  const areaOnly = input.areaId === null ? undefined : input.rates.find((rate) => rate.companyId === null && rate.areaId === input.areaId);
  if (areaOnly) return Number(areaOnly.amount);

  const defaultCommission = Number(input.defaultCommission);
  return Number.isFinite(defaultCommission) ? defaultCommission : 0;
}

export function initialOrderShares(input: {
  deliveryFee: string | number;
  driverCommission: string | number;
  returnedToCompany?: boolean;
}) {
  if (input.returnedToCompany) return { driverCommission: "0.000", companyShare: "0.000" };
  const fee = Number(input.deliveryFee);
  const commission = Number(input.driverCommission);
  const validFee = Number.isFinite(fee) ? fee : 0;
  const validCommission = Number.isFinite(commission) ? commission : 0;
  return {
    driverCommission: validCommission.toFixed(3),
    companyShare: Math.max(0, validFee - validCommission).toFixed(3),
  };
}

export function independentOrderShares(input: {
  deliveryFee: string | number;
  driverCommission: string | number;
  companyShare: string | number;
}) {
  return {
    deliveryFee: Number(input.deliveryFee).toFixed(3),
    driverCommission: Number(input.driverCommission).toFixed(3),
    companyShare: Number(input.companyShare).toFixed(3),
  };
}
