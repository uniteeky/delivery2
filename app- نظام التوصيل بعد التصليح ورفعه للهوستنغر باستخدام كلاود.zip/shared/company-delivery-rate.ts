export function resolveCompanyDeliveryRate(
  areaRate: string | number | null | undefined,
  governorateRate: string | number | null | undefined,
  fallback: string | number,
): string {
  const amount = areaRate ?? governorateRate ?? fallback;
  return typeof amount === "number" ? amount.toFixed(3) : amount;
}
