import fs from "node:fs";
const path = "client/src/i18n.tsx";
const lines = fs.readFileSync(path, "utf8").split("\n");
const repairs = {
  bn: "মেসেজিং সিস্টেমের ভেতরেই থাকবে",
  hi: "मैसेजिंग सिस्टम के अंदर रहेगी",
};
for (const code of Object.keys(repairs)) {
  const index = lines.findIndex((line) => line.trimStart().startsWith(`${code}: { dashboard:`));
  if (index < 0) throw new Error(`Missing ${code} translation line`);
  const line = lines[index];
  const start = line.indexOf('roleCompany: "');
  const end = line.indexOf("myOrders:", start);
  if (start < 0 || end < 0) throw new Error(`Missing roleCompany/myOrders boundary for ${code}`);
  const roleEnd = line.indexOf('"', start + 'roleCompany: "'.length);
  const roleValue = line.slice(start + 'roleCompany: "'.length, roleEnd);
  lines[index] = `${line.slice(0, start)}roleCompany: "${roleValue}", messagingHint: "${repairs[code]}", ${line.slice(end)}`;
}
fs.writeFileSync(path, lines.join("\n"));
console.log("Repaired Bengali and Hindi messagingHint boundaries");
