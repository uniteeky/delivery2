-- City Center Delivery: account-role compatibility upgrade for legacy Hostinger databases.
-- Take a database backup first. This script is repeatable and may be run through phpMyAdmin.
-- Preferred deployment path: npm run db:migrate && npm run db:check-accounts

ALTER TABLE `users`
  MODIFY COLUMN `role` enum('admin','supervisor','accountant','driver','company','trader') NOT NULL DEFAULT 'driver';

ALTER TABLE `users`
  MODIFY COLUMN `registrationRole` enum('driver','supervisor','accountant','company','trader');

ALTER TABLE `userRoles`
  MODIFY COLUMN `role` enum('admin','supervisor','accountant','driver','company','trader') NOT NULL DEFAULT 'driver';
