# Live verification findings — 2026-08-20

The published domain `citydelivery-kryxxu8q.manus.space` opened with an existing authenticated manager session. The Arabic operations dashboard rendered with the release marker `cc-ops-2026-08-20-r4`, role-based navigation, order KPIs, notifications, latest orders, and a live driver map area.

The live Finance screen was opened directly at `/finance`. In English, the page displayed translated headings, report description, filters, delivered-order data, address pairs, and immutable fee-history copy. Switching the language selector back to Arabic changed the navigation, page copy, filter labels, and layout to Arabic RTL. The Arabic Finance screen displayed delivered-order totals, area summaries, pickup/delivery addresses, and fee-audit empty state. This confirms live language switching and Finance translation behavior for the currently authenticated manager session.

The same session exposed a live Google map marker named `Nndjdjdj` and a recent-location timestamp in the operations view. This is evidence of a populated live map in the current session, not a substitute for multi-driver, mobile GPS, or driver-action validation.

Open items that still require an authenticated driver/supervisor workflow or a real mobile browser/device remain in `todo.md`; they were not marked complete based on this manager-only evidence.

The live `/messaging` route loaded in Arabic RTL for the authenticated manager. It displayed saved-conversation guidance, an empty conversation state, a new-conversation title field, a refreshed recipient list containing active drivers, and a disabled create button until recipients are chosen. No conversation or message was created because that would write operational data and requires explicit user confirmation.

The live `/orders/new` page loaded in Arabic RTL for the manager session. It showed separate optional pickup and delivery time fields, company/external source choices, delivery details, and an approved-driver assignment select. The driver list contained active approved drivers; selecting `مشعل` populated the field and did not submit or create an order. The browser action returned a serialization error after the selection, but a subsequent view confirmed the selected driver remained in the form and no save occurred.

A non-sensitive external test order was created after explicit confirmation. It used the name `اختبار التعيين`, phone `00000000`, a test area, fee `1.000`, two test addresses, and an internal note. The driver dropdown visibly showed `مشعل`; the browser selection action returned a UTF-8 serialization error, but the subsequent form view showed `مشعل` in the selected field. The application save action then succeeded and displayed order number `CC-MT1PLXUC`.

The authenticated dashboard recent-orders procedure returned the saved order with numeric id `300001`, status `assigned`, and `assignedDriverId: 180001`. A separate authorized `drivers.list` query mapped id `180001` to driver `مشعل` (vehicle/license label `ييي`). Opening `/orders/300001` displayed the saved order, both test addresses, assigned status, audit event `created`, and the driver transfer control. This verifies that an approved driver can be assigned in NewOrder and that the assignment is persisted on the created order. The test order was not sent to WhatsApp, and no driver status or media action was performed.

The manager email/OAuth path was reviewed in the deployed source. The public home still calls the standard email/Google login action, while `/local-login` is a separate Civil ID/password endpoint. The OAuth callback exchanges the provider code, upserts the user, creates a session, and redirects to `/`; it contains no `user is blocked` condition. Therefore the observed `Permission denied — user is blocked` is occurring at the identity provider/authorization layer before the application callback, not because the manager email button was removed from the site.

The authentication review found that the public registration route is intentionally a driver-registration route: it stores `role=driver`, `approvalStatus=pending`, and `status=inactive`, and local login rejects pending or inactive accounts. It does not create an active operational driver. Manager-created supervisor/accountant/company accounts use the protected manager procedure instead. The focused registration/local-login suite passed 8 tests across 3 files. The Google `user is blocked` message remains external to the application callback and cannot be fixed by changing the local role defaults.

Live verification after checkpoint 3f727b93: `https://citydelivery-kryxxu8q.manus.space/admin-recovery` returned the deployed site's 404 page, while the managed preview URL rendered the new Arabic recovery form correctly. The code and local preview route are present; the live domain has not yet synchronized this new route. No secret or recovery credentials were entered during verification.

After checkpoint 4f1ff444, the local preview still renders `/admin-recovery`, but the live `/api/build-version` continues to return r4 rather than r5. The live log command reports the Cloud Run service is not found, so no live deployment logs are available for diagnosis. This remains a deployment synchronization issue; no live recovery attempt was made.

A server restart did not change the live marker: the domain still returns `cc-ops-2026-08-20-r4`. The recovery implementation is present in the checkpoint and local preview, but the live domain is still serving the older deployment. Do not use `/admin-recovery` on the live domain until the marker reaches r5.

Live verification succeeded after deployment synchronization: `/api/build-version` returns `cc-ops-2026-08-20-r5` with release `admin-recovery-and-auth-qa`, and `https://citydelivery-kryxxu8q.manus.space/admin-recovery` renders the recovery form. No secret or civil ID was entered during browser verification.

After the Civil ID normalization checkpoint, live `/api/build-version` still reports r5 and the live `/admin-recovery` form is available. Browser verification did not enter or submit any secret, civil ID, or password.

Live recovery UI verification after checkpoint 495e459f: `/admin-recovery` now shows the updated placeholder `12 رقمًا بعد التطبيع`, confirming the Civil ID UI bundle is synchronized. The live build-version endpoint still reports r5, so the marker itself is stale relative to the latest checkpoint, but the user-facing recovery form is updated. No data was submitted.

Live manager-session verification: the browser session is authenticated as UNITEEKY / uniteeky@gmail.com with admin role, approved and active. The Users page renders Add Driver, pending staff-account creation, approval/rejection/activation controls, role selectors, driver-profile sync, and audit history. A user named مشعل محمد الشمري appears pending approval and inactive, while existing active drivers are listed. No approval or role mutation was executed.

Additional live manager-session check: Operations Room rendered successfully with 18 daily orders, 2 in delivery, 7 delivered, 15 active drivers, and one visible driver on the map. A subsequent indexed click from that page opened the Driver interface instead of Finance; no shift, GPS, notification, or order action was executed.

Live manager-session verification continued: Operations Room shows live driver map, 18 daily orders, 2 in delivery, 7 delivered, and 15 active drivers. Finance renders Arabic RTL reports with 7 delivered orders, 15.500 KWD fees, region filters, date filters, two-address display, and an audit-preserved fee history section. No financial edit or operational mutation was performed.

Messaging live verification: the manager session can open `/messaging`; saved conversations are empty and available recipients are listed. Two automated language-select attempts failed due to browser element-index resolution, not an application error. No conversation or message was created.

A confirmed manager-only role change was initiated for the pending account مشعل محمد الشمري. The primary-role selector was set to admin; the browser save click timed out, so the result is unverified and no second save attempt was made.

The account role-save action timed out twice (once via indexed click and once via DOM-targeted click) and left the browser on a blank page. The target account still showed driver/pending on the last rendered Users page before the attempts, so the manager-only promotion remains unverified and no further save was attempted.

The explicitly confirmed account مشعل محمد الشمري was promoted directly in the database after browser saves timed out. Verified state: role=admin, approvalStatus=approved, accountStatus=active, mustChangePassword=1. No Civil ID or password was read or written in the verification output. The account's previous driver role was replaced, not combined.

## Remaining-work classification

| Category | Scope | Current disposition |
|---|---|---|
| Automated and code-verifiable | Auth guards, translation parity, Civil ID normalization, recovery validation, production artifact safety | Implemented and covered by the current test suite where marked complete in `todo.md` |
| Manager-session browser verification | Users page, Operations Room, Finance, Messaging access, manager order creation and assignment | Partially verified live; remaining approval/driver-setup items stay open until directly observed |
| Supervisor-session verification | Supervisor order-management access, approval changes, unauthorized-route boundaries | Requires a separate approved supervisor session; not closed using the manager session |
| Driver-device verification | GPS permission, active shift, notification sound, pickup/delivery media, mobile screenshots | Requires a real connected driver session and device/browser permission; not safely simulated by manager actions |
| Security-sensitive or destructive actions | Public test bypasses, hidden credentials, automatic account promotion, arbitrary test records | Intentionally not added or executed; production safety guards remain enabled |

Live browser verification after the database promotion shows مشعل محمد الشمري as الدور الأساسي: مدير, معتمد, نشط. The previous driver/pending state is no longer shown.
