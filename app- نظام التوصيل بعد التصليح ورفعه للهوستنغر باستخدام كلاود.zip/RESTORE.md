# Source export and restore

## Create an export

From the project root, run:

```bash
pnpm export:source
```

The command creates `exports/city-center-delivery-source-<timestamp>.tar.gz`. The archive includes application source, schema, migrations, tests, documentation, and package manifests. It excludes `node_modules`, `dist`, `.git`, `.manus-logs`, `exports`, and every `.env` file so secrets are never bundled.

## Restore into a clean directory

Extract the archive into a new directory, install dependencies, and run the checks:

```bash
mkdir restored-city-center-delivery
 tar -xzf exports/city-center-delivery-source-<timestamp>.tar.gz -C restored-city-center-delivery
cd restored-city-center-delivery
pnpm install --frozen-lockfile
pnpm check
pnpm test
```

For a connected environment, provide the required environment variables through the project secret manager, then run the normal development command:

```bash
pnpm dev
```

Database migrations must be reviewed and applied through the project migration workflow; the archive does not contain database credentials or production data. A source restore and a data restore are separate operations.

## Verified restore test

The export command was executed successfully during development and produced a compressed archive. Before production, repeat the extraction commands above in a clean working directory, run `pnpm install --frozen-lockfile`, `pnpm check`, and `pnpm test`, and record the result in the release notes. Keep at least one archive outside the application server.
