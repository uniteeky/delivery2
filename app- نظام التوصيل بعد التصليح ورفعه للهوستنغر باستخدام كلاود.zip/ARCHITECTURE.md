# City Center Delivery Platform

## Current architecture

The platform is a single React, tRPC, Express, Drizzle, and MySQL application. The public company presence and internal operations screens share one application and one typed API surface. Authentication is provided by the existing OAuth flow, while operational roles are represented in the database as admin, supervisor, accountant, driver, and future company users.

## Mobile and future apps

The UI is designed mobile-first, with a dedicated driver route. Business rules and data access are implemented through tRPC procedures so future iOS and Android clients can consume the same API without duplicating operational logic.

## Data protection

Operational changes write to the permanent audit log. Order media is stored through the configured object storage helper, while the database stores file references and metadata. Backup scheduling is represented in the database and should be connected to an off-server destination before production activation.

## Source preservation

The full source is maintained in the project repository and can be downloaded from the project management interface. Checkpoints provide restorable snapshots of the application state. Before production, configure an external repository or off-server archive and test a complete restore.

## Next production milestones

Complete supervisor dispatch and map workflows, driver delivery confirmation, company/user administration, financial filters and exports, messaging UI, multilingual dictionaries, scheduled backup execution, and end-to-end security/performance testing before production use.
