import fs from "node:fs";
const lines = fs.readFileSync("client/src/i18n.tsx", "utf8").split("\n");
for (const lineNumber of [13, 14]) {
  if (lineNumber === 13) console.log(JSON.stringify(lines[lineNumber - 1].slice(4500, 4600)));
  const line = lines[lineNumber - 1];
  const positions = [];
  for (let index = 0; index < line.length; index += 1) {
    if (line[index] === '"') positions.push(index + 1);
  }
  const keys = [...line.matchAll(/(?:^|, )([A-Za-z][A-Za-z0-9]*):/g)].map((match) => match[1]);
  const duplicateKeys = keys.filter((key, index) => keys.indexOf(key) !== index);
  console.log(JSON.stringify({ lineNumber, count: positions.length, duplicateKeys: [...new Set(duplicateKeys)], last: positions.slice(-8) }));
  for (const position of positions) {
    const index = position - 1;
    const previous = line[index - 1] ?? "";
    const next = line[index + 1] ?? "";
    if (previous !== ":" && next !== "," && next !== "}") {
      console.log(JSON.stringify({ position, context: line.slice(Math.max(0, index - 80), index + 120) }));
    }
  }
}
