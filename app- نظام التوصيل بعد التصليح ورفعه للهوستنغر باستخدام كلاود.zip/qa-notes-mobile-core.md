# Mobile core-screen QA

## 2026-08-20

Captured 390×844 previews for `/`, `/users`, `/backups`, `/operations-room`, `/driver`, and `/local-login`. Arabic RTL rendering is readable on Users, Backups, Operations Room, and Local Login; cards stack without horizontal clipping. The driver route correctly shows an authorization state in the current manager session rather than exposing driver controls. The public root remained in its loading state during the capture and should be rechecked in an authenticated or fully settled browser session before final handover.

No data mutation or credential submission was performed during this screenshot pass.
