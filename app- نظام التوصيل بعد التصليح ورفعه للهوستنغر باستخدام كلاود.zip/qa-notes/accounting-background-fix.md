# QA note — accounting and opaque backgrounds

- TypeScript passed.
- Vitest passed: 39 files, 127 tests.
- Finance summary now scopes the by-area aggregation to delivered orders.
- Finance screen defaults the report list to delivered status, while retaining an explicit all-status option.
- Shared sidebar mobile and desktop containers now use `bg-background text-foreground` instead of undefined `bg-sidebar` tokens.
- Driver account language selector and password inputs now use solid `bg-slate-800` surfaces rather than translucent `bg-white/5` fields.
- Mobile screenshots loaded the Users page and DriverAccount page with readable solid surfaces. Finance and DriverHome were auth-gated/loading in the unauthenticated preview, so authenticated data-flow verification remains open.
- No implementation was made for closed-screen Push or automatic WhatsApp, per user instruction.
