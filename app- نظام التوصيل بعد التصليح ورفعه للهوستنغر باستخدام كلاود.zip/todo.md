# Project TODO

- [x] Confirm approved product scope: one unified delivery operations platform with public company presence and internal operations screens
- [x] Define scalable multi-role account model for Admin, Supervisor, Accountant, and Driver
- [x] Define future Company Portal accounts and keep portal activation disabled by default
- [x] Design scalable company, driver, user, order, trip, shift, location, media, audit, notification, messaging, report, and backup data models
- [x] Implement role-based access control and account activation/deactivation/reset flows
- [x] Implement company management with per-company delivery pricing and explicit UI feedback
- [x] Implement user management procedures and UI for create/edit users, activate/deactivate accounts, and secure reset-password/temporary-password flows by role
- [x] Extend company management with update and activate/deactivate procedures plus admin UI, preserving per-company delivery fee editing and feedback
- [x] Build a dedicated mobile-first driver interface for order list/statuses and pickup/delivery actions
- [ ] Capture authenticated mobile evidence with assigned orders, active shift, and pickup/delivery actions
- [x] Implement company and external order creation with free-text delivery address
- [x] Implement order media capture for order, invoice, and delivery confirmation
- [x] Integrate order/invoice/delivery image upload into order details and the driver delivery workflow
- [x] Persist uploaded media state in order details and provide upload success/error/retry feedback
- [x] Require or clearly associate delivery-confirmation media with delivered status completion
- [x] Add per-file upload loading/success/error feedback, previews, and retry handling
- [x] Add API/integration test for attachMedia followed by order details reload
- [x] Add component/browser verification that a newly uploaded OrderDetails media file appears after success and reload (live upload succeeded, the image rendered, and the same image remained after a fresh page load)
- [x] Add API verification for failed media upload propagation
- [x] Add UI-level verification that the retry action succeeds after a failed upload (one-shot network failure showed retry; retry succeeded and rendered the new invoice image)

- [x] Implement pickup and delivery events with UTC timestamps and GPS coordinates
- [x] Add a persistence test confirming pickup/delivery events store UTC timestamps and GPS coordinates
- [x] Verify persisted pickup/delivery event timestamps and GPS values are UTC-consistent
- [x] Implement multi-order trips across multiple companies
- [x] Implement driver mobile-first order interface
- [x] Implement driver shift start/end with GPS and timestamps
- [x] Add and test end-shift action in driver UI with geolocation and visible success/error feedback
- [x] Implement order assignment and transfer workflow with permanent transfer history
- [x] Implement supervisor operations room with order monitoring and driver map
- [x] Implement supervisor address editing with before/after audit history
- [x] Implement accountant reports, filters, fee editing, and permanent financial edit history
- [x] Implement Admin KPI dashboard and management screens
- [x] Implement permanent non-deletable operations audit log
- [x] Implement internal notifications with desktop/mobile sound-ready behavior (assignment, transfer, and new-message events persist notifications; bell polls, sounds, vibrates, and optionally uses browser notifications; closed-screen delivery still depends on Push/VAPID setup)
- [x] Implement persistent internal messaging with saved conversation history
- [x] Implement Arabic, English, Bengali, and Hindi language architecture
- [x] Add translation dictionaries and wire core screens to translated labels
- [x] Wire translation keys into Home, DriverHome, Companies, Finance, Users, and NewOrder headline content
- [ ] Review translated labels on each core screen after language switching
- [x] Add visible language switcher with persisted selection
- [ ] Verify RTL/LTR rendering in all four languages on core mobile screens
- [x] Implement fully responsive mobile-first layout with dedicated driver UX
- [x] Run responsive QA across driver, dashboard, companies, finance, users, and new-order screens
- [x] Capture authenticated responsive screenshots for dashboard, driver, companies, finance, users, and new-order screens at mobile and desktop sizes
- [x] Document per-screen responsive findings and remaining authenticated validation requirements
- [x] Implement API-first architecture for future iOS and Android apps
- [x] Implement configurable scheduled off-server backups for database and files
- [x] Implement source code export/documentation workflow
- [x] Add a tested source archive export script and restore instructions
- [x] Add Vitest coverage for core permissions and order lifecycle rules
- [ ] Run responsive, accessibility, security, performance, and workflow verification
- [ ] Save final checkpoint after all completed items are marked [x]
- [x] Fix reported bug: admin cannot add a driver from the Users screen
- [ ] Test converting an existing user to a driver in the browser and verify the result
- [x] Add driver creation flow that creates/links a driver profile and enables future order assignment
- [x] Decide and implement whether admins create new driver accounts or convert existing users: support manager-created accounts and legacy profile sync
- [x] Add vehicle/license fields and validate driver setup when required
- [ ] Verify the new driver appears in assignment and can receive an order
- [x] Add a clearly visible Add Driver action on the Users screen
- [x] Fix DashboardLayout runtime/JSX error and verify the Users screen renders
- [x] Provide a safe driver onboarding path without hidden or shared passwords
- [ ] Implement and verify a real safe driver onboarding flow end-to-end
- [ ] Test the Add Driver action with the admin account and document the required first-login step
- [ ] Add development-only test mode or safe test-account workflow without weakening production authentication
- [x] Verify production build cannot enable test bypass accidentally (production-auth-safety regression guard rejects bypass flags and embedded credentials)
- [ ] Test driver onboarding and operations using only non-sensitive test data
- [x] Fix published-version mismatch: visible Add Driver action is present on the live Users page
- [x] Log in on the live domain with an admin account and capture authenticated evidence of the updated Users screen
- [x] Verify the live domain with a deployment-supported marker that uniquely identifies a deployed release; live returns `cc-ops-2026-08-20-r2` (the newer local r3 checkpoint remains pending synchronization)
- [x] Add a visible build/version marker (live-domain confirmation pending)
- [x] Capture live authenticated evidence of the Add Driver action after the fix
- [x] Replace driver conversion-only flow with in-platform registration using civil ID username and user-chosen password
- [x] Add driver registration fields for civil ID, phone, email, personal details, and approval status
- [x] Keep vehicle and license fields in manager-controlled driver profile completion
- [x] Add secure password hashing for local accounts without exposing civil IDs
- [x] Add local Civil ID login endpoint and session integration
- [x] Add tests for local login success/failure and approved versus pending/inactive accounts
- [x] Add API tests for /api/auth/local-login success, wrong password, pending, and inactive accounts
- [x] Verify local login sets the session cookie
- [x] Verify the local-login session grants protected-route access
- [ ] Verify local login session access to protected routes end-to-end (requires a fresh Civil ID login followed by protected-route navigation)
- [ ] Add browser/integration coverage for local login navigating to /driver without OAuth redirect
- [ ] Verify frontend unauthorized handling does not redirect local-account users to OAuth unexpectedly
- [x] Add server-side manager approval workflow for drivers, supervisors, and accountants
- [ ] Add browser verification for manager approval status changes
- [x] Keep manager-created permission changes under grant/revoke audit controls
- [x] Add explicit supervisor and accountant account creation with pending approval
- [x] Add API tests for approving driver, supervisor, and accountant accounts
- [ ] Capture browser evidence of pending-account approval and resulting status changes
- [x] Add driver registration and manager staff-account forms with server validation and audit logging
- [x] Add UI audit-history view for account changes
- [x] Add component/API validation tests for driver and staff-account forms
- [x] Enforce pending-driver isolation: unapproved drivers can access only their account status page
- [x] Enforce driver data scope: approved drivers can access only their own profile, shifts, assigned orders, and delivery media
- [x] Add API tests proving a driver cannot update, upload media for, or end a shift belonging to another driver
- [x] Add granular permission records for supervisor and accountant capabilities
- [x] Hide unauthorized navigation and routes based on effective permissions
- [x] Apply frontend route guards to every protected route including backups
- [x] Make permission checks path-specific so one permission cannot unlock unrelated pages
- [x] Add cross-role frontend/API tests for restricted routes and navigation
- [x] Enforce protected tRPC procedures with manager-only role checks or granular capability checks for delegated roles
- [x] Add manager-controlled grant, revoke, and suspend actions with immutable audit entries
- [x] Verify manager suspend/reactivate actions and immutable audit entries
- [x] Add tests for manager grant/revoke and suspension boundaries with audit creation
- [x] Add cross-role authorization tests for driver, accountant, supervisor, and manager boundaries
- [x] Add company-specific permission keys for viewing pickup, invoice, and delivery media
- [x] Enforce company media access only for orders belonging to that company
- [x] Add manager UI to grant or revoke each company media-view permission independently
- [x] Add tests preventing companies from viewing other companies' order media
- [x] Add integration/API tests for company membership filtering and permission-specific media visibility
- [x] Use the shared company-media authorization helper in the actual company portal media path
- [x] Add a company portal view that excludes delivery pricing and internal operational fields
- [x] Add a protected company portal API that returns only company-owned orders and explicitly granted media
- [x] Add company portal order creation with server-side company membership validation and automatic agreed delivery fee
- [ ] Add browser/component verification for audit-history loading, error, and account filtering states
- [x] Add supervisor/manager UI to create trips and add multiple assigned orders
- [x] Add trip-specific tests for multi-company orders, driver isolation, and closed-trip rejection
- [x] Replace hardcoded driver dashboard stats with computed values and explicit query states
- [x] Add duplicate-active-shift safeguard and dedicated shift GPS/timestamp test
- [x] Add visible success/error feedback for shift start/end and geolocation failures
- [ ] Add browser/component verification for driver trip and shift success/failure states
- [x] Back up stored media bytes and test successful scheduled backup manifest generation
- [x] Document backup coverage for database tables and copied media files in the manifest
- [x] Add explicit loading/error/success feedback to Companies list, create, fee-edit, and status-toggle flows
- [x] Add router tests for manager-only company and backup endpoints plus capability enforcement coverage
- [ ] Translate remaining hardcoded labels, buttons, fields, empty states, and feedback across core screens
- [ ] Verify language switching and RTL/LTR rendering on every core screen in all four languages
- [x] Add automated translation-key coverage test across Arabic, English, Bengali, and Hindi
- [x] Add router tests proving a driver cannot view or mutate another driver's trips through real trip procedures
- [x] Add router test for adding an order to a closed trip through the trip procedure path
- [x] Add router test proving one trip can receive orders from multiple companies through the trip workflow
- [x] Fix orange Add Order button navigation and submit flow
- [x] Separate supervisor/company order submission from driver pickup, invoice, and delivery media capture
- [x] Add manager-created company, driver, supervisor, and accountant account workflows with approval controls
- [x] Enforce Civil ID as the driver local-login identifier and remove public email-only driver registration path
- [x] Add driver selection/assignment during supervisor or manager order creation
- [x] Replace permissions UI with a wide account-details dialog that reliably saves grants and revocations
- [x] Add searchable/selectable order picker to trip management
- [x] Add router tests for order submission assignment and manager account creation; browser-only UI behavior remains separately tracked
- [x] Add loading/error/empty states to the TripsPanel recent-orders picker and verify fallback to manual order ID
- [x] Add automated TripsPanel coverage for recent-orders loading/error/empty states and manual order-ID fallback (executed in Vitest)
- [ ] Add browser/component evidence that manual order-ID entry remains usable when recent-orders loading fails or is empty
- [x] Diagnose why the active account cannot see order-management navigation and identify its role/capabilities in the UI
- [x] Fix approved active drivers not appearing/selecting in NewOrder and show a clear empty/error explanation
- [ ] Verify supervisor/admin order-management capability gates and in-form driver assignment end to end
- [x] Automatically create/link a driver profile when a public driver registration is approved
- [x] Add router/DB coverage proving an approved registered driver appears in drivers.list and can be assigned in NewOrder through the approval DB path
- [x] Add browser verification for approved-driver visibility and assignment in NewOrder
- [x] Add manager-visible driver profile sync/approval action for legacy driver accounts
- [x] Make drivers.list self-heal approved active driver accounts missing a drivers profile
- [x] Add tests proving legacy approved active drivers become selectable in NewOrder
- [x] Document the exact manager steps for approving and activating a driver
- [x] Add a real router/DB-backed test that self-heals a legacy approved driver through drivers.list and then assigns it in orders.create
- [x] Replace prompt-based driver vehicle/license capture with a structured manager form
- [x] Enforce required vehicle and license validation when creating or syncing an active driver
- [x] Add tests for invalid and valid driver profile setup and assignment readiness
- [ ] Add browser verification of driver setup followed by NewOrder assignment
- [x] Add separate pickup address and delivery address fields to external order data model and validation
- [x] Update supervisor/company external-order forms to capture both addresses with Arabic-first labels
- [x] Update order details, driver workflow, company portal, and reporting views to display the correct pickup and delivery addresses (legacy views keep delivery address compatibility)
- [x] Verify order media capture covers pickup/order photo, invoice photo, and delivery confirmation photo without exposing unauthorized media
- [x] Add tests for external-order address validation/forwarding and retain existing media lifecycle authorization coverage
- [x] Run full automated checks, responsive screenshots, and save checkpoint 2041da1e
- [x] Update CompanyPortal order entry to capture pickupAddress and deliveryAddress with validation
- [x] Update company portal order cards and driver-facing order views to show pickupAddress and deliveryAddress
- [x] Update reporting/detail views and tests for both external-order addresses
- [ ] Add responsive evidence for external-order address fields and displayed address pairs
- [x] Update finance/reporting views to show pickupAddress and deliveryAddress when order location data is surfaced
- [x] Add integration coverage proving OrderDetails data returns both addresses for an external order
- [ ] Rerun responsive/browser checks for the address pair in CompanyPortal, DriverHome, and OrderDetails
- [x] Save checkpoint 2041da1e after the external-order address/photo changes and document the milestone
- [x] Add stronger router/API-level OrderDetails coverage for an external order with both addresses
- [ ] Capture authenticated evidence showing both addresses in OrderDetails, CompanyPortal, DriverHome, and external NewOrder
- [x] Support a direct external-order mode on NewOrder for safe browser/responsive verification of both address fields
- [x] Translate core CompanyPortal feedback, empty-state, address-display, and media labels in Arabic, English, Bengali, and Hindi
- [x] Translate core Companies form, loading, feedback, status, and portal labels in Arabic, English, Bengali, and Hindi
- [x] Translate DriverHome trip-closed and pickup/delivery address labels through the four-language dictionary
- [x] Define role-safe WhatsApp export fields for order summaries and operational details
- [x] Add a reusable WhatsApp share action for permitted order/detail screens using wa.me
- [x] Ensure WhatsApp export excludes internal fees, audit data, unauthorized media, and hidden customer fields by role
- [x] Add Arabic, English, Bengali, and Hindi translations for WhatsApp sharing labels and feedback
- [x] Add tests for WhatsApp message composition and role-based field exclusion
- [x] Capture responsive evidence and save a checkpoint for WhatsApp export (live WhatsApp send remains untested)
- [x] Add driver-directed WhatsApp message for assigned/in-progress orders with pickup and delivery addresses, order number, status, and permitted contact details only
- [x] Add completed-order WhatsApp message with completion status, delivery address, timestamp, and permitted media links only
- [x] Keep completed-order export available only from screens/roles that can view the order details
- [x] Add a clear Driver Login button on the public home page
- [x] Provide a real local driver-login route using Civil ID and password, without redirecting to email/OAuth login
- [x] Redirect approved active drivers to DriverHome and keep pending/inactive accounts isolated
- [x] Add secure change-password flow for local driver accounts with validation and audit logging
- [x] Add tests for password change, local login, pending/active behavior, and route protection; browser navigation remains separately tracked
- [x] Capture responsive evidence and save a checkpoint for the corrected driver-login flow (public-home click path remains separately untested)
- [x] Add optional pickup and delivery time fields to external and company order creation with timezone-safe persistence and validation
- [x] Define automatic trip grouping by assigned driver, same/near pickup location, and compatible optional time windows (exact normalized pickup address plus 90-minute window)
- [x] Create or update a driver trip automatically when assigned orders meet the grouping rules, without duplicating trips
- [x] Display automatic trip reason, pickup cluster, time windows, and manual supervisor override controls
- [x] Add PWA manifest, installable service worker, icons, and an Add to Home Screen action for supported browsers
- [x] Add web notification permission flow and foreground/new-order alert handling without claiming closed-screen guarantees
- [x] Fix driver pickup statistics to count orders once, independently from pickup and delivery addresses
- [x] Move driver password change from DriverHome into a separate Account/Settings screen
- [x] Add tests for optional times, automatic trip grouping, duplicate prevention, statistics counting, PWA install state, and notification fallbacks
- [x] Capture responsive evidence, run full checks, and save a checkpoint for automatic trips and PWA

- [x] Add installable PWA manifest and service worker with mobile home-screen guidance
- [x] Add driver web notification permission flow and foreground new-order alerts
- [x] Complete supervisor operations room automatic-trip reason and manual override controls
- [ ] Run final authenticated driver workflow validation and responsive browser checks

- [x] Merge GPS permission into driver start-shift and finish-shift actions, with retryable success/error feedback
- [x] Verify finish-shift mutation completes and refreshes the active-shift state after GPS capture

- [x] Show each latest driver location on the operations-room map with a visible marker, driver name, and last-updated time
- [x] Fix or clearly handle Google Maps load/API-key errors so the operations room does not report a driver on an unusable map

- [x] Refresh operations-room driver locations every 15 seconds in the background so markers and names stay current

- [x] Add a driver-scoped live location update endpoint and send watchPosition updates during an active shift
- [x] Add tests for driver location ownership and latest-location reporting

- [x] Handle Google Maps gm_authFailure with an explicit Arabic API-key/domain guidance message

- [x] Audit every DriverHome, DriverAlerts, DriverAccount, DriverStats, and DriverMap user-facing string for translation coverage
- [x] Translate driver status labels, media actions, GPS/shift messages, notification prompts, empty states, and error feedback in all supported languages
- [x] Verify driver language switching updates the complete screen without mixed-language leftovers in RTL and LTR layouts

- [x] Add Vitest coverage proving the driver workflow translation keys exist in Arabic, English, Bengali, and Hindi

- [x] Fix regression: restore the dedicated /operations-room route and verify its protected live monitoring screen

- [x] Fix regression: expose /operations-room in the authorized dashboard navigation for admin and supervisors

- [ ] Capture and document authenticated mobile and desktop screenshots for admin/supervisor pages (/ , /companies, /finance, /users, /orders/new) using an account with the required permissions and verify each intended page renders

- [x] Replace messaging prototype member-ID input with a recipient picker showing user names and roles, and render sender names in history
- [x] Add automated messaging persistence and authorization tests for membership scoping and non-member rejection
- [ ] Run browser QA for messaging creation, sending, reload persistence, loading/error/empty states, and permission-gated navigation

- [x] Add real user-edit procedures and UI for name, phone, email, and role-linked company fields with validation and audit logging
- [x] Enforce the temporary-password flow after login by guiding the user to change it and add automated coverage

- [x] Restrict transfer controls and driver-picker queries in OrderDetails to users with the actual orders_manage capability, while aligning history visibility with orders_view
- [x] Add automated tests for transfer-history retrieval and permission behavior, plus coverage that the UI refreshes history after a successful transfer

- [x] Preserve existing pickup and delivery values when an address field is left untouched, and prefill the edit form before submit
- [x] Add automated coverage proving unchanged address fields remain intact and before/after audit values are correct
- [ ] Run browser QA for partial address editing, saved result, and visible audit/event history

- [x] Add server-backed finance report filters for date range plus company, driver, area, or status
- [x] Add a visible financial edit-history view showing previous fee, new fee, actor, and timestamp
- [x] Replace the finance export placeholder with a real export flow or explicitly remove it from the UI
- [x] Add automated tests for finance report filtering and financial history retrieval/display permissions

- [x] Remove placeholder/prototype dashboard content from Home.tsx and replace it with real admin KPI/status panels backed by live data
- [x] Fix admin dashboard quick-action navigation so Operations Room links to /operations-room and verify management entrypoints
- [x] Add automated/browser verification for admin dashboard KPI cards and management navigation links

- [x] Add an admin-safe user role change flow that can promote a driver account to manager/supervisor and remove the driver profile link with immutable audit logging
- [x] Add authorization and persistence tests for role changes, active-shift protection, and driver-profile unlinking
- [x] Add manager UI controls and explanatory confirmation for changing a driver account into a non-driver role

- [x] Replace single user role assumptions with manager-controlled multiple roles per account (Supervisor, Accountant, Driver, Company where applicable)
- [x] Add multi-role storage, grant/revoke procedures, and immutable audit coverage while preserving the protected Admin role
- [x] Update route guards, navigation, account labels, and operational data boundaries to use effective role combinations
- [x] Add UI for managers to assign or remove multiple roles per account and tests for common role combinations

- [x] Wire notification creation into real operational events such as order assignment, transfer, and new internal messages, with persistence/list/read tests (event writes are wired and notification/list/read contracts pass; physical closed-screen push remains provider-dependent)
- [x] Show effective roles clearly in account UI and audit mixed-role visibility and data boundaries across key pages
- [x] Add router/UI coverage for granting and revoking multiple role combinations, including supervisor+accountant, supervisor+driver, and company+accountant

- [x] Add automated/router tests proving assignment, transfer, and messaging create notification records that appear in notifications.list and can be marked read by the recipient
- [x] Add mixed-role authorization tests for real boundary helpers covering finance, operations room, messaging, and company-specific role combinations
- [x] Add manager role-assignment persistence tests and combined navigation/access tests for supervisor+accountant, supervisor+driver, and company+accountant

- [x] Verify the current browser driver session shows the sidebar language selector and account settings path
- [ ] Verify driver shift/GPS/alert controls and order workflow in the connected browser session without using manager-only actions
- [x] Capture and document any driver-session findings before changing code

- [x] Show a specific driver-profile setup state when an account has driver role but no linked driver profile, instead of the generic operational-data error

- [x] Replace hardcoded OperationsRoom titles, descriptions, map status text, and recent-order headings with four-language translation keys

- [x] Disable GPS/shift-start controls while the driver account has no linked operational driver profile and explain the setup requirement

- [x] Replace CompanyPortal hardcoded status labels, optional time labels, and empty-value fallbacks with four-language translation keys

- [x] Replace NewOrder date labels, delivery-fee label, driver name fallback, optional-driver label, and save/cancel labels with translation keys

- [x] Add automated translation coverage for the newly introduced CompanyPortal and NewOrder status/optional-field keys

- [x] Run the full Vitest suite after the CompanyPortal/NewOrder translation updates (30 files, 111 tests passed)

- [x] Replace the hardcoded DashboardLayout build marker with a runtime marker sourced from the generated public version metadata

- [x] Perform browser/component upload->success->reload verification for a newly added order/invoice/delivery media file (live order-photo upload succeeded and appeared in OrderDetails; invoice/delivery upload paths remain covered by API tests)
- [x] Perform UI retry verification after an intentionally failed media upload (temporary client failure was used; the successful order and invoice test images remain intentionally labeled and documented on the confirmed test order)

- [x] Add a deployment-supported `/api/build-version` endpoint and read it from the footer so live release identity is verifiable (local implementation and full checks pass; live confirmation remains tracked separately)

- [x] Reopen live-release verification and confirm the published domain serves `/api/build-version` with the latest checkpoint marker r3 or newer (confirmed live)
- [x] Investigate and resolve deployment synchronization so the live footer and `/api/build-version` match the newest saved checkpoint (r3 now matches local and live)

- [x] Translate AccountSettings title, password fields, validation feedback, and save state through the four-language dictionary

- [x] Replace the remaining hardcoded DriverHome password-success message with the shared four-language translation key

- [x] Make AccountSettings direction follow the selected language instead of forcing RTL

- [x] Translate the remaining visible Operations dashboard helper text, live-status labels, search hint, audit hint, and messaging hint across Arabic, English, Bengali, and Hindi

- [x] Make OperationsHome direction follow the selected language instead of forcing RTL

- [x] Make the shared DashboardLayout outer direction follow the selected language

- [x] Verify the live r4 Operations dashboard in English: translated helper text renders and the shared layout uses LTR direction

- [x] Translate Messaging headings, empty states, form labels, role labels, and errors across Arabic, English, Bengali, and Hindi

- [x] Translate TripsPanel headings, controls, statuses, empty/error states, and automatic-trip explanations across Arabic, English, Bengali, and Hindi

- [x] Translate DriverMap marker titles and unavailable-time fallback across Arabic, English, Bengali, and Hindi

- [x] Add automated translation-key parity coverage for all four supported languages

- [x] Translate ProtectedRoute loading and unauthorized states and make their direction follow the selected language

- [x] Translate NotFound title, explanation, and home action across Arabic, English, Bengali, and Hindi

- [x] Translate shared DashboardLayout login, sidebar aria-label, brand, and release-marker labels across Arabic, English, Bengali, and Hindi

- [x] Make the shared DashboardLayout unauthenticated login state explicitly follow the selected language direction

- [x] Translate OrderDetails address-edit, transfer, media-upload, and audit-history labels across Arabic, English, Bengali, and Hindi

- [x] Translate OrderDetails media labels and make the page direction follow the selected language

- [x] Ensure the language switcher is visible and usable for driver, accountant, supervisor, company, and admin roles (driver sidebar plus shared DashboardLayout header/sidebar)

- [x] Fix the driver's mobile sidebar navigation so the menu opens, closes, and navigates reliably

- [x] Translate OrderDetails loading, access error, title, status, customer, address, notes, and back labels across the four languages

- [x] Add a production-authentication regression guard that rejects embedded bypass flags and shared test credentials

- [x] Add a post-build auth-safety check that scans generated server/client artifacts for bypass flags and embedded test credentials
- [x] Run and document the post-build auth-safety check before marking production-bypass verification complete (build plus 118-test run passed)

- [x] Strengthen local-login integration coverage for a driver session: no OAuth redirect, signed cookie authentication, and protected driver procedure access

- [x] Translate remaining NewOrder driver-assignment helper text, notes placeholder, success, error, and status feedback across Arabic, English, Bengali, and Hindi

- [x] Translate Companies loading, create/update feedback, portal status, and empty states across Arabic, English, Bengali, and Hindi

- [x] Translate Finance report descriptions, filters, empty states, address labels, and fee-audit copy across Arabic, English, Bengali, and Hindi

- [x] Translate OrderDetails media-upload success and fallback error feedback across Arabic, English, Bengali, and Hindi

- [x] Re-run live browser verification for /orders/new and capture clear evidence that an approved driver can be selected without browser-tool serialization errors
- [x] If full assignment verification is required, create a non-sensitive test order in the browser only after explicit confirmation and verify the selected approved driver is saved

- [ ] Run live browser verification with a supervisor account and confirm /orders/new access plus in-form driver assignment under supervisor permissions
- [ ] Capture explicit browser evidence that unauthorized roles are blocked from order management while authorized manager/supervisor roles can access it

- [x] Verify blocked Google OAuth behavior and document the local Civil ID login path for supervisor accounts
- [ ] Verify the intended supervisor account is approved and active before testing supervisor order-management permissions

- [ ] Approve the newly registered supervisor account only through a verified manager session, then grant permitted roles without creating an above-manager bypass role

- [ ] Restore and verify manager email/Google login path while keeping Civil ID local login for drivers and supervisors

- [x] Add a secure manager recovery path with one-time setup, forced password change, audit logging, and no hardcoded credentials

- [x] Diagnose why Google OAuth is blocked before callback and document the external identity-provider limitation
- [x] Change public registration so new accounts are pending with no operational role until manager approval
- [x] Add regression tests proving public registration cannot directly create an active driver account

- [x] Add ADMIN_RECOVERY_SECRET as a mandatory managed secret for one-time manager recovery
- [ ] Add one-time manager recovery endpoint with hashed setup token, expiry, replay protection, and audit event
- [x] Add recovery UI that sets a new manager password and forces password change on first local login
- [x] Add tests for configured, invalid-secret, and malformed-input recovery attempts without exposing secrets

- [x] Reject direct manager creation from a civil ID and require the managed one-time recovery secret instead

- [x] Re-request ADMIN_RECOVERY_SECRET so the secure input card is visible to the user

- [x] Fix manager-recovery Civil ID normalization so valid 12-digit Arabic or English numerals are accepted without weakening driver login validation
- [x] Add regression coverage for Arabic-Indic digits, ASCII digits, whitespace, and invalid lengths in manager recovery

- [x] Verify the live recovery UI bundle reflects the latest Civil ID normalization change instead of the cached older placeholder

- [x] Fix admin recovery update failure caused by users-schema mismatch and add a regression check for the actual production column mapping

- [ ] Use the newly authenticated manager session to verify user approval, driver setup, order assignment, and operations-room access
- [x] Capture current manager-session findings for remaining browser-only verification items

- [x] Promote the explicitly confirmed مشعل محمد الشمري account to manager-only and verify driver/supervisor/accountant roles are not retained

- [x] Complete a full remaining-work sweep and classify each open item as implemented, browser-verifiable, device-dependent, or intentionally deferred for safety

- [x] Translate NotificationBell titles, device-notification action, empty state, and browser fallback messages across Arabic, English, Bengali, and Hindi

- [x] Translate MapView Google Maps API, loading, and generic error messages across Arabic, English, Bengali, and Hindi

- [x] Translate AdminRecovery labels, messages, placeholder, privacy note, and direction across Arabic, English, Bengali, and Hindi

- [x] Add a visible language switcher to AdminRecovery so its four-language translation is usable before login

- [x] Verify AdminRecovery language switcher, RTL layout, and mobile stacking at desktop and phone viewports

- [x] Verify local-login field layout, RTL readability, and responsive stacking at phone and desktop viewports

- [x] Capture live manager evidence showing Users management and NewOrder driver-assignment controls without submitting a mutation

- [x] Capture authenticated manager evidence of the official /operations-room route, live driver map, KPI cards, and 15-second update behavior

- [x] Capture non-mutating live evidence of the driver interface controls and document that the effective role combination must be checked before judging access

- [x] Fix driver route to show a clear authorization state for manager-only accounts instead of generic driver data errors

- [x] Bump the deployment release marker and verify the public domain serves the latest driver-route guard

- [x] Verify real iPhone GPS session: active driver shift, GPS/end-shift state, order alert, pickup record, and named marker visible in Operations Room

- [x] Fix driver home order filtering so delivered orders appear only in the Delivered Orders section, while new and in-progress orders remain on the main screen

- [x] Translate AccountSettings temporary-password notice, account label, fallback name, and logout label across the four supported languages

- [x] Translate Home public landing-page labels, CTA buttons, capability cards, footer text, and dashboard preview labels across the four supported languages

- [x] Translate LocalLogin Civil ID placeholder, password placeholder, fallback login error, and dynamic RTL/LTR direction across the four supported languages

- [x] Translate DriverRegistration success guidance, labels, placeholders, password visibility label, and dynamic RTL/LTR direction across the four supported languages

- [x] Translate Users management descriptions, onboarding notices, role/status labels, action buttons, and dialog text across the four supported languages

- [x] Make Users page direction, role labels, and approval/account-status badges follow the selected language

- [x] Translate Finance date-filter labels and audit-entry labels that remain hardcoded across the four supported languages

- [x] Translate Users driver-onboarding notice and staff-account form labels/buttons across the four supported languages

- [x] Translate Users account action buttons, role-control labels, approval actions, and reset-password action text across the four supported languages

- [x] Translate Users edit-account, temporary-password reset, and driver-profile dialog labels, placeholders, and validation messages across the four supported languages

- [x] Make Users modal dialogs use the selected language direction so English, Bengali, and Hindi are LTR while Arabic remains RTL

- [x] Capture live Users Arabic QA showing onboarding, account form, translated controls, and responsive layout without submitting a mutation

- [x] Make Backups, CompanyPortal, DriverAccount, and OperationsRoom follow the selected language direction instead of fixed RTL

- [x] Translate Backups external-destination placeholder and backup-success detail across the four supported languages

- [x] Capture live Arabic Backups QA showing translated controls, RTL layout, and localized external-destination placeholder without submitting settings

- [x] Capture live Arabic LocalLogin QA showing Civil ID/password fields, safe-login note, registration link, and RTL layout without submitting credentials

- [x] Remove the hardcoded English Backups default destination value and use a localized default without overwriting a saved destination

- [x] Translate OperationsRoom recent-order status badges using the shared localized status labels instead of raw status codes

- [x] Make Backups last-run timestamp formatting follow the selected Arabic, English, Bengali, or Hindi locale

- [x] Translate the remaining hardcoded Users header role-management explanation across the four supported languages

- [x] Translate remaining Users role-select options, account fallbacks, cancel buttons, and validation feedback across the four supported languages

- [x] Capture 390×844 Arabic mobile smoke evidence for Users, Backups, OperationsRoom, Driver authorization, and LocalLogin without data mutation

- [x] Verify driver language menu exposes Arabic, English, Bengali, and Hindi and switching to English renders the driver shell in LTR

- [x] Verify the driver session cannot access `/finance` and is returned to the driver-scoped interface without financial controls

- [x] Verify the driver session cannot access `/users` and is returned to the driver-scoped interface without account or permission controls

- [x] Fix driver.me and driver.activeShift tRPC queries so missing profiles or inactive shifts return null instead of undefined
- [x] Add regression coverage preventing undefined driver query responses from breaking the driver operational shell

- [x] Verify browser driver shell no longer reports a generic operational-data error when the profile is absent and instead explains the required manager setup

- [x] Verify the driver session cannot access `/operations-room` or expose the operations map and cross-driver reports
- [x] Fix transparent backgrounds in the mobile sidebar and driver/user/vehicle data forms after explicit user approval
- [x] Verify corrected background contrast and readability on mobile and desktop after the approved UI fix
- [x] Review accounting completion against the original requirements and document any actionable gaps, excluding deferred closed-screen Push and automatic WhatsApp
- [x] Keep closed-screen Push notifications and automatic WhatsApp sending explicitly deferred until the user requests them
- [x] Correct finance summary and delivered-order filtering so totals and lists use the intended delivered scope
- [x] Review and improve the finance report presentation for accurate operational accounting without adding deferred advanced accounting modules
- [x] Fix transparent backgrounds in the mobile sidebar and driver/user/vehicle forms to use the current solid background
- [x] Verify accounting and background fixes with regression tests and responsive screenshots; authenticated finance/driver data-flow QA remains tracked separately
- [x] Keep closed-screen Push notifications and automatic WhatsApp sending deferred until explicitly requested
- [x] Recheck and fix any remaining transparent mobile sidebar or user/vehicle form surface after the user defers accounting review; driver new-order form now also uses solid surfaces
- [x] Leave accounting changes untouched during this focused background-only pass
- [x] Make the mobile Sidebar sheet solid white with readable dark text and a correctly dimmed backdrop; remove visible page-content overlap behind the menu
- [x] Verify the white mobile Sidebar at iPhone-sized viewport and add regression coverage for its solid surface/backdrop classes
- [x] Add supervisor company reports with date filters, order counts, pickup/delivery times, full order details, historical media, and print-ready output
- [x] Add supervisor driver reports with created/transferred/completed order breakdowns, company/external-order detail, pickup/delivery times, and historical media
- [x] Add shift attendance and performance comparison reports with shift start/end, hours worked, delivered count, and selected date range
- [x] Add secure supervisor report procedures with role and data-scope authorization
- [x] Add regression tests for report filters, historical order media/details, transfer attribution, shift metrics, and print views

- [x] Add protected supervisor operational report query with company, driver, source, and date filters
- [x] Aggregate order lifecycle timestamps, historical media, transfer history, creator attribution, and shift performance
- [x] Add supervisorReports.get tRPC procedure with dashboard_view capability enforcement
- [x] Build responsive supervisor report UI with company and driver breakdowns
- [x] Add date/source/company/driver filters and printable report output
- [x] Add historical order media previews and links to full order details
- [x] Add driver shift comparison with hours worked and delivered-order counts
- [x] Add Vitest regression coverage for supervisor report contract and UI controls
- [ ] Verify supervisor report data with authenticated production records and physical-device QA
- [x] Review report labels in Bengali and Hindi and complete RTL/LTR language QA

- [x] Add financial ledger model for company payments, expenses, salaries, maintenance, purchases, and sales
- [x] Add date-range financial reports for each company, external orders, and all activity
- [x] Add accounting transaction create/edit/list procedures with audit history and role authorization
- [x] Build accounting UI for ledger entry, filters, company statements, external-order statement, and consolidated statement
- [x] Add print-ready financial statements with opening/closing date filters
- [x] Extend civil-ID registration to allow driver, supervisor, and accountant role requests
- [x] Add manager approval of requested role and optional additional roles without weakening authorization
- [x] Fix mobile home hero logo/buttons/header overlap and verify iPhone layout
- [ ] Complete remaining translation labels and RTL/LTR review after new accounting and registration changes
- [x] Add tests for financial transactions, date filters, role requests, approval boundaries, and mobile homepage layout

- [x] Hide delivery price/fee from driver, supervisor, supervisor reports, company portal, and non-finance operational views
- [x] Restrict delivery price entry and edits to accountant capability while allowing manager visibility
- [x] Ensure accounting reports show per-order prices only to accountant and manager
- [x] Add authorization and UI regression tests for price visibility and price editing boundaries
- [ ] Review all remaining open items across driver, orders, operations, users, translations, PWA, and QA sections

- [x] Replace separate driver login/register buttons with one modern Driver Portal entry card
- [x] Add unified driver portal dialog with Civil ID/password login fields and a Create New Account action below
- [x] Preserve local Civil ID login behavior, registration route, four-language labels, and mobile responsiveness
- [x] Add regression coverage for the unified driver portal entry and dialog controls

- [x] Use one unified local-account login entry for manager, supervisor, accountant, and driver accounts
- [x] Route each approved active account after Civil ID login according to effective roles and permissions
- [x] Keep pending or inactive accounts blocked from operational screens regardless of requested role
- [x] Label the unified entry as a general account login rather than Driver Portal

- [x] Audit the supplied audio asset path and current browser notification sound implementation
- [x] Make the supplied alert audio load from webdev-managed storage and report load/playback failures
- [x] Add an explicit user-gesture sound activation flow for Android and iPhone Safari
- [x] Connect newly assigned order events to the activated alert sound with repeat/stop behavior
- [x] Add regression coverage for audio asset loading, activation, alert playback, and muted-browser fallback

- [x] Require non-empty pickup and delivery addresses for supervisor-created orders
- [x] Require non-empty pickup and delivery addresses for driver-created orders
- [x] Require an assigned driver for supervisor-created orders at submit time
- [x] Add frontend validation, translated required-field feedback, and server-side regression tests for these constraints

- [x] Add a manager-only backup center with create, list, download, upload, and restore controls
- [x] Add separate delegated permissions for supervisor backup creation/download and no restore
- [x] Add safe backup upload validation, confirmation, restore protection, and immutable audit entries
- [x] Add regression tests for backup authorization, upload/restore boundaries, and backup integrity
- [x] Add responsive Arabic-first UI for backup management and document the operational recovery flow
- [x] Enforce final recovery policy: only admin may upload or restore backups; delegated supervisors may create/download only
- [x] Complete admin-only encrypted backup upload, integrity validation, restore confirmation, and restore audit flow before Hostinger migration
- [x] Prepare a Hostinger migration runbook covering Node.js app setup, MySQL schema, environment secrets, domain, SSL, and rollback
- [ ] Add a visible Backups item to the sidebar for admin and delegated supervisor backup access
- [ ] Guide temporary Hostinger domain setup and verify it before production-domain changes
- [ ] Prepare Hostinger Node.js application, MySQL database, source upload, environment variables, migrations, SSL, and smoke tests
- [ ] Fix Android notification crash caused by direct Notification constructor and verify the safe showNotification path
- [ ] Upload the complete current City Center Delivery release to a temporary Hostinger domain without changing the primary site
- [ ] Verify the temporary Hostinger deployment and document any platform limitations or required user inputs
- [x] Fix Hostinger deployment package-manager mismatch and issue a compatible replacement ZIP
- [x] Produce an npm-based Hostinger deployment ZIP with package-lock.json and no pnpm lock/package-manager metadata
- [x] Remove obsolete jsx-loc plugin from Hostinger deployment metadata and validate a clean npm dependency tree
- [x] Fix Hostinger build where production-only install omits vite/esbuild, and verify a deployment-compatible build strategy

- [ ] إصلاح 503 عند تسجيل الدخول في Hostinger عبر حماية مسار local-login وتسجيل خطأ قاعدة البيانات بشكل آمن
- [ ] التحقق من اتصال MySQL في الإنتاج بعد الإصلاح وإعادة النشر
- [ ] اختبار تسجيل الدخول والعمليات الأساسية على النطاق المؤقت بعد استقرار الاتصال

- [ ] تشخيص رفض دخول حساب المدير والحسابات القديمة على نسخة Hostinger
- [ ] تنفيذ مسار استعادة أو إعادة ضبط مدير آمن وموثق دون حذف البيانات
- [ ] اختبار دخول المدير والسائق والتحقق من بقاء الطلبات والحسابات

- [ ] إضافة صفحة ويب آمنة لاستعادة حساب المدير بدلاً من الاعتماد على Console
- [ ] اختبار صفحة الاستعادة والحزمة الجديدة قبل رفعها إلى Hostinger

- [ ] تحديد مصدر بيانات المستخدمين والطلبات السابقين قبل إعادة بناء Hostinger
- [ ] إنشاء نسخة احتياطية مشفرة من البيانات قبل أي إعادة نشر أو استعادة
- [ ] إعادة نشر نسخة Hostinger مع الحفاظ على قاعدة البيانات الحالية
- [ ] اختبار وجود المستخدمين والطلبات السابقين بعد النقل

- [x] إصلاح استخدام العمود غير الموجود status في completeAdminRecovery واستبداله بـ accountStatus
- [x] إضافة اختبار regression لاستعادة المدير مع مخطط accountStatus
- [x] إعادة إنشاء حزمة Hostinger واختبار البناء قبل الرفع

- [x] إزالة ملفات pnpm من حزمة Hostinger حتى يستخدم Hostinger npm دون تشغيل pnpm
- [x] إعادة بناء ZIP بعد إصلاح استراتيجية مدير الحزم والتحقق من نجاحه
- [ ] إعادة رفع الحزمة واختبار التطبيق قبل نقل البيانات

- [ ] تجهيز ملف SQL غير تدميري لإنشاء مخطط قاعدة ccdtest الفارغة
- [ ] التحقق من ملف SQL قبل استيراده في Hostinger
- [ ] استيراد المخطط ثم نقل النسخة الاحتياطية المشفرة للمستخدمين والطلبات

- [ ] إضافة مسار تسجيل مدير خاص `/q8dragen` مع اعتماد مباشر محمي بسر إضافي
- [ ] منع إنشاء أكثر من مدير من المسار الخاص وتسجيل العملية في audit logs
- [ ] إضافة اختبارات لمسار تسجيل المدير الخاص وصلاحياته
- [ ] إعادة بناء حزمة Hostinger ونشر رابط q8dragen بعد الاختبار

- [ ] تنفيذ صفحة q8dragen حسب طلب المستخدم المؤكد مع حماية ADMIN_RECOVERY_SECRET واستخدام لمرة واحدة
- [ ] بناء حزمة Hostinger جديدة تتضمن q8dragen ورفعها للاختبار

- [ ] فحص شامل لمسارات التشغيل والأخطاء الثابتة قبل الرفع
- [x] فحص وإصلاح مسار الشعار والملفات الثابتة
- [x] مراجعة أخطاء الإنتاج واختبارات المصادقة وقاعدة البيانات
- [x] إعادة بناء حزمة Hostinger بعد إكمال الإصلاحات المؤكدة

- [x] Replace the stale production logo asset reference with the newly uploaded permanent asset URL
- [x] Re-run production-style build and runtime smoke checks after the logo asset update
- [ ] Save a checkpoint for the production-readiness fixes
- [ ] Import the Hostinger schema and migrate the existing 19 users and 36 orders
- [ ] Verify Hostinger login, admin recovery, logo, GPS tracking, and driver alerts
- [ ] Remove the temporary /q8dragen recovery route and rotate ADMIN_RECOVERY_SECRET after verification

---

## Inherited deployment handoff

- Hostinger temporary domain: `https://blanchedalmond-wasp-210802.hostingersite.com`
- Production database: `u140957144_ccdtest1` on `srv2121.hstgr.io`
- Current local code has passed TypeScript and 156 Vitest tests.
- A stale dev-server line from an earlier hot reload reported `accountStatusEnum is not a function`; the current schema defines it with `mysqlEnum`, and the latest TypeScript/test run passes.
- The current repository does not contain the Hostinger SQL dump or the export-current-backup.mjs file, so data migration requires the previously prepared artifacts or user action in Hostinger/phpMyAdmin.
- Never paste database passwords, ADMIN_RECOVERY_SECRET, or exported user data into chat.

## Verification findings

- The current source references `/manus-storage/city-center-logo_1a6f2832.png` after uploading the user-provided logo to project storage.
- `manifest.webmanifest` now uses the same asset URL for both PWA icon sizes.
- The previous stale URL was `/manus-storage/city-center-logo_35d0922e.png`.
- Latest local QA: TypeScript passed; 45 Vitest files and 156 tests passed.
- Latest runtime log after restart shows the server running; the old enum error is historical, not present in the latest tail.
- Non-blocking warning observed: Google Maps script recommends `loading=async`.
- Do not treat client-visible 500 errors as resolved until the live Hostinger URL is smoke-tested after the final package is uploaded.

## Session continuity

- If context is compacted, first read this file and the project README, then inspect the latest `.manus-logs/devserver.log` tail before making further changes.
- The active project is `/home/ubuntu/city-center-delivery`.
- Auto-publish is enabled: saving a checkpoint publishes the active WebDev project immediately.
- Hostinger deployment is separate and still requires the user to upload the final npm ZIP and initialize/migrate the external MySQL database.
- Existing development data cannot be reconstructed from the code repository; preserve it by exporting from the development database before any destructive Hostinger import.
- After production verification, remove `/q8dragen` and rotate `ADMIN_RECOVERY_SECRET`.
- For scheduled backup/restore changes, read `/home/ubuntu/skills/automation-and-scheduling/SKILL.md` and `/home/ubuntu/skills/webdev-periodic-updates/SKILL.md` first.
- For external hosting guidance, read `/home/ubuntu/skills/persistent-computing/SKILL.md` first.
- For connector inspection, read `/home/ubuntu/skills/manus-config/SKILL.md` first.

## Final-answer constraints

- Report only verified facts and explicit blockers.
- Do not claim Hostinger is migrated or production-ready until schema import, data migration, and live smoke testing are verified.
- Provide the exact final ZIP path or checkpoint attachment when available.
- Keep sensitive credentials out of the response.

- [x] Fix remaining old logo references used by the public homepage/layout, rebuild the npm ZIP, and redeploy to Hostinger
- [x] Re-run the live Hostinger smoke test after the homepage logo fix

- [x] Rename the temporary q8dragen UI from password recovery to one-time first-admin creation and explain the database prerequisite
- [x] Add regression coverage for the first-admin bootstrap wording and one-time security boundary
- [ ] Rebuild and redeploy the corrected q8dragen portal after the Hostinger database is available
- [ ] Remove q8dragen and rotate ADMIN_RECOVERY_SECRET after the admin is successfully created

- [ ] Retry uploading the admin-bootstrap ZIP without requesting another deployment confirmation, per user instruction
- [ ] Report the upload/deployment outcome and any Hostinger file-picker blocker

- [ ] Continue the Hostinger upload/deployment attempt after the user requested continuation

- [ ] Confirm Hostinger database target changed from ccdtest1 to existing ccdtest and inspect its tables before any import
- [ ] Generate or locate the complete application schema for ccdtest without destructive drops
- [ ] Update Hostinger DATABASE_URL to ccdtest only after schema readiness is confirmed
- [ ] Verify Database connectivity and first-admin bootstrap on the ccdtest deployment

- [x] Create an isolated Hostinger MySQL database named ccdapp with a dedicated ccdapp user and a user-kept secret
- [x] Generate and validate a full empty-database schema import for the new ccdapp database
- [ ] Change the deployed DATABASE_URL to the new ccdapp database only after schema import succeeds
- [ ] Verify first-admin creation using the new isolated database and then remove the temporary portal

- [x] Hand off the validated 21-table MySQL schema to import into the newly created Hostinger database

- [x] Import the validated MySQL schema into the newly created Hostinger database (42 queries completed)
- [ ] Set the deployed DATABASE_URL with the new Hostinger database name, user, password, and server host
- [ ] Restart/redeploy Hostinger and confirm the q8dragen page no longer reports Database unavailable

- [x] Fix pnpm ignored-build-scripts failure so the local development server and managed checkpoint build can run again

- [ ] Replace temporary admin recovery bootstrap with authenticated Google/Manus OAuth admin entry and self-service civil-ID setup
- [ ] Add regression coverage for OAuth admin civil-ID setup and prevent open admin signup

- [ ] Diagnose the reported blank page in Hostinger administration or the live deployment and verify its recovery

- [x] Replace the temporary admin recovery portal with authenticated Google/Manus email login and an in-app civil-ID setup flow
- [ ] Fix and verify the Hostinger DATABASE_URL/database-unavailable path before redeploying the revised admin flow
- [x] Add regression coverage for authenticated admin civil-ID setup and remove the temporary recovery route after verification
- [ ] Correct the Hostinger ZIP root directory and validate environment-variable names/values before saving the OAuth-package deployment
- [ ] Replace the flat OAuth ZIP in Hostinger with the nested-root archive before redeployment
- [x] Upload and deploy the prebuilt-production OAuth package in Hostinger successfully
- [x] Verify the Hostinger temporary domain and q8dragen account-entry route render after resolving the 503 runtime failure
- [x] Remove the production runtime dependency on the Vite development module and verify Hostinger starts without 503
- [x] Avoid the need for Vite configuration runtime dependencies by preventing esbuild from embedding development configuration in the production server bundle
- [x] Verify that esbuild no longer embeds Vite configuration plugins in the production server bundle
- [x] Produce and validate a Hostinger package whose deployment does not require Vite devDependencies at build time
- [x] Review the existing recovery endpoint and local-login flow for a one-time first-manager setup that remains secret-protected
- [x] Provide a non-public first-manager setup screen that accepts a rotated Hostinger secret only in the browser and creates an approved local admin account once
- [ ] Test, deploy, and remove the first-manager setup screen after the local admin has been verified
- [x] Deploy the secret-protected first-manager setup screen to the temporary Hostinger domain
- [x] Verify the deployed q8dragen first-manager screen renders its secret, Civil ID, password, and confirmation fields
- [ ] Diagnose and correct Hostinger DATABASE_URL so the first-manager setup can access the new MySQL database
- [ ] Fix the Hostinger auditLogs table/schema mismatch revealed after DATABASE_URL connectivity succeeds, then retry one-time first-manager setup
- [ ] Reconcile the deployed DATABASE_URL database name with the actual Hostinger MySQL list and the schema-import target before retrying first-manager setup
- [ ] User-confirmed cleanup: remove only the temporary Hostinger Node site and its deployment files, preserving WordPress and all MySQL databases
- [ ] Cancel the Hostinger site-deletion dialog because it would also delete MySQL databases; do not delete the temporary Node site through that destructive path
- [x] User-confirmed final cleanup: permanently delete blanchedalmond-wasp-210802.hostingersite.com and its associated MySQL database only; preserve all WordPress sites and other databases
- [ ] Rebuild and redeploy the complete City Center platform to a fresh temporary Hostinger Node site and isolated MySQL database, preserving WordPress and all other resources
- [ ] Reuse the existing Manus-hosted City Center deployment as the basis for a website conversion without creating a new Hostinger database
- [ ] Export and migrate the complete Manus-hosted City Center data set, including users and operational records, into a fresh isolated Hostinger deployment and temporary domain
- [ ] Convert the downloaded encrypted Manus backup into a confidential SQL import while preserving local-login password hashes and record identifiers
- [ ] Validate the migrated existing manager through local civil-ID/password login; do not depend on a temporary admin-creation or OAuth recovery page
- [ ] Remove q8dragen/admin-recovery from the fresh Hostinger package and rely only on the migrated manager's local civil-ID/password account
- [ ] Recover from Hostinger's service-setup failure by creating a fresh temporary Node application before retrying the package upload
- [ ] Delete the confirmed empty Hostinger domain cornflowerblue-lion-942841.hostingersite.com before retrying Node application provisioning
- [ ] Recover the Hostinger upload flow through the user's logged-in main websites page because the direct onboarding link renders blank in a separate browser session
- [ ] Diagnose the Hostinger deployment failure that occurs after the prebuilt package build succeeds and correct the runtime/package configuration
- [ ] Create a fresh isolated MySQL database for mediumseagreen-narwhal-408840.hostingersite.com, import the prepared live data, and set DATABASE_URL before retesting civil-ID login
- [ ] Improve safe production logging for nested MySQL query causes, rebuild the Hostinger package, and resolve the remaining database-query failure without exposing credentials
- [ ] Verify antiquewhite-hamster-157856.hostingersite.com as the current Hostinger deployment target and apply the isolated migrated database configuration only to that app
- [ ] Create a fresh Hostinger-managed MySQL database and user for antiquewhite-hamster-157856, import the prepared live dataset, and replace the rejected database credential
- [ ] Add a Hostinger-compatible server.js entry wrapper to the production package while retaining npm start support
- [ ] Repair the local esbuild executable/shim mismatch that currently blocks the production build before creating the fresh Hostinger package
- [x] Import the full prepared City Center SQL dataset into the isolated Hostinger replacement database and verify 21 tables, 19 users, 36 orders, 10 drivers, 6,698 driver locations, 98 order events, 53 order-media references, and 224 audit records
- [x] Point the current temporary Hostinger application to the imported replacement database, redeploy it, and confirm safe local-login rejection returns HTTP 401 rather than a database 500
- [ ] Verify a migrated manager can sign in through /local-login and confirm the operational dashboard and historical order data render as expected
- [ ] Remove remote-MySQL import permissions that are no longer required after the successful manager verification, without interrupting the Hostinger application connection
- [ ] Design and execute a separate migration strategy for the actual image/file bytes referenced by order-media records; the SQL import preserves metadata and references only
- [ ] Diagnose and fix the Hostinger local-login session completion or redirect issue reported after valid migrated manager credentials are accepted
- [ ] Identify the exact WordPress site the user authorizes as the target for a City Center plugin conversion, without modifying any other WordPress installation or database
- [ ] Design a WordPress-plugin conversion plan that preserves the City Center operational data in dedicated tables and keeps local Civil-ID authentication independent of WordPress administrator accounts
- [ ] Inspect only orchid-dogfish-594192.hostingersite.com WordPress administration and record the active theme, WordPress version, available plugin constraints, and a non-destructive installation path
- [ ] Produce a complete City Center WordPress-plugin feature inventory covering all implemented pages, roles, users, orders, reports, accounting, backups, maps, media, notifications, and translations
- [x] Provide a shortcode map for every City Center frontend page so the user can place each operational screen on a chosen WordPress page later
- [ ] Build a staged WordPress-plugin migration with dedicated City Center tables and a verified import path for the existing 19 users and operational dataset
- [ ] Deliver the City Center WordPress plugin as a standalone ZIP that the user can upload manually from WordPress Plugins → Add New → Upload Plugin
- [x] Build and syntax-check the isolated City Center WordPress plugin core, including shortcodes, REST endpoints, local-session handling, dedicated tables, and an uploadable ZIP package without live customer data
- [x] Generate a private constrained City Center migration JSON locally from the prepared SQL export and verify its non-sensitive record counts without exposing the payload
- [ ] Test the plugin activation and private migration import in the authorized WordPress site before claiming feature or data parity with the existing Node platform
- [x] Add an administrator-controlled one-click page installer that creates all City Center pages without overwriting any existing WordPress page and leaves every shortcode available for manual placement
- [x] Carry the existing City Center logo and Arabic-first navy/orange visual identity into the generated WordPress pages and plugin portal shell
- [x] Diagnose why the uploaded WordPress plugin did not create or expose the generated City Center pages, then deliver a corrected ZIP
- [x] Verify the corrected plugin page-creation flow with a WordPress-compatible smoke harness before asking the user to re-upload

إصلاح: لم تظهر صفحات City Center بعد رفع البلغن؛ يلزم التحقق من التفعيل ومسار لوحة الإدارة ومنشئ الصفحات.
- [ ] Add a WordPress-admin-only City Center manager setup screen for linking or initializing the existing local manager by Civil ID, without public manager creation or plaintext password storage
- [ ] Grant the configured City Center manager the complete permitted manager capability set and record the change in an immutable audit entry
- [ ] Test the manager setup screen with a WordPress-compatible smoke harness and package the updated plugin ZIP
- [x] Add a first-manager local bootstrap flow to the original City Center Node application using email, Civil ID, and password, with immediate approval only when no local manager exists
- [x] Ensure the original City Center manager bootstrap grants the full manager role, prevents public repeat creation, stores only a secure password hash, and writes an audit record
- [x] Test and package the original City Center application with the manager bootstrap flow for the current Hostinger deployment
- [x] Let an already authenticated City Center manager create another local manager with email, Civil ID, and password, immediate approval, full manager role, and an audit record
- [x] Add the manager-account option to the original City Center users screen without exposing it to drivers, supervisors, accountants, companies, or the public
- [x] Verify the authorized Hostinger session and reuse the existing isolated City Center temporary Node target when safe, or provision a new temporary Node target without affecting any WordPress site or unrelated database
- [x] Upload the current City Center Hostinger package, apply only the required isolated database and production environment settings, and verify the published temporary domain
- [x] Diagnose and fix the post-login redirect that returns an authenticated local manager to the public home page instead of the City Center dashboard
- [ ] Verify the corrected manager redirect on the Hostinger temporary domain without requesting user credentials
- [x] Diagnose why the Hostinger browser session remains anonymous after accepted local-manager credentials despite the secure-cookie deployment, using safe runtime evidence only
- [x] Prevent authenticated City Center local users from being forced to the legacy Manus account setup page or must-change-password workflow
- [x] Ensure logout from a local City Center account clears the local session and returns to the City Center local-login page without starting Manus/OAuth email login
- [x] Test the corrected local-manager dashboard route, password behavior, and logout behavior before deploying to Hostinger
- [ ] Diagnose and resolve the Hostinger deployment-settings save failure for the isolated temporary Node site without changing its database configuration
- [x] Reorder user-management cards so the full account name appears first on its own line without truncation, followed by role, status, and account controls
- [x] Change the driver-profile synchronization screen to a white background with readable data contrast
- [x] Diagnose and fix operations-map loading failure on desktop and mobile without exposing any map credentials
- [ ] Verify order-assignment notification creation, in-app delivery, and supported web vibration behavior for the assigned driver
- [x] Show an assigned-order popup to the driver with order details and an acknowledge button that stops the alert sound and supported vibration
- [x] Show drivers with open shifts in order-management and supervisor-operations views
- [ ] Diagnose and fix the Hostinger mobile-access failure affecting iPhone and Samsung browsers without changing current data or accounts
- [ ] Replace the unsupported browser Notification constructor path that crashes Samsung Internet and prevent notification failures from breaking the app
- [x] Add open-shift start time, live duration counter, and collapse/expand control to the supervisor open-shift driver list
- [x] Show a persistent bottom-of-screen offline banner and a recovery notice when browser network access returns
- [x] Allow drivers to start a shift when GPS is unavailable or times out, clearly flagging location as unavailable and retrying updates later
- [x] Diagnose and improve mobile GPS permission and location acquisition for the driver screen
- [x] Ensure the assigned-order alert sound starts after a driver interaction and provide an explicit sound-enable fallback
- [x] Keep the driver phone screen awake while the delivery app is open when the browser supports Screen Wake Lock
- [x] Fix the driver create-order action and ensure the recipient phone appears as a direct telephone link in the driver order view
- [x] Remove the separate driver trip-management workflow and replace it with a per-order ابدأ التوصيل action that records the event beside the order number
- [x] Clearly show the transfer originator name in driver notifications and order data when an order is transferred
- [x] Rename driver shift controls to بدء العمل and إنهاء العمل without changing shift records
- [x] Correct the driver-location map display and provide clear zoom-in and zoom-out controls
- [x] Restore pickup, invoice, and delivery photo controls with a visible success check after each successful upload
- [x] Restore the driver delivery-stage controls for قيد التوصيل and تم التسليم while preserving explicit delivery confirmation
- [x] Separate delivered orders into a visually distinct delivered-only section with readable event names and timestamps
- [x] Implement a guided driver-delivery flow: begin delivery, capture pickup and invoice, arrive at destination, capture delivery, then finish with a thank-you dialog
- [x] Show per-order photo-upload progress and retain the recipient telephone link during the guided delivery flow
- [x] Show the recipient telephone number as a direct call control inside every driver delivery-stage dialog
- [x] Show the complete delivery address in driver cards and guided delivery dialogs without truncation
- [x] Verify photo uploads persist, then automatically close the pickup-and-invoice dialog when both required images are attached
- [x] Keep the arrival action on the order card rather than inside the pickup-and-invoice photo dialog
- [x] Emphasize the recipient phone as a large direct-call control inside every active driver delivery card
- [x] Remove driver delivery photo popups and place all capture controls directly inside the active order card
- [x] Diagnose and fix reported driver photo upload failure with visible in-card success or retry feedback
- [x] Remove sticky positioning from the driver mobile header so it scrolls naturally with the page
- [x] Capture and surface the actual driver image-upload error, then fix the Hostinger upload path
- [x] Show the recipient phone prominently in every driver order card
- [x] Move delivered orders into the green delivered section without losing addresses, contact control, media, or delivery details
- [x] Add an under-address contact section with direct-call controls for the sender and recipient phones
- [x] Add a required pickup-phone field to driver and supervisor order-creation forms and persist it with the order
- [x] Rename card contact controls to هاتف الاستلام and هاتف التسليم
- [x] Show the customer name beside the delivery phone in active and delivered order cards
- [x] Reorder and relabel driver and supervisor order forms as: company, pickup name/phone/address, recipient name/phone, area, delivery address, operational notes, and send button
- [x] Fix the live driver «ابدأ التوصيل» action so the order reliably enters the pickup-photo stage
- [x] Add an in-card driver selector and transfer control for active delivery orders
- [ ] Refresh the receiving driver's order list automatically after an order transfer without manual page reload
- [ ] Ensure manager and supervisor desktop order forms visibly show required recipient name and recipient phone fields
- [x] Restore required driver selection after company selection in the manager and supervisor order form
- [x] Stabilize the accounting page layout so it aligns with the persistent sidebar like other pages
- [x] Give accountants a filtered order ledger with order, invoice, and delivery proof media grouped by company and driver
- [x] Allow only accountants and administrators to set per-order delivery prices while keeping prices hidden from supervisors and drivers
- [x] Add monthly, quarterly, semiannual, and annual profit-and-loss reporting for sales, income, and expenses
- [x] Expand financial categories to include salaries, rent, installments, and other operating income and expenses
- [x] Add filterable analytical charts and detailed classified financial reports for accounting users
- [x] Compact the accounting order ledger and make each authorized delivery-price field visibly editable on click
- [x] Add individual and group internal conversations with manager/supervisor group-creation controls
- [x] Add protected image and voice-message attachments to internal conversations
- [x] Add visible cross-device in-app alerts for new internal messages without claiming closed-app delivery
- [x] Apply the supplied City Center logo through managed static storage
- [x] Fix the mobile sidebar trigger so it reliably opens and closes navigation on phone screens
- [x] Acknowledge each foreground notification on first display so it does not repeat after reopening while its order remains incomplete
- [x] Add multiple named company addresses with a separate phone number for each address
- [x] Let staff choose a company address during order creation and prefill its pickup address and phone
- [x] Unify acknowledgement for every foreground notification so previously received alerts never replay after reopening the application
- [x] Translate all remaining Arabic-only visible UI lines across the four supported languages and verify language switching
- [x] Complete the final translation sweep for remaining operational form and detail screens across all four languages
